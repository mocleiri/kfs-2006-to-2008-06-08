package org.apache.ojb.broker.transaction;

/**
 * Internal used tagging interface for transactional objects. 
 *
 * @author <a href="mailto:arminw@apache.org">Armin Waibel</a>
 * @version $Id: OJBTxObject.java,v 1.1 2004/05/03 23:05:56 arminw Exp $
 */
public interface OJBTxObject
{
}
