package org.apache.ojb.broker.transaction;

/**
 * Internal used tagging interface for transactional objects. 
 *
 * @author <a href="mailto:arminw@apache.org">Armin Waibel</a>
 * @version $Id: OJBTxObject.java,v 1.1 2007/08/24 22:17:39 ewestfal Exp $
 */
public interface OJBTxObject
{
}
