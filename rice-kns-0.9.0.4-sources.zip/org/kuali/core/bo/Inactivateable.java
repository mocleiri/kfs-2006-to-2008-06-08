/*
 * Copyright 2007 The Kuali Foundation.
 * 
 * Licensed under the Educational Community License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 * http://www.opensource.org/licenses/ecl1.php
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.kuali.core.bo;

/**
 * This interface is used to tag business objects as inactivateable, so that the framework will automatically handle special
 * processing related to active indicator, e.g. default active indicator to active on new or copy, have a show/hide inactive and
 * hide inactive by default for collections in maintenance documents, display active indicator in the search criteria and result set
 * for lookups and default the search criteria field to active
 */
public interface Inactivateable {
    
    /**
     * Indicates whether the record is active or inactive.
     */
    public boolean isActive();

    /**
     * Sets the record to active or inactive.
     */
    public void setActive(boolean active);
}
