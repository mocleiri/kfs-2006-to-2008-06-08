/*
 * Copyright 2005-2006 The Kuali Foundation.
 * 
 * 
 * Licensed under the Educational Community License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 * http://www.opensource.org/licenses/ecl1.php
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package edu.iu.uis.eden.clientapp.vo;

import java.io.Serializable;

import edu.iu.uis.eden.engine.node.RouteNodeInstance;

/**
 * Transport object representing a {@link RouteNodeInstance}.
 * 
 * @author Kuali Rice Team (kuali-rice@googlegroups.com)
 * 
 * @workflow.webservice-object
 */
public class RouteNodeInstanceVO implements Serializable {

    private static final long serialVersionUID = -5456548621231617447L;
    
    private Long routeNodeInstanceId;
    private Long documentId;
    private Long branchId;
    private Long routeNodeId;
    private Long processId;
    private String name;
    private boolean active;
    private boolean complete;
    private boolean initial;
    private StateVO[] state = new StateVO[0];
    private RouteNodeInstanceVO[] nextNodes = new RouteNodeInstanceVO[0];
    
    public boolean isActive() {
        return active;
    }
    public void setActive(boolean active) {
        this.active = active;
    }
    public Long getBranchId() {
        return branchId;
    }
    public void setBranchId(Long branchId) {
        this.branchId = branchId;
    }
    public boolean isComplete() {
        return complete;
    }
    public void setComplete(boolean complete) {
        this.complete = complete;
    }
    public Long getDocumentId() {
        return documentId;
    }
    public void setDocumentId(Long documentId) {
        this.documentId = documentId;
    }
    public boolean isInitial() {
        return initial;
    }
    public void setInitial(boolean initial) {
        this.initial = initial;
    }
    public Long getProcessId() {
        return processId;
    }
    public void setProcessId(Long processId) {
        this.processId = processId;
    }
    public String getName() {
        return name;
    }
    public void setName(String name) {
        this.name = name;
    }
    public Long getRouteNodeId() {
        return routeNodeId;
    }
    public void setRouteNodeId(Long routeNodeId) {
        this.routeNodeId = routeNodeId;
    }
    public Long getRouteNodeInstanceId() {
        return routeNodeInstanceId;
    }
    public void setRouteNodeInstanceId(Long routeNodeInstanceId) {
        this.routeNodeInstanceId = routeNodeInstanceId;
    }
    public StateVO[] getState() {
        return state;
    }
    public void setState(StateVO[] state) {
        this.state = state;
    }
    
    public StateVO getState(String key) {
        for (int index = 0; index < getState().length; index++) {
            StateVO nodeState = (StateVO) getState()[index];
            if (nodeState.getKey().equals(key)) {
                return nodeState;
            }
        }
        return null;
    }
    
    public RouteNodeInstanceVO[] getNextNodes() {
        return nextNodes;
    }
 
    public void setNextNodes(RouteNodeInstanceVO[] nextNodes) {
        this.nextNodes = nextNodes;
    }
}