package org.apache.ojb.tutorial5;

/* Copyright 2002-2004 The Apache Software Foundation
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

import java.util.Collection;

import javax.jdo.PersistenceManagerFactory;
import javax.jdo.PersistenceManager;
import javax.jdo.Query;

/**
 * Use case for editing a product.
 */
public class UCEditProduct extends AbstractUseCase
{
    /**
     * Creates a new edit use case instance.
     * 
     * @param factory The factory for getting persistence managers
     */
    public UCEditProduct(PersistenceManagerFactory factory)
    {
        super(factory);
    }

    /**
     * Returns a description of this use case.
     * 
     * @return A description of the use case
     */
    public String getDescription()
    {
        return "Edit a product entry";
    }

    /**
     * Performs this use case.
     */
    public void apply()
    {
    	// ask user which object should edited
        String             in      = readLineWithMessage("Edit Product with id:");
        int                id      = Integer.parseInt(in);
        PersistenceManager manager = null;

        try
        {
		    // We don't have a reference to the selected Product.
		    // So we have to look it up first,

			// 1. start transaction
			manager = factory.getPersistenceManager();          
            manager.currentTransaction().begin();

            // 2. Build a query to look up product by the id            
            Query query = manager.newQuery(Product.class, "id == " + id);     

            // 3. execute query  
            Collection result     = (Collection)query.execute();
            Product    toBeEdited = (Product)result.iterator().next();

            if (toBeEdited == null)
            {
            	System.out.println("did not find a matching instance...");
            	manager.currentTransaction().rollback();
            	return;	
            }

            // 4. edit the existing entry
            System.out.println("please edit the product entry");
            in = readLineWithMessage("enter name (was " + toBeEdited.getName() + "):");
            toBeEdited.setName(in);
            in = readLineWithMessage("enter price (was " + toBeEdited.getPrice() + "):");
            toBeEdited.setPrice(Double.parseDouble(in));
            in = readLineWithMessage("enter available stock (was "+ toBeEdited.getStock()+ "):");
            toBeEdited.setStock(Integer.parseInt(in));

            // 5. commit changes
            manager.currentTransaction().commit();
        }
        catch (Throwable t)
        {
            // rollback in case of errors
            manager.currentTransaction().rollback();
            t.printStackTrace();
        }
        finally 
        {
        	manager.close();	
        }
    }
}
