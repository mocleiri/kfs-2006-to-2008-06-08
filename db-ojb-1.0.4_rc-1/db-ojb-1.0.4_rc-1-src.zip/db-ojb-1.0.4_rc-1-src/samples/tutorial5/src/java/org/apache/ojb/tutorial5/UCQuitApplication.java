package org.apache.ojb.tutorial5;

/* Copyright 2002-2004 The Apache Software Foundation
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

import javax.jdo.PersistenceManagerFactory;

/**
 * Use case for quitting the application.
 */
public class UCQuitApplication extends AbstractUseCase
{
    /**
     * Creates a new quit use case instance.
     * 
     * @param factory The factory for getting persistence managers
     */
    public UCQuitApplication(PersistenceManagerFactory factory)
    {
        super(factory);
    }

    /**
     * Returns a description of this use case.
     * 
     * @return A description of the use case
     */
    public String getDescription()
    {
        return "Quit Application";
    }

    /**
     * Performs this use case.
     */
    public void apply()
    {
        // no OJB API for quitting the application ;-)
        System.out.println("bye...");
        System.exit(0);
    }
}
