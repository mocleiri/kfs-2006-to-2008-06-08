package org.apache.ojb.tutorial5;

/* Copyright 2002-2004 The Apache Software Foundation
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

import javax.jdo.PersistenceManager;
import javax.jdo.PersistenceManagerFactory;
import javax.jdo.Query;

import org.apache.ojb.broker.PersistenceBrokerFactory;

import java.util.Collection;
import java.util.Iterator;

/**
 * Use case for listing all products in the database.
 */
public class UCListAllProducts extends AbstractUseCase
{
    /**
     * Creates a new list-all use case instance.
     * 
     * @param factory The factory for getting persistence managers
     */
    public UCListAllProducts(PersistenceManagerFactory factory)
    {
        super(factory);
    }

    /**
     * Returns a description of this use case.
     * 
     * @return A description of the use case
     */
    public String getDescription()
    {
        return "List all product entries";
    }

    /**
     * Performs this use case.
     */
    public void apply()
    {
        System.out.println("The list of available products:");

        PersistenceManager manager = factory.getPersistenceManager();

        try
        {
        	// JDO does not like old instances...
        	PersistenceBrokerFactory.defaultPersistenceBroker().clearCache();

        	manager.currentTransaction().begin();

            Query      query       = manager.newQuery(Product.class);
            Collection allProducts = (Collection)query.execute(); 

            // now iterate over the result to print each product
            for (Iterator iter = allProducts.iterator(); iter.hasNext();)
            {
                System.out.println(iter.next());
            }
            manager.currentTransaction().commit();
        }
        catch (Throwable t)
        {
            t.printStackTrace();
        }
        finally
        {
        	manager.close();	
        }
    }
}
