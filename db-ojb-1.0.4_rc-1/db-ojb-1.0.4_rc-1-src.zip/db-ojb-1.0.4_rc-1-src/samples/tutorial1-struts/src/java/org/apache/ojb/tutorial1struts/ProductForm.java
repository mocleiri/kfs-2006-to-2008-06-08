package org.apache.ojb.tutorial1struts;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.struts.action.ActionErrors;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.action.ActionMessage;

/* Copyright 2002-2004 The Apache Software Foundation
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

/**
 * The struts form for editing a Product.
 */
public class ProductForm extends ActionForm
{
    /** The log instance for this form */
    private Log log = LogFactory.getLog(getClass());

    /**
     * The product id
     */
    private Integer id;

    /**
     * The Product name
     */
    protected String name;

    /**
     * The price per item
     */
    protected double price;

    /**
     * The stock of currently available items
     */
    protected int stock;

    /**
     * Returns the id
     * 
     * @return The id
     */
    public Integer getId()
    {
        return id;
    }

    /**
     * Returns the name of the product.
     * 
     * @return The name
     */
    public String getName()
    {
        return name;
    }

    /**
     * Returns the price of the product.
     * 
     * @return The price
     */
    public double getPrice()
    {
        return price;
    }

    /**
     * Returns the number of available items of this product.
     * 
     * @return The number of items in stock
     */
    public int getStock()
    {
        return stock;
    }

    /**
     * Sets the id of the product.
     * 
     * @param newId The new id
     */
    public void setId(Integer newId)
    {
        id = newId;
    }

    /**
     * Sets the name of the product.
     * 
     * @param newName The new name
     */
    public void setName(String newName)
    {
        name = newName;
    }

    /**
     * Sets the price of the product
     * 
     * @param newPrice The new price
     */
    public void setPrice(double newPrice)
    {
        price = newPrice;
    }

    /**
     * Sets the number of available items of this product.
     * 
     * @param newStock The number of available items 
     */
    public void setStock(int newStock)
    {
        stock = newStock;
    }

    /* (non-Javadoc)
     * @see org.apache.struts.action.ActionForm#validate(org.apache.struts.action.ActionMapping, javax.servlet.http.HttpServletRequest)
     */
    public ActionErrors validate(ActionMapping mapping, HttpServletRequest request)
    {
        if (log.isDebugEnabled())
        {
            log.debug("Validating the form");
        }

        ActionErrors errors = new ActionErrors();

        if ((name == null) || (name.length() == 0))
        {
            if (log.isErrorEnabled())
            {
                log.error("No name has been specified");
            }
            errors.add("name", new ActionMessage("productForm.name.notSpecified"));
        }
        if (price <= 0.0)
        {
            if (log.isErrorEnabled())
            {
                log.error("The specified price was not positive");
            }
            errors.add("price", new ActionMessage("productForm.price.notPositive"));
        }
        if (stock < 0)
        {
            if (log.isErrorEnabled())
            {
                log.error("The specified stock was negative");
            }
            errors.add("stock", new ActionMessage("productForm.price.negative"));
        }
        return errors;
    }
}