package org.apache.ojb.tutorial1struts;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.struts.action.Action;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

/**
 * Action that is executed first when a user accesses the web app.
 */
public class StartupAction extends Action implements WebappConstants
{
    /** The log instance for this action */
    private Log log = LogFactory.getLog(getClass());

    /**
     * Performs the action
     * 
     * @param mapping  The action mapping
     * @param form     The form if any
     * @param request  The request
     * @param response The response
     */
    public ActionForward execute(ActionMapping       mapping,
                                 ActionForm          form,
                                 HttpServletRequest  request,
                                 HttpServletResponse response) throws Exception
    {
        if (log.isDebugEnabled())
        {
            log.debug("Starting the webapp");
        }

        request.getSession().invalidate();

        // Now we're initializing OJB
        // We use a data source that already has username and password specified
        // so we're leaving them out
        new ProductDAO().initOJB(getDataSource(request, "default"), null, null);

        return mapping.findForward(FORWARD_NAME_TARGET);
    }

}
