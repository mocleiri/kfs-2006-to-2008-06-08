package org.apache.ojb.tutorial1struts;

/* Copyright 2002-2004 The Apache Software Foundation
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

import java.util.Collection;

import javax.sql.DataSource;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.ojb.broker.OJBRuntimeException;
import org.apache.ojb.broker.PersistenceBroker;
import org.apache.ojb.broker.PersistenceBrokerFactory;
import org.apache.ojb.broker.metadata.ConnectionRepository;
import org.apache.ojb.broker.metadata.JdbcConnectionDescriptor;
import org.apache.ojb.broker.metadata.MetadataManager;
import org.apache.ojb.broker.metadata.SequenceDescriptor;
import org.apache.ojb.broker.query.Query;
import org.apache.ojb.broker.query.QueryByCriteria;
import org.apache.ojb.broker.query.QueryByIdentity;
import org.apache.ojb.broker.util.sequence.SequenceManagerHighLowImpl;

/**
 * Contains all database functionality for working with {@link Product} objects. 
 */
public class ProductDAO
{
    /** The log instance for this DAO */
    private Log log = LogFactory.getLog(getClass());

    /**
     * Initializes OJB using the given datasource.
     * 
     * @param dataSource The data source
     * @param username   The user name (if required by the data source, otherwise use <code>null</code>)
     * @param password   The password (if required by the data source, otherwise use <code>null</code>)
     */
    public void initOJB(DataSource dataSource,
                        String     username,
                        String     password)
    {
        if (log.isDebugEnabled())
        {
            log.debug("Initializing OJB");
        }

        // This line effectively loads OJB.properties & repository.xml
        ConnectionRepository     connRep = MetadataManager.getInstance().connectionRepository();
        JdbcConnectionDescriptor jcd     = connRep.addDescriptor("default", dataSource, username, password);
        SequenceDescriptor       seqDesc = new SequenceDescriptor(jcd);

        seqDesc.setSequenceManagerClass(SequenceManagerHighLowImpl.class);
        jcd.setSequenceDescriptor(seqDesc);
    }

    /**
     * Retrieves all product objects from the database.
     * 
     * @return A collection of all products
     */
    public Collection getAllProducts()
    {
        if (log.isDebugEnabled())
        {
            log.debug("Retrieving all products");
        }

        // 1. build a query that select all objects of Class Product, without any further criteria
        Query             query  = new QueryByCriteria(Product.class, null);
        PersistenceBroker broker = null;
        Collection        result = null;

        try
        {
            // 2. create a broker and ask it to retrieve the Product collection
            broker = PersistenceBrokerFactory.defaultPersistenceBroker();
            // 3. start broker transaction
            broker.beginTransaction();
            // 4. retrieve the products
            result = broker.getCollectionByQuery(query);
            // 5. abort transaction (because we don't want to change anything)
            broker.abortTransaction();
        }
        finally
        {
            // 6. we should not hold onto the broker instance
            if (broker != null)
            {
                broker.close();
            }
        }
        if (log.isDebugEnabled())
        {
            log.debug("Found "+(result == null ? 0 : result.size())+" products");
        }
        return result;
    }

    /**
     * Retrieves from the database the product with the given id.
     * 
     * @param id The id of the product
     * @return The product or <code>null</code> if there is no product with this id
     */
    public Product getProduct(Integer id)
    {
        if (log.isDebugEnabled())
        {
            log.debug("Retrieving product with the id "+id);
        }

        // 1. build an example object with matching primary key values:
        Product example = new Product();
        Product result  = null;

        example.setId(id);

        // 2. build a QueryByIdentity from this sample instance:
        Query             query  = new QueryByIdentity(example);
        PersistenceBroker broker = null;

        try
        {
            // 3. get a broker and lookup the product specified by the QBE
            broker = PersistenceBrokerFactory.defaultPersistenceBroker();
            // 4. start broker transaction
            broker.beginTransaction();
            // 5. retrieve object
            result = (Product)broker.getObjectByQuery(query);
            // 6. abort transaction (because we don't want to change anything)
            broker.abortTransaction();
        }
        finally
        {
            // 7. we should not hold onto the broker instance
            if (broker != null)
            {
                broker.close();
            }
        }
        if (log.isDebugEnabled())
        {
            log.debug(result == null ? "Could not find the product" : "Found product "+result.getName());
        }
        return result;
    }

    /**
     * Stores the given product in the database.
     * 
     * @param product The product
     */
    public void storeProduct(Product product)
    {
        if (log.isDebugEnabled())
        {
            log.debug("Stroring product "+product);
        }

        PersistenceBroker broker = null;

        try
        {
            // 1. get a broker
            broker = PersistenceBrokerFactory.defaultPersistenceBroker();
            // 2. start broker transaction
            broker.beginTransaction();
            // 3. now ask broker to store the edited object
            broker.store(product);
            // 4. commit transaction
            broker.commitTransaction();
        }
        catch (OJBRuntimeException ex)
        {
            // rollback in case of errors
            if (broker != null)
            {
                broker.abortTransaction();
            }
            throw ex;
        }
        finally
        {
            // 5. we should not hold onto the broker instance
            if (broker != null)
            {
                broker.close();
            }
        }
    }

    /**
     * Deletes the product with the given id from the database.
     * 
     * @param id The id
     */
    public void deleteProduct(Integer id)
    {
        if (log.isDebugEnabled())
        {
            log.debug("Deleting product with id "+id);
        }

        // 1. build an example object with matching primary key values:
        Product example = new Product();

        example.setId(id);

        // 2. build a QueryByIdentity from this sample instance:
        Query             query  = new QueryByIdentity(example);
        PersistenceBroker broker = null;

        try
        {
            // 3. get a broker
            broker = PersistenceBrokerFactory.defaultPersistenceBroker();
            // 4. start broker transaction
            broker.beginTransaction();
            // 5. delete product
            broker.deleteByQuery(query);
            // 6. commit transaction
            broker.commitTransaction();
        }
        catch (OJBRuntimeException ex)
        {
            // rollback in case of errors
            if (broker != null)
            {
                broker.abortTransaction();
            }
            throw ex;
        }
        finally
        {
            // 7. We should not hold onto the broker instance
            if (broker != null)
            {
                broker.close();
            }
        }
    }
}
