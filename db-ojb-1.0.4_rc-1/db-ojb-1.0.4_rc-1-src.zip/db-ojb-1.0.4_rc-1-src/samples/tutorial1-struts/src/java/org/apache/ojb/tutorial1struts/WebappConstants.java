package org.apache.ojb.tutorial1struts;

/* Copyright 2002-2004 The Apache Software Foundation
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

/**
 * Constants for the tutorial webapp.
 */
public interface WebappConstants
{
    /** Name of the forward used for unconditional forwards */
    public static final String FORWARD_NAME_TARGET  = "target";
    /** Name of the forward used for the conditional forwards in case of success */
    public static final String FORWARD_NAME_SUCCESS = "success";
    /** Name of the forward used for the conditional forwards in case of failure */
    public static final String FORWARD_NAME_RELOAD  = "reload";

    /** Name of the parameter name for the products list */
    public static final String PARAMETER_PRODUCTS   = "products";
    /** Name of the parameter name for the product id */
    public static final String PARAMETER_PRODUCT_ID = "productId";
}
