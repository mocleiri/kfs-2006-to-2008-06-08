package org.apache.ojb.tutorials;

/* Copyright 2002-2004 The Apache Software Foundation
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

import org.odmg.DList;
import org.odmg.Database;
import org.odmg.Implementation;
import org.odmg.OQLQuery;
import org.odmg.Transaction;

import org.apache.ojb.odmg.OJB;
import org.apache.ojb.odmg.TransactionExt;

/**
 * ODMG API Usage Examples for the ODMG Tutorial
 */
public class ODMGExample
{
    /**
     * Stores the given product in the database.
     * 
     * @param product The product to store
     */
    public static void storeProduct(Product product)
    {
        Implementation impl = OJB.getInstance();
        Transaction    tx   = impl.newTransaction();

        tx.begin();
        tx.lock(product, Transaction.WRITE);
        tx.commit();
    }

    /**
     * Finds the product with the given name.
     * 
     * @param name The name of the product
     * @return The product if found
     */
    public static Product findProductByName(String name) throws Exception
    {
        Implementation impl = OJB.getInstance();
        Transaction    tx   = impl.newTransaction();

        tx.begin();

        OQLQuery query = impl.newOQLQuery();

        query.create("select products from " + Product.class.getName() + " where name = $1");
        query.bind(name);

        DList   results = (DList)query.execute();
        Product product = (Product)results.iterator().next();

        tx.commit();
        return product;
    }

    /**
     * Sells the given amount of products.
     * 
     * @param product The product to sell
     * @param number  The number of items to sell
     */
    public static void sellProduct(Product product, int number)
    {
        Implementation impl = OJB.getInstance();
        Transaction    tx   = impl.newTransaction();

        tx.begin();

        tx.lock(product, Transaction.WRITE);
        product.setStock(product.getStock() -  number);

        tx.commit();
    }

    /**
     * Deletes the given product from the database.
     * 
     * @param product The product to delete
     */
    public static void deleteProduct(Product product)
    {
        Implementation impl = OJB.getInstance();
        Transaction    tx = impl.newTransaction();

        tx.begin();

        Database db = impl.getDatabase(product);

        db.deletePersistent(product);

        tx.commit();
    }

    /**
     * Stores any changes to the product in the database.
     * 
     * @param product The product to update in the database
     */
    public static void persistChanges(Product product)
    {
        Implementation impl = OJB.getInstance();
        TransactionExt tx  = (TransactionExt)impl.newTransaction();

        tx.begin();
        tx.markDirty(product);
        tx.commit();
    }

    /**
     * The main entry point for this sample application.
     * 
     * @param args The commandline arguments
     */
    public static void main(String[] args) throws Exception
    {
        Implementation odmg = OJB.getInstance();
        Database       db   = odmg.newDatabase();

        db.open("default", Database.OPEN_READ_WRITE);

        Product product = new Product();

        product.setName("Widget");
        product.setPrice(9.99);
        product.setStock(11);

        storeProduct(product);

        Product same = findProductByName(product.getName());

        System.out.println(same.getId() + " = " + product.getId());

        sellProduct(same, 1);

        db.close();
    }
}
