package org.apache.ojb.servlet;

/* Copyright 2002-2004 The Apache Software Foundation
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.ojb.broker.PBFactoryException;
import org.apache.ojb.broker.PersistenceBroker;
import org.apache.ojb.broker.PersistenceBrokerFactory;
import org.apache.ojb.broker.query.Criteria;
import org.apache.ojb.broker.query.Query;
import org.apache.ojb.broker.query.QueryFactory;
import org.apache.ojb.tutorial1.Product;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Collection;
import java.util.Date;
import java.util.Iterator;

/**
 * A simple servlet looking up the Producs table and printing the results 
 * as an HTML table.
 */
public class TestServlet extends HttpServlet
{
    /**
     * Creates a new servlet instance.
     */
    public TestServlet()
    {
        super();
    }

    /*
     * @see javax.servlet.HttpServlet#doGet(HttpServletRequest, HttpServletResponse)
     */
    protected void doGet(HttpServletRequest req, HttpServletResponse response)
        throws ServletException, IOException
    {
        PersistenceBroker broker = null;

        try
        {
            broker = getBroker();
        }
        catch (Exception ex)
        {
            throw new IOException(ex.getMessage()); 
        }

        response.setContentType("text/html");
        
        PrintWriter writer = response.getWriter();

        writeHeader(writer);
      	writeTable(getProducts(broker), writer);
       	writeFooter(writer);

        broker.close();
    }

    /**
     * Writes the page header to the given writer.
     * 
     * @param writer The writer
     */
    protected void writeHeader(PrintWriter writer)
    {
        writer.println("<html><head><title>OJB sample servlet</title></head>");
      	writer.println("<body><h1>OJB sample servlet</h1>");
       	writer.println(new Date().toString());  
       	writer.println("<hr>");
    }
    
    /**
     * Writes the page footer to the given writer.
     * 
     * @param writer The writer
     */
    protected void writeFooter(PrintWriter writer)
    {
        writer.println("<hr>");
        writer.println("</body></html>");
    }
    
    /**
     * Writes a table containg the given products to the writer.
     * 
     * @param products The products to write
     * @param writer   The writer
     */
    protected void writeTable(Collection products, PrintWriter writer)
    {
        writer.println("<table border=\"1\">");
        writer.println("<tr><td><b>ID</b></td> <td><b>NAME</b></td> <td><b>PRICE</b></td> <td><b>STOCK</b></td></tr>");
        if (products != null)
        {
            for (Iterator it = products.iterator(); it.hasNext();)
            {
             	Product a = (Product)it.next();
    
                writer.println("<tr><td>" + a.getId() + "</td> <td>" + a.getName() + "</td> <td>" + a.getPrice()+ "</td> <td>" + a.getStock() + "</td></tr>");   
            }
        }
        writer.println("</table>");
        
    }

    /**
     * Retrieves the products to write.
     * 
     * @return The products
     */
    protected Collection getProducts(PersistenceBroker broker) throws IOException
    {
        Criteria   selectAll = null;
        Query      query     = QueryFactory.newQuery(Product.class, selectAll);

        return broker.getCollectionByQuery(query);
    }

    /**
     * Returns the persistence broker to use for database operations.
     * 
     * @return The persistence broker
     */
    protected PersistenceBroker getBroker() throws PBFactoryException
    {
     	return PersistenceBrokerFactory.defaultPersistenceBroker();
    }
}


