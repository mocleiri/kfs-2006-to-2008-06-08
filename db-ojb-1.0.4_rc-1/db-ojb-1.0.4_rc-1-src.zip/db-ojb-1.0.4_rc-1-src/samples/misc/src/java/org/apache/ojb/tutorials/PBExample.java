package org.apache.ojb.tutorials;

/* Copyright 2002-2004 The Apache Software Foundation
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

import java.util.Collection;

import org.apache.ojb.broker.PersistenceBroker;
import org.apache.ojb.broker.PersistenceBrokerException;
import org.apache.ojb.broker.PersistenceBrokerFactory;
import org.apache.ojb.broker.query.Criteria;
import org.apache.ojb.broker.query.QueryByCriteria;

/**
 * PB-api usage examples.
 *
 * @version $Id: PBExample.java,v 1.1.2.1 2005/01/11 22:15:00 tomdz Exp $
 */
public class PBExample
{
    /**
     * Stores a product in the database.
     * 
     * @param product The product to store
     */
    public static void storeProduct(Product product)
    {
        PersistenceBroker broker = null;

        try
        {
            broker = PersistenceBrokerFactory.defaultPersistenceBroker();

            broker.beginTransaction();
            broker.store(product);
            broker.commitTransaction();
        }
        catch (PersistenceBrokerException ex)
        {
            if (broker != null)
            {
                broker.abortTransaction();
            }
            ex.printStackTrace();
        }
        finally
        {
            if (broker != null)
            {
                broker.close();
            }
        }
    }

    /**
     * Stores products in the database.
     * 
     * @param products The products to store
     */
    public static void storeProducts(Product[] products)
    {
        PersistenceBroker broker = null;

        try
        {
            broker = PersistenceBrokerFactory.defaultPersistenceBroker();

            broker.beginTransaction();
            for (int idx = 0; idx < products.length; idx++)
            {
                broker.store(products[idx]);
            }
            broker.commitTransaction();
        }
        catch (PersistenceBrokerException ex)
        {
            if (broker != null)
            {
                broker.abortTransaction();
            }
            ex.printStackTrace();
        }
        finally
        {
            if (broker != null)
            {
                broker.close();
            }
        }
    }

    /**
     * Tries to find the product that is similar to the given one.
     * 
     * @param template The product whose equal shall be found
     * @return The found product if any
     */
    public static Product findByTemplate(Product template)
    {
        PersistenceBroker broker = null;
        Product           result = null;

        try
        {
            broker = PersistenceBrokerFactory.defaultPersistenceBroker();

            QueryByCriteria query = new QueryByCriteria(template);

            result = (Product)broker.getObjectByQuery(query);
        }
        finally
        {
            if (broker != null)
            {
                broker.close();
            }
        }
        return result;
    }

    /**
     * Returns all products that are not less expensive than 100000, and of which
     * there are at most 10 items in stock.
     * 
     * @return The products if products were found
     */
    public static Collection getExpensiveLowStockProducts()
    {
        PersistenceBroker broker  = null;
        Collection        results = null;

        try
        {
            broker = PersistenceBrokerFactory.defaultPersistenceBroker();

            Criteria criteria = new Criteria();

            criteria.addLessOrEqualThan("stock", new Integer(20));
            criteria.addGreaterOrEqualThan("price", new Double(100000.0));

            QueryByCriteria query = new QueryByCriteria(Product.class, criteria);

            results = broker.getCollectionByQuery(query);
        }
        catch (PersistenceBrokerException ex)
        {
            ex.printStackTrace();
        }
        finally
        {
            if (broker != null)
            {
                broker.close();
            }
        }
        return results;
    }

    /**
     * Sells one product (which decreases the stock for it).
     * 
     * @param template The product to sell
     * @return Whether the product was sold
     */
    public static boolean sellOneProduct(Product template)
    {
        PersistenceBroker broker = null;
        boolean           isSold = false;

        try
        {
            broker = PersistenceBrokerFactory.defaultPersistenceBroker();

            QueryByCriteria query  = new QueryByCriteria(template);
            Product         result = (Product)broker.getObjectByQuery(query);

            if (result != null)
            {
                broker.beginTransaction();
                result.setStock(result.getStock() - 1);

                broker.store(result);
                // alternative, more performant:
                // broker.store(result, ObjectModificationDefaultImpl.UPDATE);

                broker.commitTransaction();
                isSold = true;
            }
        }
        catch (PersistenceBrokerException ex)
        {
            if (broker != null)
            {
                broker.abortTransaction();
            }
            ex.printStackTrace();
        }
        finally
        {
            if (broker != null)
            {
                broker.close();
            }
        }
        return isSold;
    }

    /**
     * Tries to find the product that equals the given one, and deletes it.
     * 
     * @param template The product whose equal shall be deleted from the database
     * @return Whether the product was deleted
     */
    public static boolean findAndDeleteProduct(Product template)
    {
        PersistenceBroker broker    = null;
        boolean           isDeleted = false;

        try
        {
            broker = PersistenceBrokerFactory.defaultPersistenceBroker();

            QueryByCriteria query  = new QueryByCriteria(template);
            Product         result = (Product)broker.getObjectByQuery(query);

            if (result != null)
            {
                broker.beginTransaction();
                broker.delete(result);
                broker.commitTransaction();
                isDeleted = true;
            }
        }
        catch (PersistenceBrokerException ex)
        {
            if (broker != null)
            {
                broker.abortTransaction();
            }
            ex.printStackTrace();
        }
        finally
        {
            if (broker != null)
            {
                broker.close();
            }
        }
        return isDeleted;
    }

    /**
     * Deletes the given product from the database.
     * 
     * @param product The product to delete
     */
    public static void deleteProduct(Product product)
    {
        PersistenceBroker broker = null;

        try
        {
            broker = PersistenceBrokerFactory.defaultPersistenceBroker();

            broker.beginTransaction();
            broker.delete(product);
            broker.commitTransaction();
        }
        catch (PersistenceBrokerException ex)
        {
            if (broker != null)
            {
                broker.abortTransaction();
            }
            ex.printStackTrace();
        }
        finally
        {
            if (broker != null)
            {
                broker.close();
            }
        }
    }

    /**
     * Main entry point for this sample program.
     * 
     * @param args The commandline arguments
     */
    public static void main(String[] args)
    {
        Product product = new Product();

        product.setName("Sprocket");
        product.setPrice(1.99);
        product.setStock(10);

        System.out.println("1a. Store product: " + product);

        storeProduct(product);

        System.out.println("1b. Product stored: " + product);
        System.out.println();

        Product template = new Product();

        template.setName("Sprocket");

        System.out.println("2a. Find product by template, used template: " + template);

        Product aProduct = findByTemplate(template);

        System.out.println("2b. Found product: " + aProduct);
        System.out.println();

        System.out.println("3a. Sell one product, stock before was " + aProduct.getStock());

        sellOneProduct(template);
        aProduct = findByTemplate(template);

        System.out.println("3b. Product sold, current stock is " + aProduct.getStock());
        System.out.println();

        System.out.println("4a. Delete a product object");

        deleteProduct(aProduct);

        System.out.println("4b. Product deleted");
        System.out.println("4c. Try to lookup deleted product");

        Product newProduct = findByTemplate(aProduct);

        System.out.println("4d. Found product: " + newProduct);

        System.exit(0);
    }
}
