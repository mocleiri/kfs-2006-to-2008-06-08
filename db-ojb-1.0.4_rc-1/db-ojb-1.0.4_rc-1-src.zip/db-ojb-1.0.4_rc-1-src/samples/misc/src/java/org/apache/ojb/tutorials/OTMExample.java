package org.apache.ojb.tutorials;

/* Copyright 2002-2004 The Apache Software Foundation
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

import org.odmg.OQLQuery;
import org.odmg.QueryInvalidException;
import org.odmg.QueryParameterTypeInvalidException;
import org.odmg.QueryParameterCountInvalidException;

import org.apache.ojb.broker.PersistenceBrokerFactory;
import org.apache.ojb.broker.query.Query;
import org.apache.ojb.broker.query.QueryFactory;
import org.apache.ojb.otm.OTMConnection;
import org.apache.ojb.otm.OTMKit;
import org.apache.ojb.otm.core.Transaction;
import org.apache.ojb.otm.kit.SimpleKit;
import org.apache.ojb.otm.lock.LockingException;
import org.apache.ojb.otm.lock.LockType;

import java.util.Iterator;

/**
 * OTM api usage examples.
 */
public class OTMExample
{
    /**
     * Stores the given product in the database.
     * 
     * @param product The product to store
     */
    public static void storeProduct(Product product) throws LockingException
    {
        OTMKit        kit  = SimpleKit.getInstance();
        OTMConnection conn = null;
        Transaction   tx   = null;

        try
        {
            conn = kit.acquireConnection(PersistenceBrokerFactory.getDefaultKey());
            tx   = kit.getTransaction(conn);

            tx.begin();

            conn.makePersistent(product);

            tx.commit();
        }
        catch (LockingException ex)
        {
            if (tx.isInProgress())
            {
                tx.rollback();
            }
            throw ex;
        }
        finally
        {
            conn.close();
        }
    }

    /**
     * Removes the given product from the database.
     * 
     * @param product The product to remove
     */
    public static void removeProduct(Product product) throws LockingException
    {
        OTMKit        kit  = SimpleKit.getInstance();
        OTMConnection conn = null;
        Transaction   tx   = null;

        try
        {
            conn = kit.acquireConnection(PersistenceBrokerFactory.getDefaultKey());
            tx   = kit.getTransaction(conn);

            tx.begin();

            conn.deletePersistent(product);

            tx.commit();
        }
        catch (LockingException ex)
        {
            if (tx.isInProgress())
            {
                tx.rollback();
            }
            throw ex;
        }
        finally
        {
            conn.close();
        }
    }

    /**
     * Returns an iterator of all objects that were found by the given query.
     * 
     * @param query The query to perform
     * @return The iterator
     */
    public Iterator findByCriteria(Query query)
    {
        OTMKit        kit  = SimpleKit.getInstance();
        OTMConnection conn = null;
        Transaction   tx   = null;
        try
        {
            conn = kit.acquireConnection(PersistenceBrokerFactory.getDefaultKey());
            tx   = kit.getTransaction(conn);

            tx.begin();

            Iterator results = conn.getIteratorByQuery(query);

            tx.commit();

            return results;
        }
        finally
        {
            conn.close();
        }
    }

    /**
     * Returns an iterator of all objects that were found by the given query.
     * 
     * @param query The query to perform
     * @param lock  The type of lock to be applied to the objects
     * @return The iterator
     */
    public Iterator findByCriteriaWithLock(Query query, int lock)
    {
        OTMKit        kit  = SimpleKit.getInstance();
        OTMConnection conn = null;
        Transaction   tx   = null;
        try
        {
            conn = kit.acquireConnection(PersistenceBrokerFactory.getDefaultKey());
            tx   = kit.getTransaction(conn);

            tx.begin();

            Iterator results = conn.getIteratorByQuery(query, lock);

            tx.commit();

            return results;
        }
        finally
        {
            conn.close();
        }
    }

    /**
     * Returns an iterator of all objects that were found by the given OQL query.
     * 
     * @param query       The OQL query to perform
     * @param queryParams Parameter values for the query
     * @return The iterator
     */
    public Iterator findByOQL(String query, Object[] queryParams) throws Exception
    {
        OTMKit        kit  = SimpleKit.getInstance();
        OTMConnection conn = null;
        Transaction   tx   = null;

        try
        {
            conn = kit.acquireConnection(PersistenceBrokerFactory.getDefaultKey());
            tx   = kit.getTransaction(conn);

            OQLQuery oql = conn.newOQLQuery();

            oql.create(query);

            if (queryParams != null)
            {
                for (int idx = 0; idx < queryParams.length; ++idx)
                {
                    oql.bind(queryParams[idx]);
                }
            }

            tx.begin();

            Iterator results = conn.getIteratorByOQLQuery(oql);

            tx.commit();

            return results;
        }
        catch (QueryInvalidException ex)
        {
            if (tx.isInProgress())
            {
                tx.rollback();
            }
            throw new Exception("Invalid OQl expression given");
        }
        catch (QueryParameterCountInvalidException ex)
        {
            if (tx.isInProgress())
            {
                tx.rollback();
            }
            throw new Exception("Incorrect number of bindings given");
        }
        catch (QueryParameterTypeInvalidException ex)
        {
            if (tx.isInProgress())
            {
                tx.rollback();
            }
            throw new Exception("Incorrect type of object given as binding");
        }
        finally
        {
            conn.close();
        }
    }

    /**
     * Returns an iterator of all objects that were found by the given query.
     * 
     * @param query The query to perform
     * @param lock  The type of lock to be applied to the objects
     * @return The iterator
     */
    public Iterator moreRealisticQueryByCriteria(Query query, int lock)
    {
        OTMKit        kit  = SimpleKit.getInstance();
        OTMConnection conn = null;
        Transaction   tx   = null;
        try
        {
            conn = kit.acquireConnection(PersistenceBrokerFactory.getDefaultKey());
            tx   = kit.getTransaction(conn);

            boolean auto = !tx.isInProgress();

            if (auto)
            {
                tx.begin();
            }

            Iterator results = conn.getIteratorByQuery(query, lock);

            if (auto)
            {
                tx.commit();
            }

            return results;
        }
        finally
        {
            conn.close();
        }
    }

    /**
     * Sample method that renames all product with a specific name.
     */
    public void renameWidgetExample()
    {
        OTMKit        kit  = SimpleKit.getInstance();
        OTMConnection conn = null;
        Transaction   tx   = null;

        try
        {
            conn = kit.acquireConnection(PersistenceBrokerFactory.getDefaultKey());
            tx   = kit.getTransaction(conn);

            tx.begin();

            Product sample = new Product();

            sample.setName("Wonder Widget");

            Query    query         = QueryFactory.newQueryByExample(sample);
            Iterator wonderWidgets = moreRealisticQueryByCriteria(query, LockType.WRITE_LOCK);

            while (wonderWidgets.hasNext())
            {
                Product widget = (Product)wonderWidgets.next();

                widget.setName("Improved Wonder Widget");
            }

            tx.commit();
        }
        finally
        {
            conn.close();
        }
    }
}
