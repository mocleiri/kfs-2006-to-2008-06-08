package org.apache.ojb.tutorial2;

/* Copyright 2002-2004 The Apache Software Foundation
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

import java.util.List;

import org.odmg.Implementation;
import org.odmg.Transaction;
import org.odmg.OQLQuery;

/**
 * Use case for editing a product.
 */
public class UCEditProduct extends AbstractUseCase
{
    /**
     * Creates a new edit use case instance.
     * 
     * @param odmg The odmg implementation to use
     */
    public UCEditProduct(Implementation odmg)
    {
        super(odmg);
    }

    /**
     * Returns a description of this use case.
     * 
     * @return A description of the use case
     */
    public String getDescription()
    {
        return "Edit a product entry";
    }

    /**
     * Performs this use case.
     */
    public void apply()
    {
        String in = readLineWithMessage("Edit Product with id:");
        int    id = Integer.parseInt(in);

        // We don't have a reference to the selected Product.
        // So first we have to lookup the object.

        // 1. build oql query to select product by id:
        String      oqlQuery = "select del from " + Product.class.getName() + " where id = " + id;
        Transaction tx       = null;

        try
        {
            // 2. start transaction
            tx = odmg.newTransaction();
            tx.begin();

            // 3. lookup the product specified by query
            OQLQuery query = odmg.newOQLQuery();

            query.create(oqlQuery);

            List   result     = (List)query.execute();
            Product toBeEdited = (Product)result.get(0);

            // 4. lock the product for write access
            tx.lock(toBeEdited, Transaction.WRITE);

            // 5. Edit the product entry
            System.out.println("please edit existing product");
            in = readLineWithMessage("enter name (was " + toBeEdited.getName() + "):");
            toBeEdited.setName(in);
            in = readLineWithMessage("enter price (was " + toBeEdited.getPrice() + "):");
            toBeEdited.setPrice(Double.parseDouble(in));
            in = readLineWithMessage("enter available stock (was " + toBeEdited.getStock() + "):");
            toBeEdited.setStock(Integer.parseInt(in));

            // 6. commit transaction
            tx.commit();
        }
        catch (Throwable t)
        {
            // rollback in case of errors
            tx.abort();
            t.printStackTrace();
        }
    }
}
