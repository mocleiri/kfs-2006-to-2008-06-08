package org.apache.ojb.tutorial2;

/* Copyright 2002-2004 The Apache Software Foundation
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

import java.util.Iterator;
import java.util.List;

import org.odmg.Implementation;
import org.odmg.OQLQuery;
import org.odmg.Transaction;

/**
 * Use case for listing all products in the database.
 */
public class UCListAllProducts extends AbstractUseCase
{
    /**
     * Creates a new list-all use case instance.
     * 
     * @param odmg The odmg implementation to use
     */
    public UCListAllProducts(Implementation odmg)
    {
        super(odmg);
    }

    /**
     * Returns a description of this use case.
     * 
     * @return A description of the use case
     */
    public String getDescription()
    {
        return "List all product entries";
    }

    /**
     * Performs this use case.
     */
    public void apply()
    {
        System.out.println("The list of available products:");

        try
        {
            // 1. open a transaction
            Transaction tx = odmg.newTransaction();

            tx.begin();

            // 2. get an OQLQuery object from the ODMG facade
            OQLQuery query = odmg.newOQLQuery();

            // 3. set the OQL select statement
            query.create("select allproducts from " + Product.class.getName());

            // 4. perform the query and store the result in a persistent Collection
            List allProducts = (List) query.execute();

            tx.commit();

            // 5. now iterate over the result to print each product
            for (Iterator iter = allProducts.iterator(); iter.hasNext();)
            {
                System.out.println(iter.next());
            }
        }
        catch (Throwable t)
        {
            t.printStackTrace();
        }
    }
}
