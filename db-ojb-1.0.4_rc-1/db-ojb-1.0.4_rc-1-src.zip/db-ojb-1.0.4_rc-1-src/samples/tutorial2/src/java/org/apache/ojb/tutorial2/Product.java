package org.apache.ojb.tutorial2;

/* Copyright 2002-2004 The Apache Software Foundation
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

/**
 * Represents product objects in the tutorial system
 * 
 * @ojb.class
 */
public class Product implements java.io.Serializable
{
    /**
     * Artificial primary key atribute
     * 
     * @ojb.field primarykey="true"
     *            autoincrement="ojb"
     */
    private Integer id;

    /**
     * Product name
     * 
     * @ojb.field length="100"
     */
    protected String name;

    /**
     * Price per item
     * 
     * @ojb.field
     */
    protected double price;

    /**
     * Stock of currently available items
     * 
     * @ojb.field
     */
    protected int stock;

    /**
     * Returns the id
     * 
     * @return The id
     */
    public int getId()
    {
        return id.intValue();
    }

    /**
     * Returns the name of the product.
     * 
     * @return The name
     */
    public String getName()
    {
        return name;
    }

    /**
     * Returns the price of the product.
     * 
     * @return The price
     */
    public double getPrice()
    {
        return price;
    }

    /**
     * Returns the number of available items of this product.
     * 
     * @return The number of items in stock
     */
    public int getStock()
    {
        return stock;
    }

    /**
     * Sets the id of the product.
     * 
     * @param newId The new id
     */
    public void setId(int newId)
    {
        id = new Integer(newId);
    }

    /**
     * Sets the name of the product.
     * 
     * @param newName The new name
     */
    public void setName(String newName)
    {
        name = newName;
    }

    /**
     * Sets the price of the product
     * 
     * @param newPrice The new price
     */
    public void setPrice(double newPrice)
    {
        price = newPrice;
    }

    /**
     * Sets the number of available items of this product.
     * 
     * @param newStock The number of available items 
     */
    public void setStock(int newStock)
    {
        stock = newStock;
    }

    /**
     * Returns a string representation of the product.
     * 
     * @return The string representation
     */
    public String toString()
    {
        return "[" + id + "] " + name + "\t\t\t price: " + price + "\t\t stock: " + stock;
    }
}
