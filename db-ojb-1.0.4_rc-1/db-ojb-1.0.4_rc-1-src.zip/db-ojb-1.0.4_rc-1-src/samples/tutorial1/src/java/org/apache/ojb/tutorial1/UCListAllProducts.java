package org.apache.ojb.tutorial1;

/* Copyright 2002-2004 The Apache Software Foundation
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

import org.apache.ojb.broker.PersistenceBroker;
import org.apache.ojb.broker.query.Query;
import org.apache.ojb.broker.query.QueryByCriteria;

import java.util.Collection;
import java.util.Iterator;

/**
 * Use case for listing all products in the database.
 */
public class UCListAllProducts extends AbstractUseCase
{
    /**
     * Creates a new list-all use case instance.
     * 
     * @param broker The broker to use for database operations
     */
    public UCListAllProducts(PersistenceBroker broker)
    {
        super(broker);
    }

    /**
     * Returns a description of this use case.
     * 
     * @return A description of the use case
     */
    public String getDescription()
    {
        return "List all product entries";
    }

    /**
     * Performs this use case.
     */
    public void apply()
    {
        System.out.println("The list of available products:");

        // 1. build a query that select all objects of Class Product, without any further criteria
        // according to ODMG the Collection containing all instances of a persistent class is called "Extent"
        Query query = new QueryByCriteria(Product.class, null);

        try
        {
            // 2. ask the broker to retrieve the Extent collection
            Collection allProducts = broker.getCollectionByQuery(query);

            // 3. now iterate over the result to print each product
            for (Iterator iter = allProducts.iterator(); iter.hasNext();)
            {
                System.out.println(iter.next());
            }
        }
        catch (Throwable t)
        {
            t.printStackTrace();
        }
    }
}
