package org.apache.ojb.tutorial1;

/* Copyright 2002-2004 The Apache Software Foundation
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

import org.apache.ojb.broker.PersistenceBroker;
import org.apache.ojb.broker.PersistenceBrokerFactory;
import org.apache.ojb.broker.util.ui.AsciiSplash;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.Vector;

/**
 * The tutorial application.
 */
public class Application
{
    /** The use cases */
    private Vector useCases;
    /** The broker to use for database operations */
    private PersistenceBroker broker;

    /**
     * Creates a new application object.
     */
    public Application()
    {
        broker = null;
        try
        {
            broker = PersistenceBrokerFactory.defaultPersistenceBroker();
        }
        catch (Throwable t)
        {
            t.printStackTrace();
        }

        useCases = new Vector();
        useCases.add(new UCListAllProducts(broker));
        useCases.add(new UCEnterNewProduct(broker));
        useCases.add(new UCEditProduct(broker));
        useCases.add(new UCDeleteProduct(broker));
        useCases.add(new UCQuitApplication(broker));
    }

    /**
     * Disply the available use cases.
     */
    public void displayUseCases()
    {
        System.out.println();
        for (int idx = 0; idx < useCases.size(); idx++)
        {
            System.out.println("[" + idx + "] " + ((UseCase)useCases.get(idx)).getDescription());
        }
    }

    /**
     * The main entry point of the tutorial application
     *
     * @param args The commandline arguments
     */
    public static void main(String[] args)
    {
        Application app = new Application();

        app.run();
    }

    /**
     * Reads a single line from stdin and returns it.
     * 
     * @return The user's intput
     */
    private String readLine()
    {
        try
        {
            BufferedReader rin = new BufferedReader(new InputStreamReader(System.in));

            return rin.readLine();
        }
        catch (Exception e)
        {
            return "";
        }
    }

    /**
     * The application's main loop.
     */
    public void run()
    {    	
    	System.out.println(AsciiSplash.getSplashArt());
        System.out.println("Welcome to the OJB PB tutorial application");
        System.out.println();

        // never stop (there is a special use case to quit the application)
        while (true)
        {
            try
            {
                // select a use case and perform it
                UseCase uc = selectUseCase();

                uc.apply();
            }
            catch (Throwable t)
            {
                broker.close();
                System.out.println(t.getMessage());
            }
        }
    }

    /**
     * Allows the user to select a use case.
     */
    public UseCase selectUseCase()
    {
        displayUseCases();
        System.out.println("type in number to select a use case");

        String in  = readLine();
        int    idx = Integer.parseInt(in);

        return (UseCase)useCases.get(idx);
    }
    

}
