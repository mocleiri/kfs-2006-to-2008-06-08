package org.apache.ojb.broker.cache;

import java.util.Properties;

import com.opensymphony.oscache.base.Cache;
import com.opensymphony.oscache.base.NeedsRefreshException;
import com.opensymphony.oscache.general.GeneralCacheAdministrator;
import org.apache.ojb.broker.Identity;
import org.apache.ojb.broker.PersistenceBroker;
import org.apache.ojb.broker.util.logging.Logger;
import org.apache.ojb.broker.util.logging.LoggerFactory;

/* Copyright 2002-2004 The Apache Software Foundation
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

/**
 * ObjectCache implementation to use OSCache. We use the extended caching interface
 * {@link ObjectCacheInternal} to allow usage of this implementation in
 * {@link ObjectCacheTwoLevelImpl}.
 */
public class ObjectCacheOSCacheImpl implements ObjectCacheInternal
{
    private Logger log = LoggerFactory.getLogger(ObjectCacheOSCacheImpl.class);
    private static GeneralCacheAdministrator admin = new GeneralCacheAdministrator();
    private static final int REFRESH_PERIOD = com.opensymphony.oscache.base.CacheEntry.INDEFINITE_EXPIRY;

    public ObjectCacheOSCacheImpl()
    {
    }

    public ObjectCacheOSCacheImpl(PersistenceBroker broker, Properties prop)
    {
    }

    public void cache(Identity oid, Object obj)
    {
        try
        {
            /*
            Actually, OSCache sends notifications (Events) only on flush
            events. The putInCache method do not flush the cache, so no event is sent.
            The ObjectCacheOSCacheInternalImpl should force OSCache to flush the entry
            in order to generate an event. This guarantee that other nodes always
            in sync with the DB.
            Alternative a non-indefinite refresh-period could be used in conjunction
            with optimistic-locking for persistent objects.
            */
            remove(oid);
            admin.putInCache(oid.toString(), obj);
        }
        catch(Exception e)
        {
            log.error("Error while try to cache object: " + oid, e);
        }
    }

    public void doInternalCache(Identity oid, Object obj, int type)
    {
        cache(oid, obj);
    }

    public boolean cacheIfNew(Identity oid, Object obj)
    {
        boolean result = false;
        Cache cache = admin.getCache();
        try
        {
            cache.getFromCache(oid.toString());
        }
        catch(NeedsRefreshException e)
        {
            try
            {
                cache.putInCache(oid.toString(), obj);
                result = true;
            }
            catch(Exception e1)
            {
                cache.cancelUpdate(oid.toString());
                log.error("Error while try to cache object: " + oid, e);
            }
        }
        return result;
    }

    public Object lookup(Identity oid)
    {
        Cache cache = admin.getCache();
        try
        {
            return cache.getFromCache(oid.toString(), REFRESH_PERIOD);
        }
        catch(NeedsRefreshException e)
        {
            // not found in cache
            if(log.isDebugEnabled()) log.debug("Not found in cache: " + oid);
            cache.cancelUpdate(oid.toString());
            return null;
        }
        catch(Exception e)
        {
            log.error("Unexpected error when lookup object from cache: " + oid, e);
            cache.cancelUpdate(oid.toString());
            return null;
        }
    }

    public void remove(Identity oid)
    {
        try
        {
            if(log.isDebugEnabled()) log.debug("Remove from cache: " + oid);
            admin.flushEntry(oid.toString());
        }
        catch(Exception e)
        {
            throw new RuntimeCacheException("Unexpected error when remove object from cache: " + oid, e);
        }
    }

    public void clear()
    {
        try
        {
            if(log.isDebugEnabled()) log.debug("Clear cache");
            admin.flushAll();
        }
        catch(Exception e)
        {
            throw new RuntimeCacheException("Unexpected error while clear cache", e);
        }
    }
}
