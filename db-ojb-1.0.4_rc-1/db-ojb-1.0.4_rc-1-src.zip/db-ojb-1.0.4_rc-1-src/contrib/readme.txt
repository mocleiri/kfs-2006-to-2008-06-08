===================================================================
contrib - The Contribution Directory
===================================================================
-------------------
db-ojb/contrib
-------------------
The 'db-ojb/contrib' directory contains documents, proposals
and tools relating to OJB.


-------------------
db-ojb/contrib/src
-------------------
Under 'db-ojb/contrib/src' you can find contribution classes and implementations,
extensions of OJB classes with e.g. non-distributable dependencies.