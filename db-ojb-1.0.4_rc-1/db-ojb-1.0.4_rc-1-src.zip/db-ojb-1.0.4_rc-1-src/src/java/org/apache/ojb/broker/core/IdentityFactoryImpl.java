package org.apache.ojb.broker.core;

import org.apache.ojb.broker.Identity;
import org.apache.ojb.broker.IdentityFactory;
import org.apache.ojb.broker.PersistenceBroker;
import org.apache.ojb.broker.PersistenceBrokerException;
import org.apache.ojb.broker.metadata.ClassDescriptor;
import org.apache.ojb.broker.metadata.FieldDescriptor;

/**
 * @see org.apache.ojb.broker.IdentityFactory
 * 
 * @author <a href="mailto:armin@codeAuLait.de">Armin Waibel</a>
 * @version $Id: IdentityFactoryImpl.java,v 1.2.2.2 2005/03/23 12:39:57 arminw Exp $
 */
public class IdentityFactoryImpl implements IdentityFactory
{
    private PersistenceBroker broker;

    public IdentityFactoryImpl(PersistenceBroker broker)
    {
        this.broker = broker;
    }

    /**
     * @see org.apache.ojb.broker.IdentityFactory#buildIdentity(java.lang.Object)
     */
    public Identity buildIdentity(Object obj)
    {
        return new Identity(obj, broker);
    }

    /**
     * @see org.apache.ojb.broker.IdentityFactory#buildIdentity(java.lang.Object)
     */
    public Identity buildIdentity(ClassDescriptor cld, Object obj)
    {
        return new Identity(obj, broker, cld);
    }

    /**
     * @see org.apache.ojb.broker.IdentityFactory#buildIdentity(java.lang.Class, java.lang.Class, java.lang.String[], java.lang.Object[])
     */
    public Identity buildIdentity(Class realClass, Class topLevelClass, String[] pkFieldNames, Object[] pkValues)
    {
        Object[] orderedPKValues = pkValues;
        if(pkValues == null)
        {
            throw new NullPointerException("Given primary key value array can't be null");
        }
        if(pkValues.length == 1 && (pkFieldNames == null || pkFieldNames.length == 1))
        {
            /*
            we assume only a single PK field is defined and do no further checks,
            we have nothing to do
            */
        }
        else
        {
            // in other more complex cases we do several check
            FieldDescriptor[] flds = broker.getClassDescriptor(realClass).getPkFields();
            if(!isOrdered(flds, pkFieldNames))
            {
                orderedPKValues = reorderPKValues(flds, pkFieldNames, pkValues);
            }
        }
        return new Identity(realClass, topLevelClass, orderedPKValues);
    }

    private Object[] reorderPKValues(FieldDescriptor[] flds, String[] pkFieldNames, Object[] pkValues)
    {
        String fieldName = null;
        Object[] orderedPKValues = new Object[flds.length];
        for (int i = 0; i < flds.length; i++)
        {
            fieldName = flds[i].getPersistentField().getName();
            int realPosition = findFieldName(pkFieldNames, fieldName);
            orderedPKValues[i] = pkValues[realPosition];
        }
        return orderedPKValues;
    }

    private int findFieldName(String[] fieldNames, String searchName)
    {
        for (int i = 0; i < fieldNames.length; i++)
        {
            if(searchName.equals(fieldNames[i]))
            {
                return i;
            }
        }
        throw new PersistenceBrokerException("Can't find field name '" + searchName +
                "' in given array of field names");
    }

    /**
     * Checks length and compare order of field names with declared PK fields in metadata.
     */
    private boolean isOrdered(FieldDescriptor[] flds, String[] pkFieldNames)
    {
        if((flds.length > 1 && pkFieldNames == null) || flds.length != pkFieldNames.length)
        {
            throw new PersistenceBrokerException("pkFieldName length does not match number of defined PK fields." +
                    " Expected number of PK fields is " + flds.length + ", given number was " +
                    (pkFieldNames != null ? pkFieldNames.length : 0));
        }
        boolean result = true;
        for (int i = 0; i < flds.length; i++)
        {
            FieldDescriptor fld = flds[i];
            result = result && fld.getPersistentField().getName().equals(pkFieldNames[i]);
        }
        return result;
    }

    /**
     * @see org.apache.ojb.broker.IdentityFactory#buildIdentity(java.lang.Class, java.lang.String[], java.lang.Object[])
     */
    public Identity buildIdentity(Class realClass, String[] pkFieldNames, Object[] pkValues)
    {
        return buildIdentity(realClass, broker.getTopLevelClass(realClass), pkFieldNames, pkValues);
    }

    /**
     * @see org.apache.ojb.broker.IdentityFactory#buildIdentity(java.lang.Class, java.lang.String[], java.lang.Object[])
     */
    public Identity buildIdentity(Class realClass, Class topLevelClass, Object[] pkValues)
    {
        return new Identity(realClass, topLevelClass, pkValues);
    }

    /**
     * @see org.apache.ojb.broker.IdentityFactory#buildIdentity(java.lang.Class, java.lang.Object)
     */
    public Identity buildIdentity(Class realClass, Object pkValue)
    {
        return buildIdentity(realClass, (String[]) null, new Object[]{pkValue});
    }
}
