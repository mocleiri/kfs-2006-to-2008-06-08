package org.apache.ojb.broker;

import java.util.Enumeration;

import org.apache.ojb.broker.accesslayer.RelationshipPrefetcherFactory;
import org.apache.ojb.broker.core.QueryReferenceBroker;
import org.apache.ojb.broker.core.proxy.ProxyFactory;
import org.apache.ojb.broker.metadata.ClassDescriptor;
import org.apache.ojb.broker.query.Query;

/* Copyright 2002-2004 The Apache Software Foundation
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

/**
 * Internal used extended version of {@link PersistenceBroker}
 *
 * @author <a href="mailto:arminw@apache.org">Armin Waibel</a>
 * @version $Id: PersistenceBrokerInternal.java,v 1.1.2.4 2005/08/09 20:03:20 aclute Exp $
 */
public interface PersistenceBrokerInternal extends PersistenceBroker
{
    /**
     * If <em>true</em> this instance is handled by a managed
     * environment - registered within a JTA transaction.
     */
    public boolean isManaged();

    /**
     * Set <em>true</em> if this instance is registered within a
     * JTA transaction. On {@link #close()} call this flag was reset
     * to <em>false</em> automatic.
     */
    public void setManaged(boolean managed);

    /**
     * Method which start the real store work (insert or update)
     * and is intended for use by top-level api or internal calls.
     *
     * @param obj The object to store.
     * @param oid The {@link Identity} of the object to store.
     * @param cld The {@link org.apache.ojb.broker.metadata.ClassDescriptor} of the object.
     * @param insert If <em>true</em> an insert operation will be performed, else update operation.
     * @param ignoreReferences With this flag the automatic storing/linking
     * of references can be suppressed (independent of the used auto-update setting in metadata),
     * except {@link org.apache.ojb.broker.metadata.SuperReferenceDescriptor}
     * these kind of reference (descriptor) will always be performed. If <em>true</em>
     * all "normal" referenced objects will be ignored, only the specified object is handled.
     */
    public void store(Object obj, Identity oid, ClassDescriptor cld,  boolean insert, boolean ignoreReferences);

    /**
     * Deletes the concrete representation of the specified object in the underlying
     * persistence system. This method is intended for use in top-level api or
     * by internal calls.
     *
     * @param obj The object to delete.
     * @param ignoreReferences With this flag the automatic deletion/unlinking
     * of references can be suppressed (independent of the used auto-delete setting in metadata),
     * except {@link org.apache.ojb.broker.metadata.SuperReferenceDescriptor}
     * these kind of reference (descriptor) will always be performed. If <em>true</em>
     * all "normal" referenced objects will be ignored, only the specified object is handled.
     * @throws PersistenceBrokerException
     */
    public void delete(Object obj, boolean ignoreReferences) throws PersistenceBrokerException;

    /**
     * Answer the ReferenceBroker.
     * @return QueryReferenceBroker
     */
    public QueryReferenceBroker getReferenceBroker();
    
    /**
     * Check if the references of the specified object have enabled
     * the <em>refresh</em> attribute and refresh the reference if set <em>true</em>.
     *
     * @throws PersistenceBrokerException if there is a error refreshing collections or references
     * @param obj The object to check.
     * @param oid The {@link Identity} of the object.
     * @param cld The {@link org.apache.ojb.broker.metadata.ClassDescriptor} of the object.
     */
    public void checkRefreshRelationships(Object obj, Identity oid, ClassDescriptor cld);

    /**
     * Return the relationship prefetcher factory.
     */
    public RelationshipPrefetcherFactory getRelationshipPrefetcherFactory();
    
    /**
     * Returns an Enumeration of PrimaryKey Objects for objects of class DataClass.
     * The Elements returned come from a SELECT ... WHERE Statement
     * that is defined by the fields and their coresponding values of vecFields
     * and vecValues.
     * Useful for EJB Finder Methods...
     * NOT YET AWARE OF EXTENTS !
     * @param PrimaryKeyClass the pk class for the searched objects
     * @param query the query
     */
    public Enumeration getPKEnumerationByQuery(Class PrimaryKeyClass, Query query)
            throws PersistenceBrokerException;
    
    public ProxyFactory getProxyFactory();
    
    /**
     * Creates a proxy of the given type.
     * 
     * @param proxyClass           The proxy type
     * @param realSubjectsIdentity The identity of the real subject
     * @return The proxy
     */
    public Object createProxy(Class proxyClass, Identity realSubjectsIdentity);
    
   
}
