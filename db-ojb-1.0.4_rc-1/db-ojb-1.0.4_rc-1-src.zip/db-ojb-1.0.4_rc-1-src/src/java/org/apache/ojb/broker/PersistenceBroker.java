package org.apache.ojb.broker;

/* Copyright 2002-2004 The Apache Software Foundation
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

import org.apache.ojb.broker.accesslayer.ConnectionManagerIF;
import org.apache.ojb.broker.accesslayer.JdbcAccess;
import org.apache.ojb.broker.accesslayer.StatementManagerIF;
import org.apache.ojb.broker.accesslayer.sql.SqlGenerator;
import org.apache.ojb.broker.cache.ObjectCache;
import org.apache.ojb.broker.metadata.ClassDescriptor;
import org.apache.ojb.broker.metadata.DescriptorRepository;
import org.apache.ojb.broker.query.Query;
import org.apache.ojb.broker.util.BrokerHelper;
import org.apache.ojb.broker.util.ObjectModification;
import org.apache.ojb.broker.util.configuration.Configurable;
import org.apache.ojb.broker.util.sequence.SequenceManager;
import org.odbms.ObjectContainer;

import java.util.Collection;
import java.util.Enumeration;
import java.util.Iterator;

/**
 *
 * PersistenceBroker declares a protocol for persisting arbitrary objects.
 * A typical implementation might wrap an RDBMS access layer.
 *
 * @see org.apache.ojb.broker.core.PersistenceBrokerImpl
 * @see org.apache.ojb.broker.core.PersistenceBrokerBean
 *
 * @author <a href="mailto:thomas.mahler@itellium.com">Thomas Mahler<a>
 * @version $Id: PersistenceBroker.java,v 1.30.2.4 2005/07/07 17:00:09 arminw Exp $
 *
 */
public interface PersistenceBroker extends Configurable, ObjectContainer
{
    // *************************************************************************
    // Services handled by the PersistenceBroker
    // *************************************************************************

    /**
     * Returns the {@link org.apache.ojb.broker.accesslayer.StatementManagerIF} instance associated with this broker.
     */
    public StatementManagerIF serviceStatementManager();

    /**
     * Returns the {@link org.apache.ojb.broker.accesslayer.ConnectionManagerIF} instance associated with this broker.
     */
    public ConnectionManagerIF serviceConnectionManager();

    /**
     * Returns the {@link org.apache.ojb.broker.accesslayer.sql.SqlGenerator} instance associated with this broker.
     */
    public SqlGenerator serviceSqlGenerator();

    /**
     * Returns the {@link org.apache.ojb.broker.accesslayer.JdbcAccess} instance associated with this broker.
     */
    public JdbcAccess serviceJdbcAccess();

    /**
     * Returns the {@link org.apache.ojb.broker.util.sequence.SequenceManager} instance associated with this broker.
     */
    public SequenceManager serviceSequenceManager();

    /**
     * Returns the {@link org.apache.ojb.broker.util.BrokerHelper} instance associated with this broker.
     * Makes some helper methods available.
     */
    public BrokerHelper serviceBrokerHelper();

    /**
     * Returns the {@link org.apache.ojb.broker.cache.ObjectCache} instance associated
     * with this broker.
     */
    public ObjectCache serviceObjectCache();

    /**
     * Return the {@link IdentityFactory} instance associated with this broker.
     * @return service to create {@link Identity} objects.
     */
    public IdentityFactory serviceIdentity();


    // *************************************************************************
    // PersistenceBroker listener methods
    // *************************************************************************

    /**
     * Performs a broker event to inform all managed
     * {@link PBListener} implementations.
     */
    public void fireBrokerEvent(PersistenceBrokerEvent event);

    /**
     * Performs a broker event to inform all managed
     * {@link PBListener} implementations.
     */
    public void fireBrokerEvent(PBLifeCycleEvent event);

    /**
     * Performs a broker event to inform all managed
     * {@link PBListener} implementations.
     */
    public void fireBrokerEvent(PBStateEvent event);

    /**
     * Removes all temporary listeners from this PersistenceBroker instance
     * - Handle with care!
     */
    public void removeAllListeners() throws PersistenceBrokerException;

    /**
     * If parameter <code>permanet</code> was <code>true</code> all permanent and temporary listeners
     * will be removed from this PersistenceBroker instance.
     * <br/>
     * <b>NOTE:</b> Handle with care!
     *
     * @see #removeListener(PBListener listener)
     */
    public void removeAllListeners(boolean permanent) throws PersistenceBrokerException;


    /**
     * Adds a temporary {@link org.apache.ojb.broker.PBListener}
     * to this PersistenceBroker instance - when PersistenceBroker.close() was
     * called the listener was removed.
     *
     * @param listener The listener to add
     * @see #addListener(org.apache.ojb.broker.PBListener listener, boolean permanent)
     */
    public void addListener(PBListener listener) throws PersistenceBrokerException;

    /**
     * Adds a permanent {@link org.apache.ojb.broker.PBListener}
     * to this PersistenceBroker instance if parameter <code>permanent</code>
     * was <code>true</code>. This means the listener will be
     * hold the whole life time of the broker.
     * <br/>
     * <b>NOTE:</b> Handle carefully when using this method, keep in mind you don't
     * know which instance was returned next time from the pool, with a permanent
     * listener or without! To garantee that any pooled broker instance use the permanent
     * listener, best way is to implement your own
     * {@link org.apache.ojb.broker.core.PersistenceBrokerFactoryIF} or extend the default
     * implementation {@link org.apache.ojb.broker.core.PersistenceBrokerFactoryDefaultImpl}
     * and add the listener at creation of the {@link org.apache.ojb.broker.PersistenceBroker}
     * instances.
     */
    public void addListener(PBListener listener, boolean permanent) throws PersistenceBrokerException;

    /**
     * Removes a listener from this PersistenceBroker instance
     * @param listener
     */
    public void removeListener(PBListener listener) throws PersistenceBrokerException;


    // *************************************************************************
    // Transaction and instance handling stuff
    // *************************************************************************

    /**
     * Abort and close the transaction.
     * Calling abort abandons all persistent object modifications and releases the
     * associated locks.
     * <br>
     * If transaction is not in progress a TransactionNotInProgressException is thrown
     */
    public void abortTransaction() throws TransactionNotInProgressException;

    /**
     * Begin a transaction against the underlying RDBMS.
     * Calling <code>beginTransaction</code> multiple times,
     * without an intervening call to <code>commitTransaction</code> or <code>abortTransaction</code>,
     * causes the exception <code>TransactionInProgressException</code> to be thrown
     * on the second and subsequent calls.
     */
    public void beginTransaction()
            throws TransactionInProgressException, TransactionAbortedException;

    /**
     * Commit and close the transaction.
     * Calling <code>commit</code> commits to the database all
     * UPDATE, INSERT and DELETE statements called within the transaction and
     * releases any locks held by the transaction.
     * If beginTransaction() has not been called before, a
     * TransactionNotInProgressException exception is thrown.
     * If the transaction cannot be commited a TransactionAbortedException exception is thrown.
     */
    public void commitTransaction()
            throws TransactionNotInProgressException, TransactionAbortedException;


    /**
     * Returns <tt>true</tt> if the broker performs a transaction, <tt>false</tt>
     * in the other case.
     */
    public boolean isInTransaction() throws PersistenceBrokerException;

    /**
     * Close this PersistenceBroker so that no further requests may be made on it.
     * A PersistenceBroker instance can be used only until it is closed.
     * Closing a PersistenceBroker might release it to the pool of
     * available PersistenceBrokers, or might be garbage collected, at the option of the implementation.
     *
     * @return true if successful
     */
    public boolean close();

    /**
     * Returns <tt>true</tt> if this instance is closed.
     */
    public boolean isClosed();



    // *************************************************************************
    // Metadata service methods
    // *************************************************************************

    /**
     * Returns the {@link org.apache.ojb.broker.metadata.DescriptorRepository}
     * associated with this broker.
     */
    public DescriptorRepository getDescriptorRepository();

    /**
     * Get the {@link PBKey} for this broker.
     */
    public PBKey getPBKey();

    /**
     * Returns a ClassDescriptor for the persistence capable class.
     * Throws a PersistenceBrokerException if clazz is not persistence capable,
     * i.e. if no metadata was defined for this class or class was not found.
     */
    public ClassDescriptor getClassDescriptor(Class clazz) throws PersistenceBrokerException;

    /**
     * Same as {@link #getClassDescriptor}, but does not throw an exception when class was not found.
     * Useful for checking if an object is persistence Capable.
     * @param clazz target class
     * @return true if descriptor was found
     */
    public boolean hasClassDescriptor(Class clazz);


    /**
     * Returns the top level (extent) class to which the given class belongs.
     * This may be a (abstract) base-class, an interface or the given class itself, if
     * no extent is defined.
     * @throws PersistenceBrokerException if clazz is not persistence capable,
     * i.e. if clazz is not defined in the DescriptorRepository.
     */
    public Class getTopLevelClass(Class clazz) throws PersistenceBrokerException;



    // *************************************************************************
    // Object lifecycle
    // *************************************************************************

    /**
     * clears the brokers internal cache.
     * removing is recursive. That is referenced Objects are also
     * removed from the cache, if the auto-retrieve flag is set
     * for obj.getClass() in the metadata repository.
     *
     */
    public void clearCache() throws PersistenceBrokerException;

    /**
     * Removes the object from the brokers internal cache.
     * If object is instance of {@link org.apache.ojb.broker.Identity},
     * the associated object was removed from cache.
     * <br/>
     * Note: Removing is not recursive.
     */
    public void removeFromCache(Object objectOrIdentity) throws PersistenceBrokerException;

    /**
     * makes object obj persistent in the underlying persistence system.
     * E.G. by INSERT INTO ... or UPDATE ...  in an RDBMS.
     * The ObjectModification parameter can be used to generate optimized SQL code
     *
     * (decide whether insert or update is needed. And for updates only generate code for modified columns)
     */
    public void store(Object obj,
                      ObjectModification modification) throws PersistenceBrokerException;

    /**
     * make object obj persistent in the underlying persistence system.
     * E.G. by INSERT INTO ... or UPDATE ...  in an RDBMS
     */
    public void store(Object obj) throws PersistenceBrokerException;

    /**
     * deletes the objects obj concrete representation in the underlying persistence system.
     * E.G. by DELETE FROM ... WHERE ... in an RDBMS
     */
    public void delete(Object obj) throws PersistenceBrokerException;

    /**
     * Deletes and MtoN implementor (a row on a indirection table)
     * As it is today, ojb doesn't handle collection inherence, so collections descriptors
     * are written per class. We try to match one of these collection descriptors, iterating from the left side
     * and looking for possible for classes on the right side using : collection descriptor element . isAssinableFrom(rightClass)
     *
     * TODO: handle cache problems
     * TODO: delete more than one row if possible
     *
     *
     * <b>Pre-coditions :</b>
     * <li></li>
     *
     * <b>Pos-coditions :</b>
     * <li></li>
     *
     * <b>Assertions :</b>
     * <li></li>
     *
     * @param m2nImpl
     * @throws PersistenceBrokerException if an error occours
     */
    public void deleteMtoNImplementor(MtoNImplementor m2nImpl) throws PersistenceBrokerException;

    /**
     *
     */
    public void addMtoNImplementor(MtoNImplementor m2nImpl) throws PersistenceBrokerException;

    /**
     * Deletes all objects matching the query from the underlying persistence system.
     * E.G. by DELETE FROM ... WHERE ... in an RDBMS
     * <p/>
     * <b>Note:</b> This method directly perform the delete statement ignoring object
     * references and do not synchronize the cache - take care!
     */
    public void deleteByQuery(Query query) throws PersistenceBrokerException;





    // *************************************************************************
    // Query methods
    // *************************************************************************

    /**
     * Retrieve all Reference- and  Collection-attributes of a given
     * instance, independent from the used metadata-settings of the
     * references.
     *  
     * @param pInstance the persistent instance
     */
    public void retrieveAllReferences(Object pInstance) throws PersistenceBrokerException;

    /**
     * retrieve a single reference- or collection attribute
     * of a persistent instance.
     * @param pInstance the persistent instance
     * @param pAttributeName the name of the Attribute to load
     */
    public void retrieveReference(Object pInstance, String pAttributeName) throws PersistenceBrokerException;

    /**
     * Returns the count of elements a given query will return.
     */
    public int getCount(Query query) throws PersistenceBrokerException;

    /**
     *
     * Retrieve a collection of itemClass Objects matching the Query query.
     * If the Query has no criteria no WHERE-clause is generated, i.e. ALL table rows are selected.
     */
    public Collection getCollectionByQuery(Query query) throws PersistenceBrokerException;

    /**
     * Retrieve a userdefined Collection that implements the interface Manageable collection
     * that contains all Objects matching the Query query.
     * <br>
     * If query has no criteria no WHERE-clause is generated, i.e. ALL table rows are selected.
     */
    public ManageableCollection getCollectionByQuery(Class collectionClass, Query query)
            throws PersistenceBrokerException;

    /**
     * returns an Iterator that iterates Objects of class c if calling the .next()
     * method. The Elements returned come from a SELECT ... WHERE Statement
     * that is defined by the Query query.
     * If itemProxy is null, no proxies are used.
     */
    public Iterator getIteratorByQuery(Query query) throws PersistenceBrokerException;

    /**
     * Returns an Iterator that iterates Object[] calling the .next()
     * method. The Elements returned come from a SELECT ... WHERE sqlStatement
     * The Class c is only used to provide the associated JDBC Connection
     */
    public Iterator getReportQueryIteratorByQuery(Query query) throws PersistenceBrokerException;

    /**
     * Retrieve an Object by its Identity. Application Developers are encouraged to use getObjectByQuery().
     * This method is mainly used for internal performant handling of
     * materialization by OID (e.g. in Proxies)
     */
    public Object getObjectByIdentity(Identity id) throws PersistenceBrokerException;

    /**
     * Retrieve an Object by query.
     * I.e perform a SELECT ... FROM ... WHERE ...  in an RDBMS
     */
    public Object getObjectByQuery(Query query) throws PersistenceBrokerException;

    /**
     * Returns an Enumeration of PrimaryKey Objects for objects of class DataClass.
     * The Elements returned come from a SELECT ... WHERE Statement
     * that is defined by the fields and their coresponding values of vecFields
     * and vecValues.
     * Useful for EJB Finder Methods...
     * NOT YET AWARE OF EXTENTS !
     * @param PrimaryKeyClass the pk class for the searched objects
     * @param query the query
     */
    public Enumeration getPKEnumerationByQuery(Class PrimaryKeyClass, Query query)
            throws PersistenceBrokerException;
}
