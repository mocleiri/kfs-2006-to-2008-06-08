package org.apache.ojb.broker.transaction;

import org.apache.ojb.broker.OJBRuntimeException;

/**
 *
 *
 * @author <a href="mailto:arminw@apache.org">Armin Waibel</a>
 * @version $Id: TransactionNotInProgressException.java,v 1.1 2004/05/03 23:05:56 arminw Exp $
 */
public class TransactionNotInProgressException extends OJBRuntimeException
{
    public TransactionNotInProgressException()
    {
    }

    public TransactionNotInProgressException(String msg)
    {
        super(msg);
    }

    public TransactionNotInProgressException(Throwable cause)
    {
        super(cause);
    }

    public TransactionNotInProgressException(String msg, Throwable cause)
    {
        super(msg, cause);
    }
}
