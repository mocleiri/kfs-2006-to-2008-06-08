package org.apache.ojb.broker;

/* Copyright 2002-2004 The Apache Software Foundation
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

/**
 * This interface defines a protocol for persistent objects that must be
 * aware of the operations of the PersistenceBroker.
 * It defines callback methods that allows implementors to interact with
 * persistence operations.
 * <br/>
 * Non persistent objects could use the {@link PBLifeCycleListener}
 * to be notified on PersistenceBroker operations.
 *
 *
 * @author <a href="mailto:thma@apache.org">Thomas Mahler<a>
 * @version $Id: PersistenceBrokerAware.java,v 1.7 2004/04/04 23:53:30 brianm Exp $
 */
public interface PersistenceBrokerAware
{
    /**
     * this method is called as the first operation before perform an
     * object update.
     */
    public void beforeUpdate(PersistenceBroker broker) throws PersistenceBrokerException;

    /**
     * this method is called as the last operation within an update
     * operation.
     */
    public void afterUpdate(PersistenceBroker broker) throws PersistenceBrokerException;

    /**
     * this method is called as the first operation before perform an
     * object insert.
     */
    public void beforeInsert(PersistenceBroker broker) throws PersistenceBrokerException;

    /**
     * this method is called as the last operation within an insert
     * operation.
     */
    public void afterInsert(PersistenceBroker broker) throws PersistenceBrokerException;

    /**
     * this method is called as the first operation within a call to
     * PersistenceBroker.delete(...).
     */
    public void beforeDelete(PersistenceBroker broker) throws PersistenceBrokerException;


    /**
     * this method is called as the last operation within a call to
     * PersistenceBroker.delete(...).
     */
    public void afterDelete(PersistenceBroker broker) throws PersistenceBrokerException;

    /**
     * this method is called as the last operation within a call to
     * PersistenceBroker.getObjectByXXX() or
     * PersistenceBroker.getCollectionByXXX().
     */
    public void afterLookup(PersistenceBroker broker) throws PersistenceBrokerException;
}
