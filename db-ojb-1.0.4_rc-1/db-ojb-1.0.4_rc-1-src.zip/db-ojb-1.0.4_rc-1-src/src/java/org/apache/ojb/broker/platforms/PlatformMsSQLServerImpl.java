package org.apache.ojb.broker.platforms;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.Types;
import java.sql.SQLException;

/* Copyright 2002-2004 The Apache Software Foundation
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

/**
 * This class extends <code>PlatformDefaultImpl</code> and defines specific behavior for the
 * Microsoft SQL Server platform.
 * 
 * @author <a href="mailto:thma@apache.org">Thomas Mahler <a>
 * @version $Id: PlatformMsSQLServerImpl.java,v 1.8 2004/04/04 23:53:35 brianm Exp $
 */

public class PlatformMsSQLServerImpl extends PlatformDefaultImpl
{
    /**
     * Get join syntax type for this RDBMS - one on of the constants from JoinSyntaxType interface
     * MBAIRD: MS SQL Server 2000 actually supports both types, but due to a problem with the sql
     * generator, we opt to have no parens.
     */
    public byte getJoinSyntaxType()
    {
        return SQL92_NOPAREN_JOIN_SYNTAX;
    }

    public CallableStatement prepareNextValProcedureStatement(Connection con, String procedureName,
            String sequenceName) throws PlatformException
    {
        try
        {
            String sp = "{?= call " + procedureName + " (?)}";
            CallableStatement cs = con.prepareCall(sp);
            cs.registerOutParameter(1, Types.INTEGER);
            cs.setString(2, sequenceName);
            return cs;
        }
        catch (SQLException e)
        {
            throw new PlatformException(e);
        }
    }

    public String getLastInsertIdentityQuery(String tableName)
    {
        // matthias.roth@impart.ch
        // the function is used by the
        // org.apache.ojb.broker.util.sequence.SequenceManagerNativeImpl
        // this call must be made before commit the insert cammand, so you
        // must turn off autocommit by setting the useAutoCommit="2"
        return "SELECT @@IDENTITY AS id FROM " + tableName;
    }

    /**
     * Answer the Character for Concatenation
     */
    protected String getConcatenationCharacter()
    {
        return "+";
    }

}
