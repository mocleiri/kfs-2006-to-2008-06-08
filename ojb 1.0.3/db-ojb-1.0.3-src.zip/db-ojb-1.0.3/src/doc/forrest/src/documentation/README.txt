This is the base documentation directory. It usually contains two files:

skinconf.xml     # This file customizes Forrest for your project. In it, you
                 # tell forrest the project name, logo, copyright info, etc

sitemap.xmap     # Optional. This sitemap overrides the default one bundled
                 # with Forrest. Typically, one would copy a sitemap from
                 # xml-forrest/src/resources/conf/sitemap.xmap, and customize
                 # it.

