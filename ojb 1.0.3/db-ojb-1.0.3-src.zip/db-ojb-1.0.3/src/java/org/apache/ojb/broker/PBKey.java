package org.apache.ojb.broker;

import java.io.Serializable;

/* Copyright 2002-2004 The Apache Software Foundation
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

/**
 * A immutable key to identify PB instances in pools, ...
 * <br>
 * The used <i>jcdAlias</i> name represents an alias for a connection
 * defined in the repository file.
 *
 * @author <a href="mailto:armin@codeAuLait.de">Armin Waibel</a>
 * @version $Id: PBKey.java,v 1.11.2.2 2004/12/22 21:34:05 arminw Exp $
 */
public class PBKey implements Cloneable, Serializable
{
	static final long serialVersionUID = -8858811398162391578L;
    private final String jcdAlias;
    private final String user;
    private final String password;
    private int hashCode;

    /**
     * Constructor for new PBKey.
     * @param jcdAlias alias name, defined in the repository file.
     * @param user
     * @param password
     */
    public PBKey(final String jcdAlias, final String user, final String password)
    {
        this.jcdAlias = jcdAlias;
        this.user = user;
        this.password = password;
    }

    /**
     * Convenience constructor for PBKey(jcdAlias, null, null)
     */
    public PBKey(final String jcdAlias)
    {
        this(jcdAlias, null, null);
    }

    public boolean equals(Object obj)
    {
        if (obj == this)
        {
            return true;
        }
        if (!(obj instanceof PBKey))
        {
            return false;
        }
        PBKey other = (PBKey) obj;
        return this.jcdAlias.equals(other.getAlias())
                && (user != null ? user.equals(other.user) : null == other.user)
                && (password != null ? password.equals(other.password) : null == other.password);
    }

    /**
     * Returns an 'deep' copy of this key.
     */
    protected Object clone() throws CloneNotSupportedException
    {
        return new PBKey(this.jcdAlias, this.user, this.password);
    }

    /**
     * Return the hash code of this PBKey,
     * formed by the repository-, user-, password-name.
     */
    public int hashCode()
    {
        if(hashCode == 0)
        {
            hashCode = jcdAlias.hashCode()
                    + (user != null ? user.hashCode() : 0)
                    + (password != null ? password.hashCode() : 0);
        }
        return hashCode;
    }

    public String toString()
    {
        return this.getClass().getName() + ": jcdAlias="+jcdAlias+", user="+user+
                (user != null ? ", password=*****" : ", password="+password);
    }

    /**
     * Returns the jcd-alias name, defined in the repository file.
     */
    public String getAlias()
    {
        return jcdAlias;
    }

    /**
     * @deprecated use {@link #getAlias} instead.
     */
    public String getRepositoryFile()
    {
        return jcdAlias;
    }

    public String getUser()
    {
        return user;
    }

    public String getPassword()
    {
        return password;
    }
}
