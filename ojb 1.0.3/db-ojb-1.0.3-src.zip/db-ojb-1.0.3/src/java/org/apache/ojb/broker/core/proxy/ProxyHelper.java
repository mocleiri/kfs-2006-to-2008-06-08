package org.apache.ojb.broker.core.proxy;

/* Copyright 2002-2004 The Apache Software Foundation
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

//#ifdef JDK13
import java.lang.reflect.Proxy;
//#else
/*
import net.sf.cglib.proxy.Proxy;
*/
//#endif
import org.apache.ojb.broker.PersistenceBrokerException;
import org.apache.ojb.broker.util.logging.Logger;
import org.apache.ojb.broker.util.logging.LoggerFactory;

/**
 * ProxyHelper used to get the real thing behind a proxy
 *
 * @author <a href="mailto:jbraeuchi@hotmail.com">Jakob Braeuchi</a>
 * @version $Id: ProxyHelper.java,v 1.2.2.1 2005/01/25 20:00:53 tomdz Exp $
 */
public class ProxyHelper
{
    private static Logger log = LoggerFactory.getLogger(ProxyHelper.class);

    /**
     * Get the real Object
     *
     * @param objectOrProxy
     * @return Object
     */
    public static final Object getRealObject(Object objectOrProxy)
    {
        if (isNormalOjbProxy(objectOrProxy))
        {
            String msg;

            try
            {
                return ((IndirectionHandler)Proxy.getInvocationHandler(objectOrProxy)).getRealSubject();
            }
            catch (ClassCastException e)
            {
                // shouldn't happen but still ...
                msg = "The InvocationHandler for the provided Proxy was not an instance of " + IndirectionHandler.class.getName();
                log.error(msg);
                throw new PersistenceBrokerException(msg, e);
            }
            catch (IllegalArgumentException e)
            {
                msg = "Could not retrieve real object for given Proxy: " + objectOrProxy;
                log.error(msg);
                throw new PersistenceBrokerException(msg, e);
            }
            catch (PersistenceBrokerException e)
            {
                log.error("Could not retrieve real object for given Proxy: " + objectOrProxy);
                throw e;
            }
        }
        else if (isVirtualOjbProxy(objectOrProxy))
        {
            try
            {
                return ((VirtualProxy)objectOrProxy).getRealSubject();
            }
            catch (PersistenceBrokerException e)
            {
                log.error("Could not retrieve real object for VirtualProxy: " + objectOrProxy);
                throw e;
            }
        }
        else
        {
            return objectOrProxy;
        }
    }

    /**
     * Get the real Object for already materialized Handler
     *
     * @param objectOrProxy
     * @return Object or null if the Handel is not materialized
     */
    public static final Object getRealObjectIfMaterialized(Object objectOrProxy)
    {
        if (isNormalOjbProxy(objectOrProxy))
        {
            String msg;

            try
            {
                IndirectionHandler handler = (IndirectionHandler) Proxy.getInvocationHandler(objectOrProxy);

                return handler.alreadyMaterialized() ? handler.getRealSubject() : null;
            }
            catch (ClassCastException e)
            {
                // shouldn't happen but still ...
                msg = "The InvocationHandler for the provided Proxy was not an instance of " + IndirectionHandler.class.getName();
                log.error(msg);
                throw new PersistenceBrokerException(msg, e);
            }
            catch (IllegalArgumentException e)
            {
                msg = "Could not retrieve real object for given Proxy: " + objectOrProxy;
                log.error(msg);
                throw new PersistenceBrokerException(msg, e);
            }
            catch (PersistenceBrokerException e)
            {
                log.error("Could not retrieve real object for given Proxy: " + objectOrProxy);
                throw e;
            }
        }
        else if (isVirtualOjbProxy(objectOrProxy))
        {
            try
            {
                VirtualProxy proxy = (VirtualProxy)objectOrProxy;

                return proxy.alreadyMaterialized() ? proxy.getRealSubject() : null;
            }
            catch (PersistenceBrokerException e)
            {
                log.error("Could not retrieve real object for VirtualProxy: " + objectOrProxy);
                throw e;
            }
        }
        else
        {
            return objectOrProxy;
        }
    }

    /**
     * Get the real Class
     *
     * @param objectOrProxy
     * @return Class
     */
    public static final Class getRealClass(Object objectOrProxy)
    {
        IndirectionHandler handler;

        if (isNormalOjbProxy(objectOrProxy))
        {
            String msg;

            try
            {
                handler = (IndirectionHandler)Proxy.getInvocationHandler(objectOrProxy);
                /*
                arminw:
                think we should return the real class
                */
                // return handler.getIdentity().getObjectsTopLevelClass();
                return handler.getIdentity().getObjectsRealClass();
            }
            catch (ClassCastException e)
            {
                // shouldn't happen but still ...
                msg = "The InvocationHandler for the provided Proxy was not an instance of " + IndirectionHandler.class.getName();
                log.error(msg);
                throw new PersistenceBrokerException(msg, e);
            }
            catch (IllegalArgumentException e)
            {
                msg = "Could not retrieve real object for given Proxy: " + objectOrProxy;
                log.error(msg);
                throw new PersistenceBrokerException(msg, e);
            }
        }
        else if (isVirtualOjbProxy(objectOrProxy))
        {
            handler = VirtualProxy.getIndirectionHandler((VirtualProxy) objectOrProxy);
            /*
            arminw:
            think we should return the real class
            */
            // return handler.getIdentity().getObjectsTopLevelClass();
            return handler.getIdentity().getObjectsRealClass();
        }
        else
        {
            return objectOrProxy.getClass();
        }
    }

    /**
     * Determines whether the given object is an OJB proxy.
     * 
     * @return <code>true</code> if the object is an OJB proxy
     */
    public static boolean isNormalOjbProxy(Object proxyOrObject)
    {
        /*
         arminw
         TODO: Check it out. Because the isProxyClass method is costly and most objects
         aren't proxies, I add a instanceof check before. Is every Proxy a instance of Proxy?
         */
        return (proxyOrObject instanceof Proxy) &&
               Proxy.isProxyClass(proxyOrObject.getClass()) &&
               (Proxy.getInvocationHandler(proxyOrObject) instanceof IndirectionHandler);
    }

    /**
     * Determines whether the given object is an OJB virtual proxy.
     * 
     * @return <code>true</code> if the object is an OJB virtual proxy
     */
    public static boolean isVirtualOjbProxy(Object proxyOrObject)
    {
        return proxyOrObject instanceof VirtualProxy;
    }

    /**
     * Returns <tt>true</tt> if the given object is a {@link java.lang.reflect.Proxy}
     * or a {@link VirtualProxy} instance.
     */
    public static boolean isProxy(Object proxyOrObject)
    {
        return isNormalOjbProxy(proxyOrObject) || isVirtualOjbProxy(proxyOrObject);
    }

    /**
     * Returns the invocation handler object of the given proxy object.
     * 
     * @param obj The object
     * @return The invocation handler if the object is an OJB proxy, or <code>null</code>
     *         otherwise
     */
    public static IndirectionHandler getIndirectionHandler(Object obj)
    {
        if (obj == null)
        {
            return null;
        }
        else if (isNormalOjbProxy(obj))
        {
            return (IndirectionHandler) Proxy.getInvocationHandler(obj);
        }
        else if (isVirtualOjbProxy(obj))
        {
            return VirtualProxy.getIndirectionHandler((VirtualProxy) obj);
        }
        else
        {
            return null;
        }
    }

    /**
     * Determines whether the object is a materialized object, i.e. no proxy or a
     * proxy that has already been loaded from the database.
     *   
     * @param object The object to test
     * @return <code>true</code> if the object is materialized
     */
    public static boolean isMaterialized(Object object)
    {
        IndirectionHandler handler = getIndirectionHandler(object);

        return handler == null ? true : handler.alreadyMaterialized();
    }

    /**
     * Materialization-safe version of toString. If the object is a yet-unmaterialized proxy,
     * then only the text "unmaterialized proxy for ..." is returned and the proxy is NOT
     * materialized. Otherwise, the normal toString method is called. This useful e.g. for
     * logging etc.
     * 
     * @param object The object for which a string representation shall be generated
     * @return The string representation
     */
    public static String toString(Object object)
    {
        IndirectionHandler handler = getIndirectionHandler(object);

        if ((handler != null) && handler.alreadyMaterialized())
        {
            return "unmaterialized proxy for " + handler.getIdentity();
        }
        else
        {
            return object.toString();
        }
    }

    /**
     * Return CollectionProxy for item is item is a CollectionProxy, otherwise return null
     */
    public static CollectionProxy getCollectionProxy(Object item)
    {
        if (isCollectionProxy(item)) return (CollectionProxy) item;
        else return null;
    }

    /**
     * Reports if item is a CollectionProxy.
     *
     * @todo Provide handling for pluggable  collection proxy implementations
     */
    public static boolean isCollectionProxy(Object item)
    {
        return (item instanceof CollectionProxy);
    }
}
