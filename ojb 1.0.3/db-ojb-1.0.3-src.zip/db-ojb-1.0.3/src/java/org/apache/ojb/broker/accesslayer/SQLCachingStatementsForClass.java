package org.apache.ojb.broker.accesslayer;

/* Copyright 2002-2004 The Apache Software Foundation
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import org.apache.ojb.broker.PersistenceBrokerException;
import org.apache.ojb.broker.metadata.ClassDescriptor;
import org.apache.ojb.broker.metadata.JdbcConnectionDescriptor;
import org.apache.ojb.broker.query.Query;
import org.apache.ojb.broker.util.logging.Logger;
import org.apache.ojb.broker.util.logging.LoggerFactory;

/**
 * @version $Id: SQLCachingStatementsForClass.java,v 1.12 2004/04/04 23:53:31 brianm Exp $
 */
public class SQLCachingStatementsForClass extends StatementsForClassImpl
{
	private Logger logger = LoggerFactory.getLogger(SQLCachingStatementsForClass.class);
    /**
	 * the SQL String used for PK lookups
	 */
	private String selectByPKSQL;
	/**
	 * the SQL String used for inserts
	 */
	private String insertSQL;
	/**
	 * the SQL String used for updates
	 */
	private String updateSQL;
	/**
	 * the SQL String used for deletes
	 */
	private String deleteSQL;

	public SQLCachingStatementsForClass(final JdbcConnectionDescriptor jcd, final ClassDescriptor mif)
	{
		super(jcd, mif);
	}

//	/**
//	 * Obtains the connection from the ConnectionManager.
//	 * This method is used for jdbc 1.0 drivers.
//	 */
//    protected Connection getConnection() throws SQLException
//    {
//        try
//        {
//            return connectionManager.getConnection();
//        }
//        catch (PersistenceBrokerException e)
//        {
//            throw new SQLException("OJB Error: could not obtain a Connection");
//        }
//        catch (LookupException e)
//        {
//            throw new SQLException("OJB Error: could not obtain a Connection");
//        }
//
//    }


	public PreparedStatement getDeleteStmt(Connection con) throws SQLException
	{
		if (deleteSQL == null)
		{
			synchronized (this)
			{
				deleteSQL = sqlGenerator.getPreparedDeleteStatement(classDescriptor);
				if (deleteSQL == null)
					throw new PersistenceBrokerException("Could not generate delete Key SQL for class (" + classDescriptor.getClassOfObject().getName() + ")");
			}
		}
		try
		{
			return prepareStatement(con, deleteSQL, Query.NOT_SCROLLABLE, true);
		}
		catch (SQLException ex)
		{
			logger.error("Error getting delete statement for class (" + classDescriptor.getClassOfObject().getName() + ")", ex);
			throw ex;
		}
	}

	public PreparedStatement getInsertStmt(Connection con) throws SQLException
	{
		if (insertSQL == null)
		{
			synchronized (this)
			{
				insertSQL = sqlGenerator.getPreparedInsertStatement(classDescriptor);
				if (insertSQL == null)
					throw new PersistenceBrokerException("Could not generate insert SQL for class (" + classDescriptor.getClassOfObject().getName() + ")");
			}
		}
		try
		{
			return prepareStatement(con, insertSQL, Query.NOT_SCROLLABLE, true);
		}
		catch (SQLException ex)
		{
			logger.error("Error getting insert statement for class (" + classDescriptor.getClassOfObject().getName() + ")", ex);
			throw ex;
		}
	}

	public PreparedStatement getSelectByPKStmt(Connection con) throws SQLException
	{
		if (selectByPKSQL == null)
		{
			synchronized (this)
			{
				selectByPKSQL = sqlGenerator.getPreparedSelectByPkStatement(classDescriptor);
				if (selectByPKSQL == null)
					throw new PersistenceBrokerException("Could not generate Select by Primary Key SQL for class (" + classDescriptor.getClassOfObject().getName() + ")");
			}
		}
		try
		{
			return prepareStatement(con, selectByPKSQL, Query.NOT_SCROLLABLE, true);
		}
		catch (SQLException ex)
		{
			logger.error("Error getting select by primary key statement for class (" + classDescriptor.getClassOfObject().getName() + ")", ex);
			throw ex;
		}
	}

	public PreparedStatement getUpdateStmt(Connection con) throws SQLException
	{
		if (updateSQL == null)
		{
			synchronized (this)
			{
				updateSQL = sqlGenerator.getPreparedUpdateStatement(classDescriptor);
				if (updateSQL == null)
					throw new PersistenceBrokerException("Could not generate Update SQL for class (" + classDescriptor.getClassOfObject().getName() + ")");
			}
		}
		try
		{
			return prepareStatement(con, updateSQL, Query.NOT_SCROLLABLE, true);
		}
		catch (SQLException ex)
		{
			logger.error("Error getting update statement for class (" + classDescriptor.getClassOfObject().getName() + ")", ex);
			throw ex;
		}
	}
}
