package org.apache.ojb.broker;

/* Copyright 2002-2004 The Apache Software Foundation
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

import java.lang.reflect.Method;

/**
 * The Base Exception for all Exceptions that can happend within ObjectRelationalBridge.
 *
 * @author <a href="mailto:thomas.mahler@itellium.com">Thomas Mahler<a>
 * @version $Id: PersistenceBrokerException.java,v 1.9 2004/05/22 09:51:26 brj Exp $
 */
public class PersistenceBrokerException extends OJBRuntimeException
{
    /**
     * The cause of this Exception.
     */
    private Throwable sourceException = null;

    /**
     *
     * PersistenceBrokerException constructor comment.
     *
     */
    public PersistenceBrokerException()
    {
        super();
    }

    /**
     * Constructs a new PersistenceBrokerException with the specified detail message.
     *
     * @param   message   the detail message. The detail message is saved for
     *          later retrieval by the {@link #getMessage()} method.
     */
    public PersistenceBrokerException(String message)
    {
        super(message);
    }

    public PersistenceBrokerException(String message, Throwable cause)
    {
        super(message, cause);
        setSourceException(cause);
    }

    /**
     *
     * PersistenceBrokerException constructor comment.
     *
     * @param cause The cause of this Exception
     *
     */
    public PersistenceBrokerException(Throwable cause)
    {
        super(cause);
        setSourceException(cause);
    }

    /**
     * Gets the sourceException.
     * @return Returns a Throwable
     */
    public Throwable getSourceException()
    {
        Method getCause = null;
        try
        {
            getCause = getClass().getMethod("getCause", new Class[]{});
        }
        catch (NoSuchMethodException e)
        {
            //ignore it
        }
        catch (SecurityException e)
        {
            //ignore it
        }

        if (getCause != null)
        {
            try
            {
                return (Throwable) getCause.invoke(this, new Object[]{});
            }
            catch (Throwable e)
            {
                return sourceException;
            }
        }
        else
        {
            return sourceException;
        }
    }

    private void setSourceException(Throwable cause)
    {
        Method initCause = null;
        try
        {
            initCause = getClass().getMethod("initCause", new Class[]{Throwable.class});
        }
        catch (NoSuchMethodException e)
        {
            //ignore it
        }
        catch (SecurityException e)
        {
            //ignore it
        }

        if (initCause != null)
        {
            try
            {
                initCause.invoke(this, new Object[]{cause});
            }
            catch (Throwable e)
            {
                sourceException = cause;
            }
        }
        else
        {
            sourceException = cause;
        }
    }
}