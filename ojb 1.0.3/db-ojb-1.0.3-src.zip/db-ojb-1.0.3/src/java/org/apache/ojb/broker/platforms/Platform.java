package org.apache.ojb.broker.platforms;

/* Copyright 2002-2004 The Apache Software Foundation
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

import org.apache.ojb.broker.metadata.JdbcConnectionDescriptor;
import org.apache.ojb.broker.query.LikeCriteria;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

/**
 * this interface provides callbacks that allow to perform
 * RDBMS Platform specific operations whereever neccessary.
 * The Platform implementation is selected by the <dbms.name></dbms.name>
 * entry in the repository.xml file.
 *
 * @version $Id: Platform.java,v 1.24 2004/04/04 23:53:35 brianm Exp $
 * @author	 Thomas Mahler
 */
public interface Platform
{
    /**
     * Called after a jdbc-m_connection statement was created.
     */
    public void afterStatementCreate(Statement stmt) throws PlatformException;

    /**
     * Called by {@link org.apache.ojb.broker.accesslayer.StatementManager} implementation
     * before invoke <tt>stmt.close()</tt> method.
     */
    public void beforeStatementClose(Statement stmt, ResultSet rs) throws PlatformException;

    /**
     * Called by {@link org.apache.ojb.broker.accesslayer.StatementManager} implementation
     * after invoke <tt>stmt.close()</tt> method.
     */
    public void afterStatementClose(Statement stmt, ResultSet rs) throws PlatformException;

    /**
     *
     * @param stmt the statement you want to batch on
     * @throws PlatformException
     */
    public void beforeBatch(PreparedStatement stmt) throws PlatformException;

    /**
     *
     * @param stmt the statement you are adding to the batch
     * @throws PlatformException
     */
    public void addBatch(PreparedStatement stmt) throws PlatformException;

    /**
     *
     * @param stmt the statement you want to execute the batch on
     * @throws PlatformException
     */
    public int[] executeBatch(PreparedStatement stmt) throws PlatformException;

    /**
     * callback called immediately after a JDBC Connection has been obtained
     * in ...
     * @param conn the Connection to be initialized
     */
    public void initializeJdbcConnection(JdbcConnectionDescriptor jcd, Connection conn) throws PlatformException;

    /**
     * Used to do a temporary change of the m_connection autoCommit state.
     * When using this method ensure to reset the original state before
     * m_connection was returned to pool or closed.
     * Only when
     * {@link org.apache.ojb.broker.metadata.JdbcConnectionDescriptor#getUseAutoCommit()} was set to
     * {@link org.apache.ojb.broker.metadata.JdbcConnectionDescriptor#AUTO_COMMIT_SET_TRUE_AND_TEMPORARY_FALSE}
     * the change of the autoCommit state take effect.
     */
    public void changeAutoCommitState(JdbcConnectionDescriptor jcd, Connection con, boolean newState);

    /**
     * some JDBC-Drivers do not support all sqlTypes
     * this callback is used set parameters to a PreparedStatement
     */
    public void setObjectForStatement(PreparedStatement ps, int index, Object value, int sqlType)
            throws SQLException;

    /**
     * some JDBC-Drivers do not support all sqlTypes
     * this callback is used set parameters to a PreparedStatement
     */
    public void setNullForStatement(PreparedStatement ps, int index, int sqlType)
            throws SQLException;

    /**
     * Get join syntax type for this RDBMS - one on of the constants from JoinSyntaxType interface
     */
    public byte getJoinSyntaxType();

    /**
     * Override default ResultSet size determination (rs.last();rs.getRow())
     * with select count(*) operation
     */
    public boolean useCountForResultsetSize();

    /**
     * if this platform supports the batch operations jdbc 2.0 feature. This is
     * by driver, so we check the driver's metadata once and set something in
     * the platform.
     * @return true if the platform supports batch, false otherwise.
     */
    public boolean supportsBatchOperations();

// arminw: think we can handle this internally
//    /**
//     * Sets platform information for if the jdbc driver/db combo support
//     * batch operations. Will only be checked once, then have same batch
//     * support setting for the entire session.
//     * @param conn
//     */
//    public void checkForBatchSupport(Connection conn);

    /**
     * Returns a query to create a sequence entry.
     * @return a sql string to create a sequence
     */
    public String createSequenceQuery(String sequenceName);

    /**
     * Returns a query to obtain the next sequence key.
     * @return a sql string to get next sequence value
     */
    public String nextSequenceQuery(String sequenceName);

    /**
     * Returns a query to drop a sequence entry.
     * @return a sql string to drop a sequence
     */
    public String dropSequenceQuery(String sequenceName);

    /**
     * Create stored procedure call for a special sequence manager implementation
     * {@link org.apache.ojb.broker.util.sequence.SequenceManagerStoredProcedureImpl},
     * because it seems that jdbc-driver differ in handling of CallableStatement.
     * <br/>
     * Note: The out-parameter of the stored procedure must be registered at
     * first position, because lookup for new long id in the implementation:
     * <br/>
     * <pre>
     * Connection con = broker.serviceConnectionManager().getConnection();
     * cs = getPlatform().prepareNextValProcedureStatement(con, PROCEDURE_NAME, sequenceName);
     * cs.executeUpdate();
     * return cs.getLong(1);
     * </pre>
     */
    public CallableStatement prepareNextValProcedureStatement(Connection con, String procedureName,
                                                              String sequenceName) throws PlatformException;

    /**
     * If database supports native key generation via identity column, this
     * method should return the sql-query to obtain the last generated id.
     */
    public String getLastInsertIdentityQuery(String tableName);

    /**
     * Answer true if LIMIT or equivalent is supported
     * <b> SQL-Paging is not yet supported </b>
     * @return 
     */
    public boolean supportsPaging();
    
    /**
     * Add the LIMIT or equivalent to the SQL 
     * <b> SQL-Paging is not yet supported </b>
     */
    public void addPagingSql(StringBuffer anSqlString);
    
    /**
     * Answer true if the LIMIT parameters are bound before the query parameters
     * <b> SQL-Paging is not yet supported </b>
     * @return
     */
    boolean bindPagingParametersFirst();
    
    /**
     * Bind the Paging Parameters
     * <b> SQL-Paging is not yet supported </b>
     * @param ps
     * @param index parameter index
     * @param startAt
     * @param endAt
     * @return
     */
    public int bindPagingParameters(PreparedStatement ps, int index, int startAt, int endAt) throws SQLException;
    
    /**
     * Concatenate the columns </br>
     * ie: col1 || col2 || col3 (ANSI)</br>
     * ie: col1 + col2 + col3 (MS SQL-Server)</br>
     * ie: concat(col1, col2, col3) (MySql)
     * 
     * @param theColumns
     * @return the concatenated String 
     */
    public String concatenate(String[] theColumns);
    
    /**
     * Answer the Clause used Escape wildcards in LIKE 
     * @param aCriteria
     * @return
     */
    public String getEscapeClause(LikeCriteria aCriteria);
    
}
