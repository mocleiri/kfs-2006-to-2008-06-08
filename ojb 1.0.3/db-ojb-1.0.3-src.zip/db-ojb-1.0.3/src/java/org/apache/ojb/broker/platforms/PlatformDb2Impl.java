package org.apache.ojb.broker.platforms;

/* Copyright 2002-2004 The Apache Software Foundation
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Types;

/**
 * This class extends <code>PlatformDefaultImpl</code> and defines specific
 * behavior for the DB2 platform.
 *
 * @author <a href="mailto:thma@apache.org">Thomas Mahler<a>
 * @version $Id: PlatformDb2Impl.java,v 1.10 2004/04/04 23:53:35 brianm Exp $
 */
public class PlatformDb2Impl extends PlatformDefaultImpl
{
    /**
     * Patch provided by Avril Kotzen (hi001@webmail.co.za)
     * DB2 handles TINYINT (for mapping a byte).
     */
    public void setObjectForStatement(PreparedStatement ps, int index,
                                      Object value, int sqlType) throws SQLException
    {
        if (sqlType == Types.TINYINT)
        {
            ps.setByte(index, ((Byte) value).byteValue());
        }
        else
        {
            super.setObjectForStatement(ps, index, value, sqlType);
        }
    }

    public String createSequenceQuery(String sequenceName)
    {
        return "create sequence " + sequenceName;
    }

    public String nextSequenceQuery(String sequenceName)
    {
        return "values nextval for "+ sequenceName;
    }

    public String dropSequenceQuery(String sequenceName)
    {
        return "drop sequence " + sequenceName;
    }
  
	public String getLastInsertIdentityQuery(String tableName)
	{
		// matthias.roth@impart.ch
		// the function is used by the org.apache.ojb.broker.util.sequence.SequenceManagerNativeImpl
		// this call must be made before commit the insert cammand, so you
		// must turn off autocommit by seting the useAutoCommit="2"
		return "select IDENTITY_VAL_LOCAL() from sysibm.sysdummy1";
	}
}
