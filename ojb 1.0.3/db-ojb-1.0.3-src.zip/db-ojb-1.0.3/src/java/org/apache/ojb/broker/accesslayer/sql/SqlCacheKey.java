package org.apache.ojb.broker.accesslayer.sql;

/* Copyright 2002-2004 The Apache Software Foundation
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

import org.apache.ojb.broker.query.Query;
import org.apache.ojb.broker.metadata.ClassDescriptor;

/**
 * Helper key class to store generated sql statements
 *
 * @author Matthew Baird
 * @version $Id: SqlCacheKey.java,v 1.7 2004/04/04 23:53:32 brianm Exp $
 */
class SqlCacheKey
{
	public static final int TYPE_SELECT = 1;
    public static final int TYPE_INSERT = 2;
    public static final int TYPE_UPDATE = 3;
    public static final int TYPE_DELETE = 4;

    private final Query m_query;
    private final ClassDescriptor m_cld;
    private final int type;

    public SqlCacheKey(final Query query, final ClassDescriptor cld, final int type)
	{
		m_query = query;
		m_cld = cld;
        this.type = type;
	}

    public int hashCode()
	{
		int retval = 0;
		if (getCld() != null)
		{
			retval += getCld().hashCode();
		}
		if (getQuery() != null)
		{
			retval += getQuery().hashCode();
		}
		return retval+type;
	}

	public boolean equals(Object other)
	{
		if (other == null)
		{
			return false;
		}
		if (other instanceof SqlCacheKey)
		{
			SqlCacheKey temp = (SqlCacheKey) other;
			if (temp.getCld().equals(getCld()) && (temp.getQuery().equals(getQuery())) && (temp.getType() == this.getType()))
			{
				return true;
			}
			else
            {
				return false;
            }
		}
		else
        {
			return false;
        }
	}

	public Query getQuery()
	{
		return m_query;
	}

	public ClassDescriptor getCld()
	{
		return m_cld;
	}

    public int getType()
    {
        return type;
    }
    /*
    arminw:
    When we declare cld and query final, we have to eliminate setters.
    */

//	public void setCld(ClassDescriptor cld)
//	{
//		m_cld = cld;
//	}
//
//    public void setQuery(Query query)
//    {
//        m_query = query;
//    }

}
