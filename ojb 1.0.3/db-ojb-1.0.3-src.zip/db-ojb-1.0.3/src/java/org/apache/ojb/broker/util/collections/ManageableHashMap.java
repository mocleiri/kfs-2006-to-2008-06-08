package org.apache.ojb.broker.util.collections;

/* Copyright 2003-2004 The Apache Software Foundation
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
import org.apache.ojb.broker.ManageableCollection;
import org.apache.ojb.broker.PersistenceBroker;
import org.apache.ojb.broker.PersistenceBrokerException;
import org.apache.ojb.broker.PersistenceBrokerFactory;
import org.apache.ojb.broker.metadata.ClassDescriptor;

import java.util.HashMap;
import java.util.Iterator;


/**
 * Creates a Map where the primary key is the map key, and the object is the map value
 */
public class ManageableHashMap extends HashMap implements ManageableCollection
{
	public void ojbAdd(Object anObject)
	{
		if (anObject != null)
		{
			ClassDescriptor cd = PersistenceBrokerFactory.defaultPersistenceBroker().getDescriptorRepository().getDescriptorFor(anObject.getClass());
			Object key = cd.getPrimaryKey().getPersistentField().get(anObject);
			put(key,anObject);
		}
	}

	public void ojbAddAll(ManageableCollection otherCollection)
	{
		Iterator it = otherCollection.ojbIterator();
		while (it.hasNext())
		{
			ojbAdd(it.next());
		}
	}

	public Iterator ojbIterator()
	{
		return values().iterator();
	}

	public void afterStore(PersistenceBroker broker) throws PersistenceBrokerException
	{
        //do nothing
	}
}
