package org.apache.ojb.broker.core.proxy;

/* Copyright 2002-2004 The Apache Software Foundation
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Modifier;
import java.util.Collection;
import java.util.List;
import java.util.Set;

import org.apache.ojb.broker.Identity;
import org.apache.ojb.broker.ManageableCollection;
import org.apache.ojb.broker.PBKey;
import org.apache.ojb.broker.PersistenceBrokerException;
import org.apache.ojb.broker.metadata.MetadataException;
import org.apache.ojb.broker.query.Query;
import org.apache.ojb.broker.util.configuration.impl.OjbConfigurator;

/**
 * Factory class for creating instances of the indirection handler used by OJB's proxies, and
 * for the collection proxies.
 *
 * @author <a href="mailto:tomdz@apache.org">Thomas Dudziak<a>
 * @version $Id: ProxyFactory.java,v 1.1 2004/04/09 13:22:29 tomdz Exp $
 */
public class ProxyFactory
{
    /** The class to be used for indirection handler instances */
    private static Constructor _indirectionHandlerConstructor;
    /** The constructor used for creating list proxies */
    private static Constructor _listProxyConstructor;
    /** The constructor used for creating set proxies */
    private static Constructor _setProxyConstructor;
    /** The constructor used for creating collection proxies */
    private static Constructor _collectionProxyConstructor;

    /**
     * Returns the configuration object for proxies.
     * 
     * @return The configuration object
     */
    private static ProxyConfiguration getProxyConfiguration()
    {
        return (ProxyConfiguration)OjbConfigurator.getInstance().getConfigurationFor(null);
    }

    /**
     * Returns the constructor of the indirection handler class.
     * 
     * @return The constructor for indirection handlers
     */
    private static Constructor getIndirectionHandlerConstructor()
    {
        if (_indirectionHandlerConstructor == null)
        {
            setIndirectionHandlerClass(getProxyConfiguration().getIndirectionHandlerClass());
        }
        return _indirectionHandlerConstructor;
    }

    /**
     * Returns the indirection handler class.
     * 
     * @return The class for indirection handlers
     */
    public static Class getIndirectionHandlerClass()
    {
        return getIndirectionHandlerConstructor().getDeclaringClass();
    }

    /**
     * Sets the indirection handler class.
     * 
     * @param indirectionHandlerClass The class for indirection handlers
     */
    public static void setIndirectionHandlerClass(Class indirectionHandlerClass)
    {
        if (indirectionHandlerClass == null)
        {
            throw new MetadataException("No IndirectionHandlerClass specified.");
        }
        if (indirectionHandlerClass.isInterface() ||
            Modifier.isAbstract(indirectionHandlerClass.getModifiers()) ||
            !IndirectionHandler.class.isAssignableFrom(indirectionHandlerClass))
        {
            throw new MetadataException("Illegal class "+indirectionHandlerClass.getName()+" specified for IndirectionHandlerClass. Must be a concrete subclass of "+IndirectionHandler.class.getName());
        }

        Class[] paramType = {PBKey.class, Identity.class};

        try
        {
            _indirectionHandlerConstructor = indirectionHandlerClass.getConstructor(paramType);
        }
        catch (NoSuchMethodException ex)
        {
            throw new MetadataException("The class "+indirectionHandlerClass.getName()+" specified for IndirectionHandlerClass"+
                                        " is required to have a public constructor with signature ("+
                                        PBKey.class.getName()+", "+Identity.class.getName()+").");
        }
    }

    /**
     * Creates a new indirection handler instance.
     * 
     * @param brokerKey The key of the persistence broker
     * @param id        The subject's ids
     * @return The new instance
     */
    public static IndirectionHandler createIndirectionHandler(PBKey brokerKey, Identity id)
    {
        Object args[] = { brokerKey, id };

        try
        {
            return (IndirectionHandler)getIndirectionHandlerConstructor().newInstance(args);
        }
        catch (InvocationTargetException ex)
        {
            throw new PersistenceBrokerException("Exception while creating a new indirection handler instance", ex);
        }
        catch (InstantiationException ex)
        {
            throw new PersistenceBrokerException("Exception while creating a new indirection handler instance", ex);
        }
        catch (IllegalAccessException ex)
        {
            throw new PersistenceBrokerException("Exception while creating a new indirection handler instance", ex);
        }
    }

    /**
     * Retrieves the constructor that is used by OJB to create instances of the given collection proxy
     * class.
     * 
     * @param proxyClass The proxy class
     * @param baseType   The required base type of the proxy class
     * @param typeDesc   The type of collection proxy
     * @return The constructor
     */
    private static Constructor retrieveCollectionProxyConstructor(Class proxyClass, Class baseType, String typeDesc)
    {
        if (proxyClass == null)
        {
            throw new MetadataException("No "+typeDesc+" specified.");
        }
        if (proxyClass.isInterface() ||
            Modifier.isAbstract(proxyClass.getModifiers()) ||
            !baseType.isAssignableFrom(proxyClass))
        {
            throw new MetadataException("Illegal class "+proxyClass.getName()+" specified for "+typeDesc+". Must be a concrete subclass of "+baseType.getName());
        }

        Class[] paramType = {PBKey.class, Class.class, Query.class};

        try
        {
            return proxyClass.getConstructor(paramType);
        }
        catch (NoSuchMethodException ex)
        {
            throw new MetadataException("The class "+proxyClass.getName()+" specified for "+
                                        typeDesc+" is required to have a public constructor with signature ("+
                                        PBKey.class.getName()+", "+Class.class.getName()+", "+Query.class.getName()+").");
        }
    }
    
    /**
     * Returns the list proxy class.
     * 
     * @return The class used for list proxies
     */
    public static Class getListProxyClass()
    {
        return getListProxyConstructor().getDeclaringClass();
    }

    /**
     * Returns the constructor of the list proxy class.
     * 
     * @return The constructor for list proxies
     */
    private static Constructor getListProxyConstructor()
    {
        if (_listProxyConstructor == null)
        {
            setListProxyClass(getProxyConfiguration().getListProxyClass());
        }
        return _listProxyConstructor;
    }

    /**
     * Dets the proxy class to use for collection classes that implement the {@link java.util.List} interface.
     * Notes that the proxy class must implement the {@link java.util.List} interface, and have a constructor
     * of the signature ({@link org.apache.ojb.broker.PBKey}, {@link java.lang.Class}, {@link org.apache.ojb.broker.query.Query}).
     *
     * @param listProxyClass The proxy class
     */
    public static void setListProxyClass(Class listProxyClass)
    {
        _listProxyConstructor = retrieveCollectionProxyConstructor(listProxyClass, List.class, "ListProxyClass");
    }
    
    /**
     * Returns the set proxy class.
     * 
     * @return The class used for set proxies
     */
    public static Class getSetProxyClass()
    {
        return getSetProxyConstructor().getDeclaringClass();
    }

    /**
     * Returns the constructor of the set proxy class.
     * 
     * @return The constructor for set proxies
     */
    private static Constructor getSetProxyConstructor()
    {
        if (_setProxyConstructor == null)
        {
            setSetProxyClass(getProxyConfiguration().getSetProxyClass());
        }
        return _setProxyConstructor;
    }

    /**
     * Dets the proxy class to use for collection classes that implement the {@link Set} interface.
     *
     * @param setProxyClass The proxy class
     */
    public static void setSetProxyClass(Class setProxyClass)
    {
        _setProxyConstructor = retrieveCollectionProxyConstructor(setProxyClass, Set.class, "SetProxyClass");
    }

    /**
     * Returns the collection proxy class.
     * 
     * @return The class used for collection proxies
     */
    public static Class getCollectionProxyClass()
    {
        return getCollectionProxyConstructor().getDeclaringClass();
    }

    /**
     * Returns the constructor of the generic collection proxy class.
     * 
     * @return The constructor for collection proxies
     */
    private static Constructor getCollectionProxyConstructor()
    {
        if (_collectionProxyConstructor == null)
        {
            setCollectionProxyClass(getProxyConfiguration().getCollectionProxyClass());
        }
        return _collectionProxyConstructor;
    }

    /**
     * Dets the proxy class to use for generic collection classes implementing the {@link java.util.Collection} interface.
     *
     * @param collectionProxyClass The proxy class
     */
    public static void setCollectionProxyClass(Class collectionProxyClass)
    {
        _collectionProxyConstructor = retrieveCollectionProxyConstructor(collectionProxyClass, Collection.class, "CollectionProxyClass");
        // we also require the class to be a subclass of ManageableCollection
        if (!ManageableCollection.class.isAssignableFrom(collectionProxyClass))
        {
            throw new MetadataException("Illegal class "+collectionProxyClass.getName()+
                                        " specified for CollectionProxyClass. Must be a concrete subclass of "+
                                        ManageableCollection.class.getName());
        }
    }

    /**
     * Determines which proxy to use for the given collection class (list, set or generic collection proxy).
     * 
     * @param collectionClass The collection class
     * @return The constructor of the proxy class
     */
    private static Constructor getCollectionProxyConstructor(Class collectionClass)
    {
        if (List.class.isAssignableFrom(collectionClass))
        {
            return getListProxyConstructor();
        }
        else if (Set.class.isAssignableFrom(collectionClass))
        {
            return getSetProxyConstructor();
        }
        else
        {
        	return getCollectionProxyConstructor();
        }
    }

    /**
     * Create a Collection Proxy for a given query.
     * 
     * @param brokerKey       The key of the persistence broker
     * @param query           The query
     * @param collectionClass The class to build the proxy for
     * @return The collection proxy
     */
    public static ManageableCollection createCollectionProxy(PBKey brokerKey, Query query, Class collectionClass)
    {
        Object args[] = { brokerKey, collectionClass, query };

        try
        {
            return (ManageableCollection)getCollectionProxyConstructor(collectionClass).newInstance(args);
        }
        catch (InstantiationException ex)
        {
            throw new PersistenceBrokerException("Exception while creating a new collection proxy instance", ex);
        }
        catch (InvocationTargetException ex)
        {
            throw new PersistenceBrokerException("Exception while creating a new collection proxy instance", ex);
        }
        catch (IllegalAccessException ex)
        {
            throw new PersistenceBrokerException("Exception while creating a new collection proxy instance", ex);
        }
    }
}
