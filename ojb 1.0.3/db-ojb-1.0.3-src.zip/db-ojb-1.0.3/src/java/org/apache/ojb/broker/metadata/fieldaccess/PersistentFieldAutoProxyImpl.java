package org.apache.ojb.broker.metadata.fieldaccess;

/* Copyright 2003-2004 The Apache Software Foundation
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

import java.lang.reflect.Field;
import java.lang.reflect.Member;

import org.apache.commons.beanutils.DynaBean;
import org.apache.ojb.broker.metadata.MetadataException;
import org.apache.ojb.broker.util.ClassHelper;

/**
 * PeristentField implementation that attempts to detect the nature of
 * the field it is persisting.
 * <p>
 * First checks to see if it is a Field, then Property, then DynaBean
 * <p>
 * It will match in that order.
 */
public class PersistentFieldAutoProxyImpl extends AbstractPersistentField
{
    private static final long serialVersionUID = 6148669985786992032L;

    /** The actual field handler */
    private AbstractPersistentField wrapped;
    /** Whether we actually found a field handler, or it is still the default one */
    private boolean hasBeenDetermined = false;
    
    /**
     * Being nice to Class.newInstance() seems popular.
     */
    public PersistentFieldAutoProxyImpl()
    {
        super();
    }

    /**
     * Creates a new auto handler object for the indicated field.
     * 
     * @param type      The type of the object containing the field
     * @param fieldName The name of the field
     */
    public PersistentFieldAutoProxyImpl(Class type, String fieldName)
    {
        super(type, fieldName);
    }

    /**
     * Creates an instance of the given field handler type.
     * 
     * @param handlerType The field handler type
     * @return The handler instance
     * @throws MetadataException If the handler could not be found, or cannot handle the field
     */
    private AbstractPersistentField getFieldImpl(Class handlerType) throws MetadataException
    {
        Class[]  types = { Class.class, String.class };
        Object[] args  = { rootObjectType, fieldName };

        try
        {
            return (AbstractPersistentField)ClassHelper.newInstance(handlerType, types, args);
        }
        catch (Exception ex)
        {
            if (ex instanceof MetadataException)
            {
                throw (MetadataException)ex;
            }
            else
            {
                throw new MetadataException(ex);
            }
        }
    }

    /**
     * Returns an instance of the field-direct handler.
     * 
     * @return The handler instance
     * @throws MetadataException If the handler could not be found, or cannot handle the field
     */
    private AbstractPersistentField getDirectImpl() throws MetadataException
    {
        return getFieldImpl(PersistentFieldDirectAccessImpl.class);
    }

    /**
     * Returns an instance of the privileged field-direct handler.
     * 
     * @return The handler instance
     * @throws MetadataException If the handler could not be found, or cannot handle the field
     */
    private AbstractPersistentField getPrivilegedDirectImpl() throws MetadataException
    {
        return getFieldImpl(PersistentFieldPrivilegedImpl.class);
    }

    /**
     * Returns an instance of the dyna bean handler.
     * 
     * @return The handler instance
     * @throws MetadataException If the handler could not be found, or cannot handle the field
     */
    private AbstractPersistentField getDynaBeanImpl() throws MetadataException
    {
        return getFieldImpl(PersistentFieldDynaBeanAccessImpl.class);
    }

    /**
     * Returns an instance of the bean-property handler.
     * 
     * @return The handler instance
     * @throws MetadataException If the handler could not be found, or cannot handle the field
     */
    private AbstractPersistentField getPropertyImpl() throws MetadataException
    {
        return getFieldImpl(PersistentFieldIntrospectorImpl.class);
    }

    /**
     * Returns the actual field handler. If none is determined yet, it first tries to
     * find one for the field.
     * 
     * @return The wrapped field handler
     * @throws MetadataException If no handler for the field could be found
     */
    private AbstractPersistentField getWrapped() throws MetadataException
    {
        // 1. direct field 
        // 2. bean
        // 3. dyna bean
        if (wrapped != null)
        {
            return wrapped;
        }

        /*
         * this switches on a series of exceptions. Sadly, it is the only real way to detect
         * which one works. --Brian
         */

        try
        {
            Field           field   = AbstractPersistentField.computeField(rootObjectType, fieldName, isNestedField(), false);
            SecurityManager manager = System.getSecurityManager();

            // ok we have a real field,
            // however, for non-public fields we have to check whether we're allowed to access
            // it directly; this is guarded by the security manager, so we ask it
            try
            {
                if ((manager != null) && !field.isAccessible())
                {
                    // this throws an exception if we're not allowed to the access the declared members
                    manager.checkMemberAccess(field.getDeclaringClass(), Member.DECLARED);
                }
                // no security manager or we're allowed to access the field
                wrapped = getDirectImpl();
            }
            catch (SecurityException ex)
            {
                wrapped = getPrivilegedDirectImpl();
            }
            hasBeenDetermined = true;
            return wrapped;
        }
        catch (MetadataException ex)
        {
            // no direct field to use
        }

        try
        {
            if (PersistentFieldIntrospectorImpl.findPropertyDescriptor(rootObjectType, fieldName) != null)
            {
                wrapped           = getPropertyImpl();
                hasBeenDetermined = true;
                return wrapped;
            }
        }
        catch (MetadataException ex)
        {
            // no bean property either
        }

        // Only option left is for it to be a dynabean which we'll use as the default
        // as we can check it only when actually doing something
        // of course, we can only use the dyna bean if the library is present
        try
        {
            wrapped = getDynaBeanImpl();
            return wrapped;
        }
        catch (NoClassDefFoundError ex)
        {
            String message = "Could not use dyna beans (not in classpath), and no field or property matches " + rootObjectType.getName() + "." + fieldName;

            getLog().error(message);
            throw new MetadataException(message);
        }
    }

    /**
     * Returns the wrapped field handler. This method is also able to check whether the default
     * handler (dyna bean) can actually be used as it has an actual object whose field shall be
     * accessed (which then must be a dyna bean).
     * 
     * @param targetObject The object whose field is accessed
     * @return The wrapped field handler
     * @throws MetadataException If no handler for the field could be found
     */
    private AbstractPersistentField getWrapped(Object targetObject) throws MetadataException
    {
        // ensure that we at least tried to find the handler
        AbstractPersistentField result = getWrapped();

        if (!hasBeenDetermined)
        {
            // still the default handler, so this is the first time that we can check for dyna beans
            if (targetObject instanceof DynaBean)
            {
                // the default dyna bean is ok
                hasBeenDetermined = true;
            }
            else
            {
                // no handler could be found -> error
                String message = "No field, property, or DynaProperty can be found to match " + rootObjectType.getName() + "." + fieldName;

                getLog().error(message);
                throw new MetadataException(message);
            }
        }
        return result;
    }

    /* These are all the implementation methods delagating to the wrapped impl*/

    /**
     * Set the field value for the given target object.
     * 
     * @param targetObject The object that contains the field to set
     * @param value        The value to set
     */
    public void doSet(Object targetObject, Object value)
    {
        getWrapped(targetObject).doSet(targetObject, value);
    }

    /**
     * Gets the field value from the given target object.
     * 
     * @param targetObject The object that contains the field to set
     * @return The field's value
     */
    public Object doGet(Object targetObject)
    {
        return getWrapped(targetObject).doGet(targetObject);
    }

    public Class getDeclaringClass()
    {
        return getWrapped().getDeclaringClass();
    }

    public boolean usesAccessorsAndMutators()
    {
        return getWrapped().usesAccessorsAndMutators();
    }

    public String getName()
    {
        return getWrapped().getName();
    }

    public Class getType()
    {
        return getWrapped().getType();
    }

    public boolean makeAccessible()
    {
        return getWrapped().makeAccessible();
    }

    public String toString()
    {
        return getWrapped().toString();
    }
}
