package org.apache.ojb.broker;

import org.apache.ojb.broker.metadata.ClassDescriptor;

/**
 * Builds {@link org.apache.ojb.broker.Identity} objects to identify persistence capable objects within OJB.
 * In many cases the primary key (based on metadata declaration) of an object is known
 * and the whole object should be materialized (e.g. findByPrimaryKey(...) calls).
 * This class make available a bunch of methods help to create {@link org.apache.ojb.broker.Identity}
 * objects based on
 * <ul>
 *    <li>the persistence capable object itself</li>
 *    <li>the primary key values of a persistence capable object</li>
 * </ul>
 * NOTE:
 * <br/>
 * It is possible to assign new created objects
 * with a valid UID before they are written to database - more info see {@link org.apache.ojb.broker.Identity}.
 * This should be
 * used with care, because not all {@link org.apache.ojb.broker.util.sequence.SequenceManager}
 * implementations return the "real" UID value before the object was stored (e.g. when database based
 * Identity columns are used, a temporary placeholder is returned).
 *
 * @author <a href="mailto:armin@codeAuLait.de">Armin Waibel</a>
 * @version $Id: IdentityFactory.java,v 1.2.2.2 2005/03/23 12:39:57 arminw Exp $
 */
public interface IdentityFactory
{
    /**
     * Build a unique {@link org.apache.ojb.broker.Identity} for the given
     * persistence capable object.
     *
     * @param obj The object to build the {@link Identity} for.
     * @return The a new created <em>Identity</em> object.
     */
    Identity buildIdentity(Object obj);

    /**
     * Build a unique {@link org.apache.ojb.broker.Identity} for the given
     * persistence capable object.
     *
     * @param cld The {@link org.apache.ojb.broker.metadata.ClassDescriptor} of the
     * object.
     * @param obj The object to build the {@link Identity} for.
     * @return The a new created <em>Identity</em> object.
     */
    Identity buildIdentity(ClassDescriptor cld, Object obj);

    /**
     * Build a unique {@link org.apache.ojb.broker.Identity}
     * for the given primary key values (composite PK's) of a
     * persistence capable object.
     *
     * @param realClass The class of the associated object.
     * @param topLevelClass The top-level class of the associated object.
     * @param pkFieldName The field names of the PK fields.
     * @param pkValues The PK values.
     * @return The a new created <em>Identity</em> object.
     */
    Identity buildIdentity(Class realClass, Class topLevelClass, String[] pkFieldName, Object[] pkValues);

    /**
     * Convenience method for
     * {@link #buildIdentity(java.lang.Class, java.lang.Class, java.lang.String[], java.lang.Object[])}
     */
    Identity buildIdentity(Class realClass, String[] fieldName, Object[] pkValues);

    /**
     * Convenience method for persistent objects with single primary key.
     * NOTE: Do not use for objects with composed PK!
     *
     * @param realClass The class of the associated object.
     * @param pkValue The PK value.
     * @return The a new created <em>Identity</em> object.
     * @see #buildIdentity(java.lang.Class, java.lang.String[], java.lang.Object[])
     */
    Identity buildIdentity(Class realClass, Object pkValue);

    /**
     * Create a new {@link Identity} object based on given arguments - NOTE: There
     * will be no check to resolve the order of the PK values. This method expect
     * the correct order.
     *
     * @param realClass The class of the associated object.
     * @param topLevelClass The top-level class of the associated object.
     * @param pkValues The PK values.
     * @return The a new created <em>Identity</em> object.
     */
    Identity buildIdentity(Class realClass, Class topLevelClass, Object[] pkValues);
}
