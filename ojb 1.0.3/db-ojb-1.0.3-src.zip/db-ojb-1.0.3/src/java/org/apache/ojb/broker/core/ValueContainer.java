package org.apache.ojb.broker.core;

import java.io.Serializable;

import org.apache.ojb.broker.metadata.JdbcType;
import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;

/* Copyright 2003-2004 The Apache Software Foundation
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
public final class ValueContainer implements Serializable
{
    private static final long serialVersionUID = 3689069556052340793L;
  
    private JdbcType m_jdbcType;
    private Object m_value;

    public ValueContainer(Object value, JdbcType jdbcType)
    {
        setJdbcType(jdbcType);
        setValue(value);
    }

    public JdbcType getJdbcType()
    {
        return m_jdbcType;
    }

    public void setJdbcType(JdbcType jdbcType)
    {
        this.m_jdbcType = jdbcType;
    }

    public Object getValue()
    {
        return m_value;
    }

    public void setValue(Object value)
    {
        if (value instanceof ValueContainer)
        {
            throw new RuntimeException("We can't nest ValueContainers");
        }
        this.m_value = value;
    }

    public boolean equals(Object obj)
    {
        if(obj == this) return true;
        boolean result = false;
        if(obj instanceof ValueContainer)
        {
            ValueContainer container = (ValueContainer) obj;
            // if jdbcType was null, we can't compare
            result = this.m_jdbcType != null ? this.m_jdbcType.equals(container.getJdbcType()) : false;
            if(result)
            {
                result = this.m_value == null ? null == container.getValue() : this.m_value.equals(container.getValue());
                result = new EqualsBuilder().append(this.m_value, container.getValue()).isEquals();
            }
        }
        return result;
    }

    public int hashCode()
    {
//        int hash =  m_value != null ? m_value.hashCode() : 0;
//        hash += m_jdbcType != null ? m_jdbcType.hashCode() : 0;
//        return hash;
        return new HashCodeBuilder().append(m_jdbcType).append(m_value).toHashCode();
    }

    public String toString()
    {
        return this.getClass().getName() + "[jdbcType: "
        + m_jdbcType
        + ", value: " + m_value + "]";
    }

}
