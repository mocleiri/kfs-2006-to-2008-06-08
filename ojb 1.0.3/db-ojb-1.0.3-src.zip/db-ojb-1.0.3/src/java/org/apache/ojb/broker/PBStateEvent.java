package org.apache.ojb.broker;

/* Copyright 2003-2004 The Apache Software Foundation
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

import org.apache.commons.lang.builder.ToStringBuilder;


/**
 * The <code>PBStateEvent</code> encapsulates information about
 * the life-cycle/transaction demarcation of the used {@link org.apache.ojb.broker.PersistenceBroker}
 * instance.
 *
 * @author <a href="mailto:armin@codeAuLait.de">Armin Waibel</a>
 * @version $Id: PBStateEvent.java,v 1.5 2004/04/04 23:53:30 brianm Exp $
 */
public final class PBStateEvent extends PersistenceBrokerEvent
{
    public static final int KEY_BEFORE_CLOSE = 1;
    public static final int KEY_BEFORE_BEGIN = 2;
    public static final int KEY_BEFORE_COMMIT = 3;
    public static final int KEY_BEFORE_ROLLBACK = 4;
    public static final int KEY_AFTER_BEGIN = 5;
    public static final int KEY_AFTER_COMMIT = 6;
    public static final int KEY_AFTER_OPEN = 7;
    public static final int KEY_AFTER_ROLLBACK = 8;

    private Type eventType;

    public PBStateEvent(PersistenceBroker broker, Type eventType)
    {
        super(broker);
        this.eventType = eventType;
    }

    public String toString()
    {
        ToStringBuilder buf = new ToStringBuilder(this);
        buf.append("type", eventType.toString()).
                append("source object", getSource());
        return buf.toString();
    }

    public Type getEventType()
    {
        return eventType;
    }

    //**********************************************************************
    // Immutable inner class
    //**********************************************************************
    public static class Type
    {
        /**
         * Caused after a <code>PersistenceBroker transaction</code> was started.
         */
        public static final Type BEFORE_BEGIN = new Type(KEY_BEFORE_BEGIN);
        /**
         * Caused after a <code>PersistenceBroker transaction</code> was started.
         */
        public static final Type AFTER_BEGIN = new Type(KEY_AFTER_BEGIN);
        /**
         * Caused before a <code>PersistenceBroker commit</code> was called.
         */
        public static final Type BEFORE_COMMIT = new Type(KEY_BEFORE_COMMIT);
        /**
         * Caused after a <code>PersistenceBroker commit</code> was called.
         */
        public static final Type AFTER_COMMIT = new Type(KEY_AFTER_COMMIT);
        /**
         * Caused before a <code>PersistenceBroker rollback</code> was called.
         */
        public static final Type BEFORE_ROLLBACK = new Type(KEY_BEFORE_ROLLBACK);
        /**
         * Caused after a <code>PersistenceBroker roolback</code> was called.
         */
        public static final Type AFTER_ROLLBACK = new Type(KEY_AFTER_ROLLBACK);
        /**
         * Caused after the {@link org.apache.ojb.broker.PersistenceBroker}
         * instance was obtained from pool.
         */
        public static final Type AFTER_OPEN = new Type(KEY_AFTER_OPEN);
        /**
         * Caused before the {@link org.apache.ojb.broker.PersistenceBroker}
         * instance was returned to pool.
         */
        public static final Type BEFORE_CLOSE = new Type(KEY_BEFORE_CLOSE);

        private int type;

        protected Type(int id)
        {
            this.type = id;
        }

        public final boolean equals(Object obj)
        {
            if (obj == this)
            {
                return true;
            }
            if (!(obj instanceof PBStateEvent))
            {
                return false;
            }

            return type == ((Type) obj).type;
        }

        public final int hashCode()
        {
            return type;
        }
        
        /**
         * Returns an unique identifier of the used type.
         */
        public final int typeId()
        {
            return type;
        }

        public String toString()
        {
            return this.getClass().getName() + " [type= " + typeAsName(type) + "]";
        }

        private String typeAsName(int aType)
        {
            if (aType == KEY_AFTER_BEGIN)
                return "AFTER_BEGIN";
            else if (aType == KEY_AFTER_COMMIT)
                return "AFTER_COMMIT";
            else if (aType == KEY_AFTER_OPEN)
                return "AFTER_OPEN";
            else if (aType == KEY_AFTER_ROLLBACK)
                return "AFTER_ROLLBACK";
            else if (aType == KEY_BEFORE_BEGIN)
                return "BEFORE_BEGIN";
            else if (aType == KEY_BEFORE_CLOSE)
                return "BEFORE_CLOSE";
            else if (aType == KEY_BEFORE_COMMIT)
                return "BEFORE_COMMIT";
            else if (aType == KEY_BEFORE_ROLLBACK)
                return "BEFORE_ROLLBACK";
            else
            {
                throw new OJBRuntimeException("Could not find type " + aType);
            }
        }
    }
}
