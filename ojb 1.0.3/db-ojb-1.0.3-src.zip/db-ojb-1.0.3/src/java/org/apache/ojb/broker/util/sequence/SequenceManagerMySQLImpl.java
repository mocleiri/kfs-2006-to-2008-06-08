package org.apache.ojb.broker.util.sequence;
/* Copyright 2002-2004 The Apache Software Foundation
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
import java.math.BigDecimal;
import java.sql.Date;
import java.sql.SQLException;
import java.sql.Time;
import java.sql.Timestamp;
import java.sql.Types;
import java.util.Iterator;
import java.util.Vector;

import org.apache.ojb.broker.PersistenceBroker;
import org.apache.ojb.broker.PersistenceBrokerException;
import org.apache.ojb.broker.accesslayer.JdbcAccess;
import org.apache.ojb.broker.accesslayer.ResultSetAndStatement;
import org.apache.ojb.broker.core.proxy.ProxyHelper;
import org.apache.ojb.broker.metadata.ClassDescriptor;
import org.apache.ojb.broker.metadata.FieldDescriptor;
import org.apache.ojb.broker.metadata.ObjectReferenceDescriptor;
import org.apache.ojb.broker.metadata.fieldaccess.PersistentField;
import org.apache.ojb.broker.query.Query;
import org.apache.ojb.broker.util.logging.Logger;
import org.apache.ojb.broker.util.logging.LoggerFactory;

/**
 * MySQL SequenceManager for use with auto_increment columns.
 * <p>
 * <b>WARNING:</b> Not thoroughly tested, use at own risk.  ;-)
 * <br/>
 * Native key generation is not extent aware if the extent persistent
 * objects using different database tables.
 *
 * <p>
 * Implementation configuration properties:
 * </p>
 *
 * <table cellspacing="2" cellpadding="2" border="3" frame="box">
 * <tr>
 *     <td><strong>Property Key</strong></td>
 *     <td><strong>Property Values</strong></td>
 * </tr>
 * <tr>
 *     <td>none</td>
 *     <td>
 *
 *    </td>
 * </tr>
 * </table>
 * <br/>
 * <br/>
 *
 * @deprecated this SequenceManager implementation is outdated and will be removed,
 * use {@link SequenceManagerNativeImpl} instead
 *
 * @author Travis Reeder - travis@spaceprogram.com
 * @version $Id: SequenceManagerMySQLImpl.java,v 1.21 2004/05/22 11:24:51 brj Exp $
 *
 */
public class SequenceManagerMySQLImpl implements SequenceManager
{
    private Logger log = LoggerFactory.getLogger(SequenceManagerMySQLImpl.class);

    /**
     * reference to the PersistenceBroker
     */
    protected PersistenceBroker broker;

    public SequenceManagerMySQLImpl(PersistenceBroker broker)
    {
        this.broker = broker;
    }

    /**
     * Returns next Id get from "sequence sequence.NextVal from Dual".
     * Mount sequence name as:
     * Schema.SQ_tableName_fieldName. If you have a table named MY_TABLE
     * and the sequenced field is MY_FIELD on schema MY_SCHEMA, the command
     * to create the sequence is:
     * CREATE SEQUENCE MY_SCHEMA.SQ_MY_TABLE_MY_FIELD
     */
    private synchronized int getNextId(FieldDescriptor field) 
    {
        return 0;
    }

    /**
     * returns a unique int for class clazz and field fieldName.
     * the returned uid is unique accross all tables in the extent of clazz.
     */
    public int getUniqueId(FieldDescriptor field) 
    {
        return getNextId(field);
    }

    /**
     * returns a unique String for class clazz and field fieldName.
     * the returned uid is unique accross all tables in the extent of clazz.
     *
     */
    protected String getUniqueString(FieldDescriptor field)
    {
        return Integer.toString(getUniqueId(field));
    }

    /**
     * returns a unique long value for class clazz and field fieldName.
     * the returned number is unique accross all tables in the extent of clazz.
     */
    protected long getUniqueLong(FieldDescriptor field)
    {
        return getUniqueId(field);
    }

    /**
     * returns a unique Object for class clazz and field fieldName.
     * the returned Object is unique accross all tables in the extent of clazz.
     */
    protected Object getUniqueObject(FieldDescriptor field)
    {
        return null; //getUniqueString(clazz, fieldName);
    }

    public void afterStore(JdbcAccess dbAccess, ClassDescriptor cld, Object obj) throws SequenceManagerException
    {
        FieldDescriptor[] fldArr = cld.getAutoIncrementFields();
        FieldDescriptor fd = fldArr.length > 0 ? fldArr[0] : null;
        if(fd != null)
		{ // an autoinc column exists
			ResultSetAndStatement rsStmt = null;
            try
            {
				rsStmt = dbAccess.executeSQL("SELECT LAST_INSERT_ID() as newid FROM " + cld.getFullTableName(), cld, Query.NOT_SCROLLABLE);
                int newid = 0;
                if (rsStmt.m_rs.next())
                {
                    newid = rsStmt.m_rs.getInt("newid");
                }
                rsStmt.m_rs.close();
                if(log.isDebugEnabled()) log.debug("After store - newid=" + newid);

                PersistentField pf = fd.getPersistentField();
                pf.set(obj, new Integer(newid));
            }
            catch (PersistenceBrokerException e)
            {
				throw new SequenceManagerException(e);
            }
            catch (SQLException e)
            {
                throw new SequenceManagerException(e);
            }
			finally
			{
				rsStmt.close();
			}
        }

    }

    public void setReferenceFKs(Object obj, ClassDescriptor cld) throws SequenceManagerException
    {

        Vector objectReferenceDescriptors = cld.getObjectReferenceDescriptors();
        // get all members of obj that are references and assign FKs
        Iterator i = objectReferenceDescriptors.iterator();
        while (i.hasNext())
        {
            ObjectReferenceDescriptor rds =
                    (ObjectReferenceDescriptor) i.next();
            Object ref = rds.getPersistentField().get(obj);
            if(ref != null){ // make sure the ref object actually exists
                assertFkAssignment(obj, cld, ref, rds);
            }
        }
    }

    /**
     *
     * @param obj
     * @param cld
     * @param ref the object that is the reference descriptor
     * @param rds
     */
    private void assertFkAssignment(Object obj, ClassDescriptor cld, Object ref, ObjectReferenceDescriptor rds)
    {
    	// avoid problems with proxy instances
        Class c = ProxyHelper.getRealClass(ref);

        // get ClassDescriptor for RefDescriptor object
        ClassDescriptor refCld =
                broker.getDescriptorRepository().getDescriptorFor(c);
        ClassDescriptor objCld = cld;

        // get all the fielddescriptors in the objects that reference this one so we can set the new id
        FieldDescriptor[] objFkFields =
                rds.getForeignKeyFieldDescriptors(objCld);
        if (objFkFields != null)
        {
            FieldDescriptor refFld = refCld.getAutoIncrementFields()[0];
            FieldDescriptor fld = null;
            for (int i = 0; i < objFkFields.length; i++)
            {
                fld = objFkFields[i];
                fld.getPersistentField().set(obj, refFld.getPersistentField().get(ref));
            }
        }
    }

    /**
     * Returns a unique object for the given field attribute.
     * The returned value takes in account the jdbc-type
     * and the FieldConversion.sql2java() conversion defined for <code>field</code>.
     * The returned object is unique accross all tables in the extent
     * of class the field belongs to.
     */
    public Object getUniqueValue(FieldDescriptor field) throws SequenceManagerException
    {
    	Object result = null;
    	switch (field.getJdbcType().getType())
    	{
    		case Types.ARRAY:
    		{
    			Object[] arr = {getUniqueString(field)};
    			result = arr;
    			break;
    		}
    		case Types.BIGINT:
    		{
    			result = new Long(getUniqueLong(field));
    			break;
    		}
    		case Types.BINARY:
    		{
    			result = getUniqueString(field).getBytes();
    			break;
    		}
    		case Types.CHAR:
    		{
    			result = getUniqueString(field);
    			break;
    		}
    		case Types.DATE:
    		{
    			result = new Date(getUniqueLong(field));
    			break;
    		}
    		case Types.DECIMAL:
    		{
    			result = new BigDecimal(getUniqueLong(field));
    			break;
    		}
    		case Types.DOUBLE:
    		{
    			result = new Double(getUniqueLong(field));
    			break;
    		}
    		case Types.FLOAT:
    		{
    			result = new Double(getUniqueLong(field));
    			break;
    		}
    		case Types.INTEGER:
    		{
    			result = new Integer(getUniqueId(field));
    			break;
    		}
    		case Types.JAVA_OBJECT:
    		{
    			result = getUniqueObject(field);
    			break;
    		}
    		case Types.LONGVARBINARY:
    		{
    			result = getUniqueString(field).getBytes();
    			break;
    		}
    		case Types.LONGVARCHAR:
    		{
    			result = getUniqueString(field);
    			break;
    		}
    		case Types.NUMERIC:
    		{
    			result = new BigDecimal(getUniqueLong(field));
    			break;
    		}
    		case Types.REAL:
    		{
    			result = new Float(getUniqueLong(field));
    			break;
    		}
    		case Types.SMALLINT:
    		{
    			result = new Short((short)getUniqueId(field));
    			break;
    		}
    		case Types.TIME:
    		{
    			result = new Time(getUniqueLong(field));
    			break;
    		}
    		case Types.TIMESTAMP:
    		{
    			result = new Timestamp(getUniqueLong(field));
    			break;
    		}
    		case Types.TINYINT:
    		{
    			result = new Byte((byte)getUniqueId(field));
    			break;
    		}
    		case Types.VARBINARY:
    		{
    			result = getUniqueString(field).getBytes();
    			break;
    		}
    		case Types.VARCHAR:
    		{
    			result = getUniqueString(field);
    			break;
    		}
    		default:
    		{
    			result = getUniqueString(field);
    			break;
    		}
    	}
    	result = field.getFieldConversion().sqlToJava(result);
        return result;
    }
}
