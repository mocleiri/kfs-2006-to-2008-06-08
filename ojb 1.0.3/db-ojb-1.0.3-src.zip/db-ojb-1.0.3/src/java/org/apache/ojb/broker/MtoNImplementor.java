package org.apache.ojb.broker;

/* Copyright 2003-2004 The Apache Software Foundation
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */


import org.apache.ojb.broker.core.proxy.ProxyHelper;
import org.apache.ojb.broker.metadata.CollectionDescriptor;

/**
 * Helper class to handle single m:n relation entries (m:n indirection table entries).
 *
 * @author <a href="leandro@ibnetwork.com.br">Leandro Rodrigo Saad Cruz</a>
 * @version $Id: MtoNImplementor.java,v 1.7.2.2 2005/03/18 19:25:05 arminw Exp $
 */
public class MtoNImplementor
{
    private Object leftObject;
    private Object rightObject;
    private Class leftClass;
    private Class rightClass;
    //private CollectionDescriptor collectionDesc;
    //private PersistenceBroker broker;

    /**
     * @deprecated
     */
    public MtoNImplementor(PersistenceBroker pb, CollectionDescriptor cod, Object left, Object right)
    {
        init(left, right);
    }

    /**
     * @deprecated
     */
    public MtoNImplementor(PersistenceBroker pb, String collectionName, Object left, Object right)
    {
        //CollectionDescriptor cod = pb.getClassDescriptor(ProxyHelper.getRealClass(leftObject)).getCollectionDescriptorByName(collectionName);
        init(left, right);
    }

    public MtoNImplementor(Object leftObject, Object rightObject)
    {
        init(leftObject, rightObject);
    }

    private void init(Object left, Object right)
    {
        if(left == null || right == null)
        {
            throw new IllegalArgumentException("both objects must exist");
        }

        //broker = pb;
        //collectionDesc = cod;
        leftObject = left;
        rightObject = right;
        leftClass = ProxyHelper.getRealClass(leftObject);
        rightClass = ProxyHelper.getRealClass(rightObject);
    }

    public Class getLeftClass()
    {
        return leftClass;
    }

    public Class getRightClass()
    {
        return rightClass;
    }

    public Object getLeftObject()
    {
        return leftObject;
    }

    public Object getRightObject()
    {
        return rightObject;
    }

//    public CollectionDescriptor getCollectionDescriptor()
//    {
//        return collectionDesc;
//    }

//	/**
//	 *
//	 * @param mnKeys
//	 * @return
//	 */
//    public String getInsertStmt(Collection mnKeys)
//    {
//		String[] leftPkColumns = collectionDesc.getFksToThisClass();
//		String[] rightPkColumns = collectionDesc.getFksToItemClass();
//		String table = collectionDesc.getIndirectionTable();
//		Key key = new Key(getRightPkValues());
//		if (mnKeys.contains(key))
//		{
//			return null;
//		}
//		return broker.serviceSqlGenerator().getInsertMNStatement(table, leftPkColumns, rightPkColumns);
//    }


//	/**
//	 *
//	 * @return an Object Array with the primary key values of the left object
//	 */
//	public Object[] getLeftPkValues()
//	{
//		ClassDescriptor leftCld = broker.getClassDescriptor(leftClass);
//        BrokerHelper bh = broker.serviceBrokerHelper();
//		return bh.extractValueArray(bh.getKeyValues(leftCld, leftObject));
//	}
//
//	/**
//	 *
//	 * @return an Object Array with the primary key values of the right object
//	 */
//	public Object[] getRightPkValues()
//	{
//		ClassDescriptor rightCld = broker.getClassDescriptor(rightClass);
//        BrokerHelper bh = broker.serviceBrokerHelper();
//		return bh.extractValueArray(bh.getKeyValues(rightCld, rightObject));
//	}

//    /**
//     * Inner class to model the key
//     */
//    private static final class Key
//    {
//
//        final Object[] m_key;
//
//        Key(final Object[] aKey)
//        {
//            m_key = new Object[aKey.length];
//
//            for (int i = 0; i < aKey.length; i++)
//            {
//                // BRJ:
//                // convert all Numbers to Long to simplify equals
//                // could lead to problems when Floats are used as key
//                if (aKey[i] instanceof Number)
//                {
//                    m_key[i] = new Long(((Number)aKey[i]).longValue());
//                }
//                else
//                {
//                    m_key[i] = aKey[i];
//                }
//            }
//        }
//
//        public boolean equals(Object other)
//        {
//            if (other == this)
//            {
//                return true;
//            }
//            if (!(other instanceof Key))
//            {
//                return false;
//            }
//
//            Key otherKey = (Key) other;
//            EqualsBuilder eb = new EqualsBuilder();
//
//            eb.append(m_key, otherKey.m_key);
//            return eb.isEquals();
//        }
//
//        public int hashCode()
//        {
//            HashCodeBuilder hb = new HashCodeBuilder();
//            hb.append(m_key);
//
//            return hb.toHashCode();
//        }
//    }
}

