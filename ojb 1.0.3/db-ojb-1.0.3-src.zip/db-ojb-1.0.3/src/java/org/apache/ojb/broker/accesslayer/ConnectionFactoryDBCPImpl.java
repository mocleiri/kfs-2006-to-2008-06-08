package org.apache.ojb.broker.accesslayer;

/* Copyright 2002-2005 The Apache Software Foundation
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

import org.apache.commons.dbcp.AbandonedConfig;
import org.apache.commons.dbcp.DriverManagerConnectionFactory;
import org.apache.commons.dbcp.PoolableConnectionFactory;
import org.apache.commons.dbcp.PoolingDataSource;
import org.apache.commons.pool.KeyedObjectPoolFactory;
import org.apache.commons.pool.ObjectPool;
import org.apache.commons.pool.KeyedPoolableObjectFactory;
import org.apache.commons.pool.impl.GenericKeyedObjectPoolFactory;
import org.apache.commons.pool.impl.GenericObjectPool;
import org.apache.commons.pool.impl.GenericKeyedObjectPool;
import org.apache.ojb.broker.metadata.JdbcConnectionDescriptor;
import org.apache.ojb.broker.util.ClassHelper;
import org.apache.ojb.broker.util.logging.Logger;
import org.apache.ojb.broker.util.logging.LoggerFactory;
import org.apache.ojb.broker.PBKey;

import javax.sql.DataSource;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;
import java.util.Collection;
import java.util.Iterator;
import java.util.Collections;

/**
 * ConnectionFactory implementation using Jakarta DBCP and Commons Pool
 * to pool driver based connections.
 *
 * Based on a proposal of Dirk Verbeek - Thanks.
 *
 * @author <a href="mailto:armin@codeAuLait.de">Armin Waibel</a>
 * @version $Id: ConnectionFactoryDBCPImpl.java,v 1.10.2.1 2005/03/16 17:51:18 mkalen Exp $
 */
public class ConnectionFactoryDBCPImpl extends ConnectionFactoryAbstractImpl
{

    private Logger log = LoggerFactory.getLogger(ConnectionFactoryDBCPImpl.class);

    /** Key=PBKey, value=ObjectPool. */
    private Map poolMap = Collections.synchronizedMap(new HashMap());
    /** Key=PBKey, value=PoolingDataSource. */
    private Map dsMap = Collections.synchronizedMap(new HashMap());
    /** Synchronize object for operations not synchronized on Map only. */
    private Object poolSynch = new Object();

    public Connection getConnectionFromPool(JdbcConnectionDescriptor jcd) throws LookupException
    {
        final DataSource ds = getDataSource(jcd);

        // Returned DS is never null, exception are logged by getDataSource and gets
        // re-thrown here since we don't catch them

        Connection conn;
        try
        {
            conn = ds.getConnection();
        }
        catch (SQLException e)
        {
            throw new LookupException("Could not get connection from DBCP DataSource", e);
        }
        return conn;
    }

    public void returnConnectionToPool(JdbcConnectionDescriptor jcd, Connection con)
            throws LookupException
    {
        try
        {
            // We are using datasources, thus close returns connection to pool
            con.close();
        }
        catch (SQLException e)
        {
            log.warn("Connection close failed", e);
        }
    }

    /**
     * Closes all managed pools.
     */
    public void releaseAllResources()
    {
        super.releaseAllResources();
        synchronized (poolSynch)
        {
            if (!poolMap.isEmpty())
            {
                Collection pools = poolMap.values();
                Iterator iterator = pools.iterator();
                ObjectPool op = null;
                while (iterator.hasNext())
                {
                    try
                    {
                        op = (ObjectPool) iterator.next();
                        op.close();
                    }
                    catch (Exception e)
                    {
                        log.error("Exception occured while closing ObjectPool " + op, e);
                    }
                }
                poolMap.clear();
            }
            dsMap.clear();
        }
    }

    /**
     * Returns the DBCP DataSource for the specified connection descriptor,
     * after creating a new DataSource if needed.
     * @param jcd the descriptor for which to return a DataSource
     * @return a DataSource, after creating a new pool if needed.
     * Guaranteed to never be null.
     * @throws LookupException if pool is not in cache and cannot be created
     */
    protected DataSource getDataSource(JdbcConnectionDescriptor jcd)
            throws LookupException
    {
        final PBKey key = jcd.getPBKey();
        DataSource ds = (DataSource) dsMap.get(key);
        if (ds == null)
        {
            // Found no pool for PBKey
            try
            {
                synchronized (poolSynch)
                {
                    // Setup new object pool
                    ObjectPool pool = setupPool(jcd);
                    poolMap.put(key, pool);
                    // Create a DBCP PoolingDataSource from the object pool
                    ds = createPoolingDataSource(pool);
                    dsMap.put(key, ds);
                }
            }
            catch (Exception e)
            {
                log.error("Could not setup DBCP DataSource for " + jcd, e);
                throw new LookupException(e);
            }
        }
        return ds;
    }

    /**
     * Returns a new ObjectPool for the specified connection descriptor.
     * Override this method to setup your own pool.
     * @param jcd the connection descriptor for which to set up the pool
     * @return a newly created object pool
     */
    protected ObjectPool setupPool(JdbcConnectionDescriptor jcd)
    {
        log.info("Create new ObjectPool for DBCP connections:" + jcd);

        try
        {
            ClassHelper.newInstance(jcd.getDriver());
        }
        catch (InstantiationException e)
        {
            log.fatal("Unable to instantiate the driver class: " + jcd.getDriver() + " in ConnectionFactoryDBCImpl!" , e);
        }
        catch (IllegalAccessException e)
        {
            log.fatal("IllegalAccessException while instantiating the driver class: " + jcd.getDriver() + " in ConnectionFactoryDBCImpl!" , e);
        }
        catch (ClassNotFoundException e)
        {
            log.fatal("Could not find the driver class : " + jcd.getDriver() + " in ConnectionFactoryDBCImpl!" , e);
        }


        // get the configuration for the connection pool
        GenericObjectPool.Config conf = jcd.getConnectionPoolDescriptor().getObjectPoolConfig();

        // First, we'll need a ObjectPool that serves as the
        // actual pool of connections.
        ObjectPool connectionPool = createObjectPool(conf);

        // Next, we'll create a ConnectionFactory that the
        // pool will use to create Connections.
        // We'll use the DriverManagerConnectionFactory,
        //
        org.apache.commons.dbcp.ConnectionFactory connectionFactory = createConnectionFactory(jcd);

        KeyedObjectPoolFactory statementPoolFactory = createStatementPoolFactory(jcd);
        // set the validation query
        String validationQuery = jcd.getConnectionPoolDescriptor().getValidationQuery();
        boolean defaultReadOnly = false;
        // set autocommit mode
        boolean defaultAutoCommit = (jcd.getUseAutoCommit() == JdbcConnectionDescriptor.AUTO_COMMIT_SET_FALSE) ?
                false : true;

        // Abandoned configuration
        AbandonedConfig ac = jcd.getConnectionPoolDescriptor().getAbandonedConfig();

        //
        // Now we'll create the PoolableConnectionFactory, which wraps
        // the "real" Connections created by the ConnectionFactory with
        // the classes that implement the pooling functionality.
        //
        PoolableConnectionFactory poolableConnectionFactory = new PoolableConnectionFactory(
                connectionFactory,
                connectionPool,
                statementPoolFactory,
                validationQuery,
                defaultReadOnly,
                defaultAutoCommit,
                ac);

        return poolableConnectionFactory.getPool();
    }

    protected ObjectPool createObjectPool(GenericObjectPool.Config config)
    {
        // We'll use a GenericObjectPool instance, although
        // any ObjectPool implementation will suffice.
        //
        // TODO: make objectPool configurable at runtime?
        return new GenericObjectPool(null, config);
    }

    protected KeyedObjectPoolFactory createStatementPoolFactory(JdbcConnectionDescriptor jcd)
    {
        final String platform = jcd.getDbms();
        if (platform.equals("Oracle9i"))
        {
            // mkalen: let the platform set Oracle-specific statement pooling
            return null;
        }

        final KeyedObjectPoolFactory stmtPoolFactory;
        final KeyedPoolableObjectFactory objectFactory = null;
        final GenericKeyedObjectPool.Config factoryConfig = new GenericKeyedObjectPool.Config();
        /*
        // TODO: mkalen: allow to configure PreparedStatement pool
        final int maxTotalStmts = 100;
        factoryConfig.maxActive = (int) (maxTotalStmts * 0.7);
        factoryConfig.maxIdle = (int) (maxTotalStmts * 0.3);
        factoryConfig.maxTotal = maxTotalStmts;
        factoryConfig.testOnBorrow = true;
        factoryConfig.testWhileIdle = true;
        factoryConfig.testOnReturn = true;
        factoryConfig.numTestsPerEvictionRun = factoryConfig.maxTotal;
        factoryConfig.minEvictableIdleTimeMillis = 30 * 1000;
        */
        stmtPoolFactory = new GenericKeyedObjectPoolFactory(objectFactory, factoryConfig);
        return stmtPoolFactory;
    }

    protected PoolingDataSource createPoolingDataSource(ObjectPool pool)
    {
        return new PoolingDataSource(pool);
    }

    protected org.apache.commons.dbcp.ConnectionFactory createConnectionFactory(JdbcConnectionDescriptor jcd)
    {
        return new ConPoolFactory(jcd);
    }

    //**************************************************************************************
    // Inner classes
    //************************************************************************************

    /**
     * Inner class used as factory for connection pooling.
     * Adhers to OJB platform specification by calling platform-specific init methods
     * on newly created connections.
     * @see DriverManagerConnectionFactory
     */
    class ConPoolFactory extends DriverManagerConnectionFactory
    {

        private final JdbcConnectionDescriptor jcd;

        public ConPoolFactory(JdbcConnectionDescriptor jcd)
        {
            super(getDbURL(jcd), jcd.getUserName(), jcd.getPassWord());
            this.jcd = jcd;
        }

        public Connection createConnection() throws SQLException
        {
            final Connection conn = super.createConnection();
            if (conn != null)
            {
                try
                {
                    initializeJdbcConnection(conn, jcd);
                }
                catch (LookupException e)
                {
                    log.error("Platform dependent initialization of connection failed", e);
                }
            }
            return conn;
        }

    }

}
