package org.apache.ojb.broker.transaction;

import javax.transaction.Transaction;

/**
 * Class give support in transaction handling.
 *
 * @author <a href="mailto:arminw@apache.org">Armin Waibel</a>
 * @version $Id: OJBTxManager.java,v 1.1 2004/05/03 23:05:56 arminw Exp $
 */
public interface OJBTxManager
{
    void registerTx(OJBTxObject obj);

    void deregisterTx(OJBTxObject obj);

    /**
     * Returns the current transaction for the calling thread or <code>null</code>
     * if no transaction was found.
     *
     * @see #getCurrentJTATransaction
     */
    Transaction getJTATransaction();

    /**
     * Returns the current transaction for the calling thread.
     *
     * @see #getJTATransaction
     * @throws TransactionNotInProgressException if no transaction was found.
     */
    Transaction getCurrentJTATransaction();
}
