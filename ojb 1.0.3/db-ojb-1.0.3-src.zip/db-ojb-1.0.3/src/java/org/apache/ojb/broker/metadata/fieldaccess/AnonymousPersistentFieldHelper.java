package org.apache.ojb.broker.metadata.fieldaccess;

/* Copyright 2003-2004 The Apache Software Foundation
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

import java.util.Iterator;
import java.util.Map;
import java.util.Vector;

import org.apache.ojb.broker.metadata.AnonymousFieldDescriptor;
import org.apache.ojb.broker.metadata.ClassDescriptor;
import org.apache.ojb.broker.metadata.CollectionDescriptor;
import org.apache.ojb.broker.metadata.DescriptorRepository;
import org.apache.ojb.broker.metadata.FieldDescriptor;
import org.apache.ojb.broker.metadata.ObjectReferenceDescriptor;

/**
 * Helper class for anonymous fields.
 *
 * @author Houar TINE
 * @version $Id: AnonymousPersistentFieldHelper.java,v 1.7.2.2 2004/12/23 22:03:25 brj Exp $
 */
public class AnonymousPersistentFieldHelper
{
    public static void computeInheritedPersistentFields(final DescriptorRepository repository)
    {
        Map descriptorTable = repository.getDescriptorTable();
        final String OBJECT = Object.class.getName();
        for (Iterator iter = descriptorTable.entrySet().iterator(); iter.hasNext();)
        {
            Map.Entry me = (Map.Entry) iter.next();
            ClassDescriptor cld = (ClassDescriptor) me.getValue();
            String baseClass = cld.getBaseClass();
            if (null != baseClass)
            {
                Vector inheritedFields = new Vector();
                do
                {
                    ClassDescriptor baseCld = repository.getDescriptorFor(baseClass);
                    FieldDescriptor[] baseFields = baseCld.getFieldDescriptions();
                    for (int i = baseFields.length - 1; i >= 0; i--)
                    {
                        FieldDescriptor f = baseFields[i];
                        if (!(f instanceof AnonymousFieldDescriptor))
                        {
                            inheritedFields.add(f.getPersistentField());
                        }
                    }
                    Vector ords = baseCld.getObjectReferenceDescriptors();
                    for (int i = ords.size() - 1; i >= 0; i--)
                    {
                        ObjectReferenceDescriptor ord = (ObjectReferenceDescriptor) ords.get(i);
                        PersistentField pf = ord.getPersistentField();
                        if (!(pf instanceof AnonymousPersistentFieldForInheritance))
                        {
                            inheritedFields.add(pf);
                        }
                    }
                    Vector cds = baseCld.getCollectionDescriptors();
                    for (int i = cds.size() - 1; i >= 0; i--)
                    {
                        CollectionDescriptor cd = (CollectionDescriptor) cds.get(i);
                        inheritedFields.add(cd.getPersistentField());
                    }
                    baseClass = baseCld.getBaseClass();
                }
                while ((null != baseClass) && !(baseClass.equals(OBJECT)));
                cld.setSuperPersistentFieldDescriptors(inheritedFields);
            }
        }
    }
}
