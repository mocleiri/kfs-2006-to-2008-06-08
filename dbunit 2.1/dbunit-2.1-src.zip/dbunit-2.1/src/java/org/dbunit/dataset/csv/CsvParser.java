package org.dbunit.dataset.csv;

import org.dbunit.dataset.csv.handlers.PipelineException;

import java.io.File;
import java.io.IOException;
import java.util.List;

/**
 * Created By:   fede
 * Date:         10-mar-2004 
 * Time:         15.50.13
 *
 * Last Checkin: $Author: fspinazzi $
 * Date:         $Date: 2004/04/06 06:51:52 $
 * Revision:     $Revision: 1.3 $
 */
public interface CsvParser {
    List parse(File file) throws IOException, CsvParserException;

    List parse(String csv) throws PipelineException, IllegalInputCharacterException;
}
