package edu.iu.uis.eden.services.docelements;

import junit.framework.TestCase;

import org.jdom.Element;

import edu.iu.uis.eden.exception.InvalidXmlException;
import edu.iu.uis.eden.services.InconsistentDocElementStateException;


public class TestOrgCodeElement extends TestCase {
  private OrgCodeElement orgCode;

  public TestOrgCodeElement(String s) {
    super(s);
  }

  protected void setUp() {
    orgCode = new OrgCodeElement();
    orgCode.setOrgCode("UNIV");
  }

  protected void tearDown() {
  }

  /**
   * given a jdom element of the correct type it should load itself to the value
   * of the given jdom element
   *
   * if the jdom element is null and allowBlanks true it should return
   *
   * if the jdom element is null and allowBlanks is false its should throw
   * an InconsistentDocElementStateException
   *
   * if the element is of the incorrect type it should throw an
   * InvalidXmlException
   */
  public void testLoadFromXMLContent() {
    //make a blank OrgCodeElement
    OrgCodeElement orgCode = new OrgCodeElement();
    String orgVal = "UNIV";

    //make a good element
    Element goodEl = new Element(orgCode.getElementName());
    goodEl.setAttribute("value", orgVal);

    try {
      orgCode.loadFromXMLContent(goodEl, false);
      assertEquals("didn't properly load props from good element", orgVal, orgCode.getOrgCode());
    } catch (Exception ex) {
      fail("threw exception loading from good element");
    }

    //give null allow blanks
    try {
      orgCode.loadFromXMLContent(null, true);
    } catch (Exception ex) {
      fail("threw exception loading null element set to allow blanks");
    }

    //give null dont allow blanks
    try {
      orgCode.loadFromXMLContent(null, false);
      fail("didn't throw InconsistentDocElementStateException " +
        "loaded with null element allowBlanks set to false");
    } catch (InconsistentDocElementStateException ex) {
    } catch (InvalidXmlException ex) {
      fail("didn't throw InconsistentDocElementStateException " +
        "loaded with null element allowBlanks set to false");
    }

    //give element of wrong type
    try {
      orgCode.loadFromXMLContent(new Element("Imbad"), false);
      fail("Didn't throw InvalidXmlException when loaded with " + "element of the wrong type");
    } catch (InconsistentDocElementStateException ex) {
      fail("Didn't throw InvalidXmlException when loaded with " + "element of the wrong type");
    } catch (InvalidXmlException ex) {
    }
  }

  /**
   * if org is null or empty validate return DocElementError otherwise returns
   * null
   */
  public void testValidate() {
    try {
      //validate the default OrgCodeElement should get null - he's good
      assertNull("Good OrgCodeElement returned DocElementError on validation",
        this.orgCode.validate());

      //make orgCode Evil
      orgCode = new OrgCodeElement();
      assertNotNull("Bad OrgCodeElement returned Null on validation expected " +
        "a DocElementError", orgCode.validate());
    } catch (Exception ex) {
      fail("threw exception validating");
    }
  }

  /**
   * if orgCode is null or blank empty String returned otherwise valid
   * XML is returned.
   */
  public void testGetXMLContent() {
    assertNotNull("Returned null when loaded", orgCode.getXMLContent());
  }

  /**
   * can the object load from the same xml in generates and arrive at the same
   * property value
   */
  public void testFeedFromOwnXML() {
    Element xmlContent = orgCode.getXMLContent();

    OrgCodeElement aOrgCode = new OrgCodeElement();

    try {
      aOrgCode.loadFromXMLContent(xmlContent, false);
    } catch (Exception ex) {
      fail("XML generated from OrgCodeElement invalid could not be loaded " + "by itself");
    }

    assertEquals("OrgCodeElement could not find value from XML it generated", orgCode.getOrgCode(),
      aOrgCode.getOrgCode());
  }

  /**
   * Just inforcing a business rule that may not be so obvious
   */
  public void testRouteControlShouldbeFalse() {
    assertEquals("OrgCodeElement is not a routeControl.  " +
      "UniversityOrganizationElement is this is a friendly warning.", false,
      orgCode.isRouteControl());
  }
}





/*
 * Copyright 2003 The Trustees of Indiana University.  All rights reserved.
 *
 * This file is part of the EDEN software package.
 * For license information, see the LICENSE file in the top level directory
 * of the EDEN source distribution.
 */
