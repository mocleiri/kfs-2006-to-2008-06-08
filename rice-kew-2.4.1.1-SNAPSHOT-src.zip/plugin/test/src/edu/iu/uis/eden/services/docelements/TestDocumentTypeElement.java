package edu.iu.uis.eden.services.docelements;

import junit.framework.TestCase;

import org.jdom.Element;
import org.jdom.output.XMLOutputter;

import edu.iu.uis.eden.WorkflowServiceErrorImpl;
import edu.iu.uis.eden.exception.InvalidXmlException;
import edu.iu.uis.eden.services.IDocElement;
import edu.iu.uis.eden.services.InconsistentDocElementStateException;
import edu.iu.uis.eden.services.ServiceErrorConstants;


public class TestDocumentTypeElement extends TestCase {
  DocumentTypeElement docType;

  public TestDocumentTypeElement(String s) {
    super(s);
  }

  protected void setUp() {
    docType = new DocumentTypeElement();
  }

  protected void tearDown() {
  }

  /**
   * is he returning the correct element
   */
  public void testGetXMLContent() {
    //he's empty and should return null
    assertNull("empty DocumentTypeElement didn't return null", docType.getXMLContent());
  }

  /**
   * yes he is.
   */
  public void testIsRouteControl() {
    assertTrue("DocumentTypeElement is not flagging as routeControl", docType.isRouteControl());
    docType.setRouteControl(false);
    assertTrue("DocumentTypeElement is not flagging as routeControl", docType.isRouteControl());
  }

  /**
   * given a jdom element of the correct type it should load itself to the value
   * of the given jdom element
   *
   * if the jdom element is null and allowBlanks true it should return
   *
   * if the jdom element is null and allowBlanks is false its should throw
   * an InconsistentDocElementStateException
   *
   * if the element is of the incorrect type it should throw an
   * InvalidXmlException
   */
  public void testLoadFromXMLContent() {
    Element element = new Element(docType.getElementName());
    Element docTypeNameEl = new Element("doc_type_full_name");
    docTypeNameEl.setAttribute("value", "AddBasRv");
    element.setAttribute("route-control", "yes");
    element.addContent(docTypeNameEl);

    try {
      docType.loadFromXMLContent(element, false);
      assertEquals("didn't properly load props from good element",
        docTypeNameEl.getAttributeValue("value"), docType.getDocumentType());
    } catch (Exception ex) {
      fail("threw exception loading from good element");
    }

    nonClassSpecificLoadFromXMLTests(docType);
  }

  /**
   * should return error on blanks null on everthing else
   */
  public void testValidate() {
    try {
      WorkflowServiceErrorImpl error = docType.validate();
      assertEquals("didnt return DocElementError w/ the proper code " + "for being blank",
        ServiceErrorConstants.DOC_TYPE_BLANK, error.getKey());

      docType.setDocumentType("AddBasRv");
      assertNull("valid DocumentTypeElement didn't return null on validate", docType.validate());
    } catch (Exception ex) {
      fail("threw exception validating");
    }
  }

  /**
   * can this guy populate himself w/ xml he made.
   */
  public void testCanFeedOnOwnXML() {
    String docTypeName = "AddBasRv";
    docType.setDocumentType(docTypeName);

    Element element = docType.getXMLContent();

    DocumentTypeElement aDocType = new DocumentTypeElement();

    try {
      aDocType.loadFromXMLContent(element, false);
      assertEquals("didn't properly load props from self made element", docTypeName,
        aDocType.getDocumentType());
    } catch (Exception ex) {
      fail("threw an exception loading from self made element");
    }
  }

  /**
   * utility method that is not object specific
   *
   * @param docElement the docElement being tested
   */
  public void nonClassSpecificLoadFromXMLTests(IDocElement docElement) {
    //give null allow blanks
    try {
      docElement.loadFromXMLContent(null, true);
    } catch (Exception ex) {
      fail("threw exception loading null element set to allow blanks");
    }

    //give null dont allow blanks
    try {
      docElement.loadFromXMLContent(null, false);
      fail("didn't throw InconsistentDocElementStateException " +
        "loaded with null element allowBlanks set to false");
    } catch (InconsistentDocElementStateException ex) {
    } catch (InvalidXmlException ex) {
      fail("didn't throw InconsistentDocElementStateException " +
        "loaded with null element allowBlanks set to false");
    }

    //give element of wrong type
    try {
      docElement.loadFromXMLContent(new Element("Imbad"), false);
      fail("Didn't throw InvalidXmlException when loaded with " + "element of the wrong type");
    } catch (InconsistentDocElementStateException ex) {
      fail("Didn't throw InvalidXmlException when loaded with " + "element of the wrong type");
    } catch (InvalidXmlException ex) {
    }
  }

  public String makeElementXMLString(Element element) {
    XMLOutputter outputter = new XMLOutputter();

    return outputter.outputString(element);
  }
}





/*
 * Copyright 2003 The Trustees of Indiana University.  All rights reserved.
 *
 * This file is part of the EDEN software package.
 * For license information, see the LICENSE file in the top level directory
 * of the EDEN source distribution.
 */
