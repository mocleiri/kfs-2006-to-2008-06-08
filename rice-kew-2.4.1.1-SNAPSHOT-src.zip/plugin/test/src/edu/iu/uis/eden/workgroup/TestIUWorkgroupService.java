package edu.iu.uis.eden.workgroup;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

import junit.framework.TestCase;

import org.apache.ojb.broker.PersistenceBroker;

import edu.iu.uis.eden.SpringServiceLocator;
import edu.iu.uis.eden.util.BrokerUtil;

public class TestIUWorkgroupService extends TestCase {

    //Constants to set up test records. Add to the array if more records are
    // needed.
    private static final Long[] WORKGROUP_IDS = { new Long(0), new Long(1), new Long(2) };
    
    private static final Integer[] WORKGROUP_VER_NBRS = { new Integer(0), new Integer(1), new Integer(2) };
    
    private static final Long[] RIDS = { new Long(0), new Long(1), new Long(2) };

    /*private static final String[] ORG_CDS = { "ORG0", "ORG1", "ORG2" };

    private static final String[] FIN_COA_CDS = { "C0", "C1", "C2" };
*/
    private static final String[] WRKGRP_NMS = { "WORKGROUP1", "WORKGROUP1", "WORKGROUP2" };

    private static final Boolean[] WRKGRP_ACTV_IND = {new Boolean(true), new Boolean(false), new Boolean(true)};

    private static final String[] WRKGRP_TYP_CDS = { "F", "X", "F"};

    private static final String[] EMPL_IDS = { "0000000000", "1000000000", "2000000000" };
    
    private static final Boolean[] WORKGROUP_CUR_INDS = {new Boolean(true), new Boolean(true), new Boolean(true)};

    IUWorkgroupService workgroupService;
    
    WorkgroupMemberService workgroupMemberService;
    
    IUWorkgroupImpl workgroup0,  workgroup1, workgroup2, workgroupFound;

    WorkgroupMember member1, member2, member3;

    List members, groupsFound;

    protected void setUp() throws Exception {
        SpringServiceLocator.setToTestMode(null);
        workgroupService = (IUWorkgroupService) SpringServiceLocator
                .getService(SpringServiceLocator.WORKGROUP_SRV);
        
        workgroupMemberService = (WorkgroupMemberService) SpringServiceLocator
        .getService(SpringServiceLocator.WORKGROUP_MEMBER_SRV);
        
        //workgroup with no members
        workgroup0 = new IUWorkgroupImpl();
        setWorkgroup(workgroup0, 0);
        workgroup0.setMembers(new ArrayList());        
        workgroupService.save(workgroup0);
        
        //workgroup with 1 member
        workgroup1 = new IUWorkgroupImpl();
        setWorkgroup(workgroup1, 1);
        
        member1 = new WorkgroupMember();
        member1.setWorkgroupId(WORKGROUP_IDS[1]);
        member1.setWorkflowId(EMPL_IDS[1]);
        member1.setWorkgroupVerNbr(WORKGROUP_VER_NBRS[1]);
        members = new ArrayList();
        members.add(member1);
        workgroup1.setMembers(members);
        workgroupService.save(workgroup1);

        //workgroup with 2 members
        workgroup2 = new IUWorkgroupImpl();
        setWorkgroup(workgroup2, 2);
        
        member2 = new WorkgroupMember();
        member2.setWorkgroupId(WORKGROUP_IDS[2]);
        member2.setWorkflowId(EMPL_IDS[1]);
        member2.setWorkgroupVerNbr(WORKGROUP_VER_NBRS[2]);
        member3 = new WorkgroupMember();
        member3.setWorkgroupId(WORKGROUP_IDS[2]);
        member3.setWorkflowId(EMPL_IDS[2]); 
        member3.setWorkgroupVerNbr(WORKGROUP_VER_NBRS[2]);
        members = new ArrayList();
        members.add(member2);
        members.add(member3);
        workgroup2.setMembers(members);
        workgroupService.save(workgroup2);
    }
    
    private void setWorkgroup(IUWorkgroupImpl workgroup, int index){        
        workgroup.setWorkgroupId(WORKGROUP_IDS[index]);
       /* workgroup.setOrgCd(ORG_CDS[index]);
        workgroup.setFinCoaCd(FIN_COA_CDS[index]);*/
        workgroup.setRouteHeaderId(RIDS[index]);
        workgroup.setWorkgroupCurInd(WORKGROUP_CUR_INDS[index]);
        workgroup.setWorkgroupName(WRKGRP_NMS[index]);
        workgroup.setActiveInd(WRKGRP_ACTV_IND[index]);
        //workgroup.setWorkgroupType(WRKGRP_TYP_CDS[index]);
        workgroup.setWorkgroupVerNbr(WORKGROUP_VER_NBRS[index]);
    }

    protected void tearDown() throws Exception {
        try {
            workgroupService.delete(workgroup0);
            workgroupService.delete(workgroup1);
            workgroupService.delete(workgroup2);
        } catch (Exception e) {
            System.out.println("tearDown() caught exception, manually cleaning up db records ...");
            PersistenceBroker broker = BrokerUtil
                    .getPersistenceBroker(BrokerUtil.EDEN_CONNECTION_KEY);
            Connection conn = broker.serviceConnectionManager().getConnection();
            PreparedStatement ps = conn
                    .prepareStatement("delete from en_wrkgrp_t where wrkgrp_id < 1003 and wrkgrp_ver_nbr < " + WORKGROUP_VER_NBRS[2]);
            ps.execute();
            ps = conn
                    .prepareStatement("delete from en_wrkgrp_mbr_t where wrkgrp_id < 1003 and wrkgrp_ver_nbr < " + WORKGROUP_VER_NBRS[2]);
            ps.execute();
            conn.close();     
            //test is bad throw the exception.
            throw e;
        }
    }

//    public void testFindByUser() {
//        UserService userService = (UserService)SpringServiceLocator.getService(SpringServiceLocator.USER_SERVICE);
//        
//        groupsFound = workgroupService.findByUser(userService.getWorkflowUser(new IUUserId(IUUserId.EMPLID,EMPL_IDS[1])));
//        assertEquals(
//                "Workgroup service doesn't find correct number of workgroups for user "
//                        + EMPL_IDS[1], 2, groupsFound.size());
//
//    }
//
//    public void testFindByFullName() {
//        String fullName = FIN_COA_CDS[0] + "." + ORG_CDS[0] + "."
//                + WRKGRP_NMS[0];
//        workgroupFound = workgroupService.findByFullName(fullName);
//        assertTrue(workgroupFound != null);
//        assertEquals("Workgroup service doesn't find workgroup with full name "
//                + fullName, WRKGRP_NMS[0], workgroupFound.getWorkgroupName());
//    }

    public void testNarrowingFind() throws Exception {
        Collection groupsFound = workgroupService.search(workgroup1, true);
        assertEquals(1, groupsFound.size());
        assertEquals(
                "Workgroup service narrowingFind() doesn't find workgroup "
                        + workgroup1.getWorkgroupId().toString(),
                WORKGROUP_IDS[1], ((IUWorkgroupImpl)groupsFound.iterator().next()).getWorkgroupId());

        IUWorkgroupImpl workgroup = new IUWorkgroupImpl();
        String fin_coa_cd = "C";
        //workgroup.setFinCoaCd(fin_coa_cd);
        groupsFound = workgroupService.search(workgroup, true);

        //expect to find all three groups
        assertEquals(
                "Workgroup service narrowingFind doesn't find workgroup with Fin_Coa_Cd like "
                        + fin_coa_cd, 3, groupsFound.size());
    }

    public void testFindByWorkgroupId(){
        Collection groupsFound = workgroupMemberService.findByWorkgroupId(WORKGROUP_IDS[0]);
        assertEquals("WorkgroupMemberService doesn't find workgroup with no members and with workgroupId " + WORKGROUP_IDS[0], 0, groupsFound.size());
        
        groupsFound = workgroupMemberService.findByWorkgroupId(WORKGROUP_IDS[1]);
        assertEquals("WorkgroupMemberService doesn't find members in workgroup " + WORKGROUP_IDS[1], 1, groupsFound.size());
        
        groupsFound = workgroupMemberService.findByWorkgroupId(WORKGROUP_IDS[2]);
        assertEquals("WorkgroupMemberService doesn't find members in workgroup " + WORKGROUP_IDS[2], 2, groupsFound.size());
    }
}