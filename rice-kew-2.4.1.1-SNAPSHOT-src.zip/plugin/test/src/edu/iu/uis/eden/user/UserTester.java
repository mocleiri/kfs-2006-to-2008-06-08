package edu.iu.uis.eden.user;

import junit.framework.TestCase;
import edu.iu.uis.eden.SpringServiceLocator;
import edu.iu.uis.eden.applicationconstants.ApplicationConstant;
import edu.iu.uis.eden.applicationconstants.ApplicationConstantsService;
import edu.iu.uis.eden.cache.ApplicationConstantsCache;
import edu.iu.uis.eden.user.impl.IUWorkflowUser;
import edu.iu.uis.eden.util.Utilities;
import edu.iu.uis.sit.cache.Cache;

public class UserTester extends TestCase {

    private UserService userService;
    private ApplicationConstantsService constantsService;

    private String authenticationName = "phooten";

    private String workflowId = "100000000000";

    protected void setUp() throws Exception {
        SpringServiceLocator.setToTestMode(null);
        Cache cache = (Cache) SpringServiceLocator.getService(SpringServiceLocator.CACHE_MANAGER);
        ApplicationConstantsCache applicationConstantsCache = new ApplicationConstantsCache();
        applicationConstantsCache.reload();
        cache.add(applicationConstantsCache);
        Utilities.seedCache(cache);
        userService = (UserService) SpringServiceLocator.getService(SpringServiceLocator.USER_SERVICE);
        constantsService = (ApplicationConstantsService) SpringServiceLocator.getService(SpringServiceLocator.CONSTANTS_SERVICE);
    }

    public void testUserFetchByAuthenticationId() throws Exception {
        WorkflowUser user = userService.getWorkflowUser(new AuthenticationUserId(authenticationName));

        assertNotNull(user);
        assertEquals(user.getAuthenticationUserId().getAuthenticationId(), authenticationName);
        assertEquals(user.getWorkflowUserId().getWorkflowId(), "100000000085");
    }

    //    public void testUserFetchByUUID() throws Exception {
    //        WorkflowUser user = userService.getWorkflowUser(new
    // IUUserId(IUUserId.UUID,"1000128501"));
    //        assertNotNull(user);
    //        assertEquals(user.getEmplId(), "0001808586");
    //        assertEquals(user.getAuthenticationId(), "jacscamp");
    //        assertEquals(user.getUuId(), "1000128501");
    //        assertEquals(user.getWorkflowId(), "100000000012");
    //    }
    //    
    //    public void testUserFetchByEmplid() throws Exception {
    //        WorkflowUser user = userService.getWorkflowUser(new
    // IUUserId(IUUserId.EMPLID,"0001808586"));
    //        assertNotNull(user);
    //        assertEquals(user.getEmplId(), "0001808586");
    //        assertEquals(user.getAuthenticationId(), "jacscamp");
    //        assertEquals(user.getUuId(), "1000128501");
    //        assertEquals(user.getWorkflowId(), "100000000012");
    //    }

    public void testUserFetchByWorkflowId() throws Exception {
        WorkflowUser user = userService.getWorkflowUser(new WorkflowUserId(workflowId));
        assertNotNull(user);
        assertEquals(user.getAuthenticationUserId().getAuthenticationId(), "nbaxter");
        assertEquals(user.getWorkflowUserId().getWorkflowId(), workflowId);
    }

    public void testUserFetchCachesCorrectly() throws Exception {
        // get the cache value and save it off in a temp...
        String minutesToSave = Utilities.getApplicationConstant("Config.Application.MinutesToCacheUsers");
        ApplicationConstant constant = constantsService.findByName("Config.Application.MinutesToCacheUsers");
        constant.setApplicationConstantValue("1");
        constantsService.save(constant);
        Thread.sleep(10 * 1000 );
        
        WorkflowUser user1 = userService.getWorkflowUser(new AuthenticationUserId("bmcgough"));
        Thread.sleep(65 * 1000 );
        WorkflowUser user2 = userService.getWorkflowUser(new AuthenticationUserId("bmcgough"));
        if (((IUWorkflowUser)user1).getLastUpdateDate().equals(((IUWorkflowUser)user2).getLastUpdateDate())) {
            fail("users last update timestamp were the same and should not have been");    
        } else {
        }
        
        WorkflowUser user3 = userService.getWorkflowUser(new AuthenticationUserId("bmcgough"));
        WorkflowUser user4 = userService.getWorkflowUser(new AuthenticationUserId("bmcgough"));
        if (((IUWorkflowUser)user3).getLastUpdateDate().equals(((IUWorkflowUser)user4).getLastUpdateDate())) {
        } else {
            fail("users last update timestamp were the same and should not have been");
        }
        
        
        constant = constantsService.findByName("Config.Application.MinutesToCacheUsers");
        constant.setApplicationConstantValue(minutesToSave);
        constantsService.save(constant);
        
        Thread.sleep(65 * 1000 );
    }
    
}