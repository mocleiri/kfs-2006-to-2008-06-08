package edu.iu.uis.eden.lookupable;

import java.lang.reflect.Field;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import junit.framework.TestCase;
import edu.iu.uis.eden.SpringServiceLocator;
import edu.iu.uis.eden.plugin.attributes.WorkflowLookupable;
import edu.iu.uis.eden.workgroup.Workgroup;
import edu.iu.uis.eden.workgroup.web.WebWorkgroup;

public class WorkGroupLookupableImplTestPENDING extends TestCase {
    private WorkflowLookupable workflowLookupable;
    private Map fieldValues;
    private Map conversionFields;

    protected void setUp() throws Exception {
        SpringServiceLocator.setToTestMode(null);
        workflowLookupable = new WorkGroupLookupableImpl();

        fieldValues = new HashMap();
        fieldValues.put("workgroup_fin_coa_cd", "BL");
        fieldValues.put("workgroupName", "BLACADFINAL1");

        conversionFields = new HashMap();
        conversionFields.put("workgroupId", "test_workgroupId");
    }

    public void testGetSearchResults() throws Exception {
        List results = workflowLookupable.getSearchResults(fieldValues, conversionFields);
        assertEquals("Too many results listed.", 1, results.size());
        WebWorkgroup workgroup = (WebWorkgroup) results.get(0);

        /*assertEquals("Chart code is incorrect.", "BL", workgroup.getFinCoaCd());
        assertEquals("Org code is incorrect.", "DFAC", workgroup.getOrgCd());*/
        assertTrue("Return parameter workgroupId is not correct or database has changed.  This was in development.", workgroup.getReturnUrl().indexOf("test_workgroupId=4086") > 0);
    }

    public void testGetColumns() {
        for (Iterator iter = workflowLookupable.getColumns().iterator(); iter.hasNext();) {
            Column column = (Column) iter.next();
            try {
                Field field = Workgroup.class.getDeclaredField(column.getPropertyName());
            } catch (NoSuchFieldException e) {
                assertTrue("Column property name on WorkGroupLookupableImpl does not equal a property on the Workgroup bean. Column: "+column.getPropertyName(), false);                
            }
        }
    }
    
    public void testGetNoReturnParams() {
        String parameters = workflowLookupable.getNoReturnParams(conversionFields);
        assertTrue("Return parameter workgroupId is not correct.", parameters.indexOf("test_workgroupId=") > 0);
    }
}
