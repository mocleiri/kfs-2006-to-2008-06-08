package edu.iu.uis.eden.user;

import java.sql.PreparedStatement;
import java.sql.ResultSet;

import junit.framework.TestCase;

import org.apache.ojb.broker.PBFactoryException;
import org.apache.ojb.broker.PersistenceBroker;
import org.apache.ojb.broker.PersistenceBrokerFactory;
import org.apache.ojb.broker.accesslayer.LookupException;

import edu.iu.uis.eden.SpringServiceLocator;
import edu.iu.uis.eden.user.impl.IUWorkflowUser;
import edu.iu.uis.eden.util.Utilities;
import edu.iu.uis.my.mygds.GdsClient;
import edu.iu.uis.my.mygds.GdsException;
import edu.iu.uis.sit.util.directory.gds.GdsPerson;
import edu.iu.uis.sit.util.directory.gds.IUEduPSEMPLID;

public class TestPopulateEdenUserNames extends TestCase {
    
    protected void setUp() throws Exception {
        SpringServiceLocator.setToTestMode(null);
    }
    
    public void testMigrateIds() throws Exception {
        PersistenceBroker broker = null;
        try {

            GdsClient gdsClient = Utilities.getGdsClient();
          
            broker = PersistenceBrokerFactory.defaultPersistenceBroker();

            System.out.println("getting ready to update user records");
            PreparedStatement ps = broker.serviceConnectionManager().getConnection().prepareStatement("select PRSN_EN_ID, PRSN_UNIV_ID, " +
                    "PRSN_NTWRK_ID, PRSN_UNVL_USR_ID, PRSN_EMAIL_ADDR, PRSN_NM, USR_CRTE_DT, USR_LST_UPDT_DT, PRSN_ID_MSNG_IND, " +
                    "DB_LOCK_VER_NBR from EN.EN_USR_T");
            ResultSet rs = ps.executeQuery();

            broker.beginTransaction();
            while (rs.next()) {
                GdsPerson gdsPerson = null;
                String emplId = null;
                try {
                     emplId = rs.getString(2);
                     gdsPerson = gdsClient.fetchGdsUser(new IUEduPSEMPLID(emplId));
                     
                } catch (GdsException e) {
                    System.out.println("Error fetching empl id" + emplId);
                }

                if (gdsPerson != null) {
                    IUWorkflowUser workflowUser = new IUWorkflowUser();
                    workflowUser.setWorkflowUserId(new WorkflowUserId(rs.getString(1)));
                    workflowUser.setEmplId(new EmplId(emplId));
                    workflowUser.setCreateDate(rs.getTimestamp(7));
                    workflowUser.setLastUpdateDate(rs.getTimestamp(8));
                    workflowUser.setIdentificationMissingIndicator(new Boolean(rs.getBoolean(9)));
                    workflowUser.setAuthenticationUserId(new AuthenticationUserId(rs.getString(3)));
                    workflowUser.setDisplayName(rs.getString(6));
                    workflowUser.setGivenName(gdsPerson.getGivenName());
                    workflowUser.setLastName(gdsPerson.getSn());
                    workflowUser.setEmailAddress(rs.getString(5));
                    workflowUser.setUuId(new UuId(rs.getString(4)));
                    workflowUser.setLockVerNbr(new Integer(rs.getInt(10)));
                    broker.store(workflowUser);
                }
            }
            broker.commitTransaction();
            rs.close();
            ps.close();
        } catch (PBFactoryException e1) {
            e1.printStackTrace();
        } catch (LookupException e1) {
            e1.printStackTrace();
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            if (broker != null) {
                broker.close();
            }
        }
    }


}