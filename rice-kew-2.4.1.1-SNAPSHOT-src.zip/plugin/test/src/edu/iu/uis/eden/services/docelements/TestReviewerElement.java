package edu.iu.uis.eden.services.docelements;

import org.jdom.Element;

import edu.iu.uis.eden.WorkflowServiceErrorImpl;
import edu.iu.uis.eden.exception.InvalidXmlException;
import edu.iu.uis.eden.services.IDocElement;
import edu.iu.uis.eden.services.InconsistentDocElementStateException;
import edu.iu.uis.eden.services.ServiceErrorConstants;


public class TestReviewerElement extends IDocInterfaceTestTemplate {
  private ReviewerElement reviewer;
  private String networkId = "rkirkend";
  private String partyType = "U";

  public TestReviewerElement(String s) {
    super(s);
  }

  protected void setUp() {
    reviewer = new ReviewerElement();
  }

  protected void tearDown() {
  }

  /**
   * for use with super class
   *
   * @return the IDocElement for this test
   */
  public IDocElement getIDocElement() {
    return reviewer;
  }

  /**
   * makes some valid xml and see if it loads up correctly.
   * super class will check for standard behavior in case of
   * invalid element
   */
  public void testLoadFromXMLContent() {
    Element me = new Element(reviewer.getElementName());

    //put this guy in without children without allowing blanks
    try {
      reviewer.loadFromXMLContent(me, false);
      fail("didn't throw InconsistentDocElementStateException when " +
        "loadFromXMLContent given a root Element with no children " +
        "and allowBlank set to false");
    } catch (InvalidXmlException ex) {
      fail("didn't throw InconsistentDocElementStateException when " +
        "loadFromXMLContent given a root Element with no children " +
        "and allowBlank set to false");
    } catch (InconsistentDocElementStateException ex) {
    }

    //load w/ just one element and allow blanks
    NetworkIdElement networkId = new NetworkIdElement();
    networkId.setNetworkId("rkirkend");
    me.addContent(networkId.getXMLContent());

    try {
      reviewer.loadFromXMLContent(me, true);
      assertEquals("didn't properly load props from valid element", networkId.getNetworkId(),
        reviewer.getNetworkId());
    } catch (Exception ex) {
      fail("threw exception loading valid element with one child " +
        "missing and allowBlank set true");
    }

    //load both and check props
    PartyTypeElement partyType = new PartyTypeElement();
    partyType.setPartyType("U");
    me.addContent(partyType.getXMLContent());

    try {
      reviewer.loadFromXMLContent(me, false);
      assertEquals("didn't correctly load props from valid xml", partyType.getPartyType(),
        reviewer.getPartyType());
    } catch (Exception ex) {
      fail("threw exception loading valid element");
    }
  }

  /**
   * test varying states of the object against the element they should
   * make
   */
  public void testGetXMLContent() {
    super.testGetXMLContent();

    //set a prop so reviewer won't be empty and we can see if it's
    //bringing back the correct tag.
    reviewer.setNetworkId("rkirkend");

    Element me = reviewer.getXMLContent();
    assertEquals("didn't properly make xml element name is incorrect", reviewer.getElementName(),
      me.getName());

    //check that a child element is present
    assertNotNull("didn't represent member IDocElements in xml", me.getChild("networkid"));
  }

  /**
   *  shouldnt be valid when empty should be valid with one prop set
   */
  public void testValidate() {
    try {
      WorkflowServiceErrorImpl errors = reviewer.validate();
      assertNotNull("Empty reviewer returned null on validate", errors);

      assertEquals("ReviewerElement didn't set correct errorType", errors.getKey(),
        ServiceErrorConstants.CHILDREN_IN_ERROR);

      //set jus a prop should return a doc element error
      reviewer.setNetworkId("rkirkend");
      assertNotNull("Reviewer with just networkId set returned null on validate", errors);

      assertEquals("ReviewerElement didn't set correct errorType", errors.getKey(),
        ServiceErrorConstants.CHILDREN_IN_ERROR);

      //set just partyType test same thing
      reviewer.setNetworkId(null);
      reviewer.setPartyType("U");

      assertNotNull("Reviewer with just partType set returned null on validate", errors);

      assertEquals("ReviewerElement didn't set correct errorType", errors.getKey(),
        ServiceErrorConstants.CHILDREN_IN_ERROR);

      //set both and they should be good
      reviewer.setNetworkId("rkirkend");
      reviewer.setPartyType("U");
      assertNull("Valid reviewer didn't return null", reviewer.validate());
    } catch (Exception ex) {
      fail("threw exception validating");
    }
  }

  /**
   * test that responsibilityId is being correctly set internally
   */
  public void testSetResponsibilityId() {
    /* set the partyType and responsibilityId should be null */
    this.reviewer.setPartyType("U");
    assertNull("ResponsibilityId is being set when only partyType is set",
      this.reviewer.getResponsiblePartyId());

    /* null out partyType and set networkId result should be the same */
    this.reviewer.setPartyType(null);
    this.reviewer.setNetworkId("rkirkend");
    assertNull("ResponsibilityId is being set when only networkId is set",
      this.reviewer.getResponsiblePartyId());

    /* give two legal's and the set should be there */
    this.reviewer.setPartyType("U");
    assertNotNull("ResponsibilityId is not being set with a legal partyType " +
      "and legal networkId", this.reviewer.getResponsiblePartyId());

    /* give an illegal combo and null should come back again */
    this.reviewer.setPartyType("W");
    assertNull("ResponsibilityId is being set with a bad partyType" + "/networkId combo",
      this.reviewer.getResponsiblePartyId());

    /* give the other illegal combo and again null should be the case */
    this.reviewer.setPartyType("U");
    this.reviewer.setNetworkId("I'm evil Ash");
    assertNull("ResponsibilityId is being set with a bad partyType" + "/networkId combo",
      this.reviewer.getResponsiblePartyId());
  }

  /**
   * can this guy populate himself w/ xml he made.
   */
  public void testCanFeedOnOwnXML() {
    reviewer.setNetworkId(networkId);
    reviewer.setPartyType(partyType);

    Element reviewerEl = reviewer.getXMLContent();

    ReviewerElement aReviewer = new ReviewerElement();

    try {
      aReviewer.loadFromXMLContent(reviewerEl, false);
      assertEquals("Didn't properly load props from self generated " + "element", networkId,
        aReviewer.getNetworkId());
      assertEquals("Didn't properly load props from self generated " + "element", partyType,
        aReviewer.getPartyType());
    } catch (Exception ex) {
      fail("threw exception loading from self made element");
    }
  }

  /**
   * this test is in response to a bug.  The responsiblePartyId wasn't being set
   * when reviewer was loaded from xmlContent.
   */
  public void testresponsiblePartyIdBeingSetFromXMLContent() {
    this.reviewer.setNetworkId(this.networkId);
    this.reviewer.setPartyType(this.partyType);

    /* verify that indeed that is a valid set of values before proceeding,
       well at least that it's not null... */
    assertNotNull("valid reviewer user and party type returned null " + "responsiblePartyId",
      this.reviewer.getResponsiblePartyId());

    /* get the xmlContent and make a new reviewer from it */
    Element el = this.reviewer.getXMLContent();
    ReviewerElement aReviewer = new ReviewerElement();

    try {
      aReviewer.loadFromXMLContent(el, false);
    } catch (Exception ex) {
      ex.printStackTrace();
      fail("threw exception loading from valid xml");
    }

    assertNotNull("valid reviewer user and party type returned null " +
      "responsiblePartyId after being loaded from xml.  " +
      "The responsiblePartyId is not being set in the loading " + "of the xml",
      aReviewer.getResponsiblePartyId());
  }
}





/*
 * Copyright 2003 The Trustees of Indiana University.  All rights reserved.
 *
 * This file is part of the EDEN software package.
 * For license information, see the LICENSE file in the top level directory
 * of the EDEN source distribution.
 */
