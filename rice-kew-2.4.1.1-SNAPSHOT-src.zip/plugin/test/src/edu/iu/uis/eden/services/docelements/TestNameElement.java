package edu.iu.uis.eden.services.docelements;

import org.jdom.Element;

import edu.iu.uis.eden.WorkflowServiceErrorImpl;
import edu.iu.uis.eden.services.IDocElement;
import edu.iu.uis.eden.services.ServiceErrorConstants;


public class TestNameElement extends IDocInterfaceTestTemplate {
  private NameElement nameEl = new NameElement();

  public TestNameElement(String s) {
    super(s);
  }

  protected void setUp() {
    nameEl = new NameElement();
  }

  protected void tearDown() {
  }

  public IDocElement getIDocElement() {
    return this.nameEl;
  }

  /**
   * no its not
   */
  public void testIsRouteControl() {
    assertEquals("name element is returning true to isRouteControl", false,
      this.nameEl.isRouteControl());

    //try to set it and recheck
    this.nameEl.setRouteControl(true);
    assertEquals("name element is returning true to isRouteControl", false,
      this.nameEl.isRouteControl());
  }

  /**
   * we know from GenericStringElement it's making good xml but can
   * it load from it?
   */
  public void testLoadFromXMLContent() {
    String daNameVal = "ryan";
    this.nameEl.setName(daNameVal);

    Element element = this.nameEl.getXMLContent();

    //is the element the correct name?
    assertEquals("xml representation element given incorrect name", this.nameEl.getElementName(),
      element.getName());

    NameElement aNameEl = new NameElement();

    try {
      aNameEl.loadFromXMLContent(element, false);
      assertEquals("didn't properly load props from self generated " + "xml", daNameVal,
        aNameEl.getName());
    } catch (Exception ex) {
      fail("threw exception loading from self generated xml");
    }
  }

  /**
   * is it returning the correct error code.
   */
  public void testValidate() {
    try {
      WorkflowServiceErrorImpl error = this.nameEl.validate();
      assertEquals("NameElement not returning correct error constant",
        ServiceErrorConstants.NAME_BLANK, error.getKey());
    } catch (Exception ex) {
      fail("threw exception validating");
    }
  }
}





/*
 * Copyright 2003 The Trustees of Indiana University.  All rights reserved.
 *
 * This file is part of the EDEN software package.
 * For license information, see the LICENSE file in the top level directory
 * of the EDEN source distribution.
 */
