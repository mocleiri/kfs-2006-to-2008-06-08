/*
 * Copyright 2005-2007 The Kuali Foundation.
 * 
 * 
 * Licensed under the Educational Community License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 * http://www.opensource.org/licenses/ecl1.php
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package edu.iu.uis.eden.routing.chartorgnode;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.jdom.output.XMLOutputter;

import edu.iu.uis.eden.IUServiceLocator;
import edu.iu.uis.eden.WorkflowServiceErrorImpl;
import edu.iu.uis.eden.docsearch.SearchableAttribute;
import edu.iu.uis.eden.docsearch.SearchableAttributeStringValue;
import edu.iu.uis.eden.docsearch.SearchableAttributeValue;
import edu.iu.uis.eden.engine.node.NodeState;
import edu.iu.uis.eden.engine.node.RouteNodeInstance;
import edu.iu.uis.eden.fisdata.Organization;
import edu.iu.uis.eden.lookupable.Field;
import edu.iu.uis.eden.lookupable.Row;
import edu.iu.uis.eden.plugin.attributes.WorkflowAttribute;
import edu.iu.uis.eden.plugin.attributes.WorkflowAttributeXmlValidator;
import edu.iu.uis.eden.routeheader.DocumentContent;
import edu.iu.uis.eden.routetemplate.RuleExtension;
import edu.iu.uis.eden.routetemplate.RuleExtensionValue;
import edu.iu.uis.eden.routetemplate.WorkflowAttributeValidationError;
import edu.iu.uis.eden.services.docelements.UniversityOrganizationElement;
import edu.iu.uis.eden.util.Utilities;

/**
 * @author rkirkend 
 */
public class OrganizationRoutingAttribute implements WorkflowAttribute, SearchableAttribute, WorkflowAttributeXmlValidator {

    private List rows;
    private static final String FIN_COA_CD_KEY = "fin_coa_cd";
    private static final String CHART_ORG_FIN_COA_CD_KEY = FIN_COA_CD_KEY;//"chart_org_fin_coa_cd";

    private static final String ORG_CD_KEY = "org_cd";
    private static final String CHART_ORG_ORG_CD_KEY = ORG_CD_KEY;//"chart_org_org_cd";

    private static final String ID_KEY = "fin_coa_cd_org_cd_id";
    private static final String LOCK_KEY = "fin_coa_cd_org_cd_locknbr";
    private Field chart;
    private Field org;
    private String finCoaCd;
    private String orgCd;
    private boolean required;

    //  this is a hack added to get the ChartOrgDollarRangeAttribute working, is there a better way?
    private String classNameOverride = null;

    public OrganizationRoutingAttribute(String finCoaCd, String orgCd) {
        this();
        this.finCoaCd = finCoaCd;
        this.orgCd = orgCd;
    }

    public OrganizationRoutingAttribute() {
        rows = new ArrayList();

        List fields = new ArrayList();
        fields.add(new Field("Chart", "", Field.TEXT, true, CHART_ORG_FIN_COA_CD_KEY, "", null, "ChartOrgLookupableImplService", FIN_COA_CD_KEY));
        fields.add(new Field("", "", Field.HIDDEN, true, ID_KEY, "", null, "ChartOrgLookupableImplService"));
        fields.add(new Field("", "", Field.HIDDEN, true, LOCK_KEY, "", null, "ChartOrgLookupableImplService"));
        rows.add(new Row(fields, "Chart & Org", 2));

        fields = new ArrayList();
        fields.add(new Field("Org", "", Field.TEXT, true, CHART_ORG_ORG_CD_KEY, "", null, "ChartOrgLookupableImplService", ORG_CD_KEY));
        fields.add(new Field("", "", Field.QUICKFINDER, false, "", "", null, "ChartOrgLookupableImplService"));
        rows.add(new Row(fields, "Chart & Org", 2));
    }

    public List getRuleExtensionValues() {
        List extensions = new ArrayList();

        if (finCoaCd != null && !finCoaCd.equals("")) {
            RuleExtensionValue extensionFinCoaCd = new RuleExtensionValue();
            extensionFinCoaCd.setKey(FIN_COA_CD_KEY);
            extensionFinCoaCd.setValue(this.finCoaCd);
            extensions.add(extensionFinCoaCd);
        }
        if (orgCd != null && !orgCd.equals("")) {
            RuleExtensionValue extensionOrgCd = new RuleExtensionValue();
            extensionOrgCd.setKey(ORG_CD_KEY);
            extensionOrgCd.setValue(this.orgCd);
            extensions.add(extensionOrgCd);
        }
        return extensions;
    }

    public List validateRoutingData(Map paramMap) {
        List errors = new ArrayList();
        this.finCoaCd = (String) paramMap.get(CHART_ORG_FIN_COA_CD_KEY);
        this.orgCd = (String) paramMap.get(CHART_ORG_ORG_CD_KEY);
        if (isRequired() && (this.finCoaCd == null || "".equals(finCoaCd) || (this.orgCd == null || "".equals(orgCd)))) {
            errors.add(new WorkflowServiceErrorImpl("Chart/org is required.", "routetemplate.chartorgattribute.chartorg.required"));
        } else if ((this.finCoaCd != null && !"".equals(finCoaCd) && ((this.orgCd == null || "".equals(orgCd)))) || ((this.finCoaCd == null || "".equals(finCoaCd)) && this.orgCd != null && !"".equals(orgCd))) {
            errors.add(new WorkflowServiceErrorImpl("Chart/org is invalid.", "routetemplate.chartorgattribute.chartorg.invalid"));
        }

        if (this.finCoaCd != null && !"".equals(finCoaCd) && this.orgCd != null && !"".equals(orgCd)) {
        }
        return errors;
    }

    public List validateRuleData(Map paramMap) {
        return validateRoutingData(paramMap);
    }

    public String getDocContent() {
        if (getFinCoaCd() != null && !getFinCoaCd().equals("") && getOrgCd() != null && !getOrgCd().equals("")) {
            UniversityOrganizationElement univOrgElement = new UniversityOrganizationElement();
            univOrgElement.setChart(getFinCoaCd());
            univOrgElement.setOrgCode(getOrgCd());
            return new XMLOutputter().outputString(univOrgElement.getXMLContent());
        } else {
            throw new RuntimeException("Missing chart or org properties on attribute when getting document content");
        }
    }

    public List parseDocContent(String docContent) {
        List chartOrgModels = new ArrayList();
        return chartOrgModels;
    }

    public boolean isMatch(DocumentContent docContent, List ruleExtensions) {

        String chart = findStateInHierarchy(ChartOrgRoutingNode.CHART_NODE_STATE_KEY, docContent.getRouteContext().getNodeInstance());
        String org = findStateInHierarchy(ChartOrgRoutingNode.ORG_NODE_STATE_KEY, docContent.getRouteContext().getNodeInstance());
        if (Utilities.isEmpty(chart)) {
            throw new RuntimeException("Could not locate the chart on the node state.");
        }
        if (Utilities.isEmpty(org)) {
            throw new RuntimeException("Could not locate the org on the node state.");
        }
        
        String ruleChart = "";
        String ruleOrg = "";

        boolean foundChartOrgExtension = false;
        for (Iterator iter = ruleExtensions.iterator(); iter.hasNext();) {
            RuleExtension extension = (RuleExtension) iter.next();
            //  this is a hack added to get the ChartOrgDollarRangeAttribute working, is there a better way?
            String className = (classNameOverride != null ? classNameOverride : getClass().getName());
            if (extension.getRuleTemplateAttribute().getRuleAttribute().getClassName().equals(className)) {
                for (Iterator iterator = extension.getExtensionValues().iterator(); iterator.hasNext();) {
                    RuleExtensionValue value = (RuleExtensionValue) iterator.next();
                    if (value.getKey().equals(FIN_COA_CD_KEY)) {
                        foundChartOrgExtension = true;
                        ruleChart = value.getValue();
                    }
                    if (value.getKey().equals(ORG_CD_KEY)) {
                        foundChartOrgExtension = true;
                        ruleOrg = value.getValue();
                    }
                }
            }
        }

        return ruleChart.equals(chart) && ruleOrg.equals(org);

    }
    
    /**
     * Climbs the process hierarchy, searching for the state for the given key.
     */
    private String findStateInHierarchy(String key, RouteNodeInstance nodeInstance) {
        if (nodeInstance == null) {
            return null;
        }
        NodeState nodeState = nodeInstance.getNodeState(key);
        if (nodeState != null) {
            return nodeState.getValue();
        }
        return findStateInHierarchy(key, nodeInstance.getProcess());
    }

    public String getIdFieldName() {
        return ID_KEY;
    }

    public String getLockFieldName() {
        return LOCK_KEY;
    }

    public List getRuleRows() {
        return rows;
    }

    public List getRoutingDataRows() {
        return rows;
    }

    public String getFinCoaCd() {
        return this.finCoaCd;
    }

    public void setFinCoaCd(String finCoaCd) {
        this.finCoaCd = finCoaCd;
    }

    public String getOrgCd() {
        return this.orgCd;
    }

    public void setOrgCd(String orgCd) {
        this.orgCd = orgCd;
    }

    public boolean isRequired() {
        return required;
    }

    public void setRequired(boolean required) {
        this.required = required;
    }

    public String getSearchContent() {
        return getDocContent();
    }

    public List validateClientRoutingData() {
        List errors = new ArrayList();
        if (isRequired() && (this.finCoaCd == null || "".equals(finCoaCd) || (this.orgCd == null || "".equals(orgCd)))) {
            errors.add(new WorkflowAttributeValidationError("finCoaCd", "Chart cannot be empty."));
        } else if ((this.finCoaCd != null && !"".equals(finCoaCd) && ((this.orgCd == null || "".equals(orgCd)))) || ((this.finCoaCd == null || "".equals(finCoaCd)) && this.orgCd != null && !"".equals(orgCd))) {
            errors.add(new WorkflowAttributeValidationError("orgCd", "Organization cannot be empty"));
        }
        
        if (this.finCoaCd != null && !"".equals(finCoaCd) && this.orgCd != null && !"".equals(orgCd)) {
            Organization org = IUServiceLocator.getFISDataService().findOrganization(finCoaCd, orgCd);
            if (org == null) {
                errors.add(new WorkflowAttributeValidationError("global", "Organization is invalid"));
            }
        }
        return errors;
    }
    
    public List getSearchStorageValues(String docContent) {
        List searchStorageValues = new ArrayList();
//      TODO the variables finCoaCd and orgCd may not be populated.  Values may only be in the incoming doc content.
        if (finCoaCd != null && !finCoaCd.equals("")) {
            SearchableAttributeStringValue searchableFinCoaCd = new SearchableAttributeStringValue();
            searchableFinCoaCd.setSearchableAttributeKey(FIN_COA_CD_KEY);
            searchableFinCoaCd.setSearchableAttributeValue(this.finCoaCd);
            searchStorageValues.add(searchableFinCoaCd);
        }
        if (orgCd != null && !orgCd.equals("")) {
            SearchableAttributeStringValue searchableOrgCd = new SearchableAttributeStringValue();
            searchableOrgCd.setSearchableAttributeKey(ORG_CD_KEY);
            searchableOrgCd.setSearchableAttributeValue(this.orgCd);
            searchStorageValues.add(searchableOrgCd);
        }
        return searchStorageValues;
    }

    public List getSearchingRows() {
        return rows;
    }

    public List validateUserSearchInputs(Map paramMap) {
        return validateRoutingData(paramMap);
    }

    public void setClassNameOverride(String classNameOverride) {
        this.classNameOverride = classNameOverride;
    }

}