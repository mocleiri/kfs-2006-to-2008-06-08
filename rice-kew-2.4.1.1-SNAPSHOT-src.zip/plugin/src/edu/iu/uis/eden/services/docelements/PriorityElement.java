/*
 * Copyright 2005-2007 The Kuali Foundation.
 * 
 * 
 * Licensed under the Educational Community License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 * http://www.opensource.org/licenses/ecl1.php
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package edu.iu.uis.eden.services.docelements;

import org.jdom.Element;

import edu.iu.uis.eden.WorkflowServiceErrorImpl;
import edu.iu.uis.eden.exception.InvalidXmlException;
import edu.iu.uis.eden.services.IDocElement;
import edu.iu.uis.eden.services.InconsistentDocElementStateException;
import edu.iu.uis.eden.services.ServiceErrorConstants;


/**
 * <p>Title: PriorityElement </p>
 * <p>Description: Represents a PriorityElement element both in xml for documents
 * and as a PriorityElement entity itself concerning validation. <br><BR>
 * See IDocElement documentation for
 * further explanation.</p>
 * <p>Copyright: Copyright (c) 2002</p>
 * <p>Company: Indiana University</p>
 * @author Ryan Kirkendall
 * @version 1.0
 */
public class PriorityElement implements IDocElement {
  private static final org.apache.log4j.Logger LOG = org.apache.log4j.Logger.getLogger(PriorityElement.class);
  private static final String ATTRIBUTE_NAME = "value";
  private static final String ELEMENT_NAME = "priority";
  private boolean routeControl;
  private int priority;
  private boolean hasBeenSet;

  public PriorityElement() {
    LOG.debug("constructing . . .");
    this.routeControl = false;
  }

  public Element getXMLContent() {
    LOG.debug("getXMLContent");

    if (this.isEmpty()) {
      LOG.debug("empty returning null");

      return null;
    }

    //make element and output it
    Element me = new Element(ELEMENT_NAME);
    me.setAttribute(ATTRIBUTE_NAME, new Long(this.priority).toString());

    LOG.debug("return XMLContent " + me.toString());

    return me;
  }

  public void loadFromXMLContent(Element element, boolean allowBlank)
    throws InvalidXmlException, InconsistentDocElementStateException {
    LOG.debug("loadFromXMLContent");

    if (DocElementValidator.returnWithNoWorkDone(this, element, allowBlank)) {
      LOG.debug("returning without setting");

      return;
    }

    //it's good load from element
    String elementValue = element.getAttributeValue(ATTRIBUTE_NAME);

    Integer val = null;

    try {
      val = new Integer(elementValue);
    } catch (Exception ex) {
      throw new InvalidXmlException("Element " + ELEMENT_NAME + " attribute " + ATTRIBUTE_NAME +
        " value is of the wrong " + "type.  Must be convertible to long.");
    }

    this.priority = val.intValue();
    LOG.debug("loaded. priority =" + this.priority);
  }

  public WorkflowServiceErrorImpl validate() {
    LOG.debug("validate");

    /* must be an int greater than 0 */
    if (this.priority <= 0) {
      LOG.debug("priority not greater than 0 returning error object");

      return new WorkflowServiceErrorImpl("priority not greater than 0",
        ServiceErrorConstants.PRIORITY_INVALID);
    }

    LOG.debug("valid returning null");

    return null;
  }

  public String getElementName() {
    return ELEMENT_NAME;
  }

  public void setRouteControl(boolean routeControl) {
  }

  public boolean isRouteControl() {
    return this.routeControl;
  }

  /**
   *
   * @return boolean indicating if object has been set.
   */
  public boolean isEmpty() {
    LOG.debug("isEmpty()");

    if (this.hasBeenSet) {
      LOG.debug("not Empty returning false");

      return false;
    }

    return true;
  }

  /**
   *
   * @param priority long value of the priority
   */
  public void setPriority(int priority) {
    this.priority = priority;
    this.hasBeenSet = true;
  }

  /**
   *
   * @return long value of the priority
   */
  public int getPriority() {
    return this.priority;
  }
}





/*
 * Copyright 2003 The Trustees of Indiana University.  All rights reserved.
 *
 * This file is part of the EDEN software package.
 * For license information, see the LICENSE file in the top level directory
 * of the EDEN source distribution.
 */
