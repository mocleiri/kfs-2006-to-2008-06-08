/*
 * Copyright 2005-2007 The Kuali Foundation.
 * 
 * 
 * Licensed under the Educational Community License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 * http://www.opensource.org/licenses/ecl1.php
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *//*
 * Created on Jan 14, 2004
 *
 * To change the template for this generated file go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
package edu.iu.uis.eden.services.docelements;

import org.jdom.Element;

import edu.iu.uis.eden.WorkflowServiceErrorImpl;
import edu.iu.uis.eden.exception.InvalidXmlException;
import edu.iu.uis.eden.exception.ResourceUnavailableException;
import edu.iu.uis.eden.services.IDocElement;
import edu.iu.uis.eden.services.InconsistentDocElementStateException;


/**
 * @author rkirkend
 *
 * To change the template for this generated type comment go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
public class OldUniversityOrganizationElement extends UniversityOrganizationElement
  implements IDocElement {
  private static final org.apache.log4j.Logger LOG = org.apache.log4j.Logger.getLogger(UniversityOrganizationElement.class);
  private String elementName = "old_university_organization_eok";
  private UniversityOrganizationElement chartOrg;

  public OldUniversityOrganizationElement() {
    LOG.debug("constructing . . .");
    chartOrg = new UniversityOrganizationElement();
  }

  public Element getXMLContent() {
    LOG.debug("getXMLContent");

    if (this.isEmpty()) {
      return null;
    }

    Element me = new Element(this.elementName);
    me.addContent(this.chartOrg.getXMLContent());

    return me;
  }

  public void loadFromXMLContent(Element element, boolean allowBlank)
    throws InvalidXmlException, InconsistentDocElementStateException {
    LOG.debug("loadFromXMLContent");

    if (DocElementValidator.returnWithNoWorkDone(this, element, allowBlank)) {
      LOG.debug("returning without setting");

      return;
    }

    Element chartOrgEL = element.getChild(super.getElementName());
    this.chartOrg.loadFromXMLContent(chartOrgEL, allowBlank);

    LOG.debug("loaded OldUniversityOrganizationElement");
  }

  public WorkflowServiceErrorImpl validate() {
    LOG.debug("validate");

    return this.chartOrg.validate();
  }

  public boolean isEmpty() {
    return this.chartOrg.isEmpty();
  }

  public String getElementName() {
    return this.elementName;
  }

  public void setRouteControl(boolean routeControl) {
  }

  public boolean isRouteControl() {
    return this.chartOrg.isRouteControl();
  }

  public String getOrgCode() {
    return this.chartOrg.getOrgCode();
  }

  public void setOrgCode(String orgCode) {
    this.chartOrg.setOrgCode(orgCode);
  }

  public void setChart(String chart) {
    this.chartOrg.setChart(chart);
  }

  public String getChart() {
    return this.chartOrg.getChart();
  }

  /**
   * validates underlying chart outside of the context of being in a
   * UniversityOrganizationElement
   *
   * @return DocElementError of underlying chart's error(s)
   */
  public WorkflowServiceErrorImpl validateChart() throws ResourceUnavailableException {
    return this.chartOrg.validateChart();
  }

  /**
   * validates underlying OrgCode outside of the context of being in a
   * UniversityOrganizationElement
   *
   * @return DocElementError of underlying orgCode's error(s)
   */
  public WorkflowServiceErrorImpl validateOrgCode() throws ResourceUnavailableException {
    return this.chartOrg.validateOrgCode();
  }
}





/*
 * Copyright 2003 The Trustees of Indiana University.  All rights reserved.
 *
 * This file is part of the EDEN software package.
 * For license information, see the LICENSE file in the top level directory
 * of the EDEN source distribution.
 */
