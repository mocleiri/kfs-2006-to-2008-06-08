/*
 * Copyright 2005-2007 The Kuali Foundation.
 * 
 * 
 * Licensed under the Educational Community License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 * http://www.opensource.org/licenses/ecl1.php
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package edu.iu.uis.eden.services.docelements;

import org.jdom.Element;

import edu.iu.uis.eden.WorkflowServiceErrorImpl;
import edu.iu.uis.eden.exception.InvalidXmlException;
import edu.iu.uis.eden.services.IDocElement;
import edu.iu.uis.eden.services.InconsistentDocElementStateException;
import edu.iu.uis.eden.services.ServiceErrorConstants;


/**
 * <p>Title: FiscalUppaElement</p>
 * <p>Description: Business Respresentation of the FiscalUppa component
 * related to Fiscal|uppa route module.</p>
 * <p>Copyright: Copyright (c) 2002</p>
 * <p>Company: Indiana University</p>
 * @author unascribed
 * @version $Revision: 1.1.58.1 $ - $Date: 2007/07/25 15:35:32 $
 */
public class FiscalUppaElement implements IDocElement {
  private static final org.apache.log4j.Logger LOG = org.apache.log4j.Logger.getLogger(FiscalUppaElement.class);
  private static final String ELEMENT_NAME = "fiscal_uppa";
  private static final String ATTRIBUTE_NAME = "value";
  public static final String FISCAL_CD = "F";
  public static final String UPPA_CD = "U";
  private boolean routeControl;
  private String fiscalUppa;

  public FiscalUppaElement() {
  }

  public Element getXMLContent() {
    if (this.isEmpty()) {
      LOG.debug("fiscalUppa empty or null return empty element");

      return null;
    }

    //make an element and XMLOutputter
    Element me = new Element(ELEMENT_NAME);
    me.setAttribute(ATTRIBUTE_NAME, this.fiscalUppa);

    LOG.debug("returning XMLContent = " + me.toString());

    return me;
  }

  public void loadFromXMLContent(Element element, boolean allowBlank)
    throws InvalidXmlException, InconsistentDocElementStateException {
    LOG.debug("loadFromXMLContent allowBlank = " + allowBlank);

    if (DocElementValidator.returnWithNoWorkDone(this, element, allowBlank)) {
      return;
    }

    this.fiscalUppa = element.getAttributeValue(ATTRIBUTE_NAME);
  }

  public WorkflowServiceErrorImpl validate() {
    if (this.isEmpty()) {
      LOG.debug("FiscalUppa code null or blank return new DocElementError");

      return new WorkflowServiceErrorImpl("FiscalUppa is Empty", ServiceErrorConstants.FISCAL_UPPA_BLANK);
    }

    /* validate*/
    String fiscalUppa = this.getFiscalUppa();

    if ((!fiscalUppa.toUpperCase().equals(FISCAL_CD)) &&
          (!fiscalUppa.toUpperCase().equals(UPPA_CD))) {
      LOG.debug("fiscalUppa invalid fiscalUppa = " + fiscalUppa);

      return new WorkflowServiceErrorImpl("Fiscal|Uppa is invalid", ServiceErrorConstants.FISCAL_UPPA_INVALID);
    }

    LOG.debug("partyType is valid");

    return null;
  }

  public String getElementName() {
    return ELEMENT_NAME;
  }

  public void setRouteControl(boolean routeControl) {
    this.routeControl = false;

    //	this.routeControl = routeControl;
  }

  public boolean isRouteControl() {
    return this.routeControl;
  }

  public boolean isEmpty() {
    LOG.debug("isEmpty()");

    if ((this.fiscalUppa == null) || this.fiscalUppa.trim().equals("")) {
      LOG.debug("empty");

      return true;
    }

    LOG.debug("not empty");

    return false;
  }

  public String getFiscalUppa() {
    return fiscalUppa;
  }

  public void setFiscalUppa(String fiscalUppa) {
    this.fiscalUppa = fiscalUppa;
  }
}





/*
 * Copyright 2003 The Trustees of Indiana University.  All rights reserved.
 *
 * This file is part of the EDEN software package.
 * For license information, see the LICENSE file in the top level directory
 * of the EDEN source distribution.
 */
