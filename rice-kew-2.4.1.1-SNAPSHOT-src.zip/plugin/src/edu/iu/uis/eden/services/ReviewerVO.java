/*
 * Copyright 2005-2007 The Kuali Foundation.
 * 
 * 
 * Licensed under the Educational Community License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 * http://www.opensource.org/licenses/ecl1.php
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package edu.iu.uis.eden.services;

import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;


public class ReviewerVO implements Serializable {
  private static final org.apache.log4j.Logger LOG = org.apache.log4j.Logger.getLogger(ReviewerVO.class);
  static final long serialVersionUID = 1080685324351900781L;
  private String username;
  private String type;
  private String reviewerFirstName;
  private String reviewerLastName;

  public ReviewerVO(String username, String type) {
    this.username = username;
    this.type = type;
  }

  public String getUsername() {
    return username;
  }

  public void setUsername(String username) {
    this.username = username;
  }

  public void setType(String type) {
    this.type = type;
  }

  public String getType() {
    return type;
  }

  public String getReviewerFirstName() {
    return reviewerFirstName;
  }

  public void setReviewerFirstName(String reviewerFirstName) {
    this.reviewerFirstName = reviewerFirstName;
  }

  public String getReviewerLastName() {
    return reviewerLastName;
  }

  public void setReviewerLastName(String reviewerLastName) {
    this.reviewerLastName = reviewerLastName;
  }

  public Map getRemoveLink() {
    LOG.debug("getRemoveLink()");

    HashMap link = new HashMap();
    link.put("action", ServiceConstants.DELETE_MEMBER);
    link.put("memberName", this.getUsername());
    link.put("memberType", this.getType());

    return link;
  }
}





/*
 * Copyright 2003 The Trustees of Indiana University.  All rights reserved.
 *
 * This file is part of the EDEN software package.
 * For license information, see the LICENSE file in the top level directory
 * of the EDEN source distribution.
 */
