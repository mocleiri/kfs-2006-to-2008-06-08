/*
 * Copyright 2005-2007 The Kuali Foundation.
 * 
 * 
 * Licensed under the Educational Community License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 * http://www.opensource.org/licenses/ecl1.php
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package edu.iu.uis.eden.mail;

import java.io.FileInputStream;
import java.util.Properties;

import org.apache.log4j.Logger;
import org.kuali.rice.core.Core;
import org.springframework.beans.factory.InitializingBean;

import edu.iu.uis.sit.util.mail.AuthenticatedMailer;

public class IUAuthenticatedEmailService implements EmailService, InitializingBean {

	private static final Logger LOG = Logger.getLogger(IUAuthenticatedEmailService.class);
	
    private static final String USERNAME_PROPERTY = "username";
    private static final String PASSWORD_PROPERTY = "password";
    
	private Properties emailProperties;
	
	public void afterPropertiesSet() throws Exception {
		try {
			emailProperties = new Properties();
			emailProperties.load(new FileInputStream(Core.getCurrentContextConfig().getEmailConfigurationPath()));
		} catch (Exception e) {
			emailProperties = null;
			LOG.error("Failed to load email properties file!  Email will be disabled.  Error was: "+e.getMessage());
		}
	}
	
	public void sendEmail(EmailFrom from, EmailTo to, EmailSubject subject, EmailBody body, boolean htmlMessage) {
		if (emailProperties == null) {
			LOG.error("Email is disabled, please check configuration!");
		} else {
			try {
				AuthenticatedMailer mailer = new AuthenticatedMailer(from.getFromAddress(), emailProperties.getProperty(USERNAME_PROPERTY), emailProperties.getProperty(PASSWORD_PROPERTY));
				mailer.setHtmlMessage(htmlMessage);
				mailer.sendMessage(to.getToAddress(), subject.getSubject(), body.getBody());
			} catch (Exception e) {
				LOG.error("Error sending email.", e);
			}
		}
	}
	
}
