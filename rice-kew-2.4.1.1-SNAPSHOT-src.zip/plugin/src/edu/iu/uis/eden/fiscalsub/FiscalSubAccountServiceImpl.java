/*
 * Copyright 2005-2007 The Kuali Foundation.
 * 
 * 
 * Licensed under the Educational Community License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 * http://www.opensource.org/licenses/ecl1.php
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package edu.iu.uis.eden.fiscalsub;

import java.util.Collection;
import java.util.List;

import edu.iu.uis.eden.fiscalsub.dao.FiscalSubAccountDAO;

/**
 * Default implementation of FiscalSubAccountService.
 * 
 * @author Eric Westfall
 */
public class FiscalSubAccountServiceImpl implements FiscalSubAccountService {

    private FiscalSubAccountDAO fiscalSubAccountDAO;

    public FiscalSubAccount getSubAccount(String chart, String accountNumber, String subAccountNumber) {
        return getFiscalSubAccountDAO().getSubAccount(chart, accountNumber, subAccountNumber);
    }

    public List searchForSubAccount(String chart, String accountNumber, String subAccountNumber, String subAccountName, String activeIndicator) {
        return getFiscalSubAccountDAO().searchForSubAccount(chart, accountNumber, subAccountNumber, subAccountName, activeIndicator);
    }

    public Collection findAll() {
        return getFiscalSubAccountDAO().findAll();
    }

    public void setFiscalSubAccountDAO(FiscalSubAccountDAO fiscalSubAccountDAO) {
        this.fiscalSubAccountDAO = fiscalSubAccountDAO;
    }

    protected FiscalSubAccountDAO getFiscalSubAccountDAO() {
        return fiscalSubAccountDAO;
    }

}
