/*
 * Copyright 2005-2007 The Kuali Foundation.
 * 
 * 
 * Licensed under the Educational Community License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 * http://www.opensource.org/licenses/ecl1.php
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package edu.iu.uis.eden.ads;

import java.util.List;

import javax.naming.AuthenticationException;
import javax.naming.NamingException;
import javax.naming.directory.DirContext;

import edu.iu.uis.sit.util.directory.AdsHelper;

/**
 * Service for accessing ADS
 * 
 * Attempts to simplify some of the behind-the-scenes grunt work.  This is really not a very sophisticated service
 * at the moment.  Also, objects in the directory service are currently being represented as DirContext objects.
 * It will probably be a good idea to encapsulate them (i.e. like AdsPerson was done in AdsHelper) 
 */
public interface AdsService {
    
    /**
     * Establishes a connection with the ADS server using the default authentication method of the service implementation.  
     * Returns an initial DirContext pointing to the root of the hierarchy.
     */
    public DirContext establishConnection() throws NamingException;
    
    /**
     * Creates an OrganizationalUnit in ADS as a sub context of the given context.
     * 
     * @return the DirContext of the created OrganizationUnit  
     */
    public DirContext createOrganizationalUnit(DirContext context, String name) throws NamingException;
    
    /**
     * Creates a Group in ADS as a sub context of the given context.
     * 
     * @return the DirContext of the created Group  
     */
    public DirContext createGroup(DirContext context, String name, List members) throws NamingException;
    
    /**
     * Finds a Group with the given name inside the given context.
     */
    public DirContext findGroupByName(DirContext context, String groupName) throws NamingException;

    /**
     * Updates the members of a Group
     */
    public DirContext updateGroupMembers(DirContext groupContext, List newMembers) throws NamingException;
    
    /**
     * Returns the DirContext of the User with the given networkId.
     * Returns null if the user cannot be found.
     */
    public DirContext findUser(String networkId) throws NamingException;
    
    /**
     * Finds the DirContext for the given distinguised name
     */
    public DirContext find(String distinguishedName) throws NamingException;
    
    public AdsHelper getAdsHelper() throws AuthenticationException;
    
}
