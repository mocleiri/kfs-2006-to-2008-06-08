/*
 * Copyright 2005-2007 The Kuali Foundation.
 * 
 * 
 * Licensed under the Educational Community License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 * http://www.opensource.org/licenses/ecl1.php
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package edu.iu.uis.eden.web;

import java.util.Iterator;

import edu.iu.uis.eden.web.session.Authentication;
import edu.iu.uis.eden.web.session.BasicAuthentication;
import edu.iu.uis.eden.web.session.UserSession;

/**
 * A set of utility methods relating to UserSession within the IU Enterprise
 * environment.  Provides convienance methods for determining if a user is
 * Kerberos or Safeword authenticated.  Also includes a utility for
 * accessing the current authenticated user.
 * 
 * @author Eric Westfall
 */
public class IUUserSessionUtils {

	public static final String KERBEROS_AUTHORITY = "KERBEROS";
	public static final String SAFEWORD_AUTHORITY = "SAFEWORD_AUTHORITY";

	/**
	 * Returns the UserSession of the currently authenticated user or null if
	 * there is no currently authenticated user.
	 */
	public static UserSession getCurrentAuthenticatedUser() {
		return UserSession.getAuthenticatedUser();
	}
	
	/**
	 * Returns true if the currently logged in user is Kerberos authenticated
	 * through CAS.  Will throw an IllegalArgumentException if there is 
	 * no current authenticated user.
	 */
	public static boolean isKerberosAuthenticated() {
		return isKerberosAuthenticated(UserSession.getAuthenticatedUser());
	}
	
	/**
	 * Returns true if the given UserSession is Kerberos authenticated through CAS.
	 */
	public static boolean isKerberosAuthenticated(UserSession userSession) {
		if (userSession == null) {
			throw new IllegalArgumentException("UserSession cannot be null.");
		}
		return isAuthenticatedWithAuthority(userSession, KERBEROS_AUTHORITY);
	}
	
	/**
	 * Returns true if the currently logged in user is Safeword authenticated
	 * through CAS.  Will throw an IllegalArgumentException if there is 
	 * no current authenticated user.
	 */
	public static boolean isSafewordAuthenticated() {
		return isSafewordAuthenticated(UserSession.getAuthenticatedUser());
	}
	
	/**
	 * Returns true if the given UserSession is Safeword authenticated through CAS.
	 */
	public static boolean isSafewordAuthenticated(UserSession userSession) {
		if (userSession == null) {
			throw new IllegalArgumentException("UserSession cannot be null.");
		}
		return isAuthenticatedWithAuthority(userSession, SAFEWORD_AUTHORITY);
	}
	
	public static void setKerberosAuthenticated(UserSession userSession, boolean isKerberosAuthenticated) {
		boolean isCurrentlyKerberosAuthenticated = isKerberosAuthenticated(userSession);
		if (isKerberosAuthenticated && !isCurrentlyKerberosAuthenticated) {
			userSession.addAuthentication(new BasicAuthentication(KERBEROS_AUTHORITY));
		} else if (!isKerberosAuthenticated && isCurrentlyKerberosAuthenticated) {
			userSession.removeAuthentication(getAuthenticationByAuthority(userSession, KERBEROS_AUTHORITY));
		}
	}
	
	public static void setSafewordAuthenticated(UserSession userSession, boolean isSafewordAuthenticated) {
		boolean isCurrentlySafewordAuthenticated = isSafewordAuthenticated(userSession);
		if (isSafewordAuthenticated && !isCurrentlySafewordAuthenticated) {
			userSession.addAuthentication(new BasicAuthentication(SAFEWORD_AUTHORITY));
		} else if (!isSafewordAuthenticated && isCurrentlySafewordAuthenticated) {
			userSession.removeAuthentication(getAuthenticationByAuthority(userSession, SAFEWORD_AUTHORITY));
		}
	}
	
	/**
	 * Returns true if the given UserSession is authenticated with the given authority.
	 */
	public static boolean isAuthenticatedWithAuthority(UserSession userSession, String authority) {
		return getAuthenticationByAuthority(userSession, authority) != null;
	}
	
	public static Authentication getAuthenticationByAuthority(UserSession userSession, String authority) {
		for (Iterator iterator = userSession.getAuthentications().iterator(); iterator.hasNext(); ) {
			Authentication authentication = (Authentication) iterator.next();
			if (authentication.getAuthority().equals(authority)) {
				return authentication;
			}
		}
		return null;
	}

}
