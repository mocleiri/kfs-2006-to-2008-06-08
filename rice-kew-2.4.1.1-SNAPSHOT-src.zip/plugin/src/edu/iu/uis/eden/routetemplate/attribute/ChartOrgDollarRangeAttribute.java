/*
 * Copyright 2005-2007 The Kuali Foundation.
 * 
 * 
 * Licensed under the Educational Community License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 * http://www.opensource.org/licenses/ecl1.php
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package edu.iu.uis.eden.routetemplate.attribute;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import org.w3c.dom.Element;
import org.w3c.dom.NodeList;

import edu.iu.uis.eden.routeheader.DocumentContent;
import edu.iu.uis.eden.routeheader.PartialAttributeContent;


public class ChartOrgDollarRangeAttribute extends CompositeAttribute {

	private static final String CHART_ORG_DOLLAR_RANGE_ELEMENT = "chart_org_dollar_range";
	
	private ChartOrgAttribute chartOrg;
	private DollarRangeAttribute dollarRange;	
	
	public ChartOrgDollarRangeAttribute(String finCoaCd, String orgCd, String totalDollarAmount) {
		chartOrg = new ChartOrgAttribute(finCoaCd, orgCd);
		dollarRange = new DollarRangeAttribute(totalDollarAmount);
		addAttribute(chartOrg);
		addAttribute(dollarRange);
		overrideClassNames();
	}
	
	public ChartOrgDollarRangeAttribute() {
		chartOrg = new ChartOrgAttribute();
		dollarRange = new DollarRangeAttribute();
		addAttribute(chartOrg);
		addAttribute(dollarRange);
		overrideClassNames();
	}
	
	private void overrideClassNames() {
		chartOrg.setClassNameOverride(getClass().getName());
		dollarRange.setClassNameOverride(getClass().getName());
	}
	
	// need to do some xml magic
	
	public String getDocContent() {
		StringBuffer buffer = new StringBuffer();
		buffer.append("<").append(CHART_ORG_DOLLAR_RANGE_ELEMENT).append(">");
		buffer.append(super.getDocContent());
		buffer.append("</").append(CHART_ORG_DOLLAR_RANGE_ELEMENT).append(">");
		return buffer.toString();
	}
	
	public boolean isMatch(DocumentContent docContent, List ruleExtensions) {
		try {
			// We have to pull out each ChartOrgDollarRange section and match against it...
			NodeList chartOrgDollarElements = docContent.getDocument().getElementsByTagName(CHART_ORG_DOLLAR_RANGE_ELEMENT);
			for (int index = 0; index < chartOrgDollarElements.getLength(); index++) {
				Element element = (Element) chartOrgDollarElements.item(index);
				List documentElements = new ArrayList();
				documentElements.add(element);
				DocumentContent partialContent = new PartialAttributeContent(documentElements);
				if (super.isMatch(partialContent, ruleExtensions)) {
					return true;
				}
			}
			return false; 
		} catch (Exception e) {
            throw new RuntimeException(e);
        }
	}

	// some delegate methods just for fun

	public String getFinCoaCd() {
		return chartOrg.getFinCoaCd();
	}

	public String getOrgCd() {
		return chartOrg.getOrgCd();
	}

	public void setFinCoaCd(String finCoaCd) {
		chartOrg.setFinCoaCd(finCoaCd);
	}

	public void setOrgCd(String orgCd) {
		chartOrg.setOrgCd(orgCd);
	}

	public BigDecimal getMax() {
		return dollarRange.getMax();
	}

	public BigDecimal getMin() {
		return dollarRange.getMin();
	}

	public BigDecimal getTotalDollarAmount() {
		return dollarRange.getTotalDollarAmount();
	}

	public void setMax(BigDecimal max) {
		dollarRange.setMax(max);
	}

	public void setMax(String max) {
		dollarRange.setMax(max);
	}

	public void setMin(BigDecimal min) {
		dollarRange.setMin(min);
	}

	public void setMin(String min) {
		dollarRange.setMin(min);
	}

	public void setTotalDollarAmount(BigDecimal totalDollarAmount) {
		dollarRange.setTotalDollarAmount(totalDollarAmount);
	}

	public void setTotalDollarAmount(String totalDollarAmount) {
		dollarRange.setTotalDollarAmount(totalDollarAmount);
	}
	
}
