/*
 * Copyright 2005-2007 The Kuali Foundation.
 * 
 * 
 * Licensed under the Educational Community License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 * http://www.opensource.org/licenses/ecl1.php
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package edu.iu.uis.eden.routetemplate.attribute;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.jdom.Element;
import org.jdom.output.XMLOutputter;

import edu.iu.uis.eden.WorkflowServiceErrorException;
import edu.iu.uis.eden.WorkflowServiceErrorImpl;
import edu.iu.uis.eden.lookupable.Field;
import edu.iu.uis.eden.lookupable.Row;
import edu.iu.uis.eden.objectcode.ObjectCodeService;
import edu.iu.uis.eden.plugin.attributes.WorkflowAttribute;
import edu.iu.uis.eden.routeheader.DocumentContent;
import edu.iu.uis.eden.routetemplate.RuleExtension;
import edu.iu.uis.eden.routetemplate.RuleExtensionValue;
import edu.iu.uis.eden.services.docelements.ChartElement;
import edu.iu.uis.eden.util.Utilities;
import edu.iu.uis.eden.util.XmlHelper;

public class ObjectCodeAttribute implements WorkflowAttribute {
    
    private static final org.apache.log4j.Logger LOG = org.apache.log4j.Logger.getLogger(ObjectCodeAttribute.class);

    private static final String OBJECT_CD_ELEMENT_NAME = "objectCodeData";
    private static final String OBJECT_CD_KEY = "fin_object_cd";
    private static final String OBJECT_CD = "objectCd";
    private static final String FIN_COA_CD_KEY = "fin_coa_cd";
    private static final String OBJECT_FIN_COA_CD_KEY = "object_fin_coa_cd";
    
    private static final String UNIV_FISCAL_YR_KEY = "univ_fiscal_yr";
    private List rows;
    
    private String objectCd;
    private String finCoaCd;
    private String univFiscalYear;
    private boolean required;
    
    public ObjectCodeAttribute(String objectCd) {
        this.objectCd = objectCd;
    }
    
    public ObjectCodeAttribute() {
        rows = new ArrayList();
        List fields = new ArrayList();
        fields.add(new Field("Object Code", "", Field.TEXT, true, OBJECT_CD_KEY, "", null, "", OBJECT_CD));
        rows.add(new Row(fields, "Object Code", 3));
        
        fields = new ArrayList();
        fields.add(new Field("Chart", "", Field.TEXT, true, OBJECT_FIN_COA_CD_KEY, "", null, "", FIN_COA_CD_KEY));
        rows.add(new Row(fields, "Object Code", 3));
        
        fields = new ArrayList();
        fields.add(new Field("Fiscal Year", "", Field.TEXT, true, UNIV_FISCAL_YR_KEY, "", null, ""));
        fields.add(new Field("", "", Field.QUICKFINDER, false, "", "", null, "edu.iu.uis.eden.objectcode.ObjectCode"));        
        rows.add(new Row(fields, "Object Code", 3));
    }

    public String getDocContent() {
        
        ChartElement chartElement = new ChartElement();
        chartElement.setChart(getFinCoaCd());
        chartElement.setRouteControl(false);
        
        return "<" + OBJECT_CD_ELEMENT_NAME + ">" + new XMLOutputter().outputString(chartElement.getXMLContent()) + 
            "<" + OBJECT_CD_KEY + ">" + objectCd + "</" + OBJECT_CD_KEY + "><" + UNIV_FISCAL_YR_KEY + ">" + 
            getUnivFiscalYear() + "</" + UNIV_FISCAL_YR_KEY + ">" + "</" + OBJECT_CD_ELEMENT_NAME + ">";
    }
    
    public String getIdFieldName() {
        return OBJECT_CD_KEY;
    }
    
    public String getLockFieldName() {
        return "";
    }
    
    public List getRoutingDataRows() {
        return rows;
    }

    public List getRuleExtensionValues() {
        
        List extensionValues = new ArrayList();
        if (! Utilities.isEmpty(objectCd)) {
            RuleExtensionValue value = new RuleExtensionValue();
            value.setKey(OBJECT_CD_KEY);
            value.setValue(objectCd);
            extensionValues.add(value);
        }

        return extensionValues;
    }

    public List getRuleRows() {
        return rows;
    }
    
    public boolean isMatch(DocumentContent docContent, List ruleExtensions) {
        
        if (ruleExtensions.isEmpty()) {
            return true;
        }
        
        for (Iterator iter = ruleExtensions.iterator(); iter.hasNext();) {
            RuleExtension extension = (RuleExtension) iter.next();
            if (extension.getRuleTemplateAttribute().getRuleAttribute().getClassName().equals(this.getClass().getName())) {
                for (Iterator iterator = extension.getExtensionValues().iterator(); iterator.hasNext();) {
                    RuleExtensionValue value = (RuleExtensionValue) iterator.next();
                    if (value.getKey().equals(OBJECT_CD_KEY)) {
                        setObjectCd(value.getValue());
                        break;
                    } else if (value.getKey().equals(FIN_COA_CD_KEY)) {
                        setFinCoaCd(value.getValue());
                    } else if (value.getKey().equals(UNIV_FISCAL_YR_KEY)) {
                        setUnivFiscalYear(value.getValue());
                    }
                }
            }
        }
        
        List xmlObjectCds = parseDocContent(docContent);
        for (Iterator iter = xmlObjectCds.iterator(); iter.hasNext();) {
            ObjectCodeAttribute xmlObjectCd = (ObjectCodeAttribute) iter.next();
            if (! Utilities.isEmpty(xmlObjectCd.getObjectCd()) && ! xmlObjectCd.getObjectCd().equals(getObjectCd())) {
                 continue;
            } 
            if (! Utilities.isEmpty(xmlObjectCd.getFinCoaCd()) && ! xmlObjectCd.getObjectCd().equals(getFinCoaCd())) {
                continue;
            }
            if (! Utilities.isEmpty(xmlObjectCd.getUnivFiscalYear()) && ! xmlObjectCd.getUnivFiscalYear().equals(getUnivFiscalYear())) {
                continue;
            }
            return true;
        }

        return false;
    }
    
    public List parseDocContent(DocumentContent docContent) {
        
        List objectCodes = new ArrayList();
        Element rootElement = null;
        try {
            rootElement = XmlHelper.buildJDocument(docContent.getDocument()).getRootElement();
        } catch (Exception e) {
            throw new WorkflowServiceErrorException("Invalid XML submitted", new ArrayList());
        }
        
        List objectCodeElements = XmlHelper.findElements(rootElement, OBJECT_CD_ELEMENT_NAME);
        for (Iterator iter = objectCodeElements.iterator(); iter.hasNext();) {
            ObjectCodeAttribute objectCodeAtt = new ObjectCodeAttribute();
            Element objectCdRootElement = (Element) iter.next();
            Element objectCdElement = objectCdRootElement.getChild(OBJECT_CD_KEY);
            objectCodeAtt.setObjectCd(objectCdElement.getText());
            Element chartElement = objectCdRootElement.getChild(new ChartElement().getElementName());
            objectCodeAtt.setFinCoaCd(chartElement.getText());
            Element univFiscalYearElement = objectCdRootElement.getChild(UNIV_FISCAL_YR_KEY);
            objectCodeAtt.setUnivFiscalYear(univFiscalYearElement.getText());
            objectCodes.add(objectCodeAtt);
        }
        return objectCodes;
    }
    
    public boolean isRequired() {
        return required;
    }
    
    public void setRequired(boolean required) {
        this.required = required;
    }
    
    public List validateRoutingData(Map paramMap) {
        
        List errors = new ArrayList();
        setObjectCd((String) paramMap.get(OBJECT_CD_KEY));
        if (isRequired() && Utilities.isEmpty(getObjectCd())) {
            errors.add(new WorkflowServiceErrorImpl("Object Code is required.", "routetemplate.objectcodeattribute.objectcode.required"));
        }

        if (! Utilities.isEmpty(getObjectCd())) {
            if (getObjectCodeService().findByObjectCd(getObjectCd()) == null) {
                errors.add(new WorkflowServiceErrorImpl("Object Code is invalid.", "routetemplate.objectcodeattribute.objectcode.invalid"));
            }
        }
        return errors;
    }
    
    public List validateRuleData(Map paramMap) {
        return validateRoutingData(paramMap);
    }
    
//    public List validateTypeNpopulateRoutingDataFromParamMap(Map paramMap) {
//        List errors = new ArrayList();
//        setObjectCd((String) paramMap.get(OBJECT_CD_KEY));
//        if (isRequired() && Utilities.isEmpty(getObjectCd())) {
//            errors.add(new WorkflowServiceErrorImpl("Object Code is required.", "routetemplate.objectcodeattribute.objectcode.required"));
//        }
//        return errors;
//    }
//    
//    public List validateTypeNpopulateRuleDataFromParamMap(Map paramMap) {
//        return validateTypeNpopulateRoutingDataFromParamMap(paramMap);
//    }
    
    public String getObjectCd() {
        return objectCd;
    }
    
    public void setObjectCd(String objectCd) {
        this.objectCd = objectCd;
    }
    
    private ObjectCodeService getObjectCodeService() {
        // TODO move ObjectCodeAttribute to the Kuali project and hook up the services from there.
        throw new UnsupportedOperationException("ObjectCode and object code service need to be moved to the Kuali project");
        //return (ObjectCodeService) SpringServiceLocator.getService(SpringServiceLocator.OBJECT_CD_SERVICE);
    }
    public String getFinCoaCd() {
        return finCoaCd;
    }
    public void setFinCoaCd(String finCoaCd) {
        this.finCoaCd = finCoaCd;
    }
    public String getUnivFiscalYear() {
        return univFiscalYear;
    }
    public void setUnivFiscalYear(String univFiscalYear) {
        this.univFiscalYear = univFiscalYear;
    }
}