/*
 * Copyright 2005-2007 The Kuali Foundation.
 * 
 * 
 * Licensed under the Educational Community License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 * http://www.opensource.org/licenses/ecl1.php
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package edu.iu.uis.eden.routetemplate.attribute;

import java.util.ArrayList;
import java.util.List;

import edu.iu.uis.eden.KEWServiceLocator;
import edu.iu.uis.eden.engine.RouteContext;
import edu.iu.uis.eden.exception.EdenUserNotFoundException;
import edu.iu.uis.eden.routeheader.DocumentContent;
import edu.iu.uis.eden.routetemplate.AbstractRoleAttribute;
import edu.iu.uis.eden.routetemplate.ResolvedQualifiedRole;
import edu.iu.uis.eden.routetemplate.Role;
import edu.iu.uis.eden.user.AuthenticationUserId;
import edu.iu.uis.eden.user.UserService;
import edu.iu.uis.eden.workgroup.GroupNameId;

public class FakeRoleAttribute2 extends AbstractRoleAttribute {

    private static final String ROLE1_KEY = "ROLE1_2";
    
    public List getRoleNames() {
        List roles = new ArrayList();
        roles.add(new Role(this.getClass(), ROLE1_KEY, ROLE1_KEY));
        return roles;
    }

    public List getQualifiedRoleNames(String roleName, DocumentContent docContent) {
        List qualifiedRoleNames = new ArrayList();
        if (roleName.equals(ROLE1_KEY)) {
            qualifiedRoleNames.add("temay");
            qualifiedRoleNames.add("pmckown");
        }
        return qualifiedRoleNames;
    }

    public ResolvedQualifiedRole resolveQualifiedRole(RouteContext context, String roleName, String qualifiedRole) throws EdenUserNotFoundException {
        List members = new ArrayList();
        if (qualifiedRole.equals("ROLE1 ewestfal")) {
            members.add(new AuthenticationUserId("pmckown"));
            members.add(new GroupNameId("SB.MAS.MAS_WG"));
        } else if (qualifiedRole.equals("ROLE1 rkirkend")) {
            members.add(new AuthenticationUserId("jhopf"));
        } else {
            members.add(new AuthenticationUserId(qualifiedRole));
        }
        return new ResolvedQualifiedRole("FakeyRole2", members);
    }

    private UserService getUserService() {
        return (UserService)KEWServiceLocator.getService(KEWServiceLocator.USER_SERVICE);
    }
    
}
