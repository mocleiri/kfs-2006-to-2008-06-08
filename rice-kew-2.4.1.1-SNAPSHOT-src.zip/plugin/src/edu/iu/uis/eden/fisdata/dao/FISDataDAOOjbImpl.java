/*
 * Copyright 2005-2007 The Kuali Foundation.
 * 
 * 
 * Licensed under the Educational Community License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 * http://www.opensource.org/licenses/ecl1.php
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package edu.iu.uis.eden.fisdata.dao;

import java.util.List;

import org.apache.ojb.broker.query.Criteria;
import org.apache.ojb.broker.query.QueryByCriteria;
import org.springmodules.orm.ojb.support.PersistenceBrokerDaoSupport;

import edu.iu.uis.eden.fisdata.FiscalChart;
import edu.iu.uis.eden.fisdata.Organization;

public class FISDataDAOOjbImpl extends PersistenceBrokerDaoSupport implements FISDataDAO {

    public List findAllCharts() {
        return (List) getPersistenceBrokerTemplate().getCollectionByQuery(new QueryByCriteria(FiscalChart.class));
    }

    public Organization findOrganization(String chart, String org) {
        Criteria crit = new Criteria();
        crit.addEqualTo("finCoaCd", chart);
        crit.addEqualTo("orgCd", org);
        return (Organization) getPersistenceBrokerTemplate().getObjectByQuery(new QueryByCriteria(Organization.class, crit));
    }

    public List findOrganizations(String finCoaCd, String orgCd, String organizationName, String activeInd) {
        Criteria criteria = new Criteria();
        if (finCoaCd != null && !"".equals(finCoaCd.trim())) {
            criteria.addLike("UPPER(finCoaCd)", finCoaCd.toUpperCase());
        }
        if (orgCd != null && !"".equals(orgCd.trim())) {
            criteria.addLike("UPPER(orgCd)", orgCd.toUpperCase());
        }
        if (organizationName != null && !"".equals(organizationName.trim())) {
            criteria.addLike("UPPER(name)", organizationName.toUpperCase());
        }
        if (activeInd != null && !"".equals(activeInd.trim())) {
            criteria.addEqualTo("activeCd", activeInd);
        }
        return (List) getPersistenceBrokerTemplate().getCollectionByQuery(new QueryByCriteria(Organization.class, criteria));
    }

    public List findOrganizations(String chart) {
        Criteria crit = new Criteria();
        return (List) getPersistenceBrokerTemplate().getCollectionByQuery(new QueryByCriteria(Organization.class, crit));
    }
}
