
/*
 * Copyright 2005-2007 The Kuali Foundation.
 * 
 * 
 * Licensed under the Educational Community License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 * http://www.opensource.org/licenses/ecl1.php
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package edu.iu.uis.eden.fisdata;

import java.io.Serializable;

public class Organization implements Serializable {

    private String finCoaCd;
    private String orgCd;
    private String name;
    private String reportsToChart;
    private String reportsToOrg;
//    private Organization parent;
    private String activeCd;
    private String returnUrl;
    
    public boolean isActive() {
        return activeCd.equals("Y");
    }
    
    public String getActiveCd() {
        return activeCd;
    }
    public void setActiveCd(String activeCd) {
        this.activeCd = activeCd;
    }
    public String getFinCoaCd() {
        return finCoaCd;
    }
    public void setFinCoaCd(String chart) {
        this.finCoaCd = chart;
    }
    public String getName() {
        return name;
    }
    public void setName(String name) {
        this.name = name;
    }
    public String getOrgCd() {
        return orgCd;
    }
    public void setOrgCd(String org) {
        this.orgCd = org;
    }
//    public Organization getParent() {
//        return parent;
//    }
//    public void setParent(Organization parent) {
//        this.parent = parent;
//    }
    public String getReportsToChart() {
        return reportsToChart;
    }
    public void setReportsToChart(String reportsToChart) {
        this.reportsToChart = reportsToChart;
    }
    public String getReportsToOrg() {
        return reportsToOrg;
    }
    public void setReportsToOrg(String reportsToOrg) {
        this.reportsToOrg = reportsToOrg;
    }
    public boolean hasParent() {
        return !(getFinCoaCd().equals(getReportsToChart()) && getOrgCd().equals(getReportsToOrg()));
    }
    
    public String getReturnUrl() {
        return returnUrl;
    }
    public void setReturnUrl(String returnURL) {
        this.returnUrl = returnURL;
    }
}
