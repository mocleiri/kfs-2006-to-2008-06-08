
/*
 * Copyright (c) 2004, 2005, 2006 Trustees of Indiana University and Cornell University.
 *
 * Licensed under the Educational Community License Version 1.0 (the "License"); By obtaining,
 * using and/or copying this Original Work, you agree that you have read, understand, and will
 * comply with the terms and conditions of the Educational Community License.
 *
 * For the full text of the license, see the LICENSE.txt file or visit:
 * 
 * http://kew.indiana.edu/workflow/LICENSE.txt
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING
 * BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE
 * AND NONINFRINGEMENT.
 * IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES
 * OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 */
            
package edu.iu.uis.eden.actionlist;

import edu.iu.uis.eden.EdenConstants;
import edu.iu.uis.eden.SpringServiceLocator;
import edu.iu.uis.eden.WorkflowServiceErrorException;
import edu.iu.uis.eden.WorkflowServiceErrorImpl;
import edu.iu.uis.eden.actionitem.ActionItem;
import edu.iu.uis.eden.actionitem.dao.ActionItemDAO;
import edu.iu.uis.eden.actionlist.dao.ActionListDAO;
import edu.iu.uis.eden.actionrequests.ActionRequestService;
import edu.iu.uis.eden.actionrequests.ActionRequestValue;
import edu.iu.uis.eden.doctype.DocumentType;
import edu.iu.uis.eden.exception.EdenUserNotFoundException;
import edu.iu.uis.eden.routeheader.DocumentRouteHeaderValue;
import edu.iu.uis.eden.user.UserService;
import edu.iu.uis.eden.user.WorkflowUser;
import edu.iu.uis.eden.user.WorkflowUserId;
import edu.iu.uis.eden.workgroup.WorkflowGroupId;
import edu.iu.uis.eden.workgroup.Workgroup;
import edu.iu.uis.eden.workgroup.WorkgroupMembershipChangeProcessor;
import edu.iu.uis.eden.workgroup.WorkgroupService;

import java.sql.Timestamp;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.commons.collections.CollectionUtils;


public class ActionListServiceImpl implements ActionListService {
    protected final org.apache.log4j.Logger LOG = org.apache.log4j.Logger.getLogger(
                                                          getClass());
    private ActionListDAO actionListDAO;
    private ActionItemDAO actionItemDAO;

    public Collection findUserDelegators(WorkflowUser workflowUser, 
                                         String delegationType)
                                  throws EdenUserNotFoundException {
        return findDelegators(workflowUser, delegationType);
    }

    public Collection getActionList(WorkflowUser workflowUser, 
                                    ActionListFilter filter) {
        return getActionListDAO().getActionList(workflowUser, filter);
    }

    public void setActionListDAO(ActionListDAO actionListDAO) {
        this.actionListDAO = actionListDAO;
    }

    public ActionListDAO getActionListDAO() {
        return actionListDAO;
    }

    public boolean refreshActionList(WorkflowUser user) {
        return SpringServiceLocator.getUserOptionsService()
                                   .refreshActionList(user);
    }

    public void deleteActionItem(ActionItem actionItem) {
        try {
            SpringServiceLocator.getUserOptionsService()
                    .saveRefreshUserOption(actionItem.getUser());
        } catch (EdenUserNotFoundException e) {
            LOG.error("error saving refreshUserOption", e);
        }

        getActionItemDAO().deleteActionItem(actionItem);
    }

    public void deleteActionItems(Long actionRequestId) {
        Collection actionItems = findByActionRequestId(actionRequestId);

        for (Iterator iter = actionItems.iterator(); iter.hasNext();) {
            ActionItem actionItem = (ActionItem) iter.next();

            try {
                SpringServiceLocator.getUserOptionsService()
                    .saveRefreshUserOption(actionItem.getUser());
            } catch (EdenUserNotFoundException e) {
                LOG.error("error saving refreshUserOption", e);
            }
        }

        getActionItemDAO().deleteActionItems(actionRequestId);
    }

    public void deleteByRouteHeaderId(Long routeHeaderId) {
        Collection actionItems = findByRouteHeaderId(routeHeaderId);

        for (Iterator iter = actionItems.iterator(); iter.hasNext();) {
            ActionItem actionItem = (ActionItem) iter.next();

            try {
                SpringServiceLocator.getUserOptionsService()
                    .saveRefreshUserOption(actionItem.getUser());
            } catch (EdenUserNotFoundException e) {
                LOG.error("error saving refreshUserOption", e);
            }
        }

        getActionItemDAO().deleteByRouteHeaderId(routeHeaderId);
    }

    public Collection findByWorkgroupId(Long workgroupId) {
        return getActionItemDAO().findByWorkgroupId(workgroupId);
    }

    public Collection findByRouteHeaderId(Long routeHeaderId) {
        return getActionItemDAO().findByRouteHeaderId(routeHeaderId);
    }

    public Collection findByActionRequestId(Long actionRequestId) {
        return getActionItemDAO().findByActionRequestId(actionRequestId);
    }

    public Collection findByWorkflowUser(WorkflowUser workflowUser) {
        return getActionItemDAO().findByWorkflowUser(workflowUser);
    }

    public Collection findByWorkflowUserRouteHeaderId(String workflowUserId, 
                                                      Long routeHeaderId) {
        return getActionItemDAO()
                   .findByWorkflowUserRouteHeaderId(workflowUserId, 
                                                    routeHeaderId);
    }

    private void loadActionItemFromActionRequest(ActionRequestValue actionRequest, 
                                                 ActionItem actionItem) {
        DocumentRouteHeaderValue routeHeader = SpringServiceLocator.getRouteHeaderService()
                                                                   .getRouteHeader(actionRequest.getRouteHeaderId());
        DocumentType docType = routeHeader.getDocumentType();

        actionItem.setActionRequestCd(actionRequest.getActionRequested());
        actionItem.setActionRequestId(actionRequest.getActionRequestId());
        actionItem.setDocName(docType.getName());
        actionItem.setRoleName(actionRequest.getQualifiedRoleName());
        actionItem.setWorkflowId(actionRequest.getWorkflowId());
        actionItem.setRouteHeaderId(actionRequest.getRouteHeaderId());
        actionItem.setRouteHeader(routeHeader);
        actionItem.setDateAssigned(new Timestamp(new Date().getTime()));
        actionItem.setDocHandlerURL(docType.getDocHandlerUrl());
        actionItem.setDocLabel(docType.getLabel());
        actionItem.setDocTitle(routeHeader.getDocTitle());
        actionItem.setWorkgroupId(actionRequest.getWorkgroupId());


        //		actionItem.setResponsibilityId(actionRequest.getResponsibilityId());
        actionItem.setDelegationType(actionRequest.getDelegationType());

        ActionRequestValue delegatorActionRequest = getActionRequestService()
                                                        .findDelegatorRequest(actionRequest);

        if (delegatorActionRequest != null) {
            actionItem.setDelegatorWorkflowId(
                    delegatorActionRequest.getWorkflowId());
            actionItem.setDelegatorWorkgroupId(
                    delegatorActionRequest.getWorkgroupId());
        }
    }

    /**
     * Generates ActionItems for the given ActionRequest and returns the List of generated Action Items.
     * 
     * @return the List of generated ActionItems
     */
    public List generateActionItems(ActionRequestValue actionRequest, 
                                    boolean simulate)
                             throws EdenUserNotFoundException {
        LOG.debug("generating the action items for request " + 
                  actionRequest.getActionRequestId());

        List actionItems = new ArrayList();

        if (!actionRequest.isPrimaryDelegator()) {
            if (EdenConstants.ACTION_REQUEST_WORKGROUP_RECIPIENT_CD.equals(
                        actionRequest.getRecipientTypeCd())) {
                List users = getWorkgroupService()
                                 .getWorkgroup(new WorkflowGroupId(
                                                       actionRequest.getWorkgroupId()))
                                 .getMembers();
                actionItems.addAll(getActionItemsFromUserList(actionRequest, 
                                                              users));
            } else if (EdenConstants.ACTION_REQUEST_USER_RECIPIENT_CD.equals(
                               actionRequest.getRecipientTypeCd())) {
                ActionItem actionItem = new ActionItem();
                loadActionItemFromActionRequest(actionRequest, actionItem);
                actionItems.add(actionItem);
            }
        }

        if (!simulate) {
            for (Iterator iterator = actionItems.iterator();
                 iterator.hasNext();) {
                ActionItem actionItem = (ActionItem) iterator.next();
                saveActionItem(actionItem);
            }
        }

        return actionItems;
    }

    private List getActionItemsFromUserList(ActionRequestValue actionRequest, 
                                            List users) {
        List actionItems = new ArrayList();

        for (Iterator iterator = users.iterator(); iterator.hasNext();) {
            WorkflowUser user = (WorkflowUser) iterator.next();
            ActionItem actionItem = new ActionItem();
            loadActionItemFromActionRequest(actionRequest, actionItem);
            actionItem.setWorkflowId(user.getWorkflowUserId().getWorkflowId());
            actionItem.setRoleName(actionRequest.getQualifiedRoleName());
            actionItems.add(actionItem);
        }

        return actionItems;
    }

    /**
     * Determines the difference between the current workgroup membership and the new workgroup membership.
     * It then schedules the action item updates to happen asynchronously.
     */
    public void updateActionItemsForWorkgroupChange(Workgroup oldWorkgroup, 
                                                    Workgroup newWorkgroup)
                                             throws EdenUserNotFoundException {
        List oldMembers = oldWorkgroup.getMembers();
        List newMembers = newWorkgroup.getMembers();
        MembersDiff membersDiff = getMembersDiff(oldMembers, newMembers);

        for (Iterator iterator = membersDiff.getRemovedMembers().iterator();
             iterator.hasNext();) {
            WorkflowUser removedMember = (WorkflowUser) iterator.next();
            WorkgroupMembershipChangeProcessor.queueWorkgroupMemberRemoved(
                    removedMember, newWorkgroup);

            /*
                                    Collection actionItems = findByWorkflowUser(removedMember);
                                    for (Iterator itemIt = actionItems.iterator(); itemIt.hasNext();) {
                                            ActionItem item = (ActionItem) itemIt.next();
                                            if (item.getWorkgroupId() != null && item.getWorkgroupId().equals(currentWorkgroup.getWorkflowGroupId().getGroupId())) {
                                                    deleteActionItem(item);
                                                    //check to see this user has anymore action requests that are active and should now have an action item
                                                    List actionRequests = SpringServiceLocator.getActionRequestService().findByStatusAndDocId(EdenConstants.ACTION_REQUEST_ACTIVATED, item.getRouteHeaderId());
                                                    for (Iterator iter = actionRequests.iterator(); iter.hasNext();) {
                                    ActionRequestValue actionRequest = (ActionRequestValue) iter.next();
                                    if (actionRequest.isUserRequest() && actionRequest.getWorkflowId().equals(item.getWorkflowId())) {
                                        generateActionItems(actionRequest, false);
                                    }
                                }
                                                    
                                            }
                                    }
            */
        }

        for (Iterator iterator = membersDiff.getAddedMembers().iterator();
             iterator.hasNext();) {
            WorkflowUser addedMember = (WorkflowUser) iterator.next();
            WorkgroupMembershipChangeProcessor.queueWorkgroupMemberAdded(
                    addedMember, oldWorkgroup);

            /*                        List actionRequests = getActionRequestService().findActivatedByWorkgroup(currentWorkgroup);
                                    for (Iterator requestIt = actionRequests.iterator(); requestIt.hasNext();) {
                                            ActionRequestValue request = (ActionRequestValue) requestIt.next();
                                            ActionItem item = new ActionItem();
                                            loadActionItemFromActionRequest(request, item);
                                            item.setWorkflowId(addedMember.getWorkflowUserId().getWorkflowId());
                                            saveActionItem(item);
                                    }
            */
        }
    }

    /**
     * Update the user's Action List to reflect their addition to the given Workgroup.
     */
    public void updateActionListForUserAddedToWorkgroup(WorkflowUser user, 
                                                        Workgroup workgroup)
        throws EdenUserNotFoundException {
        // first verify that the user is still a member of the workgroup
        if (workgroup.hasMember(user)) {
            List actionRequests = getActionRequestService()
                                      .findActivatedByWorkgroup(workgroup);

            for (Iterator requestIt = actionRequests.iterator();
                 requestIt.hasNext();) {
                ActionRequestValue request = (ActionRequestValue) requestIt.next();
                ActionItem item = new ActionItem();
                loadActionItemFromActionRequest(request, item);
                item.setWorkflowId(user.getWorkflowUserId().getWorkflowId());
                saveActionItem(item);
            }
        }
    }

    /**
     * Update the user's Action List to reflect their removal from the given Workgroup.
     */
    public void updateActionListForUserRemovedFromWorkgroup(WorkflowUser user, 
                                                            Workgroup workgroup)
        throws EdenUserNotFoundException {
        // first verify that the user is no longer a member of the workgroup
        if (!workgroup.hasMember(user)) {
            Collection actionItems = findByWorkflowUser(user);

            for (Iterator itemIt = actionItems.iterator(); itemIt.hasNext();) {
                ActionItem item = (ActionItem) itemIt.next();

                if (item.isWorkgroupItem() && 
                        item.getWorkgroupId()
                            .equals(workgroup.getWorkflowGroupId().getGroupId())) {
                    deleteActionItem(item);
                }
            }
        }
    }

    public void updateActionItemsForTitleChange(Long routeHeaderId, 
                                                String newTitle)
                                         throws EdenUserNotFoundException {
        Collection items = getActionItemDAO()
                               .findByRouteHeaderId(routeHeaderId);

        for (Iterator iterator = items.iterator(); iterator.hasNext();) {
            ActionItem item = (ActionItem) iterator.next();
            item.setDocTitle(newTitle);
            saveActionItem(item);
        }
    }

    private MembersDiff getMembersDiff(Collection oldMembers, 
                                       Collection newMembers) {
        Map currentMembersMap = createUsersMap(oldMembers);
        Map newMembersMap = createUsersMap(newMembers);
        Map allMembers = mergeMaps(currentMembersMap, newMembersMap);
        Collection addedKeys = CollectionUtils.subtract(newMembersMap.keySet(), 
                                                        currentMembersMap.keySet());
        Collection removedKeys = CollectionUtils.subtract(
                                         currentMembersMap.keySet(), 
                                         newMembersMap.keySet());
        Set addedMembers = getUsersSet(addedKeys, allMembers);
        Set removedMembers = getUsersSet(removedKeys, allMembers);

        return new MembersDiff(addedMembers, removedMembers);
    }

    private Map mergeMaps(Map map1, Map map2) {
        Map newMap = new HashMap();
        newMap.putAll(map1);
        newMap.putAll(map2);

        return newMap;
    }

    private Set getUsersSet(Collection userKeys, Map memberMap) {
        Set resultSet = new HashSet();

        for (Iterator iterator = userKeys.iterator(); iterator.hasNext();) {
            String workflowId = (String) iterator.next();
            WorkflowUser user = (WorkflowUser) memberMap.get(workflowId);
            resultSet.add(user);
        }

        return resultSet;
    }

    private Map createUsersMap(Collection members) {
        Map map = new HashMap();

        for (Iterator iterator = members.iterator(); iterator.hasNext();) {
            WorkflowUser user = (WorkflowUser) iterator.next();
            map.put(user.getWorkflowUserId().getWorkflowId(), user);
        }

        return map;
    }

    public Collection findDelegators(WorkflowUser user, String delegationType)
                              throws EdenUserNotFoundException {
        return getActionItemDAO().findDelegators(user, delegationType);
    }

    public void saveActionItem(ActionItem actionItem)
                        throws EdenUserNotFoundException {
        SpringServiceLocator.getUserOptionsService()
                    .saveRefreshUserOption(actionItem.getUser());
        getActionItemDAO().saveActionItem(actionItem);
    }

    public ActionItemDAO getActionItemDAO() {
        return actionItemDAO;
    }

    public ActionRequestService getActionRequestService() {
        return (ActionRequestService) SpringServiceLocator.getActionRequestService();
    }

    public WorkgroupService getWorkgroupService() {
        return (WorkgroupService) SpringServiceLocator.getWorkgroupService();
    }

    public void setActionItemDAO(ActionItemDAO actionItemDAO) {
        this.actionItemDAO = actionItemDAO;
    }

    public UserService getUserService() {
        return (UserService) SpringServiceLocator.getUserService();
    }

    public void validateActionItem(ActionItem actionItem) {
        List errors = new ArrayList();
        String workflowId = actionItem.getWorkflowId();

        if ((workflowId == null) || workflowId.trim().equals("")) {
            errors.add(new WorkflowServiceErrorImpl("ActionItem person null.", 
                                                    "actionitem.personid.empty", 
                                                    actionItem.getActionItemId()
                                                              .toString()));
        } else {
            try {
                getUserService()
                    .getWorkflowUser(new WorkflowUserId(workflowId));
            } catch (EdenUserNotFoundException e) {
                errors.add(new WorkflowServiceErrorImpl(
                                   "ActionItem person invalid.", 
                                   "actionitem.personid.invalid", 
                                   actionItem.getActionItemId().toString()));
            }
        }

        if (actionItem.getDateAssigned() == null) {
            errors.add(new WorkflowServiceErrorImpl(
                               "ActionItem date assigned empty.", 
                               "actionitem.dateassigned.empty", 
                               actionItem.getActionItemId().toString()));
        }

        String actionRequestCd = actionItem.getActionRequestCd();

        if ((actionRequestCd == null) || actionRequestCd.trim().equals("")) {
            errors.add(new WorkflowServiceErrorImpl(
                               "ActionItem action request cd empty.", 
                               "actionitem.actionrequestcd.empty", 
                               actionItem.getActionItemId().toString()));
        } else if (!EdenConstants.ACTION_REQUEST_CD.containsKey(actionRequestCd)) {
            errors.add(new WorkflowServiceErrorImpl(
                               "ActionItem action request cd invalid.", 
                               "actionitem.actionrequestcd.invalid", 
                               actionItem.getActionItemId().toString()));
        }

        if (actionItem.getActionRequestId() == null) {
            errors.add(new WorkflowServiceErrorImpl(
                               "ActionItem action request id empty.", 
                               "actionitem.actionrequestid.empty", 
                               actionItem.getActionItemId().toString()));
        }

        if (actionItem.getRouteHeaderId() == null) {
            errors.add(new WorkflowServiceErrorImpl(
                               "ActionItem Document id empty.", 
                               "actionitem.routeheaderid.empty", 
                               actionItem.getActionItemId().toString()));
        } else if (SpringServiceLocator.getRouteHeaderService()
                                       .getRouteHeader(actionItem.getRouteHeaderId()) == null) {
            errors.add(new WorkflowServiceErrorImpl(
                               "ActionItem Document id invalid.", 
                               "actionitem.routeheaderid.invalid", 
                               actionItem.getActionItemId().toString()));
        }

        String docTypeName = actionItem.getDocName();
        DocumentType docType = null;

        if ((docTypeName == null) || docTypeName.trim().equals("")) {
            errors.add(new WorkflowServiceErrorImpl(
                               "ActionItem doctypename empty.", 
                               "actionitem.doctypename.empty", 
                               actionItem.getActionItemId().toString()));
        } else {
            docType = SpringServiceLocator.getDocumentTypeService()
                                          .findByName(actionItem.getDocName());

            if (docType == null) {
                errors.add(new WorkflowServiceErrorImpl(
                                   "ActionItem doctypename invalid.", 
                                   "actionitem.doctypename.invalid", 
                                   actionItem.getActionItemId().toString()));
            }
        }

        if ((actionItem.getDocLabel() == null) || 
                actionItem.getDocLabel().trim().equals("")) {
            errors.add(new WorkflowServiceErrorImpl(
                               "ActionItem doctypelabel empty.", 
                               "actionitem.doctypelabel.empty", 
                               actionItem.getActionItemId().toString()));
        }
        // TODO: should this be reinforced here?
        else if ((docType != null) && 
                     !docType.getLabel().equals(actionItem.getDocLabel())) {
            errors.add(new WorkflowServiceErrorImpl(
                               "ActionItem doctypelabel no match.", 
                               "actionitem.doctypelabel.nomatch", 
                               actionItem.getActionItemId().toString()));
        }

        if ((actionItem.getDocHandlerURL() == null) || 
                actionItem.getDocHandlerURL().trim().equals("")) {
            errors.add(new WorkflowServiceErrorImpl(
                               "ActionItem doc handler url empty.", 
                               "actionitem.dochdrurl.empty", 
                               actionItem.getActionItemId().toString()));
        }
        // TODO: same as doctypelabel
        else if ((docType != null) && 
                     !docType.getDocHandlerUrl()
                             .equals(actionItem.getDocHandlerURL())) {
            errors.add(new WorkflowServiceErrorImpl(
                               "ActionItem doc handler url no match.", 
                               "actionitem.dochdrurl.nomatch", 
                               actionItem.getActionItemId().toString()));
        }

        if (!errors.isEmpty()) {
            throw new WorkflowServiceErrorException(
                    "ActionItem Validation Error", errors);
        }
    }

    public ActionItem findByActionItemId(Long actionItemId) {
        return getActionItemDAO().findByActionItemId(actionItemId);
    }

    //	public ActionListEmailService getActionListEmailService() {
    //		return (ActionListEmailService) SpringServiceLocator.getActionListEmailService();
    //	}
    private class MembersDiff {
        private final Set addedMembers;
        private final Set removedMembers;

        public MembersDiff(Set addedMembers, Set removedMembers) {
            this.addedMembers = addedMembers;
            this.removedMembers = removedMembers;
        }

        public Set getAddedMembers() {
            return addedMembers;
        }

        public Set getRemovedMembers() {
            return removedMembers;
        }
    }
}