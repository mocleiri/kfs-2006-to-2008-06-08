
/*
 * Copyright (c) 2004, 2005, 2006 Trustees of Indiana University and Cornell University.
 *
 * Licensed under the Educational Community License Version 1.0 (the "License"); By obtaining,
 * using and/or copying this Original Work, you agree that you have read, understand, and will
 * comply with the terms and conditions of the Educational Community License.
 *
 * For the full text of the license, see the LICENSE.txt file or visit:
 * 
 * http://kew.indiana.edu/workflow/LICENSE.txt
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING
 * BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE
 * AND NONINFRINGEMENT.
 * IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES
 * OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 */
            
package edu.iu.uis.eden.actionlist.web;

import java.util.HashMap;
import java.util.Map;


public class ActionListPrefConstants {
    public static final String REFRESH_RATE_KEY = "REFRESH_RATE";
    public static final String OPEN_NEW_WINDOW_KEY = "OPEN_ITEMS_NEW_WINDOW";
    public static final String OPEN_NEW_WINDOW_YES_VAL = "openItemsNewWindow";
    public static final String YES_VAL = "yes";
    public static final String NO_VAL = "no";
    public static final String COLUMN_DOC_TYPE_KEY = "DOC_TYPE_COL_SHOW";
    public static final String COLUMN_TITLE_KEY = "TITLE_COL_SHOW";
    public static final String COLUMN_ACTION_REQ_KEY = 
            "ACTION_REQUESTED_COL_SHOW";
    public static final String COLUMN_INITIATOR_KEY = "INITIATOR_COL_SHOW";
    public static final String COLUMN_DATE_CREATE_KEY = "DATE_CREATED_COL_SHOW";
    public static final String COLUMN_DOCUMENT_STATUS_KEY = 
            "DOCUMENT_STATUS_COL_SHOW";
    public static final String ACTION_LIST_SIZE_KEY = "ACTION_LIST_SIZE";
    public static final String ACTION_LIST_PREF_FORM_SESSION_KEY = 
            ".actionListPrefs";
    public static final String ACTION_LIST_DEFAULT_SIZE = "10";
    public static final String REFRESH_RATE_DEFAULT_VALUE = "15"; //in minutes
    public static final Map COLOR_PALETTE;

    static {
        COLOR_PALETTE = new HashMap();
        COLOR_PALETTE.put("white", "#FFFFFF");
        COLOR_PALETTE.put("pink", "#FFDDDE");
        COLOR_PALETTE.put("blue", "#BDD8F4");
        COLOR_PALETTE.put("aqua", "#7FFFDF");
        COLOR_PALETTE.put("tan", "#E5E5B7");
        COLOR_PALETTE.put("red", "#D99394");
        COLOR_PALETTE.put("yellow", "#FFFF99");
        COLOR_PALETTE.put("purple", "#DFCAFA");
        COLOR_PALETTE.put("orange", "#FFCC99");
        COLOR_PALETTE.put("green", "#D4FF94");
        COLOR_PALETTE.put("slate", "#BDDABD");
    }
}

/*
 * Copyright 2003 The Trustees of Indiana University.  All rights reserved.
 *
 * This file is part of the EDEN software package.
 * For license information, see the LICENSE file in the top level directory
 * of the EDEN source distribution.
 */
