
/*
 * Copyright (c) 2004, 2005, 2006 Trustees of Indiana University and Cornell University.
 *
 * Licensed under the Educational Community License Version 1.0 (the "License"); By obtaining,
 * using and/or copying this Original Work, you agree that you have read, understand, and will
 * comply with the terms and conditions of the Educational Community License.
 *
 * For the full text of the license, see the LICENSE.txt file or visit:
 * 
 * http://kew.indiana.edu/workflow/LICENSE.txt
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING
 * BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE
 * AND NONINFRINGEMENT.
 * IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES
 * OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 */
            
package edu.iu.uis.eden.actionlist.web;

import edu.iu.uis.eden.actionitem.ActionItemActionListExtension;
import edu.iu.uis.eden.actionlist.DisplayParameters;

import org.displaytag.decorator.TableDecorator;


public class ActionListDecorator extends TableDecorator {
    private static final org.apache.log4j.Logger LOG = 
            org.apache.log4j.Logger.getLogger(ActionListDecorator.class);

    public String startRow() {
        ActionItemActionListExtension actionItem = (ActionItemActionListExtension) getCurrentRowObject();
        StringBuffer tbody = new StringBuffer();
        tbody.append("<tbody bgcolor='" + actionItem.getRowStyleClass());
        tbody.append("' onmouseover=\"this.className = 'over';\" ");
        tbody.append(
                "onmouseout=\"this.className = this.className.replace('over', '');\">");

        return tbody.toString();
    }

    public String finishRow() {
        ActionItemActionListExtension actionItem = (ActionItemActionListExtension) getCurrentRowObject();
        String returnRow = "</tbody>";

        try {
            DisplayParameters displayParameters = actionItem.getDisplayParameters();

            if (displayParameters != null) {
                Integer index = actionItem.getActionItemIndex();
                Integer frameHeight = new Integer(290);

                try {
                    if ((displayParameters.getFrameHeight() != null) && 
                            (displayParameters.getFrameHeight().intValue() > 0)) {
                        frameHeight = displayParameters.getFrameHeight();
                    }
                } catch (Exception ex) {
                    LOG.error("Error getting custom action list frame height.", 
                              ex);
                }

                StringBuffer newRow = new StringBuffer();
                newRow.append("<tr id='G");
                newRow.append(index.toString());
                newRow.append("' style='display: none;'>");
                newRow.append("<td class='white' height='0' colspan='11' >");
                newRow.append("<iframe name='iframeAL_");
                newRow.append(index.toString());
                newRow.append("' scrolling='yes' width=100% height=");
                newRow.append(frameHeight.toString());
                newRow.append(" hspace=0 vspace=0 frameborder=0></iframe>");
                newRow.append("</td></tr>");
                returnRow += newRow.toString();
            }
        } catch (Exception e) {
            LOG.error("Error with custom action list attribute.", e);
        }

        return returnRow;
    }
}