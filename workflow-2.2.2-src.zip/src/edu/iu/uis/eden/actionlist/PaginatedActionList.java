
/*
 * Copyright (c) 2004, 2005, 2006 Trustees of Indiana University and Cornell University.
 *
 * Licensed under the Educational Community License Version 1.0 (the "License"); By obtaining,
 * using and/or copying this Original Work, you agree that you have read, understand, and will
 * comply with the terms and conditions of the Educational Community License.
 *
 * For the full text of the license, see the LICENSE.txt file or visit:
 * 
 * http://kew.indiana.edu/workflow/LICENSE.txt
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING
 * BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE
 * AND NONINFRINGEMENT.
 * IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES
 * OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 */
            
package edu.iu.uis.eden.actionlist;

import java.util.List;

import org.displaytag.pagination.PaginatedList;

import org.displaytag.properties.SortOrderEnum;


public class PaginatedActionList implements PaginatedList {
    private final List list;
    private final int fullListSize;
    private final int pageNumber;
    private final int objectsPerPage;
    private final String searchId;
    private final String sortCriterion;
    private final SortOrderEnum sortDirection;

    public PaginatedActionList(List list, int fullListSize, int pageNumber, 
                               int objectsPerPage, String searchId, 
                               String sortCriterion, 
                               SortOrderEnum sortDirection) {
        this.list = list;
        this.fullListSize = fullListSize;
        this.pageNumber = pageNumber;
        this.objectsPerPage = objectsPerPage;
        this.searchId = searchId;
        this.sortCriterion = sortCriterion;
        this.sortDirection = sortDirection;
    }

    public int getFullListSize() {
        return fullListSize;
    }

    public List getList() {
        return list;
    }

    public int getObjectsPerPage() {
        return objectsPerPage;
    }

    public int getPageNumber() {
        return pageNumber;
    }

    public String getSearchId() {
        return searchId;
    }

    public String getSortCriterion() {
        return sortCriterion;
    }

    public SortOrderEnum getSortDirection() {
        return sortDirection;
    }
}