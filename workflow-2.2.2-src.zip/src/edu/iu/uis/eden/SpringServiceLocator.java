
/*
 * Copyright (c) 2004, 2005, 2006 Trustees of Indiana University and Cornell University.
 *
 * Licensed under the Educational Community License Version 1.0 (the "License"); By obtaining,
 * using and/or copying this Original Work, you agree that you have read, understand, and will
 * comply with the terms and conditions of the Educational Community License.
 *
 * For the full text of the license, see the LICENSE.txt file or visit:
 * 
 * http://kew.indiana.edu/workflow/LICENSE.txt
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING
 * BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE
 * AND NONINFRINGEMENT.
 * IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES
 * OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 */
            
package edu.iu.uis.eden;

import edu.iu.uis.eden.actionlist.ActionListService;
import edu.iu.uis.eden.actionrequests.ActionRequestService;
import edu.iu.uis.eden.actions.ActionRegistry;
import edu.iu.uis.eden.actiontaken.ActionTakenService;
import edu.iu.uis.eden.applicationconstants.ApplicationConstantsService;
import edu.iu.uis.eden.batch.XmlDigesterService;
import edu.iu.uis.eden.batch.XmlIngesterService;
import edu.iu.uis.eden.batch.XmlPollerService;
import edu.iu.uis.eden.core.ContextualConfigLock;
import edu.iu.uis.eden.database.platform.Platform;
import edu.iu.uis.eden.doctype.DocumentTypeService;
import edu.iu.uis.eden.edoclite.EDocLiteService;
import edu.iu.uis.eden.engine.WorkflowEngine;
import edu.iu.uis.eden.engine.node.RouteNodeService;
import edu.iu.uis.eden.help.HelpService;
import edu.iu.uis.eden.mail.ActionListEmailService;
import edu.iu.uis.eden.mail.EmailService;
import edu.iu.uis.eden.notes.NoteService;
import edu.iu.uis.eden.notification.NotificationService;
import edu.iu.uis.eden.plugin.ExtensionService;
import edu.iu.uis.eden.plugin.PluginRegistry;
import edu.iu.uis.eden.preferences.PreferencesService;
import edu.iu.uis.eden.responsibility.ResponsibilityIdService;
import edu.iu.uis.eden.routeheader.RouteHeaderService;
import edu.iu.uis.eden.routeheader.WorkflowDocumentService;
import edu.iu.uis.eden.routemanager.ExceptionRoutingService;
import edu.iu.uis.eden.routemanager.RouteManagerController;
import edu.iu.uis.eden.routemanager.RouteManagerDriver;
import edu.iu.uis.eden.routemanager.RouteManagerQueueService;
import edu.iu.uis.eden.routemodule.RouteModuleService;
import edu.iu.uis.eden.routemodule.RoutingReportService;
import edu.iu.uis.eden.routequeue.RouteQueueService;
import edu.iu.uis.eden.routetemplate.RoleService;
import edu.iu.uis.eden.routetemplate.RuleAttributeService;
import edu.iu.uis.eden.routetemplate.RuleDelegationService;
import edu.iu.uis.eden.routetemplate.RuleService;
import edu.iu.uis.eden.routetemplate.RuleTemplateService;
import edu.iu.uis.eden.server.WorkflowDocumentActions;
import edu.iu.uis.eden.server.WorkflowUtility;
import edu.iu.uis.eden.transformation.TransformationService;
import edu.iu.uis.eden.user.UserService;
import edu.iu.uis.eden.useroptions.UserOptionsService;
import edu.iu.uis.eden.util.OptimisticLockFailureService;
import edu.iu.uis.eden.web.WebAuthenticationService;
import edu.iu.uis.eden.workgroup.WorkgroupRoutingService;
import edu.iu.uis.eden.workgroup.WorkgroupService;
import edu.iu.uis.eden.xml.export.XmlExporterService;
import edu.iu.uis.sit.cache.Cache;

import java.util.HashMap;
import java.util.Map;

import javax.sql.DataSource;

import javax.transaction.TransactionManager;
import javax.transaction.UserTransaction;

import org.apache.log4j.Logger;

import org.objectweb.jotm.Current;

import org.springframework.context.ApplicationContext;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import org.springframework.transaction.jta.JtaTransactionManager;
import org.springframework.transaction.support.TransactionTemplate;


/**
 * Singleton through which all code can retrieve service definitions defined in Spring
 */
public final class SpringServiceLocator {
    private static final Logger LOG = Logger.getLogger(
                                              SpringServiceLocator.class);

    /**
     * The default top-level Spring configuration resource name
     */
    private static final String DEFAULT_SPRING_FILE = "Spring.xml";

    /**
     * The top-level Spring configuration resource name for testing
     */
    private static final String TEST_SPRING_FILE = "TestSpring.xml";

    /* Conditions are used to ensure state integrity.  Various methods that modify state
     * are already synchronized so in some places these are redundant.  At some point we
     * should switch to java.util.concurrent Lock and Condition classes and implement this
     * correctly.
     */

    /**
     * Condition that indicates whether Spring has completed initialization
     */
    private static final ContextualConfigLock SPRING_INIT_COMPLETE = 
            new ContextualConfigLock("Spring has completed initialization");

    /**
     * Condition that indicates whether Spring has started initialization
     */
    private static final ContextualConfigLock SPRING_INIT_STARTED = 
            new ContextualConfigLock("Spring has started initialization");

    /**
     * The Spring context
     */
    private static ApplicationContext appContext;
    private static boolean isOverrideAllowed = false;
    private static Map overiddenBeans = new HashMap();
    public static final String EDEN_DATASOURCE = "enWorkflowDataSource";
    public static final String WORKFLOW_UTILITY_SERVICE = 
            "enWorkflowUtilityService";
    public static final String WORKFLOW_DOCUMENT_ACTIONS_SERVICE = 
            "enWorkflowDocumentActionsService";
    public static final String QUICK_LINKS_SERVICE = "enQuickLinksService";
    public static final String USER_SERVICE = "enUserService";
    public static final String USER_DAO = "enUserDAO";
    public static final String DOCUMENT_SEARCH_SERVICE = 
            "enDocumentSearchService";

    //TODO remove references to action taken dao
    public static final String ACTION_TAKEN_DAO = "enActionTakenDAO";
    public static final String ACTION_TAKEN_SRV = "enActionTakenService";
    public static final String ACTION_REQUEST_SRV = "enActionRequestService";
    public static final String ACTION_LIST_SRV = "enActionListService";
    public static final String DOC_ROUTE_HEADER_DAO = "enDocumentRouteHeaderDAO";
    public static final String DOC_ROUTE_HEADER_SRV = "enDocumentRouteHeaderService";
    public static final String DOCUMENT_TYPE_GROUP_SERVICE = 
            "enDocumentTypeGroupService";
    public static final String DOCUMENT_TYPE_SERVICE = "enDocumentTypeService";
    public static final String DOCUMENT_TYPE_GROUP_DAO = 
            "enDocumentTypeGroupDAO";
    public static final String ROUTE_QUEUE_SRV = "enRouteQueueService";
    public static final String WORKGROUP_SRV = "enWorkgroupService";
    public static final String WORKGROUP_ROUTING_SERVICE = 
            "enWorkgroupRoutingService";
    public static final String USER_OPTIONS_SRV = "enUserOptionsService";
    public static final String DOCUMENT_CHANGE_HISTORY_SRV = 
            "enDocumentChangeHistoryService";
    public static final String APPLICATION_CONSTANTS_SRV = 
            "enApplicationConstantsService";
    public static final String DOCUMENT_VALUE_INDEX_SRV = 
            "enDocumentValueIndexService";
    public static final String ROUTE_LEVEL_SERVICE = "enRouteLevelService";
    public static final String CACHE_MANAGER = "cacheManager";
    public static final String CONSTANTS_SERVICE = "enApplicationConstantsService";
    public static final String PREFERENCES_SERVICE = "enPreferencesService";
    public static final String ROUTE_LOG_SERVICE = "enRouteLogService";
    public static final String RULE_TEMPLATE_SERVICE = "enRuleTemplateService";
    public static final String RULE_SERVICE = "enRuleService";
    public static final String RULE_ATTRIBUTE_SERVICE = 
            "enRuleAttributeService";
    public static final String RULE_TEMPLATE_ATTRIBUTE_SERVICE = 
            "enRuleTemplateAttributeService";
    public static final String ROLE_SERVICE = "enRoleService";
    public static final String RESPONSIBILITY_ID_SERVICE = 
            "enResponsibilityIdService";
    public static final String STATS_SERVICE = "enStatsService";
    public static final String ROUTE_MANAGER_QUEUE_SERVICE = 
            "enRouteManagerQueueService";
    public static final String ROUTE_MANAGER_CONTROLLER = 
            "enRouteManagerController";
    public static final String RULE_DELEGATION_SERVICE = 
            "enRuleDelegationService";
    public static final String ROUTE_MANAGER_DRIVER = "enRouteManagerDriver";
    public static final String OPTIMISTIC_LOCK_FAILURE_SERVICE = 
            "enOptimisticLockFailureService";
    public static final String WEB_AUTHENTICATION_SERVICE = 
            "enWebAuthenticationService";
    public static final String NOTE_SERVICE = "enNoteService";
    public static final String ROUTING_REPORT_SERVICE = 
            "enRoutingReportService";
    public static final String ROUTE_MODULE_SERVICE = "enRouteModuleService";
    public static final String EXCEPTION_ROUTING_SERVICE = 
            "enExceptionRoutingService";
    public static final String ACTION_REGISTRY = "enActionRegistry";
    public static final String BRANCH_SERVICE = "enBranchService";

    /**
     * Polls for xml files on disk
     */
    public static final String XML_POLLER_SERVICE = "enXmlPollerService";

    /**
     * Ingests xml docs containers
     */
    public static final String XML_INGESTER_SERVICE = "enXmlIngesterService";

    /**
     * Delegates xml doc parsing
     */
    public static final String XML_DIGESTER_SERVICE = "enXmlDigesterService";

    /**
     * Exports xml data
     */
    public static final String XML_EXPORTER_SERVICE = "enXmlExporterService";
    public static final String DB_TABLES_LOADER = "enDbTablesLoader";
    public static final String DB_PLATFORM = "enDbPlatform";
    public static final String ROUTE_NODE_SERVICE = "enRouteNodeService";
    public static final String WORKFLOW_ENGINE = "workflowEngine";
    public static final String EDOCLITE_SERVICE = "enEDocLiteService";

    //public static final String POST_PROCESSOR_SERVICE = "PostProcessorService";

    /* transactionfun services */
    public static final String TRAN_PERSON_SERVICE = "enTranPersonService";
    public static final String TRAN_ADDRESS_SERVICE = "enTranAddressService";
    public static final String ACTION_LIST_EMAIL_SERVICE = 
            "enActionListEmailService";
    public static final String EMAIL_SERVICE = "enEmailService";
    public static final String NOTIFICATION_SERVICE = "enNotificationService";
    public static final String TRANSACTION_MANAGER = "transactionManager";
    public static final String TRANSACTION_TEMPLATE = "transactionTemplate";
    public static final String JOTM = "jotm";
    public static final String PLUGIN_REGISTRY_SERVICE = "enPluginRegistry";
    public static final String HELP_SERVICE = "enHelpService";
    public static final String WORKFLOW_DOCUMENT_SERVICE = 
            "enWorkflowDocumentService";
    public static final String EXTENSION_SERVICE = "enExtensionService";
    public static final String TRANSFORMATION_SERVICE = 
            "enTransformationService";

    /* public static final String LOOKUPABLE_SERVICE = "enLookupableService";
     public static final String WORKFLOW_ATTRIBUTE_SERVICE = "enWorkflowAttributeService";*/

    // ---- Initialization methods

    /**
     * Initializes Spring with the default spring resource name
     */
    public static synchronized void initializeAppContexts() {
        initializeAppContexts(DEFAULT_SPRING_FILE);
    }

    /**
     * Sets the isOverrideAllowed flag and OJB config file system property prior to
     * initializing Spring with the given context resource name, or a default test resource name
     * If Spring has already started or completed initialization a RuntimeException is thrown.
     * This is done because this method is not expected to be idempotent - namely, it sets
     * the test-specific isOverrideAllowed and OJB properties; at this time there is no way
     * to determine whether subsequent calls are initializing with the correct context resource
     * so we just throw RuntimeException; when this method is reviewed with regard to the new
     * config system, this may be able to be handled more elegantly
     * @param altAppContextFile optional alternative context resource name
     * @param altOjbPropertyFile optional alternative ojb property file resource name
     * @throws RuntimeException if Spring has already started or completed initialization
     */
    public static void setToTestMode(String altAppContextFile, 
                                     String altOjbPropertyFile) {
        if (SPRING_INIT_COMPLETE.hasFired() || 
                SPRING_INIT_STARTED.hasFired()) {
            throw new RuntimeException(
                    "Spring has already started or completed initialization!");
        }

        isOverrideAllowed = true;

        // TODO: address this with regard to new config system
        if (altOjbPropertyFile == null) {
            System.setProperty("OJB.properties", "TestOJB.properties");
        } else {
            System.setProperty("OJB.properties", altOjbPropertyFile);
        }

        if (altAppContextFile == null) {
            initializeAppContexts(TEST_SPRING_FILE);
        } else {
            initializeAppContexts(altAppContextFile);
        }
    }

    /**
     * Initializes Spring with the specified context resource name 
     * @param rootContextFile the Spring context resource name
     */
    private static synchronized void initializeAppContexts(String rootContextFile) {
        if (SPRING_INIT_COMPLETE.hasFired()) {
            return;
        }

        SPRING_INIT_STARTED.fire();

        LOG.info("Initializing Spring from resource: " + rootContextFile);

        try {
            appContext = new ClassPathXmlApplicationContext(rootContextFile);
        } finally {
            // if an exception occurs we need to signal that init is complete
            // even though it is in error, so that close will be allowed
            SPRING_INIT_COMPLETE.fire();
        }
    }

    /**
     * @param serviceName the name of the service bean
     * @return the service
     */
    public static Object getService(String serviceName) {
        return getBean(serviceName);
    }

    /**
     * Explicitly sets the Spring context.  This is mutually exclusive with normal
     * initialization procedure.
     * @param newAppContext the application context to use
     */
    public static synchronized void setAppContext(ApplicationContext newAppContext) {
        if (SPRING_INIT_COMPLETE.hasFired() || 
                SPRING_INIT_STARTED.hasFired()) {
            throw new RuntimeException(
                    "Spring has already started or completed initialization!");
        }

        SPRING_INIT_STARTED.fire();
        appContext = newAppContext;
        SPRING_INIT_COMPLETE.fire();
    }

    /**
     * Obtains a bean from Spring, preferentially returning overridden beans
     * if isOverrideAllowed is true, and an overridden bean is present
     * TODO: revisit this in light of Spring config composition; do we need overridden beans anymore?
     * @param serviceName the name of the bean
     * @return a bean from Spring
     */
    public static Object getBean(String serviceName) {
        initializeAppContexts();

        if (appContext == null) {
            throw new RuntimeException(
                    "Spring not initialized properly.  Initialization has completed and the application context is null.");
        }

        // if overriding is allowed, check for an overridden bean first
        if (isOverrideAllowed) {
            Object bean = overiddenBeans.get(serviceName);

            if (bean != null) {
                return bean;
            }
        }

        return appContext.getBean(serviceName);
    }

    public static Class getType(String beanName) {
        initializeAppContexts();

        if (appContext == null) {
            throw new RuntimeException(
                    "Spring not initialized properly.  Initialization has completed and the application context is null.");
        }

        return appContext.getType(beanName);
    }

    public static boolean isSingleton(String beanName) {
        initializeAppContexts();

        if (appContext == null) {
            throw new RuntimeException(
                    "Spring not initialized properly.  Initialization has completed and the application context is null.");
        }

        return appContext.isSingleton(beanName);
    }

    /**
     * Closes the Spring context if initialization has at least started.
     * If initialization has NOT started, this method returns immediately.
     * If initialization HAS started, then it awaits completion before closing 
     */
    public static synchronized void close() {
        if (!SPRING_INIT_STARTED.hasFired()) {
            return;
        }


        // this is not technically necessary at this time because both close and initialize* methods
        // are synchronized so initialization should always be complete if it has been started;
        // NOTE: although - let's think about error cases...if exception is thrown from init, then
        // SPRING_INIT_COMPLETE may never have fired - that is a good thing probably, but maybe it warrants
        // a separate SPRING_INIT_FAILED condition; don't want to get too complicated though
        SPRING_INIT_COMPLETE.await();

        if (appContext instanceof ConfigurableApplicationContext) {
            ((ConfigurableApplicationContext) appContext).close();
        }

        SPRING_INIT_STARTED.reset();
        SPRING_INIT_COMPLETE.reset();
    }

    /* Review the idea of "overriding" in presence of Spring config file composition
     * (and perhaps the possibility of wrapping SpringServiceLocator)
     */

    /**
     * Explicitly overrides a bean with the specified object
     * This method should only be used by test code
     * TODO: reconsider this notion in light of composable Spring contexts
     * @param serviceName the bean/service name
     * @param bean the bean to supply as the override
     */
    public static void overrideService(String serviceName, Object bean) {
        if (!isOverrideAllowed) {
            throw new UnsupportedOperationException(
                    "Services can only be overriden for testing purposes!");
        }

        overiddenBeans.put(serviceName, bean);
    }

    /**
     * Removes the registration of an overriding bean
     * This method should only be used by test code
     * TODO: reconsider this notion in light of composable Spring contexts
     * @param serviceName the overriding bean/service name to remove
     */
    public static void unoverrideService(String serviceName) {
        overiddenBeans.remove(serviceName);
    }

    /**
     * Returns the Spring context, waiting for initialization to start and complete
     * if it hasn't already
     * @return the intiailized Spring context
     */
    public static ApplicationContext getAppContext() {
        SPRING_INIT_COMPLETE.await();

        return appContext;
    }

    // ---- Service accessors
    public static Platform getDbPlatform() {
        return (Platform) getBean(DB_PLATFORM);
    }

    public static WorkflowUtility getWorkflowUtilityService() {
        return (WorkflowUtility) getBean(WORKFLOW_UTILITY_SERVICE);
    }

    public static WorkflowDocumentActions getWorkflowDocumentActionsService() {
        return (WorkflowDocumentActions) getBean(
                       WORKFLOW_DOCUMENT_ACTIONS_SERVICE);
    }

    public static DocumentTypeService getDocumentTypeService() {
        return (DocumentTypeService) getBean(DOCUMENT_TYPE_SERVICE);
    }

    public static ActionRequestService getActionRequestService() {
        return (ActionRequestService) getBean(ACTION_REQUEST_SRV);
    }

    public static UserService getUserService() {
        return (UserService) getBean(USER_SERVICE);
    }

    public static ActionTakenService getActionTakenService() {
        return (ActionTakenService) getBean(ACTION_TAKEN_SRV);
    }

    public static WorkgroupService getWorkgroupService() {
        return (WorkgroupService) getBean(WORKGROUP_SRV);
    }

    public static WorkgroupRoutingService getWorkgroupRoutingService() {
        return (WorkgroupRoutingService) getBean(WORKGROUP_ROUTING_SERVICE);
    }

    public static ResponsibilityIdService getResponsibilityIdService() {
        return (ResponsibilityIdService) getBean(RESPONSIBILITY_ID_SERVICE);
    }

    public static RouteHeaderService getRouteHeaderService() {
        return (RouteHeaderService) getBean(DOC_ROUTE_HEADER_SRV);
    }

    public static RuleTemplateService getRuleTemplateService() {
        return (RuleTemplateService) getBean(RULE_TEMPLATE_SERVICE);
    }

    public static RuleAttributeService getRuleAttributeService() {
        return (RuleAttributeService) getBean(RULE_ATTRIBUTE_SERVICE);
    }

    //public static FiscalOrgService getFiscalChartService() {
    //    return (FiscalOrgService) getBean(SpringServiceLocator.FISCAL_ORG_SERVICE);
    //}
    public static WorkflowDocumentService getWorkflowDocumentService() {
        return (WorkflowDocumentService) getBean(WORKFLOW_DOCUMENT_SERVICE);
    }

    public static RouteQueueService getRouteQueueService() {
        return (RouteQueueService) getBean(ROUTE_QUEUE_SRV);
    }

    public static RouteModuleService getRouteModuleService() {
        return (RouteModuleService) getBean(ROUTE_MODULE_SERVICE);
    }

    public static ApplicationConstantsService getApplicationConstantsService() {
        return (ApplicationConstantsService) getBean(APPLICATION_CONSTANTS_SRV);
    }

    public static RoleService getRoleService() {
        return (RoleService) getBean(ROLE_SERVICE);
    }

    public static RuleService getRuleService() {
        return (RuleService) getBean(RULE_SERVICE);
    }

    public static RuleDelegationService getRuleDelegationService() {
        return (RuleDelegationService) getBean(RULE_DELEGATION_SERVICE);
    }

    public static PluginRegistry getPluginRegistry() {
        return (PluginRegistry) getBean(PLUGIN_REGISTRY_SERVICE);
    }

    public static ExtensionService getExtensionService() {
        return (ExtensionService) getBean(EXTENSION_SERVICE);
    }

    //    public static Current getJotm() {
    //    	return (Current)getBean(JOTM);
    //    }
    public static Current getJotm() {
        Object jotm = getBean(JOTM);

        if (jotm == null) {
            throw new RuntimeException("Could not locate JOTM.");
        }

        return (Current) jotm;
    }

    public static HelpService getHelpService() {
        return (HelpService) getBean(HELP_SERVICE);
    }

    public static RoutingReportService getRoutingReportService() {
        return (RoutingReportService) getBean(ROUTING_REPORT_SERVICE);
    }

    public static RouteManagerController getRouteManagerController() {
        return (RouteManagerController) getBean(ROUTE_MANAGER_CONTROLLER);
    }

    public static RouteManagerQueueService getRouteManagerQueueService() {
        return (RouteManagerQueueService) getBean(ROUTE_MANAGER_QUEUE_SERVICE);
    }

    public static RouteManagerDriver getRouteManagerDriver() {
        return (RouteManagerDriver) getBean(ROUTE_MANAGER_DRIVER);
    }

    public static Cache getCache() {
        return (Cache) getBean(CACHE_MANAGER);
    }

    public static PreferencesService getPreferencesService() {
        return (PreferencesService) getBean(PREFERENCES_SERVICE);
    }

    public static XmlPollerService getXmlPollerService() {
        return (XmlPollerService) getBean(XML_POLLER_SERVICE);
    }

    public static XmlIngesterService getXmlIngesterService() {
        return (XmlIngesterService) getBean(XML_INGESTER_SERVICE);
    }

    public static XmlDigesterService getXmlDigesterService() {
        return (XmlDigesterService) getBean(XML_DIGESTER_SERVICE);
    }

    public static XmlExporterService getXmlExporterService() {
        return (XmlExporterService) getBean(XML_EXPORTER_SERVICE);
    }

    public static DataSource getEdenDataSource() {
        return (DataSource) getBean(EDEN_DATASOURCE);
    }

    public static UserOptionsService getUserOptionsService() {
        return (UserOptionsService) getBean(USER_OPTIONS_SRV);
    }

    public static ActionListService getActionListService() {
        return (ActionListService) getBean(ACTION_LIST_SRV);
    }

    public static RouteNodeService getRouteNodeService() {
        return (RouteNodeService) getBean(ROUTE_NODE_SERVICE);
    }

    public static WorkflowEngine getWorkflowEngine() {
        return (WorkflowEngine) getBean(WORKFLOW_ENGINE);
    }

    public static EDocLiteService getEDocLiteService() {
        return (EDocLiteService) getBean(EDOCLITE_SERVICE);
    }

    //    public static EDLService getEDocLiteService2() {
    //        return (EDLService) getBean(EDOCLITE_SERVICE + "2");
    //    }
    public static TransformationService getTransformationService() {
        return (TransformationService) getBean(TRANSFORMATION_SERVICE);
    }

    public static WebAuthenticationService getWebAuthenticationService() {
        return (WebAuthenticationService) getBean(WEB_AUTHENTICATION_SERVICE);
    }

    public static ExceptionRoutingService getExceptionRoutingService() {
        return (ExceptionRoutingService) getBean(EXCEPTION_ROUTING_SERVICE);
    }

    public static ActionListEmailService getActionListEmailService() {
        return (ActionListEmailService) getBean(
                       SpringServiceLocator.ACTION_LIST_EMAIL_SERVICE);
    }

    public static EmailService getEmailService() {
        return (EmailService) getBean(SpringServiceLocator.EMAIL_SERVICE);
    }

    public static NotificationService getNotificationService() {
        return (NotificationService) getBean(
                       SpringServiceLocator.NOTIFICATION_SERVICE);
    }

    //    public static PlatformTransactionManager getTransactionManager() {
    //        return (PlatformTransactionManager)getBean(TRANSACTION_MANAGER);
    //    }
    public static TransactionTemplate getTransactionTemplate() {
        return (TransactionTemplate) getBean(TRANSACTION_TEMPLATE);
    }

    public static JtaTransactionManager getJtaTransactionManager() {
        return (JtaTransactionManager) getBean(TRANSACTION_MANAGER);
    }

    public static TransactionManager getTransactionManager() {
        return getJtaTransactionManager().getTransactionManager();
    }

    public static UserTransaction getUserTransaction() {
        return getJtaTransactionManager().getUserTransaction();
    }

    public static NoteService getNoteService() {
        return (NoteService) getBean(NOTE_SERVICE);
    }

    public static OptimisticLockFailureService getOptimisticLockFailureService() {
        return (OptimisticLockFailureService) getBean(
                       OPTIMISTIC_LOCK_FAILURE_SERVICE);
    }

    public static ActionRegistry getActionRegistry() {
        return (ActionRegistry) getBean(ACTION_REGISTRY);
    }
}