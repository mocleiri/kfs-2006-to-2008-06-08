
/*
 * Copyright (c) 2004, 2005, 2006 Trustees of Indiana University and Cornell University.
 *
 * Licensed under the Educational Community License Version 1.0 (the "License"); By obtaining,
 * using and/or copying this Original Work, you agree that you have read, understand, and will
 * comply with the terms and conditions of the Educational Community License.
 *
 * For the full text of the license, see the LICENSE.txt file or visit:
 * 
 * http://kew.indiana.edu/workflow/LICENSE.txt
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING
 * BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE
 * AND NONINFRINGEMENT.
 * IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES
 * OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 */
            
package edu.iu.uis.eden.actionitem.dao;

import edu.iu.uis.eden.SpringServiceLocator;
import edu.iu.uis.eden.actionitem.ActionItem;
import edu.iu.uis.eden.exception.EdenUserNotFoundException;
import edu.iu.uis.eden.user.UserService;
import edu.iu.uis.eden.user.WorkflowUser;
import edu.iu.uis.eden.user.WorkflowUserId;
import edu.iu.uis.eden.workgroup.WorkflowGroupId;
import edu.iu.uis.eden.workgroup.WorkgroupService;

import java.sql.Timestamp;

import java.util.Collection;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import org.apache.ojb.broker.query.Criteria;
import org.apache.ojb.broker.query.QueryByCriteria;
import org.apache.ojb.broker.query.QueryFactory;
import org.apache.ojb.broker.query.ReportQueryByCriteria;

import org.springframework.orm.ojb.PersistenceBrokerTemplate;


public class ActionItemDAOOjbImpl extends PersistenceBrokerTemplate
    implements ActionItemDAO {
    public ActionItem findByActionItemId(Long actionItemId) {
        Criteria crit = new Criteria();
        crit.addEqualTo("actionItemId", actionItemId);

        return (ActionItem) getObjectByQuery(
                       new QueryByCriteria(ActionItem.class, crit));
    }

    public void deleteActionItems(Long actionRequestId) {
        Criteria crit = new Criteria();
        crit.addEqualTo("actionRequestId", actionRequestId);
        deleteByQuery(new QueryByCriteria(ActionItem.class, crit));
    }

    public void deleteActionItem(ActionItem actionItem) {
        delete(actionItem);
    }

    public void deleteByRouteHeaderIdWorkflowUserId(Long routeHeaderId, 
                                                    String workflowUserId) {
        Criteria crit = new Criteria();
        crit.addEqualTo("routeHeaderId", routeHeaderId);
        crit.addEqualTo("workflowId", workflowUserId);
        deleteByQuery(new QueryByCriteria(ActionItem.class, crit));
    }

    public void deleteByRouteHeaderId(Long routeHeaderId) {
        Criteria crit = new Criteria();
        crit.addEqualTo("routeHeaderId", routeHeaderId);
        deleteByQuery(new QueryByCriteria(ActionItem.class, crit));
    }

    public Collection findByWorkflowUser(WorkflowUser workflowUser) {
        Criteria crit = new Criteria();
        crit.addEqualTo("workflowId", 
                        workflowUser.getWorkflowUserId().getWorkflowId());

        QueryByCriteria query = new QueryByCriteria(ActionItem.class, crit);
        query.addOrderByAscending("routeHeader.routeHeaderId");

        return getCollectionByQuery(query);
    }

    public Collection findByWorkflowUserRouteHeaderId(String workflowId, 
                                                      Long routeHeaderId) {
        Criteria crit = new Criteria();
        crit.addEqualTo("workflowId", workflowId);
        crit.addEqualTo("routeHeaderId", routeHeaderId);

        return getCollectionByQuery(new QueryByCriteria(ActionItem.class, crit));
    }

    public Collection findByRouteHeaderId(Long routeHeaderId) {
        Criteria crit = new Criteria();
        crit.addEqualTo("routeHeaderId", routeHeaderId);

        return getCollectionByQuery(new QueryByCriteria(ActionItem.class, crit));
    }

    public Collection findByActionRequestId(Long actionRequestId) {
        Criteria crit = new Criteria();
        crit.addEqualTo("actionRequestId", actionRequestId);

        return getCollectionByQuery(new QueryByCriteria(ActionItem.class, crit));
    }

    public Collection findByWorkgroupId(final Long workgroupId) {
        //TODO do this on DDAY
        throw new UnsupportedOperationException("Method not implemented");
    }

    public void saveActionItem(ActionItem actionItem) {
        if (actionItem.getDateAssigned() == null) {
            actionItem.setDateAssigned(new Timestamp(new Date().getTime()));
        }

        store(actionItem);
    }

    public Collection findDelegators(WorkflowUser user, String delegationType)
                              throws EdenUserNotFoundException {
        Criteria notNullWorkflowCriteria = new Criteria();
        notNullWorkflowCriteria.addNotNull("delegatorWorkflowId");

        Criteria notNullWorkgroupCriteria = new Criteria();
        notNullWorkgroupCriteria.addNotNull("delegatorWorkgroupId");

        Criteria orCriteria = new Criteria();
        orCriteria.addOrCriteria(notNullWorkflowCriteria);
        orCriteria.addOrCriteria(notNullWorkgroupCriteria);

        Criteria criteria = new Criteria();
        criteria.addEqualTo("workflowId", 
                            user.getWorkflowUserId().getWorkflowId());

        if ((delegationType != null) && !"".equals(delegationType)) {
            criteria.addEqualTo("delegationType", delegationType);
        }

        criteria.addAndCriteria(orCriteria);

        ReportQueryByCriteria query = QueryFactory.newReportQuery(
                                              ActionItem.class, criteria);

        query.setAttributes(
                new String[] { "delegatorWorkflowId", "delegatorWorkgroupId" });

        Map delegators = new HashMap();
        Iterator iterator = getReportQueryIteratorByQuery(query);

        while (iterator.hasNext()) {
            Object[] ids = (Object[]) iterator.next();

            if ((ids[0] != null) && 
                    !delegators.containsKey((String) ids[0])) {
                delegators.put((String) ids[0], 
                               getUserService()
                                   .getWorkflowUser(new WorkflowUserId(
                                                            (String) ids[0])));
            } else if (ids[1] != null) {
                Long workgroupId = new Long(ids[1].toString());

                if (!delegators.containsKey(workgroupId)) {
                    delegators.put(workgroupId, 
                                   getWorkgroupService()
                                       .getWorkgroup(new WorkflowGroupId(
                                                             workgroupId)));
                }
            }
        }

        return delegators.values();
    }

    private UserService getUserService() {
        return (UserService) SpringServiceLocator.getService(
                       SpringServiceLocator.USER_SERVICE);
    }

    private WorkgroupService getWorkgroupService() {
        return (WorkgroupService) SpringServiceLocator.getService(
                       SpringServiceLocator.WORKGROUP_SRV);
    }
}