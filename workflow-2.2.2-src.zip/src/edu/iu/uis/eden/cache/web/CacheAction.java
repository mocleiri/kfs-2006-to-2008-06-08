
/*
 * Copyright (c) 2004, 2005, 2006 Trustees of Indiana University and Cornell University.
 *
 * Licensed under the Educational Community License Version 1.0 (the "License"); By obtaining,
 * using and/or copying this Original Work, you agree that you have read, understand, and will
 * comply with the terms and conditions of the Educational Community License.
 *
 * For the full text of the license, see the LICENSE.txt file or visit:
 * 
 * http://kew.indiana.edu/workflow/LICENSE.txt
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING
 * BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE
 * AND NONINFRINGEMENT.
 * IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES
 * OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 */
            
package edu.iu.uis.eden.cache.web;

import edu.iu.uis.eden.EdenConstants;
import edu.iu.uis.eden.SpringServiceLocator;
import edu.iu.uis.eden.util.Utilities;
import edu.iu.uis.eden.web.WorkflowAction;
import edu.iu.uis.eden.workgroup.GroupNameId;
import edu.iu.uis.eden.workgroup.Workgroup;
import edu.iu.uis.eden.workgroup.WorkgroupService;
import edu.iu.uis.sit.cache.Cache;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.action.ActionMessages;


public class CacheAction extends WorkflowAction {
    public ActionForward start(ActionMapping mapping, ActionForm form, 
                               HttpServletRequest request, 
                               HttpServletResponse response)
                        throws Exception {
        return mapping.findForward("basic");
    }

    public ActionForward refresh(ActionMapping mapping, ActionForm form, 
                                 HttpServletRequest request, 
                                 HttpServletResponse response)
                          throws Exception {
        Workgroup workgroup = getWorkgroupService()
                                  .getWorkgroup(new GroupNameId(
                                                        Utilities.getApplicationConstant(
                                                                EdenConstants.WORKFLOW_ADMIN_WORKGROUP_NAME_KEY)));

        if (workgroup.hasMember(getUserSession(request).getWorkflowUser())) {
        }

        return mapping.findForward("basic");
    }

    public ActionMessages establishRequiredState(HttpServletRequest request, 
                                                 ActionForm form)
                                          throws Exception {
        CacheForm cacheForm = (CacheForm) form;
        Cache cache = Utilities.getCache();
        cacheForm.setCacheNames(cache.getCacheNames());
        cacheForm.setCaches(cache.getCaches());

        return null;
    }

    private WorkgroupService getWorkgroupService() {
        return (WorkgroupService) SpringServiceLocator.getService(
                       SpringServiceLocator.WORKGROUP_SRV);
    }
}