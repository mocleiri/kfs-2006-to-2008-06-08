
/*
 * Copyright (c) 2004, 2005, 2006 Trustees of Indiana University and Cornell University.
 *
 * Licensed under the Educational Community License Version 1.0 (the "License"); By obtaining,
 * using and/or copying this Original Work, you agree that you have read, understand, and will
 * comply with the terms and conditions of the Educational Community License.
 *
 * For the full text of the license, see the LICENSE.txt file or visit:
 * 
 * http://kew.indiana.edu/workflow/LICENSE.txt
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING
 * BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE
 * AND NONINFRINGEMENT.
 * IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES
 * OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 */
            
package edu.iu.uis.eden.cache;

import edu.iu.uis.eden.SpringServiceLocator;
import edu.iu.uis.eden.applicationconstants.ApplicationConstant;
import edu.iu.uis.eden.applicationconstants.ApplicationConstantsService;
import edu.iu.uis.sit.cache.Cachable;

import java.io.Serializable;

import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;


public class ApplicationConstantsCache implements Cachable, Serializable {
    private static final long serialVersionUID = 5333889661649031443L;
    private static org.apache.log4j.Logger LOG = org.apache.log4j.Logger.getLogger(
                                                         ApplicationConstantsCache.class);

    /**
     * ID of the application constants cache.
     */
    public static final String APPLICATION_CONSTANTS_CACHE_ID = 
            "edu.iu.uis.eden.cache.ApplicationConstantsCache";

    // injecting this service because this service needs this class injected as well
    private ApplicationConstantsService applicationConstantsService;
    private Map constants;

    /**
     * Gets the ID of the applcation constants cache.
     */
    public String getId() {
        return APPLICATION_CONSTANTS_CACHE_ID;
    }

    /**
     * Reloads the application constants cache.
     */
    public synchronized void reload() {
        LOG.debug("Start Reloading ApplicationConstantsCache...");
        constants = new HashMap();

        Collection constantsFromDB = getApplicationConstantsService().findAll();

        if (constantsFromDB != null) {
            Iterator i = constantsFromDB.iterator();

            while (i.hasNext()) {
                ApplicationConstant constant = (ApplicationConstant) i.next();
                constants.put(constant.getApplicationConstantName(), 
                              constant.getApplicationConstantValue());
            }
        }

        LOG.debug("Finished Reloading ApplicationConstantsCache.");
    }

    /**
     * Gets an application constant.
     * 
     * @param name name of the constant.
     * @return value of the constant.
     */
    public synchronized String getApplicationConstant(String name) {
        return (String) constants.get(name);
    }

    /**
     * Returns the runtime class of the cache object.
     */
    public Class getClassType() {
        return getClass();
    }

    public ApplicationConstantsService getApplicationConstantsService() {
        if (applicationConstantsService != null) {
            return applicationConstantsService;
        } else {
            return (ApplicationConstantsService) SpringServiceLocator.getService(
                           SpringServiceLocator.APPLICATION_CONSTANTS_SRV);
        }
    }

    public void setApplicationConstantsService(ApplicationConstantsService applicationConstantsService) {
        this.applicationConstantsService = applicationConstantsService;
    }
}