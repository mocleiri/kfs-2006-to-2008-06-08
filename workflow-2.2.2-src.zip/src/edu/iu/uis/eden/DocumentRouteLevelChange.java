
/*
 * Copyright (c) 2004, 2005, 2006 Trustees of Indiana University and Cornell University.
 *
 * Licensed under the Educational Community License Version 1.0 (the "License"); By obtaining,
 * using and/or copying this Original Work, you agree that you have read, understand, and will
 * comply with the terms and conditions of the Educational Community License.
 *
 * For the full text of the license, see the LICENSE.txt file or visit:
 * 
 * http://kew.indiana.edu/workflow/LICENSE.txt
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING
 * BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE
 * AND NONINFRINGEMENT.
 * IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES
 * OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 */
            
package edu.iu.uis.eden;

/**
 * <p><Title> </p>
 * <p><Description> </p>
 * <p><p><p>Copyright: Copyright (c) 2002</p>
 * <p><p>Company: UIS - Indiana University</p>
 * @author <a href="mailto:seiffert@indiana.edu">Kurt A. Seiffert</a>
 * @version $Revision: 1.2 $ - $Date: 2005/09/20 22:13:23 $
 */
public class DocumentRouteLevelChange implements IDocumentEvent {
    // TODO for now we will include the new node-based routing fields onto this object to avoid an interface
    // change to the PostProcessor interface.
    private static final long serialVersionUID = 785552701611174468L;
    private Long routeHeaderId;
    private String appDocId;
    private Integer oldRouteLevel;
    private Integer newRouteLevel;
    private String oldNodeName;
    private String newNodeName;
    private Long oldNodeInstanceId;
    private Long newNodeInstanceId;

    // TODO this constructor is for backwards compatibility
    public DocumentRouteLevelChange(Long routeHeaderId, String appDocId, 
                                    Integer oldRouteLevel, 
                                    Integer newRouteLevel) {
        this(routeHeaderId, appDocId, oldRouteLevel, newRouteLevel, null, null, 
             null, null);
    }

    public DocumentRouteLevelChange(Long routeHeaderId, String appDocId, 
                                    Integer oldRouteLevel, 
                                    Integer newRouteLevel, String oldNodeName, 
                                    String newNodeName, Long oldNodeInstanceId, 
                                    Long newNodeInstanceId) {
        this.routeHeaderId = routeHeaderId;
        this.oldRouteLevel = oldRouteLevel;
        this.newRouteLevel = newRouteLevel;
        this.oldNodeName = oldNodeName;
        this.newNodeName = newNodeName;
        this.oldNodeInstanceId = oldNodeInstanceId;
        this.newNodeInstanceId = newNodeInstanceId;
        this.appDocId = appDocId;
    }

    public String getDocumentEventCode() {
        return ROUTE_LEVEL_CHANGE;
    }

    public Long getRouteHeaderId() {
        return routeHeaderId;
    }

    public Integer getOldRouteLevel() {
        return oldRouteLevel;
    }

    public Integer getNewRouteLevel() {
        return newRouteLevel;
    }

    public Long getNewNodeInstanceId() {
        return newNodeInstanceId;
    }

    public String getNewNodeName() {
        return newNodeName;
    }

    public Long getOldNodeInstanceId() {
        return oldNodeInstanceId;
    }

    public String getOldNodeName() {
        return oldNodeName;
    }

    public String toString() {
        StringBuffer buffer = new StringBuffer();
        buffer.append("RouteHeaderID ").append(routeHeaderId);
        buffer.append(" changing from routeLevel ").append(oldRouteLevel);
        buffer.append(" to routeLevel ").append(newRouteLevel);

        return buffer.toString();
    }

    /**
     * @return
     */
    public String getAppDocId() {
        return appDocId;
    }
}

/*
 * Copyright 2003 The Trustees of Indiana University.  All rights reserved.
 *
 * This file is part of the EDEN software package.
 * For license information, see the LICENSE file in the top level directory
 * of the EDEN source distribution.
 */
