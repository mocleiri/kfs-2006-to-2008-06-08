
/*
 * Copyright (c) 2004, 2005, 2006 Trustees of Indiana University and Cornell University.
 *
 * Licensed under the Educational Community License Version 1.0 (the "License"); By obtaining,
 * using and/or copying this Original Work, you agree that you have read, understand, and will
 * comply with the terms and conditions of the Educational Community License.
 *
 * For the full text of the license, see the LICENSE.txt file or visit:
 * 
 * http://kew.indiana.edu/workflow/LICENSE.txt
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING
 * BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE
 * AND NONINFRINGEMENT.
 * IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES
 * OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 */
            
package edu.iu.uis.eden.actions;

import edu.iu.uis.eden.EdenConstants;
import edu.iu.uis.eden.exception.EdenUserNotFoundException;
import edu.iu.uis.eden.exception.InvalidActionTakenException;
import edu.iu.uis.eden.exception.ResourceUnavailableException;
import edu.iu.uis.eden.routeheader.DocumentRouteHeaderValue;
import edu.iu.uis.eden.user.Recipient;
import edu.iu.uis.eden.user.WorkflowUser;

import java.util.List;

import org.apache.log4j.MDC;


/**
 * The ApproveAction records and processes an approve action.
 * 
 * The routeheader is first checked to make sure the action is valid for the document. 
 * Next the user is checked to make sure he/she has not taken a previous action on this 
 * document at the actions responsibility or below. The action is recorded. 
 * Any requests related to this user are deactivated.
 * 
 * @version $Revision: 1.16 $ - $Date: 2006/04/28 12:35:17 $
 */
public class ApproveAction extends ActionTakenEvent {
    private static final org.apache.log4j.Logger LOG = 
            org.apache.log4j.Logger.getLogger(ApproveAction.class);

    /**
     * @param routeHeader
     *            RouteHeader for the document upon which the action is taken.
     * @param user
     *            User taking the action.
     * @param annotation
     *            User comment on the action taken
     */
    public ApproveAction(DocumentRouteHeaderValue routeHeader, 
                         WorkflowUser user, String annotation) {
        super(routeHeader, user, annotation);
        setActionTakenCode(EdenConstants.ACTION_TAKEN_APPROVED_CD);
    }

    /**
     * Records the approve action. 
     * - Checks to make sure the document status allows the action.
     * - Checks that the user has not taken a previous action.
     * - Deactivates the pending requests for this user
     * - Records the action
     * 
     * @throws InvalidActionTakenException
     * @throws ResourceUnavailableException
     */
    public void recordAction() throws InvalidActionTakenException, 
                                      EdenUserNotFoundException {
        MDC.put("docId", getRouteHeader().getRouteHeaderId());
        super.recordAction();

        if (!routeHeader.isValidActionToTake(getActionTakenCode())) {
            LOG.warn("Document not in state to be approved.");
            throw new InvalidActionTakenException(
                    "Document is not in a state to be approved");
        }

        LOG.debug("Approving document : " + annotation);

        List actionRequests = getActionRequestService()
                                  .findAllValidRequests(getUser(), 
                                                        getRouteHeaderId(), 
                                                        EdenConstants.ACTION_REQUEST_APPROVE_REQ);

        if (!isActionCompatibleRequest(actionRequests, getActionTakenCode())) {
            throw new InvalidActionTakenException(
                    "No request for the user is compatible " + 
                    "with the APPROVE action");
        }

        Recipient delegator = findDelegatorForActionRequests(actionRequests);

        LOG.debug("Record the approve action");
        saveActionTaken(delegator);

        LOG.debug("Deactivate all pending action requests");
        getActionRequestService()
            .deactivateRequests(actionTaken, actionRequests);
        notifyActionTaken(this.actionTaken);

        boolean isException = getRouteHeader().isInException();
        boolean isSaved = getRouteHeader().isStateSaved();

        if (isException || isSaved) {
            String oldStatus = getRouteHeader().getDocRouteStatus();
            LOG.debug("Moving document back to Enroute from " + 
                      EdenConstants.DOCUMENT_STATUSES.get(oldStatus));
            getRouteHeader().markDocumentEnroute();

            String newStatus = getRouteHeader().getDocRouteStatus();
            notifyStatusChange(newStatus, oldStatus);
            this.getRouteHeaderService().saveRouteHeader(getRouteHeader());
        }
    }
}