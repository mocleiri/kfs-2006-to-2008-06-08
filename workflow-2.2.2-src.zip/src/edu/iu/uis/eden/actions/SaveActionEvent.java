
/*
 * Copyright (c) 2004, 2005, 2006 Trustees of Indiana University and Cornell University.
 *
 * Licensed under the Educational Community License Version 1.0 (the "License"); By obtaining,
 * using and/or copying this Original Work, you agree that you have read, understand, and will
 * comply with the terms and conditions of the Educational Community License.
 *
 * For the full text of the license, see the LICENSE.txt file or visit:
 * 
 * http://kew.indiana.edu/workflow/LICENSE.txt
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING
 * BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE
 * AND NONINFRINGEMENT.
 * IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES
 * OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 */
            
package edu.iu.uis.eden.actions;

import edu.iu.uis.eden.EdenConstants;
import edu.iu.uis.eden.SpringServiceLocator;
import edu.iu.uis.eden.actionrequests.ActionRequestFactory;
import edu.iu.uis.eden.actionrequests.ActionRequestValue;
import edu.iu.uis.eden.engine.node.RouteNodeInstance;
import edu.iu.uis.eden.exception.EdenUserNotFoundException;
import edu.iu.uis.eden.exception.InvalidActionTakenException;
import edu.iu.uis.eden.exception.WorkflowException;
import edu.iu.uis.eden.routeheader.DocumentRouteHeaderValue;
import edu.iu.uis.eden.user.WorkflowUser;

import org.apache.log4j.MDC;


public class SaveActionEvent extends ActionTakenEvent {
    private static final org.apache.log4j.Logger LOG = 
            org.apache.log4j.Logger.getLogger(SaveActionEvent.class);
    private static final String RESPONSIBILITY_DESCRIPTION = 
            "Initiator needs to complete document.";

    public SaveActionEvent(DocumentRouteHeaderValue routeHeader, 
                           WorkflowUser user, String annotation) {
        super(routeHeader, user, annotation);
        setActionTakenCode(EdenConstants.ACTION_TAKEN_SAVED_CD);
    }

    public void recordAction() throws InvalidActionTakenException, 
                                      EdenUserNotFoundException {
        MDC.put("docId", getRouteHeader().getRouteHeaderId());
        super.recordAction();

        if (annotation == null) {
            annotation = "";
        }

        LOG.debug("Checking to see if the action is legal");

        if (getRouteHeader().isValidActionToTake(getActionTakenCode())) {
            if (getRouteHeader().isStateInitiated()) {
                LOG.debug("Record the save action");
                saveActionTaken();
                generateSaveRequest();
                LOG.debug("Marking document saved");

                try {
                    String oldStatus = getRouteHeader().getDocRouteStatus();
                    getRouteHeader().markDocumentSaved();

                    String newStatus = getRouteHeader().getDocRouteStatus();
                    notifyStatusChange(newStatus, oldStatus);
                    getRouteHeaderService().saveRouteHeader(routeHeader);
                } catch (WorkflowException ex) {
                    LOG.warn(ex, ex);
                    throw new InvalidActionTakenException(ex.getMessage());
                }
            }
        } else {
            LOG.warn("Document not in state to be saved.");
            throw new InvalidActionTakenException(
                    "Document is not in a state to be saved");
        }
    }

    protected void generateSaveRequest() throws InvalidActionTakenException, 
                                                EdenUserNotFoundException {
        RouteNodeInstance intialNode = (RouteNodeInstance) SpringServiceLocator.getRouteNodeService()
                                                                               .getInitialNodeInstances(routeHeaderId)
                                                                               .get(0);
        ActionRequestFactory arFactory = new ActionRequestFactory(routeHeader, 
                                                                  intialNode);
        ActionRequestValue saveRequest = arFactory.createActionRequest(
                                                 EdenConstants.ACTION_REQUEST_COMPLETE_REQ, 
                                                 getUser(), 
                                                 RESPONSIBILITY_DESCRIPTION, 
                                                 Boolean.TRUE, annotation);
        this.getActionRequestService().saveActionRequest(saveRequest);
    }
}