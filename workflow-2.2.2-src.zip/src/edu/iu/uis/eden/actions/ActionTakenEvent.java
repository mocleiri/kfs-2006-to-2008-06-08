
/*
 * Copyright (c) 2004, 2005, 2006 Trustees of Indiana University and Cornell University.
 *
 * Licensed under the Educational Community License Version 1.0 (the "License"); By obtaining,
 * using and/or copying this Original Work, you agree that you have read, understand, and will
 * comply with the terms and conditions of the Educational Community License.
 *
 * For the full text of the license, see the LICENSE.txt file or visit:
 * 
 * http://kew.indiana.edu/workflow/LICENSE.txt
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING
 * BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE
 * AND NONINFRINGEMENT.
 * IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES
 * OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 */
            
package edu.iu.uis.eden.actions;

import edu.iu.uis.eden.DocumentRouteStatusChange;
import edu.iu.uis.eden.EdenConstants;
import edu.iu.uis.eden.SpringServiceLocator;
import edu.iu.uis.eden.actionrequests.ActionRequestService;
import edu.iu.uis.eden.actionrequests.ActionRequestValue;
import edu.iu.uis.eden.actiontaken.ActionTakenService;
import edu.iu.uis.eden.actiontaken.ActionTakenValue;
import edu.iu.uis.eden.docsearch.SearchableAttributeProcessor;
import edu.iu.uis.eden.doctype.DocumentTypeService;
import edu.iu.uis.eden.exception.EdenUserNotFoundException;
import edu.iu.uis.eden.exception.InvalidActionTakenException;
import edu.iu.uis.eden.postprocessor.PostProcessor;
import edu.iu.uis.eden.postprocessor.ProcessDocReport;
import edu.iu.uis.eden.routeheader.DocumentRouteHeaderValue;
import edu.iu.uis.eden.routeheader.RouteHeaderService;
import edu.iu.uis.eden.routequeue.RouteQueue;
import edu.iu.uis.eden.routequeue.RouteQueueService;
import edu.iu.uis.eden.user.Recipient;
import edu.iu.uis.eden.user.WorkflowUser;
import edu.iu.uis.eden.workgroup.Workgroup;

import java.sql.Timestamp;

import java.util.Iterator;
import java.util.List;


public abstract class ActionTakenEvent {
    private static final org.apache.log4j.Logger LOG = 
            org.apache.log4j.Logger.getLogger(ActionTakenEvent.class);

    //    private ActionRequestNotificationGenerator notificationGenerator = new ActionRequestNotificationGenerator();
    private String actionTakenCode;
    protected String annotation;
    protected ActionTakenValue actionTaken;
    protected DocumentRouteHeaderValue routeHeader;
    protected Long routeHeaderId;
    protected Boolean currentInd = new Boolean(true);
    private WorkflowUser user;

    public ActionTakenEvent(DocumentRouteHeaderValue routeHeader, 
                            WorkflowUser user, String annotation) {
        this.routeHeader = routeHeader;
        this.user = user;
        this.annotation = annotation;
        this.routeHeaderId = routeHeader.getRouteHeaderId();

        //queue the document up so that it can be indexed for searching if it has searchable attributes
        if (routeHeader.getDocumentType().hasSearchableAttributes()) {
            RouteQueue searchIndexingWork = new RouteQueue();
            searchIndexingWork.setProcessorClassName(
                    SearchableAttributeProcessor.class.getName());
            searchIndexingWork.setRouteHeaderId(routeHeaderId);
            searchIndexingWork.setQueuePriority(new Integer(6));
            searchIndexingWork.setQueueStatus("Q");
            searchIndexingWork.setQueueDate(
                    new Timestamp(System.currentTimeMillis()));
            searchIndexingWork.setRetryCount(new Integer(0));
            SpringServiceLocator.getRouteQueueService()
                    .requeueDocument(searchIndexingWork);
        }
    }

    public ActionRequestService getActionRequestService() {
        return (ActionRequestService) SpringServiceLocator.getService(
                       SpringServiceLocator.ACTION_REQUEST_SRV);
    }

    public DocumentRouteHeaderValue getRouteHeader() {
        return routeHeader;
    }

    public void setRouteHeader(DocumentRouteHeaderValue routeHeader) {
        this.routeHeader = routeHeader;
    }

    public WorkflowUser getUser() {
        return user;
    }

    protected boolean isActionCompatibleRequest(List requests, 
                                                String actionTakenCode)
                                         throws EdenUserNotFoundException {
        //Blanket approval and Move is always correct because the client application has authorized it
        if (EdenConstants.ACTION_TAKEN_BLANKET_APPROVE_CD.equals(
                    actionTakenCode) || 
                EdenConstants.ACTION_TAKEN_MOVE_CD.equals(actionTakenCode)) {
            return true;
        }

        // we allow pre-approval
        if (requests.isEmpty() && 
                (EdenConstants.ACTION_TAKEN_ACKNOWLEDGED_CD.equals(
                         actionTakenCode) || EdenConstants.ACTION_TAKEN_APPROVED_CD.equals(
                                                     actionTakenCode) || 
                    EdenConstants.ACTION_TAKEN_COMPLETED_CD.equals(
                            actionTakenCode) || 
                    EdenConstants.ACTION_TAKEN_ROUTED_CD.equals(actionTakenCode))) {
            return true;
        }

        // can always cancel saved or initiated document
        if (routeHeader.isStateInitiated() || routeHeader.isStateSaved()) {
            return true;
        }

        boolean actionCompatible = false;
        Iterator ars = requests.iterator();
        ActionRequestValue actionRequest = null;

        while (ars.hasNext()) {
            actionRequest = (ActionRequestValue) ars.next();

            //if (actionRequest.isWorkgroupRequest() && !actionRequest.getWorkgroup().hasMember(this.delegator)) {
            // TODO might not need this, if so, do role check

            /*if (actionRequest.isWorkgroupRequest() && !actionRequest.getWorkgroup().hasMember(this.user)) {
                continue;
            }*/
            String request = actionRequest.getActionRequested();

            //FYI request matches all but deny and cancel
            if (EdenConstants.ACTION_REQUEST_FYI_REQ.equals(request) && 
                    !(EdenConstants.ACTION_TAKEN_DENIED_CD.equals(
                              actionTakenCode) || EdenConstants.ACTION_TAKEN_CANCELED_CD.equals(
                                                          actionTakenCode))) {
                actionCompatible = true || actionCompatible;
            }

            // ACK request matches all but FYI, DENY, and CANCEL
            if (EdenConstants.ACTION_REQUEST_ACKNOWLEDGE_REQ.equals(request) && 
                    !(EdenConstants.ACTION_TAKEN_DENIED_CD.equals(
                              actionTakenCode) || EdenConstants.ACTION_TAKEN_CANCELED_CD.equals(
                                                          actionTakenCode) || 
                        EdenConstants.ACTION_TAKEN_FYI_CD.equals(
                                actionTakenCode))) {
                actionCompatible = true || actionCompatible;
            }

            // APPROVE request matches all but FYI and ACK
            if (EdenConstants.ACTION_REQUEST_APPROVE_REQ.equals(request) && 
                    !(EdenConstants.ACTION_TAKEN_FYI_CD.equals(actionTakenCode) || EdenConstants.ACTION_TAKEN_ACKNOWLEDGED_CD.equals(
                                                                                           actionTakenCode))) {
                actionCompatible = true || actionCompatible;
            }

            // COMPLETE request matches all but FYI and ACK
            if (EdenConstants.ACTION_REQUEST_COMPLETE_REQ.equals(request) && 
                    !(EdenConstants.ACTION_TAKEN_FYI_CD.equals(actionTakenCode) || EdenConstants.ACTION_TAKEN_ACKNOWLEDGED_CD.equals(
                                                                                           actionTakenCode))) {
                actionCompatible = true || actionCompatible;
            }

            // RETURN_TO_PREVIOUS_ROUTE_LEVEL action available only if you've been routed a complete or approve request
            if (EdenConstants.ACTION_TAKEN_RETURNED_TO_PREVIOUS_CD.equals(
                        actionTakenCode) && 
                    (EdenConstants.ACTION_REQUEST_COMPLETE_REQ.equals(request) || EdenConstants.ACTION_REQUEST_APPROVE_REQ.equals(
                                                                                          request))) {
                actionCompatible = true || actionCompatible;
            }
        }

        return actionCompatible;
    }

    protected void notifyActionTaken(ActionTakenValue actionTaken) {
        try {
            LOG.debug("Notifying post processor of action taken");

            PostProcessor postProcessor = SpringServiceLocator.getExtensionService()
                                                              .getPostProcessor(routeHeader.getDocumentType()
                                                                                           .getPostProcessorName());
            ProcessDocReport report = postProcessor.doActionTaken(
                                              new edu.iu.uis.eden.ActionTakenEvent(
                                                      routeHeader.getRouteHeaderId(), 
                                                      routeHeader.getAppDocId(), 
                                                      actionTaken));

            if (!report.isSuccess()) {
                LOG.warn(report.getMessage(), report.getProcessException());
                throw new InvalidActionTakenException(report.getMessage());
            }
        } catch (Exception ex) {
            LOG.warn(ex, ex);

            //TODO don't know if this is right or wrong... needs to be addressed
            throw new RuntimeException(ex.getMessage());
        }
    }

    //
    //    protected void notifyRouteLevelChange(Integer newRouteLevel, Integer oldRouteLevel) throws InvalidActionTakenException {
    //        LOG.error("The notifyRouteLevelChange(Integer, Integer) method should no longer be called!!!");
    //        try {
    //            LOG.debug("Notifying post processor of route level change "+oldRouteLevel+"->"+newRouteLevel);
    //            PostProcessor postProcessor = SpringServiceLocator.getExtensionService().getPostProcessor(routeHeader.getDocumentType().getPostProcessorName());
    //            getRouteHeaderService().saveRouteHeader(getRouteHeader());
    //            ProcessDocReport report = postProcessor.doRouteLevelChange(new DocumentRouteLevelChange(routeHeader.getRouteHeaderId(), routeHeader.getAppDocId(), oldRouteLevel, newRouteLevel));
    //            setRouteHeader(getRouteHeaderService().getRouteHeader(getRouteHeaderId()));
    //            if (!report.isSuccess()) {
    //                LOG.warn(report.getMessage(), report.getProcessException());
    //                throw new InvalidActionTakenException(report.getMessage());
    //            }
    //        } catch (Exception ex) {
    //            LOG.warn(ex, ex);
    //            //TODO don't know if this is right or wrong... needs to be addressed
    //            throw new RuntimeException(ex.getMessage());
    //        }
    //    }
    protected void notifyStatusChange(String newStatusCode, 
                                      String oldStatusCode)
                               throws InvalidActionTakenException {
        DocumentRouteStatusChange statusChangeEvent = new DocumentRouteStatusChange(
                                                              routeHeader.getRouteHeaderId(), 
                                                              routeHeader.getAppDocId(), 
                                                              oldStatusCode, 
                                                              newStatusCode);

        try {
            LOG.debug("Notifying post processor of status change " + 
                      oldStatusCode + "->" + newStatusCode);

            PostProcessor postProcessor = SpringServiceLocator.getExtensionService()
                                                              .getPostProcessor(routeHeader.getDocumentType()
                                                                                           .getPostProcessorName());
            ProcessDocReport report = postProcessor.doRouteStatusChange(
                                              statusChangeEvent);

            if (!report.isSuccess()) {
                LOG.warn(report.getMessage(), report.getProcessException());
                throw new InvalidActionTakenException(report.getMessage());
            }
        } catch (Exception ex) {
            LOG.warn(ex, ex);

            //TODO don't know if this is right or wrong... needs to be addressed
            throw new RuntimeException(ex.getMessage());
        }
    }

    public void queueDocument() {
        getRouteQueueService()
            .requeueDocument(getRouteHeader().getRouteHeaderId());
    }

    public void recordAction() throws InvalidActionTakenException, 
                                      EdenUserNotFoundException {
        if (!user.getWorkflowUserId().getWorkflowId()
                 .equals(routeHeader.getInitiatorWorkflowId()) && 
                (routeHeader.isStateSaved() || routeHeader.isStateInitiated())) {
            throw new InvalidActionTakenException(
                    "only initator can take action on initated or saved document");
        }

        checkLocking();
    }

    public void checkLocking() throws InvalidActionTakenException {
        if (routeHeader.isLocked()) {
            throw new InvalidActionTakenException("The document " + 
                                                  routeHeader.getRouteHeaderId() + 
                                                  " is locked.  Action cannot be taken.");
        }
    }

    protected ActionTakenValue saveActionTaken() {
        return saveActionTaken(null);
    }

    protected ActionTakenValue saveActionTaken(Recipient delegator) {
        ActionTakenValue val = new ActionTakenValue();
        val.setActionTaken(actionTakenCode);
        val.setAnnotation(annotation);
        val.setDocVersion(routeHeader.getDocVersion());
        val.setRouteHeaderId(routeHeaderId);
        val.setWorkflowId(user.getWorkflowUserId().getWorkflowId());

        if (delegator instanceof WorkflowUser) {
            val.setDelegatorWorkflowId(((WorkflowUser) delegator).getWorkflowUserId()
                                                               .getWorkflowId());
        } else if (delegator instanceof Workgroup) {
            val.setDelegatorWorkgroupId(((Workgroup) delegator).getWorkflowGroupId()
                                                             .getGroupId());
        }

        val.setRouteHeader(routeHeader);
        val.setCurrentIndicator(currentInd);
        getActionTakenService().saveActionTaken(val);
        this.actionTaken = val;

        //notifyActionTaken(this.actionTaken);
        return val;
    }

    /**
     * Returns the highest priority delegator in the list of action requests.
     */
    protected Recipient findDelegatorForActionRequests(List actionRequests)
        throws EdenUserNotFoundException {
        return getActionRequestService().findDelegator(actionRequests);
    }

    public void setUser(WorkflowUser user) {
        this.user = user;
    }

    public String getActionTakenCode() {
        return actionTakenCode;
    }

    public void setActionTakenCode(String string) {
        actionTakenCode = string;
    }

    public Long getRouteHeaderId() {
        return this.routeHeader.getRouteHeaderId();
    }

    public Long getActionTakenId() {
        return actionTaken.getActionTakenId();
    }

    public ActionTakenValue getActionTaken() {
        return actionTaken;
    }

    public void delete() {
        getActionTakenService().delete(actionTaken);
    }

    //    protected ActionRequestNotificationGenerator getNotificationGenerator() {
    //        return notificationGenerator;
    //    }
    public ActionTakenService getActionTakenService() {
        return (ActionTakenService) SpringServiceLocator.getService(
                       SpringServiceLocator.ACTION_TAKEN_SRV);
    }

    public DocumentTypeService getDocumentTypeService() {
        return (DocumentTypeService) SpringServiceLocator.getService(
                       SpringServiceLocator.DOCUMENT_TYPE_SERVICE);
    }

    public RouteQueueService getRouteQueueService() {
        return (RouteQueueService) SpringServiceLocator.getService(
                       SpringServiceLocator.ROUTE_QUEUE_SRV);
    }

    public RouteHeaderService getRouteHeaderService() {
        return (RouteHeaderService) SpringServiceLocator.getService(
                       SpringServiceLocator.DOC_ROUTE_HEADER_SRV);
    }

    public Boolean getCurrentInd() {
        return currentInd;
    }

    public void setCurrentInd(Boolean currentInd) {
        this.currentInd = currentInd;
    }
}