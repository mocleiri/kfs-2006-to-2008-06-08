
/*
 * Copyright (c) 2004, 2005, 2006 Trustees of Indiana University and Cornell University.
 *
 * Licensed under the Educational Community License Version 1.0 (the "License"); By obtaining,
 * using and/or copying this Original Work, you agree that you have read, understand, and will
 * comply with the terms and conditions of the Educational Community License.
 *
 * For the full text of the license, see the LICENSE.txt file or visit:
 * 
 * http://kew.indiana.edu/workflow/LICENSE.txt
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING
 * BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE
 * AND NONINFRINGEMENT.
 * IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES
 * OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 */
            
package edu.iu.uis.eden.actions;

import edu.iu.uis.eden.EdenConstants;
import edu.iu.uis.eden.exception.EdenUserNotFoundException;
import edu.iu.uis.eden.exception.InvalidActionTakenException;
import edu.iu.uis.eden.exception.ResourceUnavailableException;
import edu.iu.uis.eden.routeheader.DocumentRouteHeaderValue;
import edu.iu.uis.eden.user.WorkflowUser;

import org.apache.log4j.MDC;


public class LogDocumentActionAction extends ActionTakenEvent {
    private static final org.apache.log4j.Logger LOG = 
            org.apache.log4j.Logger.getLogger(LogDocumentActionAction.class);

    /**
     * @param rh RouteHeader for the document upon which the action is taken.
     * @param user User taking the action.
     * @param annotation User comment on the action taken
     */
    public LogDocumentActionAction(DocumentRouteHeaderValue rh, 
                                   WorkflowUser user, String annotation) {
        super(rh, user, annotation);
        setActionTakenCode(EdenConstants.ACTION_TAKEN_LOG_DOCUMENT_ACTION_CD);
        setCurrentInd(Boolean.FALSE);
    }

    /**
     * Records the non-routed document action. - Checks to make sure the document status allows the action. Records the action.
     * 
     * @throws InvalidActionTakenException
     * @throws ResourceUnavailableException
     */
    public void recordAction() throws InvalidActionTakenException, 
                                      EdenUserNotFoundException {
        MDC.put("docId", getRouteHeader().getRouteHeaderId());

        LOG.debug("Logging document action");
        saveActionTaken(null);
        notifyActionTaken(this.actionTaken);
    }
}