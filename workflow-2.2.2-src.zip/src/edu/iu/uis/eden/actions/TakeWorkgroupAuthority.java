
/*
 * Copyright (c) 2004, 2005, 2006 Trustees of Indiana University and Cornell University.
 *
 * Licensed under the Educational Community License Version 1.0 (the "License"); By obtaining,
 * using and/or copying this Original Work, you agree that you have read, understand, and will
 * comply with the terms and conditions of the Educational Community License.
 *
 * For the full text of the license, see the LICENSE.txt file or visit:
 * 
 * http://kew.indiana.edu/workflow/LICENSE.txt
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING
 * BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE
 * AND NONINFRINGEMENT.
 * IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES
 * OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 */
            
package edu.iu.uis.eden.actions;

import edu.iu.uis.eden.EdenConstants;
import edu.iu.uis.eden.SpringServiceLocator;
import edu.iu.uis.eden.actionitem.ActionItem;
import edu.iu.uis.eden.actionlist.ActionListService;
import edu.iu.uis.eden.actionrequests.ActionRequestValue;
import edu.iu.uis.eden.exception.EdenUserNotFoundException;
import edu.iu.uis.eden.exception.InvalidActionTakenException;
import edu.iu.uis.eden.routeheader.DocumentRouteHeaderValue;
import edu.iu.uis.eden.user.WorkflowUser;
import edu.iu.uis.eden.workgroup.Workgroup;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;


/**
 * Removes all workgroup action items for a document from everyone's action list except the person 
 * who took the workgroup authority
 * 
 * @author rkirkend
 *
 */
public class TakeWorkgroupAuthority extends ActionTakenEvent {
    private Workgroup workgroup;

    /**
     * @param routeHeaderId
     * @param appDocId
     * @param actionTaken
     */
    public TakeWorkgroupAuthority(DocumentRouteHeaderValue routeHeader, 
                                  WorkflowUser user, String annotation, 
                                  Workgroup workgroup) {
        super(routeHeader, user, annotation);
        this.workgroup = workgroup;
        super.setActionTakenCode(
                EdenConstants.ACTION_TAKEN_TAKE_WORKGROUP_AUTHORITY_CD);
    }

    public void recordAction() throws InvalidActionTakenException, 
                                      EdenUserNotFoundException {
        if (!workgroup.hasMember(getUser())) {
            throw new InvalidActionTakenException(getUser()
                                                      .getAuthenticationUserId() + 
                                                  " not a member of workgroup " + 
                                                  workgroup.getDisplayName());
        }

        List documentRequests = getActionRequestService()
                                    .findPendingByDoc(getRouteHeaderId());
        List workgroupRequests = new ArrayList();

        for (Iterator iter = documentRequests.iterator(); iter.hasNext();) {
            ActionRequestValue actionRequest = (ActionRequestValue) iter.next();

            if (actionRequest.isWorkgroupRequest() && 
                    actionRequest.getWorkgroup().getWorkflowGroupId()
                                 .getGroupId()
                                 .equals(workgroup.getWorkflowGroupId()
                                                  .getGroupId())) {
                workgroupRequests.add(actionRequest);
            }
        }

        saveActionTaken(findDelegatorForActionRequests(workgroupRequests));
        notifyActionTaken(this.actionTaken);

        ActionListService actionListService = SpringServiceLocator.getActionListService();
        Collection actionItems = actionListService.findByRouteHeaderId(
                                         getRouteHeaderId());

        for (Iterator iter = actionItems.iterator(); iter.hasNext();) {
            ActionItem actionItem = (ActionItem) iter.next();

            //delete all requests for this workgroup on this document not to this user
            if (actionItem.isWorkgroupItem() && 
                    actionItem.getWorkgroupId()
                              .equals(workgroup.getWorkflowGroupId()
                                               .getGroupId()) && 
                    !actionItem.getWorkflowId()
                               .equals(getUser().getWorkflowId())) {
                actionListService.deleteActionItem(actionItem);
            }
        }
    }
}