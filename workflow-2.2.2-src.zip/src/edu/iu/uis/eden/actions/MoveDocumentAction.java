
/*
 * Copyright (c) 2004, 2005, 2006 Trustees of Indiana University and Cornell University.
 *
 * Licensed under the Educational Community License Version 1.0 (the "License"); By obtaining,
 * using and/or copying this Original Work, you agree that you have read, understand, and will
 * comply with the terms and conditions of the Educational Community License.
 *
 * For the full text of the license, see the LICENSE.txt file or visit:
 * 
 * http://kew.indiana.edu/workflow/LICENSE.txt
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING
 * BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE
 * AND NONINFRINGEMENT.
 * IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES
 * OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 */
            
package edu.iu.uis.eden.actions;

import edu.iu.uis.eden.EdenConstants;
import edu.iu.uis.eden.SpringServiceLocator;
import edu.iu.uis.eden.engine.BlanketApproveEngine;
import edu.iu.uis.eden.engine.OrchestrationConfig;
import edu.iu.uis.eden.engine.node.RouteNode;
import edu.iu.uis.eden.engine.node.RouteNodeInstance;
import edu.iu.uis.eden.exception.EdenUserNotFoundException;
import edu.iu.uis.eden.exception.InvalidActionTakenException;
import edu.iu.uis.eden.routeheader.DocumentRouteHeaderValue;
import edu.iu.uis.eden.user.Recipient;
import edu.iu.uis.eden.user.WorkflowUser;

import java.util.Collection;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

import org.apache.log4j.MDC;


/**
 * Returns a document to a previous node in the route.
 * 
 * Current implementation only supports returning to a node on the main branch of the
 * document.
 * 
 * @author ewestfal
 */
public class MoveDocumentAction extends ActionTakenEvent {
    protected final org.apache.log4j.Logger LOG = org.apache.log4j.Logger.getLogger(
                                                          getClass());
    private MovePoint movePoint;

    public MoveDocumentAction(DocumentRouteHeaderValue routeHeader, 
                              WorkflowUser user, String annotation, 
                              MovePoint movePoint) {
        super(routeHeader, user, annotation);
        setActionTakenCode(EdenConstants.ACTION_TAKEN_MOVE_CD);
        this.movePoint = movePoint;
    }

    public void recordAction() throws InvalidActionTakenException, 
                                      EdenUserNotFoundException {
        MDC.put("docId", getRouteHeader().getRouteHeaderId());
        super.recordAction();
        LOG.debug("Moving document " + getRouteHeader().getRouteHeaderId() + 
                  " to point: " + displayMovePoint(movePoint) + 
                  ", annotation: " + annotation);

        if (getRouteHeader().isValidActionToTake(getActionTakenCode())) {
            Collection activeNodes = SpringServiceLocator.getRouteNodeService()
                                                         .getActiveNodeInstances(getRouteHeader()
                                                                                     .getRouteHeaderId());

            RouteNodeInstance startNodeInstance = determineStartNode(
                                                          activeNodes, 
                                                          movePoint);

            List actionRequests = getActionRequestService()
                                      .findAllValidRequests(getUser(), 
                                                            getRouteHeaderId(), 
                                                            EdenConstants.ACTION_REQUEST_COMPLETE_REQ);

            if (!isActionCompatibleRequest(actionRequests, getActionTakenCode())) {
                throw new InvalidActionTakenException(
                        "No request for the user is compatible with the MOVE action");
            }

            LOG.debug("Record the move action");

            Recipient delegator = findDelegatorForActionRequests(actionRequests);
            saveActionTaken(delegator);
            getActionRequestService()
                .deactivateRequests(actionTaken, actionRequests);
            notifyActionTaken(this.actionTaken);

            // TODO this whole bit is a bit hacky at the moment
            if (movePoint.getStepsToMove() > 0) {
                Set targetNodeNames = new HashSet();
                targetNodeNames.add(determineFutureNodeName(startNodeInstance, 
                                                            movePoint));
                SpringServiceLocator.getRouteQueueService()
                    .requeueDocument(routeHeader.getRouteHeaderId(), 
                                     EdenConstants.ROUTE_QUEUE_BLANKET_APPROVE_PRIORITY, 
                                     new Long(0), 
                                     MoveDocumentProcessor.class.getName(), 
                                     MoveDocumentProcessor.getMoveDocumentProcessorValue(
                                             getUser(), getActionTaken(), 
                                             targetNodeNames));

                //BlanketApproveAction blanketAction = new BlanketApproveAction(getRouteHeader(), getUser(), annotation, targetNodeName);
                //blanketAction.actionTaken = actionTaken;
                //blanketAction.recordAction();
            } else {
                String targetNodeName = determineReturnNodeName(
                                                startNodeInstance, movePoint);
                ReturnToPreviousNodeAction returnAction = 
                        new ReturnToPreviousNodeAction(getRouteHeader(), 
                                                       getUser(), annotation, 
                                                       targetNodeName, false);
                returnAction.actionTaken = actionTaken;
                returnAction.setActionTakenCode(
                        EdenConstants.ACTION_TAKEN_MOVE_CD);
                returnAction.recordAction();
            }
        }
    }

    public void doMoveDocumentWork(Set nodeNames) throws Exception {
        if (getRouteHeader().isInException()) {
            LOG.debug("Moving document back to Enroute from Exception");

            String oldStatus = getRouteHeader().getDocRouteStatus();
            getRouteHeader().markDocumentEnroute();

            String newStatus = getRouteHeader().getDocRouteStatus();
            notifyStatusChange(newStatus, oldStatus);
        }

        OrchestrationConfig config = new OrchestrationConfig();
        config.setCause(actionTaken);
        config.setDestinationNodeNames(nodeNames);
        config.setSendNotifications(false);
        new BlanketApproveEngine(config).process(getRouteHeader()
                                                     .getRouteHeaderId(), null);
    }

    private RouteNodeInstance determineStartNode(Collection activeNodes, 
                                                 MovePoint movePoint)
                                          throws InvalidActionTakenException {
        if (activeNodes.isEmpty()) {
            throw new InvalidActionTakenException(
                    "Document has no active nodes.");
        }

        RouteNodeInstance startNodeInstance = null;

        for (Iterator iterator = activeNodes.iterator(); iterator.hasNext();) {
            RouteNodeInstance nodeInstance = (RouteNodeInstance) iterator.next();

            if (nodeInstance.getName().equals(movePoint.getStartNodeName())) {
                if (startNodeInstance != null) {
                    throw new InvalidActionTakenException(
                            "More than one active node exists with the given name:  " + 
                            movePoint.getStartNodeName());
                }

                startNodeInstance = nodeInstance;
            }
        }

        if (startNodeInstance == null) {
            throw new InvalidActionTakenException(
                    "Could not locate an active node with the given name: " + 
                    movePoint.getStartNodeName());
        }

        return startNodeInstance;
    }

    private String determineFutureNodeName(RouteNodeInstance startNodeInstance, 
                                           MovePoint movePoint)
                                    throws InvalidActionTakenException {
        return determineFutureNodeName(startNodeInstance.getRouteNode(), 
                                       movePoint, 0, new HashSet());
    }

    private String determineFutureNodeName(RouteNode node, MovePoint movePoint, 
                                           int currentStep, Set nodesProcessed)
                                    throws InvalidActionTakenException {
        if (nodesProcessed.contains(node.getRouteNodeId())) {
            throw new InvalidActionTakenException("Detected a cycle at node " + 
                                                  node.getRouteNodeName() + 
                                                  " when attempting to move document.");
        }

        nodesProcessed.add(node.getRouteNodeId());

        if (currentStep == movePoint.getStepsToMove()) {
            return node.getRouteNodeName();
        }

        List nextNodes = node.getNextNodes();

        if (nextNodes.size() == 0) {
            throw new InvalidActionTakenException(
                    "Could not proceed forward, there are no more nodes in the route.  Halted on step " + 
                    currentStep);
        }

        if (nextNodes.size() != 1) {
            throw new InvalidActionTakenException(
                    "Cannot move forward in a multi-branch path.  Located " + 
                    nextNodes.size() + " branches.  Halted on step " + 
                    currentStep);
        }

        return determineFutureNodeName((RouteNode) nextNodes.get(0), movePoint, 
                                       currentStep + 1, nodesProcessed);
    }

    private String determineReturnNodeName(RouteNodeInstance startNodeInstance, 
                                           MovePoint movePoint)
                                    throws InvalidActionTakenException {
        return determineReturnNodeName(startNodeInstance.getRouteNode(), 
                                       movePoint, 0);
    }

    private String determineReturnNodeName(RouteNode node, MovePoint movePoint, 
                                           int currentStep)
                                    throws InvalidActionTakenException {
        if (currentStep == movePoint.getStepsToMove()) {
            return node.getRouteNodeName();
        }

        List previousNodes = node.getPreviousNodes();

        if (previousNodes.size() == 0) {
            throw new InvalidActionTakenException(
                    "Could not locate the named target node in the document's past route.  Halted on step " + 
                    currentStep);
        }

        if (previousNodes.size() != 1) {
            throw new InvalidActionTakenException(
                    "Located a multi-branch path, could not proceed backward past this point.  Halted on step " + 
                    currentStep);
        }

        return determineReturnNodeName((RouteNode) previousNodes.get(0), 
                                       movePoint, currentStep - 1);
    }

    private String displayMovePoint(MovePoint movePoint) {
        return "fromNode=" + movePoint.getStartNodeName() + ", stepsToMove=" + 
               movePoint.getStepsToMove();
    }
}