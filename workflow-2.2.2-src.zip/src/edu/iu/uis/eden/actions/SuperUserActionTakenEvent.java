
/*
 * Copyright (c) 2004, 2005, 2006 Trustees of Indiana University and Cornell University.
 *
 * Licensed under the Educational Community License Version 1.0 (the "License"); By obtaining,
 * using and/or copying this Original Work, you agree that you have read, understand, and will
 * comply with the terms and conditions of the Educational Community License.
 *
 * For the full text of the license, see the LICENSE.txt file or visit:
 * 
 * http://kew.indiana.edu/workflow/LICENSE.txt
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING
 * BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE
 * AND NONINFRINGEMENT.
 * IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES
 * OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 */
            
package edu.iu.uis.eden.actions;

import edu.iu.uis.eden.WorkflowServiceErrorException;
import edu.iu.uis.eden.WorkflowServiceErrorImpl;
import edu.iu.uis.eden.actionrequests.ActionRequestValue;
import edu.iu.uis.eden.doctype.DocumentType;
import edu.iu.uis.eden.exception.EdenUserNotFoundException;
import edu.iu.uis.eden.exception.InvalidActionTakenException;
import edu.iu.uis.eden.exception.WorkflowException;
import edu.iu.uis.eden.routeheader.DocumentRouteHeaderValue;
import edu.iu.uis.eden.user.WorkflowUser;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;


public abstract class SuperUserActionTakenEvent extends ActionTakenEvent {
    private static final org.apache.log4j.Logger LOG = 
            org.apache.log4j.Logger.getLogger(SuperUserActionTakenEvent.class);
    public static String AUTHORIZATION = "general.routing.superuser.notAuthorized";
    protected String superUserAction;

    //protected DocumentRouteStatusChange event;
    private ActionRequestValue actionRequest;

    public SuperUserActionTakenEvent(DocumentRouteHeaderValue routeHeader, 
                                     WorkflowUser user, String annotation) {
        super(routeHeader, user, annotation);
    }

    public void recordAction() throws InvalidActionTakenException, 
                                      EdenUserNotFoundException {
        checkLocking();

        DocumentType docType = getRouteHeader().getDocumentType();

        if (!docType.isSuperUser(getUser())) {
            LOG.info("User not authorized");

            List errors = new ArrayList();
            errors.add(new WorkflowServiceErrorImpl(
                               "User not authorized for super user action", 
                               AUTHORIZATION));
            throw new WorkflowServiceErrorException(
                    "Super User Authorization Error", errors);
        }

        processActionRequests();

        try {
            String oldStatus = getRouteHeader().getDocRouteStatus();

            //if the document is initiated then set it enroute so we can transition to any other status
            if (getRouteHeader().isStateInitiated()) {
                getRouteHeader().markDocumentEnroute();
                notifyStatusChange(getRouteHeader().getDocRouteStatus(), 
                                   oldStatus);
            }

            markDocument();

            String newStatus = getRouteHeader().getDocRouteStatus();
            notifyStatusChange(newStatus, oldStatus);
        } catch (Exception ex) {
            LOG.error("Caught Exception talking to post processor", ex);
            throw new RuntimeException(ex.getMessage());
        }

        queueDocument();
    }

    protected abstract void markDocument() throws WorkflowException;

    protected void processActionRequests() throws InvalidActionTakenException, 
                                                  EdenUserNotFoundException {
        LOG.debug("Processing pending action requests");

        saveActionTaken();

        List actionRequests = getActionRequestService()
                                  .findPendingByDoc(getRouteHeaderId());

        for (Iterator iter = actionRequests.iterator(); iter.hasNext();) {
            ActionRequestValue actionRequest = (ActionRequestValue) iter.next();
            getActionRequestService()
                .deactivateRequest(actionTaken, actionRequest);
        }
    }

    public ActionRequestValue getActionRequest() {
        return actionRequest;
    }

    public void setActionRequest(ActionRequestValue actionRequest) {
        this.actionRequest = actionRequest;
    }
}