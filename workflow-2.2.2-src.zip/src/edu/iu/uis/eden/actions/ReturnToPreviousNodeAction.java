
/*
 * Copyright (c) 2004, 2005, 2006 Trustees of Indiana University and Cornell University.
 *
 * Licensed under the Educational Community License Version 1.0 (the "License"); By obtaining,
 * using and/or copying this Original Work, you agree that you have read, understand, and will
 * comply with the terms and conditions of the Educational Community License.
 *
 * For the full text of the license, see the LICENSE.txt file or visit:
 * 
 * http://kew.indiana.edu/workflow/LICENSE.txt
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING
 * BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE
 * AND NONINFRINGEMENT.
 * IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES
 * OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 */
            
package edu.iu.uis.eden.actions;

import edu.iu.uis.eden.DocumentRouteLevelChange;
import edu.iu.uis.eden.EdenConstants;
import edu.iu.uis.eden.SpringServiceLocator;
import edu.iu.uis.eden.actionrequests.ActionRequestFactory;
import edu.iu.uis.eden.actionrequests.ActionRequestValue;
import edu.iu.uis.eden.actiontaken.ActionTakenValue;
import edu.iu.uis.eden.engine.CompatUtils;
import edu.iu.uis.eden.engine.RouteHelper;
import edu.iu.uis.eden.engine.node.NodeGraphSearchCriteria;
import edu.iu.uis.eden.engine.node.NodeGraphSearchResult;
import edu.iu.uis.eden.engine.node.RouteNode;
import edu.iu.uis.eden.engine.node.RouteNodeInstance;
import edu.iu.uis.eden.engine.node.RouteNodeService;
import edu.iu.uis.eden.exception.EdenUserNotFoundException;
import edu.iu.uis.eden.exception.InvalidActionTakenException;
import edu.iu.uis.eden.postprocessor.PostProcessor;
import edu.iu.uis.eden.postprocessor.ProcessDocReport;
import edu.iu.uis.eden.routeheader.DocumentRouteHeaderValue;
import edu.iu.uis.eden.user.Recipient;
import edu.iu.uis.eden.user.WorkflowUser;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;

import org.apache.log4j.MDC;


/**
 * Returns a document to a previous node in the route.
 * 
 * Current implementation only supports returning to a node on the main branch of the
 * document.
 * 
 * @author ewestfal
 */
public class ReturnToPreviousNodeAction extends ActionTakenEvent {
    protected final org.apache.log4j.Logger LOG = org.apache.log4j.Logger.getLogger(
                                                          getClass());
    private RouteHelper helper = new RouteHelper();
    private String nodeName;
    private boolean superUserUsage;
    private boolean sendNotifications = true;

    public ReturnToPreviousNodeAction(DocumentRouteHeaderValue routeHeader, 
                                      WorkflowUser user, String annotation, 
                                      String nodeName, 
                                      boolean sendNotifications) {
        super(routeHeader, user, annotation);
        setActionTakenCode(EdenConstants.ACTION_TAKEN_RETURNED_TO_PREVIOUS_CD);
        this.nodeName = nodeName;
        this.sendNotifications = sendNotifications;
    }

    /**
     * TODO will this work properly in the case of an ALL APPROVE role requests with some of the requests already completed?
     */
    private void revokePendingRequests(List pendingRequests, 
                                       ActionTakenValue actionTaken, 
                                       Recipient delegator)
                                throws EdenUserNotFoundException {
        revokeRequests(pendingRequests);
        getActionRequestService()
            .deactivateRequests(actionTaken, pendingRequests);

        if (sendNotifications) {
            ActionRequestFactory arFactory = new ActionRequestFactory(
                                                     getRouteHeader());
            List notificationRequests = arFactory.generateNotifications(
                                                pendingRequests, getUser(), 
                                                delegator, 
                                                EdenConstants.ACTION_REQUEST_FYI_REQ, 
                                                getActionTakenCode());
            getActionRequestService().activateRequests(notificationRequests);
        }
    }

    /**
     * Takes a list of root action requests and marks them and all of their children as "non-current".
     */
    private void revokeRequests(List actionRequests)
                         throws EdenUserNotFoundException {
        for (Iterator iterator = actionRequests.iterator(); iterator.hasNext();) {
            ActionRequestValue actionRequest = (ActionRequestValue) iterator.next();
            actionRequest.setCurrentIndicator(Boolean.FALSE);

            if (actionRequest.getActionTaken() != null) {
                actionRequest.getActionTaken()
                             .setCurrentIndicator(Boolean.FALSE);
                SpringServiceLocator.getActionTakenService()
                    .saveActionTaken(actionRequest.getActionTaken());
            }

            revokeRequests(actionRequest.getChildrenRequests());
            SpringServiceLocator.getActionRequestService()
                    .saveActionRequest(actionRequest);
        }
    }

    private void processReturnToInitiator(RouteNodeInstance newNodeInstance)
                                   throws EdenUserNotFoundException {
        RouteNode initialNode = getRouteHeader().getDocumentType()
                                    .getPrimaryProcess().getInitialRouteNode();

        if (newNodeInstance.getRouteNode().getRouteNodeId()
                           .equals(initialNode.getRouteNodeId())) {
            LOG.debug("Document was returned to initiator");

            ActionRequestFactory arFactory = new ActionRequestFactory(
                                                     getRouteHeader(), 
                                                     newNodeInstance);
            ActionRequestValue notificationRequest = arFactory.createNotificationRequest(
                                                             EdenConstants.ACTION_REQUEST_APPROVE_REQ, 
                                                             getRouteHeader()
                                                                 .getInitiatorUser(), 
                                                             getActionTakenCode(), 
                                                             getUser(), 
                                                             "Document initiator");
            getActionRequestService().activateRequest(notificationRequest);
        }
    }

    public void recordAction() throws InvalidActionTakenException, 
                                      EdenUserNotFoundException {
        MDC.put("docId", getRouteHeader().getRouteHeaderId());
        super.recordAction();
        LOG.debug("Returning document " + 
                  getRouteHeader().getRouteHeaderId() + 
                  " to previous node: " + nodeName + ", annotation: " + 
                  annotation);

        if (getRouteHeader().isValidActionToTake(getActionTakenCode())) {
            List actionRequests = getActionRequestService()
                                      .findAllValidRequests(getUser(), 
                                                            getRouteHeaderId(), 
                                                            EdenConstants.ACTION_REQUEST_COMPLETE_REQ);

            if (!isActionCompatibleRequest(actionRequests, getActionTakenCode()) && 
                    !isSuperUserUsage()) {
                throw new InvalidActionTakenException(
                        "No request for the user is compatible with the RETURN TO PREVIOUS NODE action");
            }

            Collection activeNodeInstances = SpringServiceLocator.getRouteNodeService()
                                                                 .getActiveNodeInstances(getRouteHeader()
                                                                                             .getRouteHeaderId());
            NodeGraphSearchCriteria criteria = new NodeGraphSearchCriteria(
                                                       NodeGraphSearchCriteria.SEARCH_DIRECTION_BACKWARD, 
                                                       activeNodeInstances, 
                                                       nodeName);
            NodeGraphSearchResult result = SpringServiceLocator.getRouteNodeService()
                                                               .searchNodeGraph(criteria);
            validateReturnPoint(nodeName, activeNodeInstances, result);

            LOG.debug("Record the returnToPreviousNode action");
            super.currentInd = Boolean.FALSE;

            Recipient delegator = findDelegatorForActionRequests(actionRequests);
            saveActionTaken(delegator);


            //getActionRequestService().deactivateRequests(actionTaken, actionRequests);
            //notifyActionTaken(this.actionTaken);
            LOG.debug("Finding requests in return path and setting current indicator to FALSE");

            List doneRequests = new ArrayList();
            List pendingRequests = new ArrayList();

            for (Iterator iterator = result.getPath().iterator();
                 iterator.hasNext();) {
                RouteNodeInstance nodeInstance = (RouteNodeInstance) iterator.next();


                // mark the node instance as having been revoked
                SpringServiceLocator.getRouteNodeService()
                    .revokeNodeInstance(getRouteHeader(), nodeInstance);

                Long nodeInstanceId = nodeInstance.getRouteNodeInstanceId();
                List nodeRequests = getActionRequestService()
                                        .findRootRequestsByDocIdAtRouteNode(getRouteHeader()
                                                                                .getRouteHeaderId(), 
                                                                            nodeInstanceId);

                for (Iterator requestIt = nodeRequests.iterator();
                     requestIt.hasNext();) {
                    ActionRequestValue request = (ActionRequestValue) requestIt.next();

                    if (request.isDone()) {
                        doneRequests.add(request);
                    } else {
                        pendingRequests.add(request);
                    }
                }
            }

            revokeRequests(doneRequests);
            LOG.debug("Change pending requests to FYI and activate for docId " + 
                      getRouteHeader().getRouteHeaderId());
            revokePendingRequests(pendingRequests, actionTaken, delegator);
            notifyActionTaken(this.actionTaken);
            executeNodeChange(activeNodeInstances, result);
        } else {
            String docStatus = getRouteHeader().getDocRouteStatus();
            throw new InvalidActionTakenException("Document of status '" + 
                                                  docStatus + 
                                                  "' cannot taken action '" + 
                                                  EdenConstants.ACTION_TAKEN_RETURNED_TO_PREVIOUS + 
                                                  "' to node name " + 
                                                  nodeName);
        }
    }

    /**
     * This method runs various validation checks on the nodes we ended up at so as to make sure we don't
     * invoke strange return scenarios.
     */
    private void validateReturnPoint(String nodeName, 
                                     Collection activeNodeInstances, 
                                     NodeGraphSearchResult result)
                              throws InvalidActionTakenException {
        RouteNodeInstance resultNodeInstance = result.getResultNodeInstance();

        if (result.getResultNodeInstance() == null) {
            throw new InvalidActionTakenException(
                    "Could not locate return point for node name '" + 
                    nodeName + "'.");
        }

        assertValidNodeType(resultNodeInstance);
        assertValidBranch(resultNodeInstance, activeNodeInstances);
        assertValidProcess(resultNodeInstance, activeNodeInstances);
        assertFinalApprovalNodeNotInPath(result.getPath());
    }

    private void assertValidNodeType(RouteNodeInstance resultNodeInstance)
                              throws InvalidActionTakenException {
        // the return point can only be a simple or a split node
        if (!helper.isSimpleNode(resultNodeInstance.getRouteNode()) && 
                !helper.isSplitNode(resultNodeInstance.getRouteNode())) {
            throw new InvalidActionTakenException(
                    "Can only return to a simple or a split node, attempting to return to " + 
                    resultNodeInstance.getRouteNode().getNodeType());
        }
    }

    private void assertValidBranch(RouteNodeInstance resultNodeInstance, 
                                   Collection activeNodeInstances)
                            throws InvalidActionTakenException {
        // the branch of the return point needs to be the same as one of the branches of the active nodes or the same as the root branch
        boolean inValidBranch = false;

        if (resultNodeInstance.getBranch().getParentBranch() == null) {
            inValidBranch = true;
        } else {
            for (Iterator iterator = activeNodeInstances.iterator();
                 iterator.hasNext();) {
                RouteNodeInstance nodeInstance = (RouteNodeInstance) iterator.next();

                if (nodeInstance.getBranch().getBranchId()
                                .equals(resultNodeInstance.getBranch()
                                                          .getBranchId())) {
                    inValidBranch = true;

                    break;
                }
            }
        }

        if (!inValidBranch) {
            throw new InvalidActionTakenException(
                    "Returning to an illegal branch, can only return to node within the same branch as an active node or to the primary branch.");
        }
    }

    private void assertValidProcess(RouteNodeInstance resultNodeInstance, 
                                    Collection activeNodeInstances)
                             throws InvalidActionTakenException {
        // if we are in a process, we need to return within the same process
        if (resultNodeInstance.isInProcess()) {
            boolean inValidProcess = false;

            for (Iterator iterator = activeNodeInstances.iterator();
                 iterator.hasNext();) {
                RouteNodeInstance nodeInstance = (RouteNodeInstance) iterator.next();

                if (nodeInstance.isInProcess() && 
                        nodeInstance.getProcess().getRouteNodeInstanceId()
                                    .equals(nodeInstance.getProcess()
                                                        .getRouteNodeInstanceId())) {
                    inValidProcess = true;

                    break;
                }
            }

            if (!inValidProcess) {
                throw new InvalidActionTakenException(
                        "Returning into an illegal process, cannot return to node within a previously executing process.");
            }
        }
    }

    /**
     * Cannot return past a COMPLETE final approval node.  This means that you can return from an active and incomplete final approval node.
     * @param path
     * @throws InvalidActionTakenException
     */
    private void assertFinalApprovalNodeNotInPath(List path)
                                           throws InvalidActionTakenException {
        for (Iterator iterator = path.iterator(); iterator.hasNext();) {
            RouteNodeInstance nodeInstance = (RouteNodeInstance) iterator.next();

            // if we have a complete final approval node in our path, we cannot return past it
            if (nodeInstance.isComplete() && 
                    Boolean.TRUE.equals(nodeInstance.getRouteNode()
                                                    .getFinalApprovalInd())) {
                throw new InvalidActionTakenException(
                        "Cannot return past or through the final approval node '" + 
                        nodeInstance.getName() + "'.");
            }
        }
    }

    private void executeNodeChange(Collection activeNodes, 
                                   NodeGraphSearchResult result)
                            throws InvalidActionTakenException, 
                                   EdenUserNotFoundException {
        Integer oldRouteLevel = null;
        Integer newRouteLevel = null;

        if (CompatUtils.isRouteLevelCompatible(getRouteHeader())) {
            int returnPathLength = result.getPath().size() - 1;
            oldRouteLevel = getRouteHeader().getDocRouteLevel();
            newRouteLevel = new Integer(oldRouteLevel.intValue() - 
                                        returnPathLength);
            LOG.debug("Changing route header " + 
                      getRouteHeader().getRouteHeaderId() + 
                      " route level for backward compatibility to " + 
                      newRouteLevel);
            getRouteHeader().setDocRouteLevel(newRouteLevel);
            getRouteHeaderService().saveRouteHeader(routeHeader);
        }

        List startingNodes = determineStartingNodes(result.getPath(), 
                                                    activeNodes);
        RouteNodeInstance newNodeInstance = materializeReturnPoint(
                                                    startingNodes, result);

        for (Iterator iterator = startingNodes.iterator(); iterator.hasNext();) {
            RouteNodeInstance activeNode = (RouteNodeInstance) iterator.next();
            notifyNodeChange(oldRouteLevel, newRouteLevel, activeNode, 
                             newNodeInstance);
        }

        processReturnToInitiator(newNodeInstance);
    }

    private void notifyNodeChange(Integer oldRouteLevel, Integer newRouteLevel, 
                                  RouteNodeInstance oldNodeInstance, 
                                  RouteNodeInstance newNodeInstance)
                           throws InvalidActionTakenException {
        try {
            LOG.debug("Notifying post processor of route node change '" + 
                      oldNodeInstance.getName() + "'->'" + 
                      newNodeInstance.getName());

            PostProcessor postProcessor = SpringServiceLocator.getExtensionService()
                                                              .getPostProcessor(routeHeader.getDocumentType()
                                                                                           .getPostProcessorName());
            getRouteHeaderService().saveRouteHeader(getRouteHeader());

            DocumentRouteLevelChange routeNodeChange = 
                    new DocumentRouteLevelChange(routeHeader.getRouteHeaderId(), 
                                                 routeHeader.getAppDocId(), 
                                                 oldRouteLevel, newRouteLevel, 
                                                 oldNodeInstance.getName(), 
                                                 newNodeInstance.getName(), 
                                                 oldNodeInstance.getRouteNodeInstanceId(), 
                                                 newNodeInstance.getRouteNodeInstanceId());
            ProcessDocReport report = postProcessor.doRouteLevelChange(
                                              routeNodeChange);
            setRouteHeader(getRouteHeaderService()
                               .getRouteHeader(getRouteHeaderId()));

            if (!report.isSuccess()) {
                LOG.warn(report.getMessage(), report.getProcessException());
                throw new InvalidActionTakenException(report.getMessage());
            }
        } catch (Exception ex) {
            LOG.warn(ex, ex);

            //TODO don't know if this is right or wrong... needs to be addressed
            throw new RuntimeException(ex.getMessage());
        }
    }

    private List determineStartingNodes(List path, Collection activeNodes) {
        List startingNodes = new ArrayList();

        for (Iterator iterator = activeNodes.iterator(); iterator.hasNext();) {
            RouteNodeInstance activeNodeInstance = (RouteNodeInstance) iterator.next();

            if (isInPath(activeNodeInstance, path)) {
                startingNodes.add(activeNodeInstance);
            }
        }

        return startingNodes;
    }

    private boolean isInPath(RouteNodeInstance nodeInstance, List path) {
        for (Iterator iterator = path.iterator(); iterator.hasNext();) {
            RouteNodeInstance pathNodeInstance = (RouteNodeInstance) iterator.next();

            if (pathNodeInstance.getRouteNodeInstanceId()
                                .equals(nodeInstance.getRouteNodeInstanceId())) {
                return true;
            }
        }

        return false;
    }

    private RouteNodeInstance materializeReturnPoint(Collection startingNodes, 
                                                     NodeGraphSearchResult result) {
        RouteNodeService nodeService = SpringServiceLocator.getRouteNodeService();
        RouteNodeInstance returnInstance = result.getResultNodeInstance();
        RouteNodeInstance newNodeInstance = helper.getNodeFactory()
                                                  .createRouteNodeInstance(getRouteHeaderId(), 
                                                                           returnInstance.getRouteNode());
        newNodeInstance.setBranch(returnInstance.getBranch());
        newNodeInstance.setProcess(returnInstance.getProcess());
        newNodeInstance.setComplete(false);
        newNodeInstance.setActive(true);

        for (Iterator iterator = startingNodes.iterator(); iterator.hasNext();) {
            RouteNodeInstance activeNodeInstance = (RouteNodeInstance) iterator.next();


            // TODO what if the activeNodeInstance already has next nodes?            
            activeNodeInstance.setComplete(true);
            activeNodeInstance.setActive(false);
            activeNodeInstance.setInitial(false);
            activeNodeInstance.addNextNodeInstance(newNodeInstance);
        }

        for (Iterator iterator = startingNodes.iterator(); iterator.hasNext();) {
            RouteNodeInstance activeNodeInstance = (RouteNodeInstance) iterator.next();
            nodeService.save(activeNodeInstance);
        }

        // TODO really we need to call transitionTo on this node, how can we do that?
        // this isn't an issue yet because we only allow simple nodes and split nodes at the moment which do no real
        // work on transitionTo but we may need to enhance that in the future
        return newNodeInstance;
    }

    public boolean isSuperUserUsage() {
        return superUserUsage;
    }

    public void setSuperUserUsage(boolean superUserUsage) {
        this.superUserUsage = superUserUsage;
    }
}