
/*
 * Copyright (c) 2004, 2005, 2006 Trustees of Indiana University and Cornell University.
 *
 * Licensed under the Educational Community License Version 1.0 (the "License"); By obtaining,
 * using and/or copying this Original Work, you agree that you have read, understand, and will
 * comply with the terms and conditions of the Educational Community License.
 *
 * For the full text of the license, see the LICENSE.txt file or visit:
 * 
 * http://kew.indiana.edu/workflow/LICENSE.txt
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING
 * BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE
 * AND NONINFRINGEMENT.
 * IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES
 * OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 */
            
package edu.iu.uis.eden.actions;

import edu.iu.uis.eden.EdenConstants;
import edu.iu.uis.eden.actionitem.ActionItem;
import edu.iu.uis.eden.actionrequests.ActionRequestValue;
import edu.iu.uis.eden.exception.EdenUserNotFoundException;
import edu.iu.uis.eden.exception.InvalidActionTakenException;
import edu.iu.uis.eden.routeheader.DocumentRouteHeaderValue;
import edu.iu.uis.eden.user.WorkflowUser;
import edu.iu.uis.eden.workgroup.Workgroup;

import java.util.Iterator;
import java.util.List;


/**
 * @author rkirkend
 */
public class ReleaseWorkgroupAuthority extends ActionTakenEvent {
    private Workgroup workgroup;

    /**
     * @param routeHeader
     * @param user
     * @param annotation
     */
    public ReleaseWorkgroupAuthority(DocumentRouteHeaderValue routeHeader, 
                                     WorkflowUser user, String annotation, 
                                     Workgroup workgroup) {
        super(routeHeader, user, annotation);
        this.workgroup = workgroup;
        super.setActionTakenCode(
                EdenConstants.ACTION_TAKEN_RELEASE_WORKGROUP_AUTHORITY_CD);
    }

    public void recordAction() throws InvalidActionTakenException, 
                                      EdenUserNotFoundException {
        if (!workgroup.hasMember(getUser())) {
            throw new InvalidActionTakenException(getUser()
                                                      .getAuthenticationUserId() + 
                                                  " not a member of workgroup " + 
                                                  workgroup.getDisplayName());
        }

        List actionRequests = getActionRequestService()
                                  .findPendingByDoc(getRouteHeaderId());

        //List groupRequestsToActivate = new ArrayList();//requests for this group that need action items
        for (Iterator iter = actionRequests.iterator(); iter.hasNext();) {
            ActionRequestValue actionRequest = (ActionRequestValue) iter.next();

            //we left the group active from take authority action.  pending havent been normally activated yet
            if (actionRequest.isWorkgroupRequest() && 
                    actionRequest.isActive() && 
                    actionRequest.getWorkgroupId()
                                 .equals(workgroup.getWorkflowGroupId()
                                                  .getGroupId())) {
                if (actionRequest.getActionItems().size() == 1) {
                    ActionItem actionItem = (ActionItem) actionRequest.getActionItems()
                                                                      .get(0);

                    if (!actionItem.getWorkflowId()
                                   .equals(getUser().getWorkflowId())) {
                        throw new InvalidActionTakenException(
                                "User attempting to release workgroup authority did not take it.");
                    } else {
                        actionRequest.setStatus(
                                EdenConstants.ACTION_REQUEST_INITIALIZED); //to circumvent check in service during activation
                        getActionRequestService()
                            .activateRequest(actionRequest);
                    }
                }
            }
        }
    }
}