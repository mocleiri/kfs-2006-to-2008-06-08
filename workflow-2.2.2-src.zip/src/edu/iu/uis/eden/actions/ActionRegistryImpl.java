
/*
 * Copyright (c) 2004, 2005, 2006 Trustees of Indiana University and Cornell University.
 *
 * Licensed under the Educational Community License Version 1.0 (the "License"); By obtaining,
 * using and/or copying this Original Work, you agree that you have read, understand, and will
 * comply with the terms and conditions of the Educational Community License.
 *
 * For the full text of the license, see the LICENSE.txt file or visit:
 * 
 * http://kew.indiana.edu/workflow/LICENSE.txt
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING
 * BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE
 * AND NONINFRINGEMENT.
 * IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES
 * OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 */
            
package edu.iu.uis.eden.actions;

import edu.iu.uis.eden.EdenConstants;
import edu.iu.uis.eden.SpringServiceLocator;
import edu.iu.uis.eden.exception.ResourceUnavailableException;
import edu.iu.uis.eden.exception.WorkflowRuntimeException;

import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.beanutils.ConstructorUtils;


/**
 * A simple implementation of an ActionRegistry which includes all of the default Workflow Actions.
 * 
 * @author ewestfal
 */
public class ActionRegistryImpl implements ActionRegistry {
    private static Map actionMap = new HashMap();

    static {
        actionMap.put(EdenConstants.ACTION_TAKEN_ACKNOWLEDGED_CD, 
                      AcknowledgeAction.class.getName());
        actionMap.put(EdenConstants.ACTION_TAKEN_ADHOC_CD, 
                      AdHocAction.class.getName());
        actionMap.put(EdenConstants.ACTION_TAKEN_ADHOC_REVOKED_CD, 
                      RevokeAdHocAction.class.getName());
        actionMap.put(EdenConstants.ACTION_TAKEN_APPROVED_CD, 
                      ApproveAction.class.getName());
        actionMap.put(EdenConstants.ACTION_TAKEN_BLANKET_APPROVE_CD, 
                      BlanketApproveAction.class.getName());
        actionMap.put(EdenConstants.ACTION_TAKEN_CANCELED_CD, 
                      CancelAction.class.getName());
        actionMap.put(EdenConstants.ACTION_TAKEN_COMPLETED_CD, 
                      CompleteAction.class.getName());
        actionMap.put(EdenConstants.ACTION_TAKEN_ROUTED_CD, 
                      RouteDocumentAction.class.getName());
        actionMap.put(EdenConstants.ACTION_TAKEN_DENIED_CD, 
                      DisapproveAction.class.getName());
        actionMap.put(EdenConstants.ACTION_TAKEN_FYI_CD, 
                      ClearFYIAction.class.getName());
        actionMap.put(EdenConstants.ACTION_TAKEN_LOG_DOCUMENT_ACTION_CD, 
                      LogDocumentActionAction.class.getName());
        actionMap.put(EdenConstants.ACTION_TAKEN_MOVE_CD, 
                      MoveDocumentAction.class.getName());
        actionMap.put(EdenConstants.ACTION_TAKEN_TAKE_WORKGROUP_AUTHORITY_CD, 
                      TakeWorkgroupAuthority.class.getName());
        actionMap.put(EdenConstants.ACTION_TAKEN_RELEASE_WORKGROUP_AUTHORITY_CD, 
                      ReleaseWorkgroupAuthority.class.getName());
        actionMap.put(EdenConstants.ACTION_TAKEN_RETURNED_TO_PREVIOUS_CD, 
                      ReturnToPreviousNodeAction.class.getName());
        actionMap.put(EdenConstants.ACTION_TAKEN_SAVED_CD, 
                      SaveActionEvent.class.getName());


        //actionMap.put(EdenConstants.ACTION_TAKEN_SU_ACTION_REQUEST_ACKNOWLEDGED_CD, SuperUserActionRequestAcknowledgeEvent.class.getName());
        actionMap.put(EdenConstants.ACTION_TAKEN_SU_ACTION_REQUEST_APPROVED_CD, 
                      SuperUserActionRequestApproveEvent.class.getName());


        //actionMap.put(EdenConstants.ACTION_TAKEN_SU_ACTION_REQUEST_COMPLETED_CD, SuperUserActionRequestCompleteEvent.class.getName());
        //actionMap.put(EdenConstants.ACTION_TAKEN_SU_ACTION_REQUEST_FYI_CD, SuperUserActionRequestFYIEvent.class.getName());
        actionMap.put(EdenConstants.ACTION_TAKEN_SU_APPROVED_CD, 
                      SuperUserApproveEvent.class.getName());
        actionMap.put(EdenConstants.ACTION_TAKEN_SU_CANCELED_CD, 
                      SuperUserCancelEvent.class.getName());
        actionMap.put(EdenConstants.ACTION_TAKEN_SU_DISAPPROVED_CD, 
                      SuperUserDisapproveEvent.class.getName());
        actionMap.put(EdenConstants.ACTION_TAKEN_SU_RETURNED_TO_PREVIOUS_CD, 
                      SuperUserReturnToPreviousNodeAction.class.getName());
        actionMap.put(EdenConstants.ACTION_TAKEN_SU_ROUTE_LEVEL_APPROVED_CD, 
                      SuperUserNodeApproveEvent.class.getName());
    }

    public void registerAction(String actionCode, String actionClass) {
        if (actionClass == null) {
            throw new IllegalArgumentException("Action Code '" + actionCode + 
                                               "' cannot be registered with a null action class.");
        }

        if (actionMap.containsKey(actionCode)) {
            throw new WorkflowRuntimeException(
                    "Action Code is already in use.  [" + actionCode + ", " + 
                    actionClass + "].  " + 
                    "Please unregister the existing implementation first.");
        }

        actionMap.put(actionCode, actionClass);
    }

    public void unregisterAction(String actionCode) {
        actionMap.remove(actionCode);
    }

    public Map getActionMap() {
        return Collections.synchronizedMap(actionMap);
    }

    public ActionTakenEvent createAction(String actionCode, List parameters)
                                  throws ResourceUnavailableException {
        String actionClassName = (String) actionMap.get(actionCode);

        if (actionClassName == null) {
            throw new IllegalArgumentException(
                    "No action has been registered for the given action code of '" + 
                    actionCode + "'.");
        }

        Class actionClass = SpringServiceLocator.getExtensionService()
                                                .loadClass(actionClassName);
        Object[] parameterArray = new Object[0];

        if ((parameters != null) && !parameters.isEmpty()) {
            parameterArray = parameters.toArray();
        }

        try {
            return (ActionTakenEvent) ConstructorUtils.invokeConstructor(
                           actionClass, parameterArray);
        } catch (Exception e) {
            if (e instanceof ResourceUnavailableException) {
                throw (ResourceUnavailableException) e;
            }

            throw new ResourceUnavailableException(e);
        }
    }
}