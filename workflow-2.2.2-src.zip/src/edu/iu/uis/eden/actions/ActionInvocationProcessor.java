
/*
 * Copyright (c) 2004, 2005, 2006 Trustees of Indiana University and Cornell University.
 *
 * Licensed under the Educational Community License Version 1.0 (the "License"); By obtaining,
 * using and/or copying this Original Work, you agree that you have read, understand, and will
 * comply with the terms and conditions of the Educational Community License.
 *
 * For the full text of the license, see the LICENSE.txt file or visit:
 * 
 * http://kew.indiana.edu/workflow/LICENSE.txt
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING
 * BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE
 * AND NONINFRINGEMENT.
 * IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES
 * OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 */
            
package edu.iu.uis.eden.actions;

import edu.iu.uis.eden.EdenConstants;
import edu.iu.uis.eden.SpringServiceLocator;
import edu.iu.uis.eden.exception.EdenUserNotFoundException;
import edu.iu.uis.eden.routeheader.DocumentRouteHeaderValue;
import edu.iu.uis.eden.routemanager.ParameterTranslator;
import edu.iu.uis.eden.routemanager.RouteQueueProcessor;
import edu.iu.uis.eden.routequeue.RouteQueue;
import edu.iu.uis.eden.user.AuthenticationUserId;
import edu.iu.uis.eden.user.WorkflowUser;

import java.util.ArrayList;
import java.util.List;


public class ActionInvocationProcessor implements RouteQueueProcessor {
    public void process(RouteQueue routeQueue) throws Exception {
        DocumentRouteHeaderValue document = SpringServiceLocator.getRouteHeaderService()
                                                                .getRouteHeader(routeQueue.getRouteHeaderId());
        ParameterTranslator translator = new ParameterTranslator(
                                                 routeQueue.getProcessorValue());
        String[] stringParameters = translator.getParameters();
        WorkflowUser user = getWorkflowUser(stringParameters);

        // currently, the actions we're interested in have three standard parameters,
        // 1) the document, 2) the user, 3) the annotation 
        List parameters = new ArrayList();
        parameters.add(document);
        parameters.add(user);
        parameters.add("");

        ActionTakenEvent action = SpringServiceLocator.getActionRegistry()
                                                      .createAction(stringParameters[1], 
                                                                    parameters);
        action.recordAction();
        action.queueDocument();
    }

    private WorkflowUser getWorkflowUser(String[] parameters)
                                  throws Exception {
        WorkflowUser user = SpringServiceLocator.getUserService()
                                                .getWorkflowUser(new AuthenticationUserId(
                                                                         parameters[0]));

        if (user == null) {
            throw new EdenUserNotFoundException(
                    "Could not locate the user for the given authentication id '" + 
                    parameters[0] + "'");
        }

        return user;
    }

    public static void queueActionInvocation(WorkflowUser user, Long documentId, 
                                             ActionInvocation invocation) {
        ParameterTranslator translator = new ParameterTranslator();
        translator.addParameter(user.getAuthenticationUserId()
                                    .getAuthenticationId());
        translator.addParameter(invocation.getActionCode());
        SpringServiceLocator.getRouteQueueService()
                    .requeueDocument(documentId, 
                                     EdenConstants.ROUTE_QUEUE_DEFAULT_PRIORITY, 
                                     new Long(0), 
                                     ActionInvocationProcessor.class.getName(), 
                                     translator.getUntranslatedString());
    }
}