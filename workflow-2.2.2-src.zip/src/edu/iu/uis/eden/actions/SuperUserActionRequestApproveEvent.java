
/*
 * Copyright (c) 2004, 2005, 2006 Trustees of Indiana University and Cornell University.
 *
 * Licensed under the Educational Community License Version 1.0 (the "License"); By obtaining,
 * using and/or copying this Original Work, you agree that you have read, understand, and will
 * comply with the terms and conditions of the Educational Community License.
 *
 * For the full text of the license, see the LICENSE.txt file or visit:
 * 
 * http://kew.indiana.edu/workflow/LICENSE.txt
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING
 * BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE
 * AND NONINFRINGEMENT.
 * IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES
 * OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 */
            
package edu.iu.uis.eden.actions;

import edu.iu.uis.eden.EdenConstants;
import edu.iu.uis.eden.SpringServiceLocator;
import edu.iu.uis.eden.WorkflowServiceErrorException;
import edu.iu.uis.eden.WorkflowServiceErrorImpl;
import edu.iu.uis.eden.actionrequests.ActionRequestFactory;
import edu.iu.uis.eden.actionrequests.ActionRequestValue;
import edu.iu.uis.eden.doctype.DocumentType;
import edu.iu.uis.eden.exception.EdenUserNotFoundException;
import edu.iu.uis.eden.exception.InvalidActionTakenException;
import edu.iu.uis.eden.exception.WorkflowException;
import edu.iu.uis.eden.routeheader.DocumentRouteHeaderValue;
import edu.iu.uis.eden.user.WorkflowUser;

import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.MDC;


public class SuperUserActionRequestApproveEvent
    extends SuperUserActionTakenEvent {
    private static final org.apache.log4j.Logger LOG = 
            org.apache.log4j.Logger.getLogger(
                    SuperUserActionRequestApproveEvent.class);
    private Long actionRequestId;

    public SuperUserActionRequestApproveEvent(DocumentRouteHeaderValue routeHeader, 
                                              WorkflowUser user, 
                                              Long actionRequestId, 
                                              String annotation) {
        super(routeHeader, user, annotation);

        this.superUserAction = EdenConstants.SUPER_USER_ACTION_REQUEST_APPROVE;
        this.actionRequestId = actionRequestId;
    }

    public void setActionTaken() {
        String actionRequestCode = "";

        ActionRequestValue actionRequest = getActionRequestService()
                                               .findByActionRequestId(actionRequestId);

        setActionRequest(actionRequest);

        actionRequestCode = actionRequest.getActionRequested();

        //This has been set up for all of the actions, but this class only does approvals 
        if (EdenConstants.ACTION_REQUEST_APPROVE_REQ.equals(actionRequestCode)) {
            this.setActionTakenCode(
                    EdenConstants.ACTION_TAKEN_SU_ACTION_REQUEST_APPROVED_CD);
        } else if (EdenConstants.ACTION_REQUEST_COMPLETE_REQ.equals(
                           actionRequestCode)) {
            this.setActionTakenCode(
                    EdenConstants.ACTION_TAKEN_SU_ACTION_REQUEST_COMPLETED_CD);
        } else if (EdenConstants.ACTION_REQUEST_FYI_REQ.equals(
                           actionRequestCode)) {
            this.setActionTakenCode(
                    EdenConstants.ACTION_TAKEN_SU_ACTION_REQUEST_FYI_CD);
        } else if (EdenConstants.ACTION_REQUEST_ACKNOWLEDGE_REQ.equals(
                           actionRequestCode)) {
            this.setActionTakenCode(
                    EdenConstants.ACTION_TAKEN_SU_ACTION_REQUEST_ACKNOWLEDGED_CD);
        } else {
            //TODO this should be checked
            LOG.error("Invalid SU delegation action request code: " + 
                      actionRequestCode);
            throw new RuntimeException(
                    "Invalid SU delegation action request code: " + 
                    actionRequestCode);
        }
    }

    protected void processActionRequests() throws InvalidActionTakenException, 
                                                  EdenUserNotFoundException {
        //this method has been written to process all of the actions though only approvals are currently processed
        DocumentType docType = getRouteHeader().getDocumentType();

        //        boolean userAuthorized = getDocumentTypeService().verifySUAuthority(docType, getUser());
        if (!docType.isSuperUser(getUser())) {
            List errors = new ArrayList();
            errors.add(new WorkflowServiceErrorImpl(
                               "User not authorized for super user action", 
                               SuperUserActionTakenEvent.AUTHORIZATION));
            throw new WorkflowServiceErrorException(
                    "Super User Authorization Error", errors);
        }

        this.setActionTaken();

        MDC.put("docId", getRouteHeader().getRouteHeaderId());

        if (annotation == null) {
            annotation = "";
        }

        LOG.debug("Super User Delegation Action on action request: " + 
                  annotation);

        // the statements below customize the processing for FYI and acknowledgements since these 2 actions need different processing than
        // the other actions - only approvals are currently processed by this class
        if (EdenConstants.ACTION_TAKEN_SU_ACTION_REQUEST_FYI_CD.equals(
                    this.getActionTakenCode())) {
            ;
        } else {
            this.saveActionTaken(getActionRequest().getWorkflowUser());
        }

        LOG.debug("Deactivate this action request");

        ActionRequestValue request = getActionRequest();
        getActionRequestService().deactivateRequest(actionTaken, request);

        if (docType.getSuperUserApproveNotificationPolicy().getPolicyValue()
                   .booleanValue() && request.isApproveOrCompleteRequest()) {
            SpringServiceLocator.getActionRequestService()
                    .activateRequest(new ActionRequestFactory(
                                             this.getRouteHeader()).createNotificationRequest(
                                             EdenConstants.ACTION_REQUEST_ACKNOWLEDGE_REQ, 
                                             request.getWorkflowUser(), 
                                             this.getActionTakenCode(), 
                                             this.getUser(), null));
        }

        notifyActionTaken(this.actionTaken);

        if (!(EdenConstants.ACTION_TAKEN_SU_ACTION_REQUEST_FYI_CD.equals(
                      this.getActionTakenCode()) && EdenConstants.ACTION_TAKEN_SU_ACTION_REQUEST_ACKNOWLEDGED_CD.equals(
                                                            this.getActionTakenCode()))) {
            if (getRouteHeader().isInException()) {
                LOG.debug("Moving document back to Enroute from Exception");

                String oldStatus = getRouteHeader().getDocRouteStatus();
                this.getRouteHeader().markDocumentEnroute();

                String newStatus = getRouteHeader().getDocRouteStatus();
                this.notifyStatusChange(newStatus, oldStatus);
                getRouteHeaderService().saveRouteHeader(getRouteHeader());
            }
        }
    }

    public void recordAction() throws InvalidActionTakenException, 
                                      EdenUserNotFoundException {
        checkLocking();
        this.processActionRequests();
        this.queueDocument();
    }

    protected void markDocument() throws WorkflowException {
    }
}