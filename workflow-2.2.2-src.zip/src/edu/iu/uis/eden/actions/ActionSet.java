
/*
 * Copyright (c) 2004, 2005, 2006 Trustees of Indiana University and Cornell University.
 *
 * Licensed under the Educational Community License Version 1.0 (the "License"); By obtaining,
 * using and/or copying this Original Work, you agree that you have read, understand, and will
 * comply with the terms and conditions of the Educational Community License.
 *
 * For the full text of the license, see the LICENSE.txt file or visit:
 * 
 * http://kew.indiana.edu/workflow/LICENSE.txt
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING
 * BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE
 * AND NONINFRINGEMENT.
 * IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES
 * OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 */
            
package edu.iu.uis.eden.actions;

import edu.iu.uis.eden.EdenConstants;

import java.util.ArrayList;
import java.util.List;


/**
 * Specifies a set of Action codes.
 * 
 * @author ewestfal
 */
public class ActionSet {
    private List actionSet = new ArrayList();

    public boolean hasAction(String actionCode) {
        return actionSet.contains(actionCode);
    }

    public boolean addAction(String actionCode) {
        if (!actionSet.contains(actionCode)) {
            actionSet.add(actionCode);

            return true;
        }

        return false;
    }

    public boolean removeAction(String actionCode) {
        return actionSet.remove(actionCode);
    }

    // some convienance methods for common actions
    public boolean hasApprove() {
        return hasAction(EdenConstants.ACTION_TAKEN_APPROVED_CD);
    }

    public boolean hasComplete() {
        return hasAction(EdenConstants.ACTION_TAKEN_COMPLETED_CD);
    }

    public boolean hasAcknowledge() {
        return hasAction(EdenConstants.ACTION_TAKEN_ACKNOWLEDGED_CD);
    }

    public boolean hasFyi() {
        return hasAction(EdenConstants.ACTION_TAKEN_FYI_CD);
    }

    public boolean hasDisapprove() {
        return hasAction(EdenConstants.ACTION_TAKEN_DENIED_CD);
    }

    public boolean hasCancel() {
        return hasAction(EdenConstants.ACTION_TAKEN_CANCELED_CD);
    }

    public boolean hasRouted() {
        return hasAction(EdenConstants.ACTION_TAKEN_ROUTED_CD);
    }

    public boolean addApprove() {
        return addAction(EdenConstants.ACTION_TAKEN_APPROVED_CD);
    }

    public boolean addComplete() {
        return addAction(EdenConstants.ACTION_TAKEN_COMPLETED_CD);
    }

    public boolean addAcknowledge() {
        return addAction(EdenConstants.ACTION_TAKEN_ACKNOWLEDGED_CD);
    }

    public boolean addFyi() {
        return addAction(EdenConstants.ACTION_TAKEN_FYI_CD);
    }

    public boolean addDisapprove() {
        return addAction(EdenConstants.ACTION_TAKEN_DENIED_CD);
    }

    public boolean addCancel() {
        return addAction(EdenConstants.ACTION_TAKEN_CANCELED_CD);
    }

    public boolean addRouted() {
        return addAction(EdenConstants.ACTION_TAKEN_ROUTED_CD);
    }
}