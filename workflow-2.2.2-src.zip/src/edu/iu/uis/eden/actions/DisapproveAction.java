
/*
 * Copyright (c) 2004, 2005, 2006 Trustees of Indiana University and Cornell University.
 *
 * Licensed under the Educational Community License Version 1.0 (the "License"); By obtaining,
 * using and/or copying this Original Work, you agree that you have read, understand, and will
 * comply with the terms and conditions of the Educational Community License.
 *
 * For the full text of the license, see the LICENSE.txt file or visit:
 * 
 * http://kew.indiana.edu/workflow/LICENSE.txt
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING
 * BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE
 * AND NONINFRINGEMENT.
 * IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES
 * OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 */
            
package edu.iu.uis.eden.actions;

import edu.iu.uis.eden.EdenConstants;
import edu.iu.uis.eden.SpringServiceLocator;
import edu.iu.uis.eden.actionrequests.ActionRequestFactory;
import edu.iu.uis.eden.actionrequests.ActionRequestValue;
import edu.iu.uis.eden.actiontaken.ActionTakenValue;
import edu.iu.uis.eden.engine.node.RouteNodeInstance;
import edu.iu.uis.eden.exception.EdenUserNotFoundException;
import edu.iu.uis.eden.exception.InvalidActionTakenException;
import edu.iu.uis.eden.exception.ResourceUnavailableException;
import edu.iu.uis.eden.exception.WorkflowException;
import edu.iu.uis.eden.routeheader.DocumentRouteHeaderValue;
import edu.iu.uis.eden.user.Recipient;
import edu.iu.uis.eden.user.WorkflowUser;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

import org.apache.log4j.MDC;


/**
 * Disapproves a document. This deactivates all requests on the document and sends acknowlegde requests to anybody who had already completed or approved the document.
 */
public class DisapproveAction extends ActionTakenEvent {
    private static final org.apache.log4j.Logger LOG = 
            org.apache.log4j.Logger.getLogger(DisapproveAction.class);

    /**
     * @param rh RouteHeader for the document upon which the action is taken.
     * @param user User taking the action.
     * @param delegator Delegator who delegated this action authority to the user.
     * @param annotation User comment on the action taken
     */
    public DisapproveAction(DocumentRouteHeaderValue rh, WorkflowUser user, 
                            String annotation) {
        super(rh, user, annotation);
        setActionTakenCode(EdenConstants.ACTION_TAKEN_DENIED_CD);
    }

    /**
     * Records the disapprove action. - Checks to make sure the document status allows the action. - Checks that the user has not taken a previous action. - Deactivates the pending requests for this user - Records the action
     * 
     * @throws InvalidActionTakenException
     * @throws ResourceUnavailableException
     */
    public void recordAction() throws InvalidActionTakenException, 
                                      EdenUserNotFoundException {
        MDC.put("docId", getRouteHeader().getRouteHeaderId());
        super.recordAction();

        LOG.debug("Disapproving document : " + annotation);

        LOG.debug("Checking to see if the action is legal");

        if (!getRouteHeader().isValidActionToTake(getActionTakenCode())) {
            LOG.warn("Document not in state to be disapproved.");
            throw new InvalidActionTakenException(
                    "Document is not in a state to be disapproved");
        }

        List actionRequests = getActionRequestService()
                                  .findAllValidRequests(getUser(), 
                                                        getRouteHeaderId(), 
                                                        EdenConstants.ACTION_REQUEST_COMPLETE_REQ);

        if (!isActionCompatibleRequest(actionRequests, getActionTakenCode())) {
            throw new InvalidActionTakenException(
                    "No request for the user is compatible " + 
                    "with the DISAPPROVE or DENY action");
        }

        LOG.debug("Record the disapproval action");

        Recipient delegator = findDelegatorForActionRequests(actionRequests);
        saveActionTaken(delegator);

        actionRequests = getActionRequestService()
                             .findByStatusAndDocId(EdenConstants.ACTION_REQUEST_DONE_STATE, 
                                                   getRouteHeaderId());

        List actionRequestsToNotify = new ArrayList();

        for (Iterator iter = actionRequests.iterator(); iter.hasNext();) {
            ActionRequestValue actionRequest = (ActionRequestValue) iter.next();

            //action request must be a complete and not to initiator (initiator will get specific request because they are initiator)
            if (actionRequest.isApproveOrCompleteRequest() && 
                    !actionRequest.isRecipientRoutedRequest(
                             getRouteHeader().getInitiatorUser())) {
                actionRequestsToNotify.add(actionRequest);
            }
        }

        LOG.debug("Deactivate all pending action requests");
        actionRequests = getActionRequestService()
                             .findPendingByDoc(getRouteHeaderId());
        getActionRequestService()
            .deactivateRequests(actionTaken, actionRequests);
        notifyActionTaken(this.actionTaken);

        LOG.debug("Sending Acknowledgements to all previous approvers/completers");

        // Generate the notification requests in the first node we find that the current user has an approve request
        RouteNodeInstance notificationNodeInstance = null;


        //        if (actionRequests.size() > 0) { //I don't see why this matters let me know if it does rk
        notificationNodeInstance = ((ActionRequestValue) actionRequests.get(0)).getNodeInstance();


        //        }
        generateNotifications(notificationNodeInstance);

        LOG.debug("Disapproving document");

        try {
            String oldStatus = getRouteHeader().getDocRouteStatus();
            routeHeader.markDocumentDisapproved();

            String newStatus = getRouteHeader().getDocRouteStatus();
            getRouteHeaderService().saveRouteHeader(routeHeader);
            notifyStatusChange(newStatus, oldStatus);
        } catch (WorkflowException ex) {
            LOG.warn(ex, ex);
            throw new InvalidActionTakenException(ex.getMessage());
        }
    }

    //generate notifications to all people that have approved the document including the initiator
    private void generateNotifications(RouteNodeInstance notificationNodeInstance)
                                throws EdenUserNotFoundException {
        ActionRequestFactory arFactory = new ActionRequestFactory(
                                                 getRouteHeader(), 
                                                 notificationNodeInstance);
        Collection actions = SpringServiceLocator.getActionTakenService()
                                                 .findByRouteHeaderId(getRouteHeaderId());

        //one notification per person
        Set usersNotified = new HashSet();

        for (Iterator iter = actions.iterator(); iter.hasNext();) {
            ActionTakenValue action = (ActionTakenValue) iter.next();

            if ((action.isApproval() || action.isCompletion()) && 
                    !usersNotified.contains(action.getWorkflowId())) {
                ActionRequestValue request = arFactory.createNotificationRequest(
                                                     EdenConstants.ACTION_REQUEST_ACKNOWLEDGE_REQ, 
                                                     action.getWorkflowUser(), 
                                                     getActionTakenCode(), 
                                                     getUser(), 
                                                     getActionTakenCode());
                SpringServiceLocator.getActionRequestService()
                    .activateRequest(request);
                usersNotified.add(request.getWorkflowId());
            }
        }
    }
}