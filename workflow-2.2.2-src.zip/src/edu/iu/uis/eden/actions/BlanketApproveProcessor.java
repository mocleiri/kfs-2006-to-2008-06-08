
/*
 * Copyright (c) 2004, 2005, 2006 Trustees of Indiana University and Cornell University.
 *
 * Licensed under the Educational Community License Version 1.0 (the "License"); By obtaining,
 * using and/or copying this Original Work, you agree that you have read, understand, and will
 * comply with the terms and conditions of the Educational Community License.
 *
 * For the full text of the license, see the LICENSE.txt file or visit:
 * 
 * http://kew.indiana.edu/workflow/LICENSE.txt
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING
 * BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE
 * AND NONINFRINGEMENT.
 * IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES
 * OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 */
            
package edu.iu.uis.eden.actions;

import edu.iu.uis.eden.SpringServiceLocator;
import edu.iu.uis.eden.actiontaken.ActionTakenValue;
import edu.iu.uis.eden.routeheader.DocumentRouteHeaderValue;
import edu.iu.uis.eden.routemanager.RouteQueueProcessor;
import edu.iu.uis.eden.routequeue.RouteQueue;
import edu.iu.uis.eden.user.WorkflowUser;
import edu.iu.uis.eden.user.WorkflowUserId;

import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;
import java.util.StringTokenizer;


public class BlanketApproveProcessor implements RouteQueueProcessor {
    private static final org.apache.log4j.Logger LOG = 
            org.apache.log4j.Logger.getLogger(BlanketApproveProcessor.class);

    public void process(RouteQueue routeQueue) throws Exception {
        SpringServiceLocator.getRouteHeaderService()
                    .lockRouteHeader(routeQueue.getRouteHeaderId(), true);
        LOG.debug("Blanket Approve Processing document " + 
                  routeQueue.getRouteHeaderId());

        DocumentRouteHeaderValue routeHeader = SpringServiceLocator.getRouteHeaderService()
                                                                   .getRouteHeader(routeQueue.getRouteHeaderId());
        StringTokenizer tokenizer = new StringTokenizer(
                                            routeQueue.getProcessorValue(), ",");
        String workflowId = tokenizer.nextToken();
        Long actionTakenId = new Long(tokenizer.nextToken());
        Set nodeNames = new HashSet();

        while (tokenizer.hasMoreTokens()) {
            nodeNames.add(tokenizer.nextToken());
        }

        WorkflowUser user = SpringServiceLocator.getUserService()
                                                .getWorkflowUser(new WorkflowUserId(
                                                                         workflowId));
        ActionTakenValue actionTaken = SpringServiceLocator.getActionTakenService()
                                                           .findByActionTakenId(actionTakenId);
        BlanketApproveAction blanketApprove = new BlanketApproveAction(
                                                      routeHeader, user, "", 
                                                      nodeNames);
        blanketApprove.actionTaken = actionTaken;
        LOG.debug("Doing blanket approve work document " + 
                  routeHeader.getRouteHeaderId());
        blanketApprove.doBlanketApproveWork();
        blanketApprove.queueDocument();
        LOG.debug("Work done and document requeued, document " + 
                  routeHeader.getRouteHeaderId());
    }

    public static String getBlanketApproveProcessorValue(WorkflowUser user, 
                                                         ActionTakenValue actionTaken, 
                                                         Set nodeNames) {
        String value = user.getWorkflowId() + "," + 
                       actionTaken.getActionTakenId();

        if (nodeNames != null) {
            for (Iterator iterator = nodeNames.iterator(); iterator.hasNext();) {
                value += ("," + (String) iterator.next());
            }
        }

        return value;
    }
}