
/*
 * Copyright (c) 2004, 2005, 2006 Trustees of Indiana University and Cornell University.
 *
 * Licensed under the Educational Community License Version 1.0 (the "License"); By obtaining,
 * using and/or copying this Original Work, you agree that you have read, understand, and will
 * comply with the terms and conditions of the Educational Community License.
 *
 * For the full text of the license, see the LICENSE.txt file or visit:
 * 
 * http://kew.indiana.edu/workflow/LICENSE.txt
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING
 * BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE
 * AND NONINFRINGEMENT.
 * IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES
 * OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 */
            
package edu.iu.uis.eden.actions;

import edu.iu.uis.eden.EdenConstants;
import edu.iu.uis.eden.exception.EdenUserNotFoundException;
import edu.iu.uis.eden.exception.InvalidActionTakenException;
import edu.iu.uis.eden.exception.WorkflowException;
import edu.iu.uis.eden.routeheader.DocumentRouteHeaderValue;
import edu.iu.uis.eden.user.WorkflowUser;

import java.util.List;

import org.apache.log4j.MDC;


public class CancelAction extends ActionTakenEvent {
    private static final org.apache.log4j.Logger LOG = 
            org.apache.log4j.Logger.getLogger(CancelAction.class);

    public CancelAction(DocumentRouteHeaderValue rh, WorkflowUser user, 
                        String annotation) {
        super(rh, user, annotation);
        setActionTakenCode(EdenConstants.ACTION_TAKEN_CANCELED_CD);
    }

    public void recordAction() throws InvalidActionTakenException, 
                                      EdenUserNotFoundException {
        MDC.put("docId", getRouteHeader().getRouteHeaderId());
        super.recordAction();

        LOG.debug("Canceling document : " + annotation);

        List actionRequests = getActionRequestService()
                                  .findAllValidRequests(getUser(), 
                                                        getRouteHeaderId(), 
                                                        EdenConstants.ACTION_REQUEST_COMPLETE_REQ);

        LOG.debug("Checking to see if the action is legal");

        if (!isActionCompatibleRequest(actionRequests, getActionTakenCode())) {
            throw new InvalidActionTakenException(
                    "No request for the user is compatible with the DISAPPROVE or DENY action");
        }

        LOG.debug("Record the cancel action");
        saveActionTaken(findDelegatorForActionRequests(actionRequests));

        LOG.debug("Deactivate all pending action requests");
        actionRequests = getActionRequestService()
                             .findPendingByDoc(getRouteHeaderId());

        getActionRequestService()
            .deactivateRequests(actionTaken, actionRequests);
        notifyActionTaken(this.actionTaken);

        LOG.debug("Canceling document");

        try {
            String oldStatus = getRouteHeader().getDocRouteStatus();
            getRouteHeader().markDocumentCanceled();

            String newStatus = getRouteHeader().getDocRouteStatus();
            notifyStatusChange(newStatus, oldStatus);
        } catch (WorkflowException ex) {
            LOG.warn(ex, ex);
            throw new InvalidActionTakenException(ex.getMessage());
        }

        getRouteHeaderService().saveRouteHeader(getRouteHeader());
    }
}