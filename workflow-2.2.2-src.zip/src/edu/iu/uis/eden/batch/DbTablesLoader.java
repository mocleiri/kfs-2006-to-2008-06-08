
/*
 * Copyright (c) 2004, 2005, 2006 Trustees of Indiana University and Cornell University.
 *
 * Licensed under the Educational Community License Version 1.0 (the "License"); By obtaining,
 * using and/or copying this Original Work, you agree that you have read, understand, and will
 * comply with the terms and conditions of the Educational Community License.
 *
 * For the full text of the license, see the LICENSE.txt file or visit:
 * 
 * http://kew.indiana.edu/workflow/LICENSE.txt
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING
 * BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE
 * AND NONINFRINGEMENT.
 * IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES
 * OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 */
            
package edu.iu.uis.eden.batch;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;

import org.apache.ojb.broker.PersistenceBroker;

import org.springframework.orm.ojb.OjbFactoryUtils;
import org.springframework.orm.ojb.PersistenceBrokerTemplate;


public class DbTablesLoader extends PersistenceBrokerTemplate {
    private static final org.apache.log4j.Logger LOG = 
            org.apache.log4j.Logger.getLogger(DbTablesLoader.class);
    String loadOnStartSqlDirectory;
    String checkTablesFile;
    String createTablesFile;
    FileReader fileReader = null;
    BufferedReader bufReader = null;
    String checkTablesSql = null;
    String createTablesSql = null;
    StringBuffer stringBuf = null;
    String readBuf = null;
    PersistenceBroker broker = null;
    Connection conn = null;
    ResultSet rs = null;

    public boolean dbTablesExist() throws Exception {
        boolean exist = false;

        try {
            fileReader = new FileReader(
                                 new File(loadOnStartSqlDirectory, 
                                          checkTablesFile));
            bufReader = new BufferedReader(fileReader);
            stringBuf = new StringBuffer();

            while ((readBuf = bufReader.readLine()) != null) {
                stringBuf.append(readBuf);
            }

            checkTablesSql = stringBuf.toString();
            LOG.debug("Check Tables query: " + checkTablesSql);

            broker = this.getPersistenceBroker();
            conn = broker.serviceConnectionManager().getConnection();

            Statement statement = conn.createStatement();

            try {
                rs = statement.executeQuery(checkTablesSql);

                if ((rs != null) && rs.next()) {
                    exist = true;
                }
            } finally {
                statement.close();

                if (rs != null) {
                    rs.close();
                }
            }

            return exist;
        } catch (Exception e) {
            LOG.error("Caught Exception executing check db tables query.", e);
            throw e;
        } finally {
            try {
                if (broker != null) {
                    OjbFactoryUtils.releasePersistenceBroker(broker, getPbKey());
                }
            } catch (Exception e) {
                LOG.error("Failed closing connection: " + e.getMessage(), e);
            }
        }
    }

    public void loadTables() throws Exception {
        try {
            fileReader = new FileReader(
                                 new File(loadOnStartSqlDirectory, 
                                          createTablesFile));
            bufReader = new BufferedReader(fileReader);
            stringBuf = new StringBuffer();

            while ((readBuf = bufReader.readLine()) != null) {
                stringBuf.append(readBuf);
            }

            createTablesSql = stringBuf.toString();
            LOG.debug("Load Tables query: " + createTablesSql);

            broker = this.getPersistenceBroker();
            conn = broker.serviceConnectionManager().getConnection();
            conn.createStatement().execute(createTablesSql);
        } catch (Exception e) {
            LOG.error("Caught Exception executing load db tables query.", e);
            throw e;
        } finally {
            try {
                if (broker != null) {
                    OjbFactoryUtils.releasePersistenceBroker(broker, getPbKey());
                }
            } catch (Exception e) {
                LOG.error("Failed closing connection: " + e.getMessage(), e);
            }
        }
    }

    public String getCheckTablesFile() {
        return checkTablesFile;
    }

    public void setCheckTablesFile(String checkTablesFile) {
        this.checkTablesFile = checkTablesFile;
    }

    public String getLoadOnStartSqlDirectory() {
        return loadOnStartSqlDirectory;
    }

    public void setLoadOnStartSqlDirectory(String loadOnStartSqlDirectory) {
        this.loadOnStartSqlDirectory = loadOnStartSqlDirectory;
    }

    public String getCreateTablesFile() {
        return createTablesFile;
    }

    public void setCreateTablesFile(String createTablesFile) {
        this.createTablesFile = createTablesFile;
    }
}