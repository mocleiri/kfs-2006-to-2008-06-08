
/*
 * Copyright (c) 2004, 2005, 2006 Trustees of Indiana University and Cornell University.
 *
 * Licensed under the Educational Community License Version 1.0 (the "License"); By obtaining,
 * using and/or copying this Original Work, you agree that you have read, understand, and will
 * comply with the terms and conditions of the Educational Community License.
 *
 * For the full text of the license, see the LICENSE.txt file or visit:
 * 
 * http://kew.indiana.edu/workflow/LICENSE.txt
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING
 * BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE
 * AND NONINFRINGEMENT.
 * IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES
 * OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 */
            
package edu.iu.uis.eden.batch;

import edu.iu.uis.eden.XmlLoader;
import edu.iu.uis.eden.user.WorkflowUser;
import edu.iu.uis.eden.util.Utilities;

import java.io.BufferedInputStream;
import java.io.IOException;
import java.io.InputStream;

import java.util.Iterator;

import org.apache.log4j.Logger;


/**
 * XmlDigesterService implementation.  This class simply loads the specified xml doc
 * with the specified XmlLoader.
 * @see edu.iu.uis.eden.batch.XmlDigesterService
 * @author Aaron Hamid (arh14 at cornell dot edu)
 */
public class XmlDigesterServiceImpl implements XmlDigesterService {
    private static final Logger LOG = Logger.getLogger(
                                              XmlDigesterServiceImpl.class);

    private static void addProcessingException(XmlDoc xmlDoc, String message, 
                                               Throwable t) {
        String msg = xmlDoc.getProcessingMessage();

        if (msg == null) {
            msg = "";
        }

        msg += (message + "\n" + Utilities.collectStackTrace(t));
        xmlDoc.setProcessingMessage(msg);
    }

    public void digest(XmlLoader xmlLoader, XmlDocCollection xmlDocCollection, 
                       WorkflowUser user) throws IOException {
        Iterator it = xmlDocCollection.getXmlDocs().iterator();

        while (it.hasNext()) {
            XmlDoc xmlDoc = (XmlDoc) it.next();
            InputStream inputStream = null;

            try {
                inputStream = new BufferedInputStream(xmlDoc.getStream());


                // NOTE: do we need XmlLoader to return a boolean to indicate
                // whether the document was handled at all, now that we are handing
                // all docs to all services?
                // e.g. if (xmlLoader.loadXml(inputstream)) xmlDoc.setProcessed(true);
                // it's ok if the xml doc is processed multiple times however
                // because it could have multiple types of content
                // but we need to know if it was not processed ANY times
                // (so just don't setProcessed to false)
                xmlLoader.loadXml(inputStream, user);


                // it would be nice to know if the xmlLoader actually handled the doc
                // so we could print out a log entry ONLY if the doc was handled, not
                // if it was just (successfully) ignored
                // should only be set on successful loading
                xmlDoc.setProcessed(true);
            } catch (Exception e) {
                addProcessingException(xmlDoc, 
                                       "Caught Exception loading xml data from " + 
                                       xmlDoc + 
                                       ".  Will move associated file to problem dir.", e);
                LOG.error("Caught Exception loading xml data from " + xmlDoc + 
                          ".  Will move associated file to problem dir.", e);

                if (e instanceof RuntimeException) {
                    throw (RuntimeException) e;
                } else if (e instanceof IOException) {
                    throw (IOException) e;
                }
            } finally {
                if (inputStream != null) {
                    try {
                        inputStream.close();
                    } catch (IOException ioe) {
                        LOG.warn("Error closing stream for xml doc: " + 
                                 xmlDoc, ioe);
                    }
                }
            }
        }
    }
}