
/*
 * Copyright (c) 2004, 2005, 2006 Trustees of Indiana University and Cornell University.
 *
 * Licensed under the Educational Community License Version 1.0 (the "License"); By obtaining,
 * using and/or copying this Original Work, you agree that you have read, understand, and will
 * comply with the terms and conditions of the Educational Community License.
 *
 * For the full text of the license, see the LICENSE.txt file or visit:
 * 
 * http://kew.indiana.edu/workflow/LICENSE.txt
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING
 * BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE
 * AND NONINFRINGEMENT.
 * IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES
 * OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 */
            
package edu.iu.uis.eden.batch;

import edu.iu.uis.eden.EdenConstants;
import edu.iu.uis.eden.SpringServiceLocator;
import edu.iu.uis.eden.applicationconstants.ApplicationConstant;
import edu.iu.uis.eden.applicationconstants.ApplicationConstantsService;
import edu.iu.uis.eden.routemanager.RouteQueueProcessor;
import edu.iu.uis.eden.routequeue.RouteQueue;
import edu.iu.uis.eden.routetemplate.RuleBaseValues;
import edu.iu.uis.eden.routetemplate.RuleService;

import java.sql.Timestamp;

import java.text.ParseException;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;


public class PopulateDeactivationDate implements RouteQueueProcessor {
    private static final org.apache.log4j.Logger LOG = 
            org.apache.log4j.Logger.getLogger(PopulateDeactivationDate.class);
    private RuleService ruleService;
    private Map nonCurrentRulesMap = new HashMap();
    private List nonCurrentRulesList = new ArrayList();
    private Timestamp startdate = null;
    private Timestamp date = null;

    public void process(RouteQueue routeQueue) throws Exception {
        LOG.info("Starting to populate deactivation date.");
        setup();
        populateDeactivationDate();

        ApplicationConstant constant = getApplicationConstantsService()
                                           .findByName("Config.Application.RunDeactivationDate");
        constant.setApplicationConstantValue("false");
        getApplicationConstantsService().save(constant);
        LOG.info("Finished populating deactivation date.");
    }

    private ApplicationConstantsService getApplicationConstantsService() {
        return (ApplicationConstantsService) SpringServiceLocator.getService(
                       SpringServiceLocator.APPLICATION_CONSTANTS_SRV);
    }

    private void setup() throws ParseException {
        ruleService = (RuleService) SpringServiceLocator.getService(
                              SpringServiceLocator.RULE_SERVICE);
        LOG.info("Attempting to retrieve all noncurrent rules");

        List nonCurrentRules = ruleService.fetchAllRules(false);
        LOG.info("Number of non current rules: " + nonCurrentRules.size());

        for (Iterator iter = nonCurrentRules.iterator(); iter.hasNext();) {
            RuleBaseValues rule = (RuleBaseValues) iter.next();
            nonCurrentRulesMap.put(rule.getRuleBaseValuesId(), rule);
        }

        date = new Timestamp(EdenConstants.getDefaultDateFormat()
                                          .parse("01/01/2100").getTime());
        startdate = new Timestamp(System.currentTimeMillis());
    }

    private void populateDeactivationDate() {
        LOG.info("Attempting to retrieve all current rules");

        List currentRules = ruleService.fetchAllRules(true);
        LOG.info("Number of current rules: " + currentRules.size());

        boolean save = false;

        for (Iterator iter = currentRules.iterator(); iter.hasNext();) {
            RuleBaseValues rule = (RuleBaseValues) iter.next();
            save = false;

            if (rule.getActivationDate() == null) {
                rule.setActivationDate(startdate);
                save = true;
            }

            if (rule.getDeactivationDate() == null) {
                rule.setDeactivationDate(date);
                save = true;
            }

            if (save) {
                try {
                    LOG.info("Attempting to save current rule: " + 
                             rule.getRuleBaseValuesId() + " description: " + 
                             rule.getDescription());
                    ruleService.saveDeactivationDate(rule);
                    LOG.info("Rule saved");
                } catch (Exception e) {
                    LOG.error("Error saving rule: " + 
                              rule.getRuleBaseValuesId() + " description: " + 
                              rule.getDescription(), e);
                }
            }

            if ((rule.getPreviousVersionId() != null) && 
                    (nonCurrentRulesMap.get(rule.getPreviousVersionId()) != null)) {
                updatePreviousVersion(rule.getActivationDate(), 
                                      (RuleBaseValues) nonCurrentRulesMap.get(
                                              rule.getPreviousVersionId()));
            }
        }

        Timestamp ruleLeftOverDate = null;

        for (Iterator iter = nonCurrentRulesMap.values().iterator();
             iter.hasNext();) {
            RuleBaseValues ruleLeftOver = (RuleBaseValues) iter.next();
            save = false;

            if ((ruleLeftOver.getActivationDate() == null) && 
                    !nonCurrentRulesList.contains(
                             ruleLeftOver.getRuleBaseValuesId())) {
                ruleLeftOver.setActivationDate(startdate);
                save = true;
            }

            if ((ruleLeftOver.getDeactivationDate() == null) && 
                    !nonCurrentRulesList.contains(
                             ruleLeftOver.getRuleBaseValuesId())) {
                ruleLeftOverDate = new Timestamp(ruleLeftOver.getActivationDate()
                                                             .getTime() + 
                                                 1000);
                ruleLeftOver.setDeactivationDate(ruleLeftOverDate);
                save = true;
            }

            if (save) {
                try {
                    LOG.info("Attempting to save left over rule: " + 
                             ruleLeftOver.getRuleBaseValuesId() + 
                             " description: " + 
                             ruleLeftOver.getDescription());
                    ruleService.saveDeactivationDate(ruleLeftOver);
                    LOG.info("Rule saved");
                } catch (Exception e) {
                    LOG.error("Error saving rule: " + 
                              ruleLeftOver.getRuleBaseValuesId() + 
                              " description: " + 
                              ruleLeftOver.getDescription(), e);
                }
            }

            if ((ruleLeftOver.getPreviousVersionId() != null) && 
                    (nonCurrentRulesMap.get(ruleLeftOver.getPreviousVersionId()) != null)) {
                updatePreviousVersion(ruleLeftOver.getActivationDate(), 
                                      (RuleBaseValues) nonCurrentRulesMap.get(
                                              ruleLeftOver.getPreviousVersionId()));
            }
        }
    }

    private void updatePreviousVersion(Timestamp deactivationDate, 
                                       RuleBaseValues previousRule) {
        boolean save = false;

        if ((previousRule.getActivationDate() == null) && 
                !nonCurrentRulesList.contains(
                         previousRule.getRuleBaseValuesId())) {
            previousRule.setActivationDate(startdate);
            save = true;
        }

        if ((previousRule.getDeactivationDate() == null) && 
                !nonCurrentRulesList.contains(
                         previousRule.getRuleBaseValuesId())) {
            previousRule.setDeactivationDate(deactivationDate);
            save = true;
        }

        if (save) {
            try {
                LOG.info("Attempting to save previous version rule: " + 
                         previousRule.getRuleBaseValuesId() + 
                         " description: " + previousRule.getDescription());
                ruleService.saveDeactivationDate(previousRule);
                LOG.info("Rule saved");
            } catch (Exception e) {
                LOG.error("Error saving rule: " + 
                          previousRule.getRuleBaseValuesId() + 
                          " description: " + previousRule.getDescription(), e);
            }
        }

        nonCurrentRulesList.add(previousRule.getRuleBaseValuesId());

        if ((previousRule.getPreviousVersionId() != null) && 
                (nonCurrentRulesMap.get(previousRule.getPreviousVersionId()) != null)) {
            updatePreviousVersion(previousRule.getActivationDate(), 
                                  (RuleBaseValues) nonCurrentRulesMap.get(
                                          previousRule.getPreviousVersionId()));
        }
    }
}