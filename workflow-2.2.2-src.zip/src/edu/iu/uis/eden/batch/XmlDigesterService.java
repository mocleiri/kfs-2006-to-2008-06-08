
/*
 * Copyright (c) 2004, 2005, 2006 Trustees of Indiana University and Cornell University.
 *
 * Licensed under the Educational Community License Version 1.0 (the "License"); By obtaining,
 * using and/or copying this Original Work, you agree that you have read, understand, and will
 * comply with the terms and conditions of the Educational Community License.
 *
 * For the full text of the license, see the LICENSE.txt file or visit:
 * 
 * http://kew.indiana.edu/workflow/LICENSE.txt
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING
 * BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE
 * AND NONINFRINGEMENT.
 * IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES
 * OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 */
            
package edu.iu.uis.eden.batch;

import edu.iu.uis.eden.XmlLoader;
import edu.iu.uis.eden.user.WorkflowUser;

import java.io.IOException;


/**
 * A service which is responsible for digesting (by delegating to other target services)
 * an xml document loaded at runtime. It exists so that we can apply Spring's automagical
 * transactioning.  Ordering of invocations with respect to service dependencies is the
 * caller's responsibility.
 * Pipeline:<br/>
 * <ol>
 *   <li>Acquisition: <code>XmlPollerService</code>, <i>Struts upload action</i></li>
 *   <li>Ingestion: XmlIngesterService</li>
 *   <li>Digestion: XmlDigesterService</li>
 * </ol>
 * @see edu.iu.uis.eden.batch.XmlIngesterService
 * @author Aaron Hamid (arh14 at cornell dot edu)
 */
public interface XmlDigesterService {
    /**
     * Digests an XmlDoc.  Workflow User is passed to XmlLoader and the content is routing in a document 
     * as that user if the loader supports it.  
     * 
     * @param xmlLoader
     * @param xmlDoc
     * @param user
     * @throws IOException
     */
    public void digest(XmlLoader xmlLoader, XmlDocCollection xmlDocCollection, 
                       WorkflowUser user) throws IOException;
}