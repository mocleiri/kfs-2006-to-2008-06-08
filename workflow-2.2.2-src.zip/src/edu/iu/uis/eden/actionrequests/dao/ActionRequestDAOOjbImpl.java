
/*
 * Copyright (c) 2004, 2005, 2006 Trustees of Indiana University and Cornell University.
 *
 * Licensed under the Educational Community License Version 1.0 (the "License"); By obtaining,
 * using and/or copying this Original Work, you agree that you have read, understand, and will
 * comply with the terms and conditions of the Educational Community License.
 *
 * For the full text of the license, see the LICENSE.txt file or visit:
 * 
 * http://kew.indiana.edu/workflow/LICENSE.txt
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING
 * BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE
 * AND NONINFRINGEMENT.
 * IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES
 * OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 */
            
package edu.iu.uis.eden.actionrequests.dao;

import edu.iu.uis.eden.EdenConstants;
import edu.iu.uis.eden.actionrequests.ActionRequestValue;
import edu.iu.uis.eden.workgroup.Workgroup;

import java.sql.Timestamp;

import java.util.Collection;
import java.util.Collections;
import java.util.List;

import org.apache.ojb.broker.query.Criteria;
import org.apache.ojb.broker.query.QueryByCriteria;

import org.springframework.orm.ojb.PersistenceBrokerTemplate;


public class ActionRequestDAOOjbImpl extends PersistenceBrokerTemplate
    implements ActionRequestDAO {
    public ActionRequestValue getActionRequestByActionRequestId(Long actionRequestId) {
        Criteria crit = new Criteria();
        crit.addEqualTo("actionRequestId", actionRequestId);

        return (ActionRequestValue) getObjectByQuery(
                       new QueryByCriteria(ActionRequestValue.class, crit));
    }

    public void saveActionRequest(ActionRequestValue actionRequest) {
        if (actionRequest.getActionRequestId() == null) {
            loadDefaultValues(actionRequest);
        }

        store(actionRequest);
    }

    public List findPendingByResponsibilityIds(Collection responsibilityIds) {
        if ((responsibilityIds == null) || (responsibilityIds.size() == 0)) {
            return Collections.EMPTY_LIST;
        }

        Criteria crit = new Criteria();
        Criteria statusCriteria = new Criteria();
        Criteria activatedCriteria = new Criteria();
        activatedCriteria.addEqualTo("status", 
                                     EdenConstants.ACTION_REQUEST_ACTIVATED);

        Criteria initializedCriteria = new Criteria();
        initializedCriteria.addEqualTo("status", 
                                       EdenConstants.ACTION_REQUEST_INITIALIZED);

        statusCriteria.addOrCriteria(activatedCriteria);
        statusCriteria.addOrCriteria(initializedCriteria);
        crit.addAndCriteria(statusCriteria);
        crit.addIn("responsibilityId", responsibilityIds);

        return (List) getCollectionByQuery(
                       new QueryByCriteria(ActionRequestValue.class, crit));
    }

    public List findPendingByActionRequestedAndDocId(String actionRequestedCd, 
                                                     Long routeHeaderId) {
        Criteria crit = new Criteria();
        crit.addEqualTo("actionRequested", actionRequestedCd);
        crit.addEqualTo("routeHeaderId", routeHeaderId);
        crit.addEqualTo("currentIndicator", Boolean.TRUE);
        crit.addAndCriteria(getPendingCriteria());

        return (List) getCollectionByQuery(
                       new QueryByCriteria(ActionRequestValue.class, crit));
    }

    public List findByStatusAndDocId(String statusCd, Long routeHeaderId) {
        Criteria crit = new Criteria();
        crit.addEqualTo("status", statusCd);
        crit.addEqualTo("routeHeaderId", routeHeaderId);
        crit.addEqualTo("currentIndicator", new Boolean(true));

        return (List) getCollectionByQuery(
                       new QueryByCriteria(ActionRequestValue.class, crit));
    }

    private void loadDefaultValues(ActionRequestValue actionRequest) {
        checkNull(actionRequest.getActionRequested(), "action requested");
        checkNull(actionRequest.getResponsibilityId(), "responsibility ID");
        checkNull(actionRequest.getRouteLevel(), "route level");
        checkNull(actionRequest.getDocVersion(), "doc version");

        if (actionRequest.getIgnorePrevAction() == null) {
            actionRequest.setIgnorePrevAction(Boolean.FALSE);
        }

        if (actionRequest.getStatus() == null) {
            actionRequest.setStatus(EdenConstants.ACTION_REQUEST_INITIALIZED);
        }

        if (actionRequest.getPriority() == null) {
            actionRequest.setPriority(
                    new Integer(EdenConstants.ACTION_REQUEST_DEFAULT_PRIORITY));
        }

        if (actionRequest.getCurrentIndicator() == null) {
            actionRequest.setCurrentIndicator(new Boolean(true));
        }

        actionRequest.setCreateDate(new Timestamp(System.currentTimeMillis()));
    }

    //TODO Runtime might not be the right thing to do here...
    private void checkNull(Object value, String valueName)
                    throws RuntimeException {
        if (value == null) {
            throw new RuntimeException("Null value for " + valueName);
        }
    }

    public List findPendingRootRequestsByDocIdAtRouteLevel(Long routeHeaderId, 
                                                           Integer routeLevel) {
        Criteria crit = new Criteria();
        crit.addEqualTo("routeLevel", routeLevel);
        crit.addNotEqualTo("status", EdenConstants.ACTION_REQUEST_DONE_STATE);
        crit.addEqualTo("routeHeaderId", routeHeaderId);
        crit.addEqualTo("currentIndicator", Boolean.TRUE);
        crit.addIsNull("parentActionRequest");

        return (List) getCollectionByQuery(
                       new QueryByCriteria(ActionRequestValue.class, crit));
    }

    public List findPendingByDocIdAtOrBelowRouteLevel(Long routeHeaderId, 
                                                      Integer routeLevel) {
        Criteria crit = new Criteria();
        crit.addLessOrEqualThan("routeLevel", routeLevel);
        crit.addNotEqualTo("status", EdenConstants.ACTION_REQUEST_DONE_STATE);
        crit.addEqualTo("routeHeaderId", routeHeaderId);
        crit.addEqualTo("currentIndicator", new Boolean(true));

        return (List) getCollectionByQuery(
                       new QueryByCriteria(ActionRequestValue.class, crit));
    }

    public List findPendingRootRequestsByDocIdAtOrBelowRouteLevel(Long routeHeaderId, 
                                                                  Integer routeLevel) {
        Criteria crit = new Criteria();
        crit.addLessOrEqualThan("routeLevel", routeLevel);
        crit.addNotEqualTo("status", EdenConstants.ACTION_REQUEST_DONE_STATE);
        crit.addEqualTo("routeHeaderId", routeHeaderId);
        crit.addEqualTo("currentIndicator", new Boolean(true));
        crit.addIsNull("parentActionRequest");

        return (List) getCollectionByQuery(
                       new QueryByCriteria(ActionRequestValue.class, crit));
    }

    public void delete(Long actionRequestId) {
        Criteria crit = new Criteria();
        crit.addEqualTo("actionRequestId", actionRequestId);
        deleteByQuery(new QueryByCriteria(ActionRequestValue.class, crit));
    }

    public List findAllPendingByDocId(Long routeHeaderId) {
        Criteria initializedStatCriteria = new Criteria();
        initializedStatCriteria.addEqualTo("status", 
                                           EdenConstants.ACTION_REQUEST_INITIALIZED);

        Criteria activatedStatCriteria = new Criteria();
        activatedStatCriteria.addEqualTo("status", 
                                         EdenConstants.ACTION_REQUEST_ACTIVATED);

        Criteria statusCriteria = new Criteria();
        statusCriteria.addOrCriteria(initializedStatCriteria);
        statusCriteria.addOrCriteria(activatedStatCriteria);

        Criteria crit = new Criteria();
        crit.addEqualTo("routeHeaderId", routeHeaderId);
        crit.addEqualTo("currentIndicator", new Boolean(true));
        crit.addAndCriteria(statusCriteria);

        return (List) getCollectionByQuery(
                       new QueryByCriteria(ActionRequestValue.class, crit));
    }

    public List findAllByDocId(Long routeHeaderId) {
        Criteria crit = new Criteria();
        crit.addEqualTo("routeHeaderId", routeHeaderId);
        crit.addEqualTo("currentIndicator", new Boolean(true));

        return (List) getCollectionByQuery(
                       new QueryByCriteria(ActionRequestValue.class, crit));
    }

    public List findAllRootByDocId(Long routeHeaderId) {
        Criteria crit = new Criteria();
        crit.addEqualTo("routeHeaderId", routeHeaderId);
        crit.addEqualTo("currentIndicator", new Boolean(true));
        crit.addIsNull("parentActionRequest");

        return (List) getCollectionByQuery(
                       new QueryByCriteria(ActionRequestValue.class, crit));
    }

    public List findByRouteHeaderIdIgnoreCurrentInd(Long routeHeaderId) {
        Criteria crit = new Criteria();
        crit.addEqualTo("routeHeaderId", routeHeaderId);

        return (List) getCollectionByQuery(
                       new QueryByCriteria(ActionRequestValue.class, crit));
    }

    public List findActivatedByWorkgroup(Workgroup workgroup) {
        Criteria statusCriteria = new Criteria();
        statusCriteria.addEqualTo("status", 
                                  EdenConstants.ACTION_REQUEST_ACTIVATED);

        Criteria crit = new Criteria();
        crit.addEqualTo("workgroupId", 
                        workgroup.getWorkflowGroupId().getGroupId());
        crit.addEqualTo("currentIndicator", new Boolean(true));
        crit.addAndCriteria(statusCriteria);

        return (List) getCollectionByQuery(
                       new QueryByCriteria(ActionRequestValue.class, crit));
    }

    private Criteria getPendingCriteria() {
        Criteria pendingCriteria = new Criteria();
        Criteria activatedCriteria = new Criteria();
        activatedCriteria.addEqualTo("status", 
                                     EdenConstants.ACTION_REQUEST_ACTIVATED);

        Criteria initializedCriteria = new Criteria();
        initializedCriteria.addEqualTo("status", 
                                       EdenConstants.ACTION_REQUEST_INITIALIZED);
        pendingCriteria.addOrCriteria(activatedCriteria);
        pendingCriteria.addOrCriteria(initializedCriteria);

        return pendingCriteria;
    }

    public void deleteByRouteHeaderId(Long routeHeaderId) {
        Criteria crit = new Criteria();
        crit.addEqualTo("routeHeaderId", routeHeaderId);
        deleteByQuery(new QueryByCriteria(ActionRequestValue.class, crit));
    }

    public List findPendingRootRequestsByDocumentType(Long documentTypeId) {
        Criteria crit = new Criteria();
        crit.addEqualTo("routeHeader.documentTypeId", documentTypeId);
        crit.addAndCriteria(getPendingCriteria());
        crit.addEqualTo("currentIndicator", Boolean.TRUE);
        crit.addIsNull("parentActionRequest");

        return (List) getCollectionByQuery(
                       new QueryByCriteria(ActionRequestValue.class, crit));
    }

    public List findPendingRootRequestsByDocIdAtRouteNode(Long routeHeaderId, 
                                                          Long nodeInstanceId) {
        Criteria crit = new Criteria();
        crit.addEqualTo("routeHeaderId", routeHeaderId);
        crit.addAndCriteria(getPendingCriteria());
        crit.addEqualTo("currentIndicator", Boolean.TRUE);
        crit.addIsNull("parentActionRequest");
        crit.addEqualTo("nodeInstance.routeNodeInstanceId", nodeInstanceId);

        return (List) getCollectionByQuery(
                       new QueryByCriteria(ActionRequestValue.class, crit));
    }

    public List findRootRequestsByDocIdAtRouteNode(Long documentId, 
                                                   Long nodeInstanceId) {
        Criteria crit = new Criteria();
        crit.addEqualTo("routeHeaderId", documentId);
        crit.addEqualTo("currentIndicator", Boolean.TRUE);
        crit.addIsNull("parentActionRequest");
        crit.addEqualTo("nodeInstance.routeNodeInstanceId", nodeInstanceId);

        return (List) getCollectionByQuery(
                       new QueryByCriteria(ActionRequestValue.class, crit));
    }

    /*public List findFutureAdHocRequestsByDocIdAtRouteNode(Long documentId, String nodeName) {
        Criteria crit = new Criteria();
        crit.addEqualTo("routeHeaderId", documentId);
        crit.addEqualTo("currentIndicator", Boolean.TRUE);
        crit.addIsNull("parentActionRequest");
        crit.addIsNull("nodeInstance");
        crit.addEqualTo("routeMethodName", SpringServiceLocator.getAdHocRequestsService().constructFutureAdHocRouteMethodName(nodeName));
        return (List) getCollectionByQuery(new QueryByCriteria(ActionRequestValue.class, crit));
    }*/
}