
/*
 * Copyright (c) 2004, 2005, 2006 Trustees of Indiana University and Cornell University.
 *
 * Licensed under the Educational Community License Version 1.0 (the "License"); By obtaining,
 * using and/or copying this Original Work, you agree that you have read, understand, and will
 * comply with the terms and conditions of the Educational Community License.
 *
 * For the full text of the license, see the LICENSE.txt file or visit:
 * 
 * http://kew.indiana.edu/workflow/LICENSE.txt
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING
 * BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE
 * AND NONINFRINGEMENT.
 * IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES
 * OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 */
            
package edu.iu.uis.eden.actionrequests;

import edu.iu.uis.eden.actiontaken.ActionTakenValue;
import edu.iu.uis.eden.engine.node.RouteNodeInstance;
import edu.iu.uis.eden.exception.EdenUserNotFoundException;
import edu.iu.uis.eden.routeheader.DocumentRouteHeaderValue;
import edu.iu.uis.eden.user.Recipient;
import edu.iu.uis.eden.user.WorkflowUser;
import edu.iu.uis.eden.workgroup.Workgroup;

import java.util.Collection;
import java.util.List;
import java.util.Set;


public interface ActionRequestService {
    public ActionRequestValue initializeActionRequestGraph(ActionRequestValue actionRequest, 
                                                           DocumentRouteHeaderValue document, 
                                                           RouteNodeInstance nodeInstance);

    public void deactivateRequest(ActionTakenValue actionTaken, 
                                  ActionRequestValue actionRequest);

    public void deactivateRequests(ActionTakenValue actionTaken, 
                                   List actionRequests);

    public void deactivateRequest(ActionTakenValue actionTaken, 
                                  ActionRequestValue actionRequest, 
                                  boolean simulate);

    public void deactivateRequests(ActionTakenValue actionTaken, 
                                   List actionRequests, boolean simulate);

    public void deleteActionRequestGraph(ActionRequestValue actionRequest);

    public List findAllValidRequests(WorkflowUser user, Long routeHeaderId, 
                                     String requestCode)
                              throws EdenUserNotFoundException;

    public List findAllValidRequests(WorkflowUser user, 
                                     Collection actionRequests, 
                                     String requestCode)
                              throws EdenUserNotFoundException;

    public List findPendingByDoc(Long routeHeaderId);

    public void saveActionRequest(ActionRequestValue actionRequest)
                           throws EdenUserNotFoundException;

    public void activateRequest(ActionRequestValue actionRequest)
                         throws EdenUserNotFoundException;

    public void activateRequests(Collection actionRequests)
                          throws EdenUserNotFoundException;

    public void activateRequest(ActionRequestValue actionRequest, 
                                boolean simulate)
                         throws EdenUserNotFoundException;

    public void activateRequests(Collection actionRequests, boolean simulate)
                          throws EdenUserNotFoundException;

    public List activateRequestNoNotification(ActionRequestValue actionRequest, 
                                              boolean simulate)
                                       throws EdenUserNotFoundException;

    public ActionRequestValue findByActionRequestId(Long actionRequestId);

    public List findPendingRootRequestsByDocId(Long routeHeaderId);

    public List findPendingRootRequestsByDocIdAtRouteLevel(Long routeHeaderId, 
                                                           Integer routeLevel);

    public List findPendingByDocIdAtOrBelowRouteLevel(Long routeHeaderId, 
                                                      Integer routeLevel);

    public List findPendingRootRequestsByDocIdAtOrBelowRouteLevel(Long routeHeaderId, 
                                                                  Integer routeLevel);

    public List findPendingRootRequestsByDocumentType(Long documentTypeId);

    public List findAllActionRequestsByRouteHeaderId(Long routeHeaderId);

    public List findPendingByActionRequestedAndDocId(String actionRequestedCdCd, 
                                                     Long routeHeaderId);

    public List findByStatusAndDocId(String statusCd, Long routeHeaderId);

    public void alterActionRequested(List actionRequests, 
                                     String actionRequestCd)
                              throws EdenUserNotFoundException;

    public List findByRouteHeaderIdIgnoreCurrentInd(Long routeHeaderId);

    public List findActivatedByWorkgroup(Workgroup workgroup);

    public void updateActionRequestsForResponsibilityChange(Set responsibilityIds);

    public ActionRequestValue getRoot(ActionRequestValue actionRequest);

    public List getRootRequests(Collection actionRequests);

    public boolean isDuplicateRequest(ActionRequestValue actionRequest);

    public List findPendingByDocRequestCdRouteLevel(Long routeHeaderId, 
                                                    String requestCode, 
                                                    Integer routeLevel);

    public List findPendingByDocRequestCdNodeName(Long routeHeaderId, 
                                                  String requestCode, 
                                                  String nodeName);

    /**
     * Returns the highest priority delegator in the list of action requests.
     */
    public Recipient findDelegator(List actionRequests)
                            throws EdenUserNotFoundException;

    /**
     * Returns the closest delegator for the given ActionRequest
     */
    public Recipient findDelegator(ActionRequestValue actionRequest)
                            throws EdenUserNotFoundException;

    public ActionRequestValue findDelegatorRequest(ActionRequestValue actionRequest);

    public void deleteByRouteHeaderId(Long routeHeaderId);

    public void deleteByActionRequestId(Long actionRequestId);

    public void validateActionRequest(ActionRequestValue actionRequest);

    public List findPendingRootRequestsByDocIdAtRouteNode(Long routeHeaderId, 
                                                          Long nodeInstanceId);

    public List findRootRequestsByDocIdAtRouteNode(Long documentId, 
                                                   Long nodeInstanceId);

    public List getDelegateRequests(ActionRequestValue actionRequest);

    /**
     * If this is a role request, then this method returns a List of the action request for each recipient within the
     * role.  Otherwise, it will return a List with just the original action request.
     */
    public List getTopLevelRequests(ActionRequestValue actionRequest);

    public boolean isValidActionRequestCode(String actionRequestCode);
}