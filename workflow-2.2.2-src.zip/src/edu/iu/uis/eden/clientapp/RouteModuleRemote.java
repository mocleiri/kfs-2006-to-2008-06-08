
/*
 * Copyright (c) 2004, 2005, 2006 Trustees of Indiana University and Cornell University.
 *
 * Licensed under the Educational Community License Version 1.0 (the "License"); By obtaining,
 * using and/or copying this Original Work, you agree that you have read, understand, and will
 * comply with the terms and conditions of the Educational Community License.
 *
 * For the full text of the license, see the LICENSE.txt file or visit:
 * 
 * http://kew.indiana.edu/workflow/LICENSE.txt
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING
 * BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE
 * AND NONINFRINGEMENT.
 * IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES
 * OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 */
            
package edu.iu.uis.eden.clientapp;

import edu.iu.uis.eden.clientapp.vo.ActionRequestVO;
import edu.iu.uis.eden.clientapp.vo.ResponsiblePartyVO;
import edu.iu.uis.eden.clientapp.vo.RouteHeaderVO;

import java.rmi.RemoteException;


/**
 * A RouteModule is responsible for generating Action Requests for a given Route Header document.
 * Implementations of this Interface are potentially remotable, so this Interface uses value objects.
 */
public interface RouteModuleRemote {
    /**
     * Generate action requests for the given RouteHeaderVO.
     *
     * @return ActionRequestVO[] the generated action requests
     * @throws EdenException
     */
    public ActionRequestVO[] findActionRequests(RouteHeaderVO routeHeader)
                                         throws RemoteException;

    /**
     * The route module will resolve the given responsibilityId and return an object that contains the key to
     * either a user or a Eden workgroup.
     * @param rId ResponsibiliyId that we need resolved.
     * @return The ResponsibleParty containing a key to a user or workgroup.
     * @throws EdenException if any problems are found this exception can be thrown.
     */
    public ResponsiblePartyVO resolveResponsibilityId(Long responsibilityId)
                                               throws RemoteException;
}