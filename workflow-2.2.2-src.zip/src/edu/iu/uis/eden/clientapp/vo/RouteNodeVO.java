
/*
 * Copyright (c) 2004, 2005, 2006 Trustees of Indiana University and Cornell University.
 *
 * Licensed under the Educational Community License Version 1.0 (the "License"); By obtaining,
 * using and/or copying this Original Work, you agree that you have read, understand, and will
 * comply with the terms and conditions of the Educational Community License.
 *
 * For the full text of the license, see the LICENSE.txt file or visit:
 * 
 * http://kew.indiana.edu/workflow/LICENSE.txt
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING
 * BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE
 * AND NONINFRINGEMENT.
 * IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES
 * OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 */
            
package edu.iu.uis.eden.clientapp.vo;

/**
 * @workflow.webservice-object
 */
public class RouteNodeVO implements java.io.Serializable, Cloneable {
    private static final long serialVersionUID = 6547166752590755847L;
    private Long routeNodeId;
    private Long documentTypeId;
    private String routeNodeName;
    private String routeMethodName;
    private String routeMethodCode;
    private boolean finalApprovalInd;
    private boolean mandatoryRouteInd;
    private String activationType;
    private WorkgroupVO exceptionWorkgroup;
    private String nodeType;
    private String branchName;
    private Long[] previousNodeIds = new Long[0];
    private Long[] nextNodeIds = new Long[0];

    public RouteNodeVO() {
    }

    public String getActivationType() {
        return activationType;
    }

    public void setActivationType(String activationType) {
        this.activationType = activationType;
    }

    public String getBranchName() {
        return branchName;
    }

    public void setBranchName(String branchName) {
        this.branchName = branchName;
    }

    public Long getDocumentTypeId() {
        return documentTypeId;
    }

    public void setDocumentTypeId(Long documentTypeId) {
        this.documentTypeId = documentTypeId;
    }

    public WorkgroupVO getExceptionWorkgroup() {
        return exceptionWorkgroup;
    }

    public void setExceptionWorkgroup(WorkgroupVO exceptionWorkgroup) {
        this.exceptionWorkgroup = exceptionWorkgroup;
    }

    public boolean isFinalApprovalInd() {
        return finalApprovalInd;
    }

    public void setFinalApprovalInd(boolean finalApprovalInd) {
        this.finalApprovalInd = finalApprovalInd;
    }

    public boolean isMandatoryRouteInd() {
        return mandatoryRouteInd;
    }

    public void setMandatoryRouteInd(boolean mandatoryRouteInd) {
        this.mandatoryRouteInd = mandatoryRouteInd;
    }

    public Long[] getNextNodeIds() {
        return nextNodeIds;
    }

    public void setNextNodeIds(Long[] nextNodeIds) {
        this.nextNodeIds = nextNodeIds;
    }

    public String getNodeType() {
        return nodeType;
    }

    public void setNodeType(String nodeType) {
        this.nodeType = nodeType;
    }

    public Long[] getPreviousNodeIds() {
        return previousNodeIds;
    }

    public void setPreviousNodeIds(Long[] previousNodeIds) {
        this.previousNodeIds = previousNodeIds;
    }

    public String getRouteMethodCode() {
        return routeMethodCode;
    }

    public void setRouteMethodCode(String routeMethodCode) {
        this.routeMethodCode = routeMethodCode;
    }

    public String getRouteMethodName() {
        return routeMethodName;
    }

    public void setRouteMethodName(String routeMethodName) {
        this.routeMethodName = routeMethodName;
    }

    public Long getRouteNodeId() {
        return routeNodeId;
    }

    public void setRouteNodeId(Long routeNodeId) {
        this.routeNodeId = routeNodeId;
    }

    public String getRouteNodeName() {
        return routeNodeName;
    }

    public void setRouteNodeName(String routeNodeName) {
        this.routeNodeName = routeNodeName;
    }
}