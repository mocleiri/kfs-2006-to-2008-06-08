
/*
 * Copyright (c) 2004, 2005, 2006 Trustees of Indiana University and Cornell University.
 *
 * Licensed under the Educational Community License Version 1.0 (the "License"); By obtaining,
 * using and/or copying this Original Work, you agree that you have read, understand, and will
 * comply with the terms and conditions of the Educational Community License.
 *
 * For the full text of the license, see the LICENSE.txt file or visit:
 * 
 * http://kew.indiana.edu/workflow/LICENSE.txt
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING
 * BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE
 * AND NONINFRINGEMENT.
 * IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES
 * OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 */
            
package edu.iu.uis.eden.clientapp.vo;

import java.io.Serializable;


/**
 * @workflow.webservice-object
 */
public class RouteNodeInstanceVO implements Serializable {
    private static final long serialVersionUID = -5456548621231617447L;
    private Long routeNodeInstanceId;
    private Long documentId;
    private Long branchId;
    private Long routeNodeId;
    private Long processId;
    private String name;
    private boolean active;
    private boolean complete;
    private boolean initial;
    private StateVO[] state = new StateVO[0];
    private RouteNodeInstanceVO[] nextNodes = new RouteNodeInstanceVO[0];

    public boolean isActive() {
        return active;
    }

    public void setActive(boolean active) {
        this.active = active;
    }

    public Long getBranchId() {
        return branchId;
    }

    public void setBranchId(Long branchId) {
        this.branchId = branchId;
    }

    public boolean isComplete() {
        return complete;
    }

    public void setComplete(boolean complete) {
        this.complete = complete;
    }

    public Long getDocumentId() {
        return documentId;
    }

    public void setDocumentId(Long documentId) {
        this.documentId = documentId;
    }

    public boolean isInitial() {
        return initial;
    }

    public void setInitial(boolean initial) {
        this.initial = initial;
    }

    public Long getProcessId() {
        return processId;
    }

    public void setProcessId(Long processId) {
        this.processId = processId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Long getRouteNodeId() {
        return routeNodeId;
    }

    public void setRouteNodeId(Long routeNodeId) {
        this.routeNodeId = routeNodeId;
    }

    public Long getRouteNodeInstanceId() {
        return routeNodeInstanceId;
    }

    public void setRouteNodeInstanceId(Long routeNodeInstanceId) {
        this.routeNodeInstanceId = routeNodeInstanceId;
    }

    public StateVO[] getState() {
        return state;
    }

    public void setState(StateVO[] state) {
        this.state = state;
    }

    public StateVO getState(String key) {
        for (int index = 0; index < getState().length; index++) {
            StateVO nodeState = (StateVO) getState()[index];

            if (nodeState.getKey().equals(key)) {
                return nodeState;
            }
        }

        return null;
    }

    public RouteNodeInstanceVO[] getNextNodes() {
        return nextNodes;
    }

    public void setNextNodes(RouteNodeInstanceVO[] nextNodes) {
        this.nextNodes = nextNodes;
    }
}