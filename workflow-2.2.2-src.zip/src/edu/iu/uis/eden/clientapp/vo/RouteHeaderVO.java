
/*
 * Copyright (c) 2004, 2005, 2006 Trustees of Indiana University and Cornell University.
 *
 * Licensed under the Educational Community License Version 1.0 (the "License"); By obtaining,
 * using and/or copying this Original Work, you agree that you have read, understand, and will
 * comply with the terms and conditions of the Educational Community License.
 *
 * For the full text of the license, see the LICENSE.txt file or visit:
 * 
 * http://kew.indiana.edu/workflow/LICENSE.txt
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING
 * BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE
 * AND NONINFRINGEMENT.
 * IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES
 * OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 */
            
package edu.iu.uis.eden.clientapp.vo;

import edu.iu.uis.eden.clientapp.WorkflowInfo;
import edu.iu.uis.eden.exception.WorkflowException;
import edu.iu.uis.eden.exception.WorkflowRuntimeException;

import java.io.Serializable;

import java.util.Calendar;


/**
 * @workflow.webservice-object
 */
public class RouteHeaderVO implements Serializable {
    static final long serialVersionUID = -677289794727007572L;
    private Long routeHeaderId;
    private String docRouteStatus;
    private Calendar dateCreated;
    private Calendar dateLastModified;
    private Calendar dateApproved;
    private Calendar dateFinalized;

    //private String docContent; 
    private String docTitle;
    private String appDocId;
    private String overrideInd;
    private UserVO initiator;
    private Integer docRouteLevel;

    //private String[] nodeNames;
    private Integer docVersion;

    /**
     * @deprecated this is unreliable user docTypeId to retrieve document type
     */
    private String docTypeName;
    private String documentUrl;
    private boolean fyiRequested;
    private boolean ackRequested;
    private boolean approveRequested;
    private boolean completeRequested;
    private boolean userBlanketApprover;
    private Long docTypeId;
    private DocumentContentVO documentContent = new DocumentContentVO();

    //** Modify for adding notes to web service. Modify Date: April 7, 2006
    private NoteVO[] notes = null;
    private NoteVO[] notesToDelete = null;

    //** Modify ends
    public RouteHeaderVO() {
    }

    public String getAppDocId() {
        return appDocId;
    }

    public void setAppDocId(String appDocId) {
        this.appDocId = appDocId;
    }

    public Calendar getDateApproved() {
        return dateApproved;
    }

    public void setDateApproved(Calendar dateApproved) {
        this.dateApproved = dateApproved;
    }

    public Calendar getDateCreated() {
        return dateCreated;
    }

    public void setDateCreated(Calendar dateCreated) {
        this.dateCreated = dateCreated;
    }

    public Calendar getDateFinalized() {
        return dateFinalized;
    }

    public void setDateFinalized(Calendar dateFinalized) {
        this.dateFinalized = dateFinalized;
    }

    public Calendar getDateLastModified() {
        return dateLastModified;
    }

    public void setDateLastModified(Calendar dateLastModified) {
        this.dateLastModified = dateLastModified;
    }

    /*public String getDocContent() {
        return docContent;
    }
    
    public void setDocContent(String docContent) {
        this.docContent = docContent;
    }*/
    /*public String[] getNodeNames() {
    return nodeNames;
    }
    
    public void setNodeNames(String[] nodeNames) {
    this.nodeNames = nodeNames;
    }*/
    public Integer getDocRouteLevel() {
        return docRouteLevel;
    }

    public void setDocRouteLevel(Integer docRouteLevel) {
        this.docRouteLevel = docRouteLevel;
    }

    public String getDocRouteStatus() {
        return docRouteStatus;
    }

    public void setDocRouteStatus(String docRouteStatus) {
        this.docRouteStatus = docRouteStatus;
    }

    public String getDocTitle() {
        return docTitle;
    }

    public void setDocTitle(String docTitle) {
        this.docTitle = docTitle;
    }

    /**
     * @deprecated this is unreliable user docTypeId to retrieve document type
     */
    public String getDocTypeName() {
        return docTypeName;
    }

    /**
     * @deprecated this is unreliable user docTypeId to retrieve document type
     */
    public void setDocTypeName(String docTypeName) {
        this.docTypeName = docTypeName;
    }

    public String getDocumentUrl() {
        return documentUrl;
    }

    public void setDocumentUrl(String documentUrl) {
        this.documentUrl = documentUrl;
    }

    public Integer getDocVersion() {
        return docVersion;
    }

    public void setDocVersion(Integer docVersion) {
        this.docVersion = docVersion;
    }

    public UserVO getInitiator() {
        return initiator;
    }

    public void setInitiator(UserVO initiator) {
        this.initiator = initiator;
    }

    public String getOverrideInd() {
        return overrideInd;
    }

    public void setOverrideInd(String overrideInd) {
        this.overrideInd = overrideInd;
    }

    public Long getRouteHeaderId() {
        return routeHeaderId;
    }

    public void setRouteHeaderId(Long routeHeaderId) {
        this.routeHeaderId = routeHeaderId;
    }

    public boolean isAckRequested() {
        return ackRequested;
    }

    public void setAckRequested(boolean ackRequested) {
        this.ackRequested = ackRequested;
    }

    public boolean isApproveRequested() {
        return approveRequested;
    }

    public void setApproveRequested(boolean approveRequested) {
        this.approveRequested = approveRequested;
    }

    public boolean isCompleteRequested() {
        return completeRequested;
    }

    public void setCompleteRequested(boolean completeRequested) {
        this.completeRequested = completeRequested;
    }

    public boolean isFyiRequested() {
        return fyiRequested;
    }

    public void setFyiRequested(boolean fyiRequested) {
        this.fyiRequested = fyiRequested;
    }

    public boolean isUserBlanketApprover() {
        return userBlanketApprover;
    }

    public void setUserBlanketApprover(boolean userBlanketApprover) {
        this.userBlanketApprover = userBlanketApprover;
    }

    public DocumentContentVO getDocumentContent() {
        //if (getRouteHeaderId() != null && !isSerializing() && isDocumentContentEmpty(documentContent)) {
        //	materializeDocumentContent();
        //}
        return documentContent;
    }

    /*private boolean isSerializing() {
            return WorkflowBeanSerializer.isSerializing();
    }
        
    private boolean isDocumentContentEmpty(DocumentContentVO documentContent) {
            return documentContent == null || (documentContent.getApplicationContent() == null &&
                            documentContent.getAttributeContent() == null &&
                            documentContent.getSearchableContent() == null);
    }*/
    public void setDocumentContent(DocumentContentVO documentContent) {
        this.documentContent = documentContent;
    }

    public Long getDocTypeId() {
        return docTypeId;
    }

    public void setDocTypeId(Long docTypeId) {
        this.docTypeId = docTypeId;
    }

    //  ** Modify for adding notes to web service. Modify Date: April 7, 2006
    public NoteVO[] getNotes() {
        return notes;
    }

    public void setNotes(NoteVO[] notes) {
        this.notes = notes;
    }

    public NoteVO[] getNotesToDelete() {
        return notesToDelete;
    }

    public void setNotesToDelete(NoteVO[] notesToDelete) {
        this.notesToDelete = notesToDelete;
    }

    // ** Modify Ends
    private void materializeDocumentContent() {
        try {
            this.documentContent = new WorkflowInfo().getDocumentContent(
                                           getRouteHeaderId());
        } catch (WorkflowException e) {
            throw new WorkflowRuntimeException(
                    "Failed to materialize document content.", e);
        }
    }
}