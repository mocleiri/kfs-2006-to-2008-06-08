
/*
 * Copyright (c) 2004, 2005, 2006 Trustees of Indiana University and Cornell University.
 *
 * Licensed under the Educational Community License Version 1.0 (the "License"); By obtaining,
 * using and/or copying this Original Work, you agree that you have read, understand, and will
 * comply with the terms and conditions of the Educational Community License.
 *
 * For the full text of the license, see the LICENSE.txt file or visit:
 * 
 * http://kew.indiana.edu/workflow/LICENSE.txt
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING
 * BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE
 * AND NONINFRINGEMENT.
 * IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES
 * OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 */
            
package edu.iu.uis.eden.clientapp.vo;

public class DocumentRouteLevelChangeVO extends DocumentEventVO {
    private static final long serialVersionUID = 6822976938764899168L;
    private Integer oldRouteLevel;
    private Integer newRouteLevel;
    private String oldNodeName;
    private String newNodeName;
    private Long oldNodeInstanceId;
    private Long newNodeInstanceId;

    public DocumentRouteLevelChangeVO() {
        super(ROUTE_LEVEL_CHANGE);
    }

    public Integer getNewRouteLevel() {
        return newRouteLevel;
    }

    public void setNewRouteLevel(Integer newRouteLevel) {
        this.newRouteLevel = newRouteLevel;
    }

    public Integer getOldRouteLevel() {
        return oldRouteLevel;
    }

    public void setOldRouteLevel(Integer oldRouteLevel) {
        this.oldRouteLevel = oldRouteLevel;
    }

    public Long getNewNodeInstanceId() {
        return newNodeInstanceId;
    }

    public void setNewNodeInstanceId(Long newNodeInstanceId) {
        this.newNodeInstanceId = newNodeInstanceId;
    }

    public String getNewNodeName() {
        return newNodeName;
    }

    public void setNewNodeName(String newNodeName) {
        this.newNodeName = newNodeName;
    }

    public Long getOldNodeInstanceId() {
        return oldNodeInstanceId;
    }

    public void setOldNodeInstanceId(Long oldNodeInstanceId) {
        this.oldNodeInstanceId = oldNodeInstanceId;
    }

    public String getOldNodeName() {
        return oldNodeName;
    }

    public void setOldNodeName(String oldNodeName) {
        this.oldNodeName = oldNodeName;
    }

    public String toString() {
        StringBuffer buffer = new StringBuffer();
        buffer.append("RouteHeaderID ").append(getRouteHeaderId());
        buffer.append(" changing from routeLevel ").append(oldRouteLevel);
        buffer.append(" to routeLevel ").append(newRouteLevel);
        buffer.append(", from node ").append(oldNodeName);
        buffer.append(" to node ").append(newNodeName);

        return buffer.toString();
    }
}