
/*
 * Copyright (c) 2004, 2005, 2006 Trustees of Indiana University and Cornell University.
 *
 * Licensed under the Educational Community License Version 1.0 (the "License"); By obtaining,
 * using and/or copying this Original Work, you agree that you have read, understand, and will
 * comply with the terms and conditions of the Educational Community License.
 *
 * For the full text of the license, see the LICENSE.txt file or visit:
 * 
 * http://kew.indiana.edu/workflow/LICENSE.txt
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING
 * BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE
 * AND NONINFRINGEMENT.
 * IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES
 * OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 */
            
package edu.iu.uis.eden.clientapp.vo;

import edu.iu.uis.eden.EdenConstants;
import edu.iu.uis.eden.clientapp.WorkflowInfo;
import edu.iu.uis.eden.clientapp.webservices.WorkflowBeanSerializer;
import edu.iu.uis.eden.exception.WorkflowException;
import edu.iu.uis.eden.exception.WorkflowRuntimeException;
import edu.iu.uis.eden.util.Utilities;

import java.io.Serializable;

import java.util.ArrayList;
import java.util.List;


/**
 * @workflow.webservice-object
 */
public class DocumentContentVO implements Serializable {
    private static final long serialVersionUID = -1008441110733007106L;
    private static final WorkflowAttributeDefinitionVO[] ARRAY_TYPE = 
            new WorkflowAttributeDefinitionVO[0];
    private String attributeContent = null;
    private String applicationContent = null;
    private String searchableContent = null;
    private List attributeDefinitions = new ArrayList();
    private List searchableDefinitions = new ArrayList();
    private Long routeHeaderId;
    private boolean autoMaterialize = true;

    public DocumentContentVO() {
    }

    public String getApplicationContent() {
        materialize();

        return applicationContent;
    }

    public void setApplicationContent(String applicationContent) {
        this.applicationContent = applicationContent;
    }

    public String getAttributeContent() {
        materialize();

        return attributeContent;
    }

    public void setAttributeContent(String attributeContent) {
        this.attributeContent = attributeContent;
    }

    public String getSearchableContent() {
        materialize();

        return searchableContent;
    }

    public void setSearchableContent(String searchableContent) {
        this.searchableContent = searchableContent;
    }

    public String getFullContent() {
        StringBuffer fullContent = new StringBuffer();
        fullContent.append("<").append(EdenConstants.DOCUMENT_CONTENT_ELEMENT)
           .append(">");

        if (!Utilities.isEmpty(getApplicationContent())) {
            fullContent.append("<")
                       .append(EdenConstants.APPLICATION_CONTENT_ELEMENT)
                       .append(">");
            fullContent.append(getApplicationContent());
            fullContent.append("</")
                       .append(EdenConstants.APPLICATION_CONTENT_ELEMENT)
                       .append(">");
        }

        fullContent.append(getAttributeContent());
        fullContent.append(getSearchableContent());
        fullContent.append("</").append(EdenConstants.DOCUMENT_CONTENT_ELEMENT)
           .append(">");

        return fullContent.toString();
    }

    public WorkflowAttributeDefinitionVO[] getAttributeDefinitions() {
        return (WorkflowAttributeDefinitionVO[]) attributeDefinitions.toArray(
                         ARRAY_TYPE);
    }

    public void setAttributeDefinitions(WorkflowAttributeDefinitionVO[] attributeDefinitions) {
        this.attributeDefinitions = new ArrayList();

        for (int index = 0; index < attributeDefinitions.length; index++) {
            this.attributeDefinitions.add(attributeDefinitions[index]);
        }
    }

    public WorkflowAttributeDefinitionVO[] getSearchableDefinitions() {
        return (WorkflowAttributeDefinitionVO[]) searchableDefinitions.toArray(
                         ARRAY_TYPE);
    }

    public void setSearchableDefinitions(WorkflowAttributeDefinitionVO[] searchableDefinitions) {
        this.searchableDefinitions = new ArrayList();

        for (int index = 0; index < searchableDefinitions.length; index++) {
            this.searchableDefinitions.add(searchableDefinitions[index]);
        }
    }

    public void addAttributeDefinition(WorkflowAttributeDefinitionVO definition) {
        attributeDefinitions.add(definition);
    }

    public void removeAttributeDefinition(WorkflowAttributeDefinitionVO definition) {
        attributeDefinitions.remove(definition);
    }

    public void addSearchableDefinition(WorkflowAttributeDefinitionVO definition) {
        searchableDefinitions.add(definition);
    }

    public void removeSearchableDefinition(WorkflowAttributeDefinitionVO definition) {
        searchableDefinitions.remove(definition);
    }

    public Long getRouteHeaderId() {
        return routeHeaderId;
    }

    public void setRouteHeaderId(Long routeHeaderId) {
        this.routeHeaderId = routeHeaderId;
    }

    /**
    * The document content needs to be materialized if it has a document id, any of the XML fields are not initialized,
    * and we aren't in the process of serializing the document to XML through Axis.
    */
    private boolean needsMaterialized() {
        return autoMaterialize && !WorkflowBeanSerializer.isSerializing() && 
               (!isInitialized(attributeContent) || 
               !isInitialized(searchableContent) || 
               !isInitialized(applicationContent));
    }

    private boolean isInitialized(String value) {
        return value != null;
    }

    /**
     * Materializes the document content of the document from the database if neccessary.  Rather then replacing all
     * properties on the DocumentContentVO we replace only those they have not been modified in the local copy.
     * This is to prevent changes by the client application from being lost on a lazy fetch of document content data.
     */
    private void materialize() {
        try {
            if (needsMaterialized()) {
                // if there is no document id, initialize the content with empty values
                if (routeHeaderId == null) {
                    if (!isInitialized(attributeContent)) {
                        attributeContent = "";
                    }

                    if (!isInitialized(searchableContent)) {
                        searchableContent = "";
                    }

                    if (!isInitialized(applicationContent)) {
                        applicationContent = "";
                    }
                } else {
                    DocumentContentVO materializedContent = 
                            new WorkflowInfo().getDocumentContent(routeHeaderId);


                    // Check that the fields have not already been initialized before overwriting them!
                    //
                    // Also, we're going to play it safe here because if data comes back from the server in a non-initialized 
                    // form (for whatever reason) this code would go into an infinite loop on a subsequent call to getXxxContent() 
                    // when materialize() is invoked.  Therefore we will turn off materialization on the incoming data and
                    // access its fields directly for extra-safeness
                    materializedContent.turnOffMaterialization();

                    if (!isInitialized(attributeContent) && 
                            isInitialized(materializedContent.attributeContent)) {
                        attributeContent = materializedContent.attributeContent;
                    }

                    if (!isInitialized(searchableContent) && 
                            isInitialized(materializedContent.searchableContent)) {
                        searchableContent = materializedContent.searchableContent;
                    }

                    if (!isInitialized(applicationContent) && 
                            isInitialized(
                                    materializedContent.applicationContent)) {
                        applicationContent = materializedContent.applicationContent;
                    }
                }
            }
        } catch (WorkflowException e) {
            throw new WorkflowRuntimeException(
                    "Failed to materialize document content from the server.", e);
        }
    }

    /**
     * Turns off auto-materialization.  This is utilized on the server when the object is being examined.
     *
     */
    public void turnOffMaterialization() {
        autoMaterialize = false;
    }
}