
/*
 * Copyright (c) 2004, 2005, 2006 Trustees of Indiana University and Cornell University.
 *
 * Licensed under the Educational Community License Version 1.0 (the "License"); By obtaining,
 * using and/or copying this Original Work, you agree that you have read, understand, and will
 * comply with the terms and conditions of the Educational Community License.
 *
 * For the full text of the license, see the LICENSE.txt file or visit:
 * 
 * http://kew.indiana.edu/workflow/LICENSE.txt
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING
 * BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE
 * AND NONINFRINGEMENT.
 * IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES
 * OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 */
            
package edu.iu.uis.eden.clientapp.vo;

import java.util.HashMap;
import java.util.Map;


/**
 * @workflow.webservice-object
 */
public class DocumentDetailVO extends RouteHeaderVO {
    private static final long serialVersionUID = -6089529693944755804L;
    private ActionRequestVO[] actionRequests = new ActionRequestVO[0];
    private ActionTakenVO[] actionsTaken = new ActionTakenVO[0];
    private RouteNodeInstanceVO[] nodeInstances = new RouteNodeInstanceVO[0];
    private Map nodeInstanceMap = null;

    public ActionRequestVO[] getActionRequests() {
        return actionRequests;
    }

    public void setActionRequests(ActionRequestVO[] actionRequests) {
        this.actionRequests = actionRequests;
    }

    public ActionTakenVO[] getActionsTaken() {
        return actionsTaken;
    }

    public void setActionsTaken(ActionTakenVO[] actionsTaken) {
        this.actionsTaken = actionsTaken;
    }

    public RouteNodeInstanceVO[] getNodeInstances() {
        return nodeInstances;
    }

    public void setNodeInstances(RouteNodeInstanceVO[] nodeInstances) {
        this.nodeInstances = nodeInstances;
    }

    public RouteNodeInstanceVO getNodeInstance(Long nodeInstanceId) {
        if (nodeInstanceMap == null) {
            populateNodeInstanceMap();
        }

        return (RouteNodeInstanceVO) nodeInstanceMap.get(nodeInstanceId);
    }

    private void populateNodeInstanceMap() {
        nodeInstanceMap = new HashMap();

        for (int index = 0; index < nodeInstances.length; index++) {
            RouteNodeInstanceVO nodeInstance = nodeInstances[index];
            nodeInstanceMap.put(nodeInstance.getRouteNodeInstanceId(), 
                                nodeInstance);
        }
    }
}