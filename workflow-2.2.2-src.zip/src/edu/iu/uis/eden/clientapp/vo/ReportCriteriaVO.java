
/*
 * Copyright (c) 2004, 2005, 2006 Trustees of Indiana University and Cornell University.
 *
 * Licensed under the Educational Community License Version 1.0 (the "License"); By obtaining,
 * using and/or copying this Original Work, you agree that you have read, understand, and will
 * comply with the terms and conditions of the Educational Community License.
 *
 * For the full text of the license, see the LICENSE.txt file or visit:
 * 
 * http://kew.indiana.edu/workflow/LICENSE.txt
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING
 * BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE
 * AND NONINFRINGEMENT.
 * IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES
 * OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 */
            
package edu.iu.uis.eden.clientapp.vo;

import java.io.Serializable;


/**
 * @workflow.webservice-object
 */
public class ReportCriteriaVO implements Serializable {
    private static final long serialVersionUID = 4390002636101531058L;
    private Long routeHeaderId;
    private String targetNodeName;
    private UserIdVO[] targetUsers;
    private String documentTypeName;
    private String xmlContent;
    private String[] ruleTemplateNames;
    private String[] nodeNames;

    public ReportCriteriaVO() {
    }

    public ReportCriteriaVO(Long routeHeaderId) {
        this(routeHeaderId, null);
    }

    public ReportCriteriaVO(Long routeHeaderId, String targetNodeName) {
        this.routeHeaderId = routeHeaderId;
        this.targetNodeName = targetNodeName;
    }

    public ReportCriteriaVO(String documentTypeName) {
        this.documentTypeName = documentTypeName;
    }

    public Long getRouteHeaderId() {
        return routeHeaderId;
    }

    public void setRouteHeaderId(Long routeHeaderId) {
        this.routeHeaderId = routeHeaderId;
    }

    public String getTargetNodeName() {
        return targetNodeName;
    }

    public void setTargetNodeName(String targetNodeName) {
        this.targetNodeName = targetNodeName;
    }

    public String toString() {
        return super.toString() + "[routeHeaderId=" + routeHeaderId + 
               ",targetNodeName=" + targetNodeName + "]";
    }

    public String getDocumentTypeName() {
        return documentTypeName;
    }

    public void setDocumentTypeName(String documentTypeName) {
        this.documentTypeName = documentTypeName;
    }

    public String[] getRuleTemplateNames() {
        return ruleTemplateNames;
    }

    public void setRuleTemplateNames(String[] ruleTemplateNames) {
        this.ruleTemplateNames = ruleTemplateNames;
    }

    public UserIdVO[] getTargetUsers() {
        return targetUsers;
    }

    public void setTargetUsers(UserIdVO[] targetUsers) {
        this.targetUsers = targetUsers;
    }

    public String getXmlContent() {
        return xmlContent;
    }

    public void setXmlContent(String xmlContent) {
        this.xmlContent = xmlContent;
    }

    public String[] getNodeNames() {
        return nodeNames;
    }

    public void setNodeNames(String[] nodeNames) {
        this.nodeNames = nodeNames;
    }
}