
/*
 * Copyright (c) 2004, 2005, 2006 Trustees of Indiana University and Cornell University.
 *
 * Licensed under the Educational Community License Version 1.0 (the "License"); By obtaining,
 * using and/or copying this Original Work, you agree that you have read, understand, and will
 * comply with the terms and conditions of the Educational Community License.
 *
 * For the full text of the license, see the LICENSE.txt file or visit:
 * 
 * http://kew.indiana.edu/workflow/LICENSE.txt
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING
 * BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE
 * AND NONINFRINGEMENT.
 * IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES
 * OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 */
            
package edu.iu.uis.eden.clientapp.vo;

/**
 * A document event representing the transition of a document from one status to another.
 * 
 * @workflow.webservice-object
 */
public class DocumentRouteStatusChangeVO extends DocumentEventVO {
    private static final long serialVersionUID = 3969488320690393356L;
    private String newRouteStatus;
    private String oldRouteStatus;

    public DocumentRouteStatusChangeVO() {
        super(ROUTE_STATUS_CHANGE);
    }

    public String getNewRouteStatus() {
        return newRouteStatus;
    }

    public void setNewRouteStatus(String newRouteStatus) {
        this.newRouteStatus = newRouteStatus;
    }

    public String getOldRouteStatus() {
        return oldRouteStatus;
    }

    public void setOldRouteStatus(String oldRouteStatus) {
        this.oldRouteStatus = oldRouteStatus;
    }

    public String toString() {
        StringBuffer buffer = new StringBuffer();
        buffer.append("RouteHeaderID ").append(getRouteHeaderId());
        buffer.append(" changing from routeStatus ").append(oldRouteStatus);
        buffer.append(" to routeStatus ").append(newRouteStatus);

        return buffer.toString();
    }
}