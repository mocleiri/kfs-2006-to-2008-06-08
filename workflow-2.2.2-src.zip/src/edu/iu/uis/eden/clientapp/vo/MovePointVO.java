
/*
 * Copyright (c) 2004, 2005, 2006 Trustees of Indiana University and Cornell University.
 *
 * Licensed under the Educational Community License Version 1.0 (the "License"); By obtaining,
 * using and/or copying this Original Work, you agree that you have read, understand, and will
 * comply with the terms and conditions of the Educational Community License.
 *
 * For the full text of the license, see the LICENSE.txt file or visit:
 * 
 * http://kew.indiana.edu/workflow/LICENSE.txt
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING
 * BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE
 * AND NONINFRINGEMENT.
 * IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES
 * OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 */
            
package edu.iu.uis.eden.clientapp.vo;

import java.io.Serializable;


/**
 * @workflow.webservice-object
 */
public class MovePointVO implements Serializable {
    private static final long serialVersionUID = 6682919843672420498L;
    private String startNodeName;
    private int stepsToMove;

    public MovePointVO() {
    }

    /**
     * Defines a move point which starts at the given fromNodeName and moves the
     * number of steps defined.  This can be a negative value to move backwards,
     * 0 to stay at the current position (refresh) or a positive value to move forward.
     */
    public MovePointVO(String fromNodeName, int stepsToMove) {
        this.startNodeName = fromNodeName;
        this.stepsToMove = stepsToMove;
    }

    public String getStartNodeName() {
        return startNodeName;
    }

    public void setStartNodeName(String fromNodeName) {
        this.startNodeName = fromNodeName;
    }

    public int getStepsToMove() {
        return stepsToMove;
    }

    public void setStepsToMove(int stepsToMove) {
        this.stepsToMove = stepsToMove;
    }
}