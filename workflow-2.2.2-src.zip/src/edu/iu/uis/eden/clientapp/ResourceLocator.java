
/*
 * Copyright (c) 2004, 2005, 2006 Trustees of Indiana University and Cornell University.
 *
 * Licensed under the Educational Community License Version 1.0 (the "License"); By obtaining,
 * using and/or copying this Original Work, you agree that you have read, understand, and will
 * comply with the terms and conditions of the Educational Community License.
 *
 * For the full text of the license, see the LICENSE.txt file or visit:
 * 
 * http://kew.indiana.edu/workflow/LICENSE.txt
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING
 * BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE
 * AND NONINFRINGEMENT.
 * IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES
 * OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 */
            
package edu.iu.uis.eden.clientapp;

import edu.iu.uis.eden.exception.WorkflowException;

import javax.naming.Context;
import javax.naming.NamingException;

import javax.sql.DataSource;


/**
 * 
 * @author rkirkend
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 * 
 * @deprecated I'm going by by
 */
public class ResourceLocator {
    private static final org.apache.log4j.Logger LOG = 
            org.apache.log4j.Logger.getLogger(ResourceLocator.class);
    private Context ctx;
    private String env;
    private String transactional;
    private String appCode;
    private String businessClass;
    private Object postProcessor;
    private boolean doit;

    protected ResourceLocator(Context ctx) throws WorkflowException {
        this.ctx = ctx;
        this.env = this.getValue("deployEnvironment");
        this.transactional = this.getValue("transactional");
        this.appCode = this.getValue("appCode");
        this.businessClass = this.getValue("busClassLocation");
    }

    public ResourceLocator(String env, String transactional, String appCode, 
                           String businessClass) {
        this.env = env;
        this.transactional = transactional;
        this.appCode = appCode;
        this.businessClass = businessClass;
    }

    public String getValue(String key) throws WorkflowException {
        try {
            return (String) ctx.lookup("java:comp/env/" + key);
        } catch (NamingException ex) {
            LOG.error("didn't find value for key (" + key + 
                      ") under context java:comp/env/ + key", ex);
            throw new WorkflowException("didn't find value for key (" + key + 
                                        ") under context java:comp/env/ + key");
        }
    }

    public DataSource getDataSource(String name) throws WorkflowException {
        try {
            return (DataSource) ctx.lookup("java:comp/env/jdbc/" + name);
        } catch (NamingException ex) {
            LOG.error("didn't find a DataSource for name (" + name + 
                      ") under context java:comp/env/jdbc/ + key", ex);
            throw new WorkflowException("didn't find a DataSource for name (" + 
                                        name + 
                                        ") under context java:comp/env/jdbc/ + key");
        }
    }

    public String getEnv() {
        return env;
    }

    public String getTransactional() {
        return transactional;
    }

    public String getAppCode() {
        return appCode;
    }

    public String getBusinessClass() {
        return businessClass;
    }

    public boolean isDoit() {
        return doit;
    }

    public void setDoit(boolean doit) {
        this.doit = doit;
    }

    public Object getPostProcessor() {
        return postProcessor;
    }

    public void setPostProcessor(Object postProcessor) {
        this.postProcessor = postProcessor;
    }
}