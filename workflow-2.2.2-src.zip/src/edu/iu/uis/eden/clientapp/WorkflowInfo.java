
/*
 * Copyright (c) 2004, 2005, 2006 Trustees of Indiana University and Cornell University.
 *
 * Licensed under the Educational Community License Version 1.0 (the "License"); By obtaining,
 * using and/or copying this Original Work, you agree that you have read, understand, and will
 * comply with the terms and conditions of the Educational Community License.
 *
 * For the full text of the license, see the LICENSE.txt file or visit:
 * 
 * http://kew.indiana.edu/workflow/LICENSE.txt
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING
 * BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE
 * AND NONINFRINGEMENT.
 * IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES
 * OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 */
            
package edu.iu.uis.eden.clientapp;

import edu.iu.uis.eden.clientapp.vo.ActionRequestVO;
import edu.iu.uis.eden.clientapp.vo.ActionTakenVO;
import edu.iu.uis.eden.clientapp.vo.DocumentContentVO;
import edu.iu.uis.eden.clientapp.vo.DocumentDetailVO;
import edu.iu.uis.eden.clientapp.vo.DocumentTypeVO;
import edu.iu.uis.eden.clientapp.vo.ReportCriteriaVO;
import edu.iu.uis.eden.clientapp.vo.RouteHeaderVO;
import edu.iu.uis.eden.clientapp.vo.RouteNodeInstanceVO;
import edu.iu.uis.eden.clientapp.vo.RouteTemplateEntryVO;
import edu.iu.uis.eden.clientapp.vo.UserIdVO;
import edu.iu.uis.eden.clientapp.vo.UserVO;
import edu.iu.uis.eden.clientapp.vo.WorkflowAttributeDefinitionVO;
import edu.iu.uis.eden.clientapp.vo.WorkflowAttributeValidationErrorVO;
import edu.iu.uis.eden.clientapp.vo.WorkflowGroupIdVO;
import edu.iu.uis.eden.clientapp.vo.WorkgroupIdVO;
import edu.iu.uis.eden.clientapp.vo.WorkgroupNameIdVO;
import edu.iu.uis.eden.clientapp.vo.WorkgroupVO;
import edu.iu.uis.eden.exception.InvalidWorkgroupException;
import edu.iu.uis.eden.exception.WorkflowException;
import edu.iu.uis.eden.server.WorkflowUtility;
import edu.iu.uis.eden.util.Utilities;

import java.rmi.RemoteException;


public class WorkflowInfo implements java.io.Serializable {
    private static final long serialVersionUID = 3231835171780770399L;

    /**
    * Retrieves the WorkflowUtility proxy from the locator.  The locator will cache this for us.
    */
    private WorkflowUtility getWorkflowUtility() throws WorkflowException {
        return ClientServiceLocator.getWorkflowUtility();
    }

    public RouteHeaderVO getRouteHeader(UserIdVO userId, Long routeHeaderId)
                                 throws WorkflowException {
        try {
            return getWorkflowUtility()
                       .getRouteHeaderWithUser(userId, routeHeaderId);
        } catch (Exception e) {
            throw handleException(e);
        }
    }

    public RouteHeaderVO getRouteHeader(Long documentId)
                                 throws WorkflowException {
        try {
            return getWorkflowUtility().getRouteHeader(documentId);
        } catch (Exception e) {
            throw handleException(e);
        }
    }

    public WorkgroupVO getWorkgroup(WorkgroupIdVO workgroupId)
                             throws WorkflowException {
        try {
            return getWorkflowUtility().getWorkgroup(workgroupId);
        } catch (Exception e) {
            throw handleException(e);
        }
    }

    public UserVO getWorkflowUser(UserIdVO userId) throws WorkflowException {
        try {
            return getWorkflowUtility().getWorkflowUser(userId);
        } catch (Exception e) {
            throw handleException(e);
        }
    }

    public DocumentTypeVO getDocType(Long documentTypeId)
                              throws WorkflowException {
        try {
            return getWorkflowUtility().getDocumentType(documentTypeId);
        } catch (Exception e) {
            throw handleException(e);
        }
    }

    public DocumentTypeVO getDocType(String documentTypeName)
                              throws WorkflowException {
        try {
            return getWorkflowUtility().getDocumentTypeByName(documentTypeName);
        } catch (Exception e) {
            throw handleException(e);
        }
    }

    public Long getNewResponsibilityId() throws WorkflowException {
        try {
            return getWorkflowUtility().getNewResponsibilityId();
        } catch (Exception e) {
            throw handleException(e);
        }
    }

    public WorkgroupVO[] getUserWorkgroups(UserIdVO userId)
                                    throws WorkflowException {
        try {
            return getWorkflowUtility().getUserWorkgroups(userId);
        } catch (Exception e) {
            throw handleException(e);
        }
    }

    public ActionRequestVO[] getActionRequests(Long routeHeaderId)
                                        throws WorkflowException {
        try {
            return getWorkflowUtility().getActionRequests(routeHeaderId);
        } catch (Exception e) {
            throw handleException(e);
        }
    }

    public ActionTakenVO[] getActionsTaken(Long routeHeaderId)
                                    throws WorkflowException {
        try {
            return getWorkflowUtility().getActionsTaken(routeHeaderId);
        } catch (Exception e) {
            throw handleException(e);
        }
    }

    /*public RouteHeaderDetailVO routingSimulation(RouteHeaderDetailVO detail, ActionTakenVO[] actionsToTake) throws WorkflowException {
            try {
                    return getWorkflowUtility().routingSimulation(detail, actionsToTake);
            } catch (Exception e) {
                    throw handleException(e);
            }
    }*/
    public boolean isUserAuthenticatedByRouteLog(Long routeHeaderId, 
                                                 UserIdVO userId, 
                                                 boolean lookFuture)
                                          throws WorkflowException {
        try {
            return getWorkflowUtility()
                       .isUserInRouteLog(routeHeaderId, userId, lookFuture);
        } catch (Exception e) {
            throw handleException(e);
        }
    }

    public boolean isFinalApprover(Long routeHeaderId, UserIdVO userId)
                            throws WorkflowException {
        try {
            return getWorkflowUtility().isFinalApprover(routeHeaderId, userId);
        } catch (Exception e) {
            throw handleException(e);
        }
    }

    /**
     * Validate the WorkflowAttributeDefinition against it's attribute on the server.  This will validate 
     * the inputs that will eventually become xml.  
     * 
     * Only applies to attributes implementing WorkflowAttributeXmlValidator.
     * 
     * @param attributeDefinition
     * @return WorkflowAttributeValidationErrorVO[] of error from the attribute
     * @throws WorkflowException when attribute doesn't implement WorkflowAttributeXmlValidator
     */
    public WorkflowAttributeValidationErrorVO[] validAttributeDefinition(WorkflowAttributeDefinitionVO attributeDefinition)
        throws WorkflowException {
        try {
            return getWorkflowUtility()
                       .validateWorkflowAttributeDefinitionVO(attributeDefinition);
        } catch (Exception e) {
            throw handleException(e);
        }
    }

    /**
     * Helper to prevent us from needlessly wrapping a WorkflowException in another WorkflowException.
     */
    private WorkflowException handleException(Exception e) {
        if (e instanceof WorkflowException) {
            return (WorkflowException) e;
        }

        return new WorkflowException(e);
    }

    // WORKFLOW 2.1: new methods
    public DocumentDetailVO getDocumentDetail(Long documentId)
                                       throws WorkflowException {
        try {
            return getWorkflowUtility().getDocumentDetail(documentId);
        } catch (Exception e) {
            throw handleException(e);
        }
    }

    public RouteNodeInstanceVO getNodeInstance(Long nodeInstanceId)
                                        throws WorkflowException {
        try {
            return getWorkflowUtility().getNodeInstance(nodeInstanceId);
        } catch (Exception e) {
            throw handleException(e);
        }
    }

    public RouteNodeInstanceVO[] getDocumentRouteNodeInstances(Long routeHeaderId)
        throws WorkflowException {
        try {
            return getWorkflowUtility()
                       .getDocumentRouteNodeInstances(routeHeaderId);
        } catch (Exception e) {
            throw handleException(e);
        }
    }

    public RouteNodeInstanceVO[] getActiveNodeInstances(Long routeHeaderId)
                                                 throws WorkflowException {
        try {
            return getWorkflowUtility().getActiveNodeInstances(routeHeaderId);
        } catch (Exception e) {
            throw handleException(e);
        }
    }

    public RouteNodeInstanceVO[] getTerminalNodeInstances(Long routeHeaderId)
                                                   throws WorkflowException {
        try {
            return getWorkflowUtility().getTerminalNodeInstances(routeHeaderId);
        } catch (Exception e) {
            throw handleException(e);
        }
    }

    public void reResolveRole(String documentTypeName, String roleName, 
                              String qualifiedRoleNameLabel)
                       throws WorkflowException {
        try {
            getWorkflowUtility()
                .reResolveRole(documentTypeName, roleName, 
                               qualifiedRoleNameLabel);
        } catch (Exception e) {
            throw handleException(e);
        }
    }

    public void reResolveRole(Long documentId, String roleName, 
                              String qualifiedRoleNameLabel)
                       throws WorkflowException {
        try {
            getWorkflowUtility()
                .reResolveRoleByDocumentId(documentId, roleName, 
                                           qualifiedRoleNameLabel);
        } catch (Exception e) {
            throw handleException(e);
        }
    }

    public DocumentDetailVO routingReport(ReportCriteriaVO reportCriteria)
                                   throws WorkflowException {
        try {
            return getWorkflowUtility().routingReport(reportCriteria);
        } catch (Exception e) {
            throw handleException(e);
        }
    }

    protected boolean isLastApproverAtNode(Long routeHeaderId, UserIdVO userId, 
                                           String nodeName)
                                    throws WorkflowException {
        try {
            return getWorkflowUtility()
                       .isLastApproverAtNode(routeHeaderId, userId, nodeName);
        } catch (Exception e) {
            throw handleException(e);
        }
    }

    protected boolean routeNodeHasApproverActionRequest(String docType, 
                                                        String docContent, 
                                                        String nodeName)
                                                 throws WorkflowException {
        try {
            return getWorkflowUtility()
                       .routeNodeHasApproverActionRequest(docType, docContent, 
                                                          nodeName);
        } catch (Exception e) {
            throw handleException(e);
        }
    }

    // DEPRECATED: as of Workflow 2.0

    /**
     * @deprecated use getWorkgroup(WorkgroupIdVO) instead
     */
    public WorkgroupVO getWorkgroup(String workgroupName)
                             throws WorkflowException {
        if (Utilities.isEmpty(workgroupName)) {
            throw new InvalidWorkgroupException(
                    "Workgroup name cannot be empty");
        }

        return getWorkgroup(new WorkgroupNameIdVO(workgroupName)); //getWorkflowUtility().getWorkgroup(new WorkgroupNameIdVO(workgroupName));
    }

    /**
     * @deprecated use getWorkgroup(WorkgroupIdVO) instead
     */
    public WorkgroupVO getWorkgroup(Long workgroupId) throws WorkflowException {
        if (workgroupId == null) {
            throw new InvalidWorkgroupException(
                    "Workgroup name cannot be empty");
        }

        return getWorkgroup(new WorkflowGroupIdVO(workgroupId));
    }

    /**
     * @deprecated use getDocType using the name
     */
    public RouteTemplateEntryVO[] getRoute(String documentTypeName)
                                    throws WorkflowException {
        try {
            return getWorkflowUtility().getDocRoute(documentTypeName);
        } catch (Exception e) {
            throw handleException(e);
        }
    }

    public DocumentContentVO getDocumentContent(Long routeHeaderId)
                                         throws WorkflowException {
        try {
            return getWorkflowUtility().getDocumentContent(routeHeaderId);
        } catch (Exception e) {
            throw handleException(e);
        }
    }

    public String[] getPreviousRouteNodeNames(Long documentId)
                                       throws RemoteException, 
                                              WorkflowException {
        try {
            return getWorkflowUtility().getPreviousRouteNodeNames(documentId);
        } catch (Exception e) {
            throw handleException(e);
        }
    }

    // DEPRECATED: as of Workflow 2.1

    /**
     * @deprecated use isLastApproverAtNode instead
     */
    protected boolean isLastApproverInRouteLevel(Long routeHeaderId, 
                                                 UserIdVO userId, 
                                                 Integer routeLevel)
                                          throws WorkflowException {
        try {
            return getWorkflowUtility()
                       .isLastApproverInRouteLevel(routeHeaderId, userId, 
                                                   routeLevel);
        } catch (Exception e) {
            throw handleException(e);
        }
    }

    protected boolean routeLevelHasApproverActionRequest(String docType, 
                                                         String docContent, 
                                                         Integer routeLevel)
                                                  throws WorkflowException {
        try {
            return getWorkflowUtility()
                       .routeLevelHasApproverActionRequest(docType, docContent, 
                                                           routeLevel);
        } catch (Exception e) {
            throw handleException(e);
        }
    }
}