
/*
 * Copyright (c) 2004, 2005, 2006 Trustees of Indiana University and Cornell University.
 *
 * Licensed under the Educational Community License Version 1.0 (the "License"); By obtaining,
 * using and/or copying this Original Work, you agree that you have read, understand, and will
 * comply with the terms and conditions of the Educational Community License.
 *
 * For the full text of the license, see the LICENSE.txt file or visit:
 * 
 * http://kew.indiana.edu/workflow/LICENSE.txt
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING
 * BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE
 * AND NONINFRINGEMENT.
 * IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES
 * OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 */
            
package edu.iu.uis.eden.clientapp;

import edu.iu.uis.eden.EdenConstants;
import edu.iu.uis.eden.clientapp.vo.ActionRequestVO;
import edu.iu.uis.eden.clientapp.vo.ActionTakenVO;
import edu.iu.uis.eden.clientapp.vo.AdHocRevokeVO;
import edu.iu.uis.eden.clientapp.vo.DocumentDetailVO;
import edu.iu.uis.eden.clientapp.vo.EmplIdVO;
import edu.iu.uis.eden.clientapp.vo.MovePointVO;
import edu.iu.uis.eden.clientapp.vo.NetworkIdVO;
import edu.iu.uis.eden.clientapp.vo.NoteVO;
import edu.iu.uis.eden.clientapp.vo.ResponsiblePartyVO;
import edu.iu.uis.eden.clientapp.vo.ReturnPointVO;
import edu.iu.uis.eden.clientapp.vo.RouteHeaderVO;
import edu.iu.uis.eden.clientapp.vo.RouteNodeInstanceVO;
import edu.iu.uis.eden.clientapp.vo.RouteTemplateEntryVO;
import edu.iu.uis.eden.clientapp.vo.UserIdVO;
import edu.iu.uis.eden.clientapp.vo.UuIdVO;
import edu.iu.uis.eden.clientapp.vo.WorkflowAttributeDefinitionVO;
import edu.iu.uis.eden.clientapp.vo.WorkflowAttributeValidationErrorVO;
import edu.iu.uis.eden.clientapp.vo.WorkflowIdVO;
import edu.iu.uis.eden.clientapp.vo.WorkgroupIdVO;
import edu.iu.uis.eden.exception.DocumentTypeNotFoundException;
import edu.iu.uis.eden.exception.WorkflowException;
import edu.iu.uis.eden.server.WorkflowDocumentActions;
import edu.iu.uis.eden.server.WorkflowUtility;
import edu.iu.uis.eden.util.Utilities;

import java.rmi.RemoteException;

import java.sql.Timestamp;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;


/**
 * Represents a document in Workflow from the perspective of the client.
 * 
 * This class is not thread safe and must by synchronized externally for concurrent access.
 * 
 * @author ewestfal
 */
public class WorkflowDocument implements java.io.Serializable {
    private static final long serialVersionUID = -3672966990721719088L;
    private UserIdVO userId;
    private RouteHeaderVO routeHeader;

    public WorkflowDocument(UserIdVO userId, String documentType)
                     throws WorkflowException {
        init(userId, documentType, null);
    }

    public WorkflowDocument(UserIdVO userId, Long routeHeaderId)
                     throws WorkflowException {
        init(userId, null, routeHeaderId);
    }

    private void init(UserIdVO userId, String documentType, Long routeHeaderId)
               throws WorkflowException {
        try {
            this.userId = userId;
            routeHeader = new RouteHeaderVO();
            routeHeader.setDocTypeName(documentType);

            if (routeHeaderId != null) {
                routeHeader = getWorkflowUtility()
                                  .getRouteHeaderWithUser(userId, routeHeaderId);
            }
        } catch (Exception e) {
            throw handleException(e);
        }
    }

    /**
     * Retrieves the WorkflowUtility proxy from the locator.  The locator will cache this for us.
     */
    private WorkflowUtility getWorkflowUtility() throws WorkflowException {
        return ClientServiceLocator.getWorkflowUtility();
    }

    /**
     * Retrieves the WorkflowDocumentActions proxy from the locator.  The locator will cache this for us.
     */
    private WorkflowDocumentActions getWorkflowDocumentActions()
        throws WorkflowException {
        return ClientServiceLocator.getWorkflowDocumentActions();
    }

    // ########################
    // Document Content methods
    // ########################

    /**
     * Returns the application specific document content.
     * 
     * For documents routed prior to Workflow 2.0:
     * If the application did NOT use attributes for XML generation, this method will
     * return the entire document content XML.  Otherwise it will return the empty string.
     */
    public String getApplicationContent() {
        return getRouteHeader().getDocumentContent().getApplicationContent();
    }

    /**
     * Sets the application specific document content.
     */
    public void setApplicationContent(String applicationContent) {
        getRouteHeader().getDocumentContent()
            .setApplicationContent(applicationContent);
    }

    /**
     * Clears all attribute document content from the document.
     * Typically, this will be used if it is necessary to update the attribute doc content on
     * the document.  This can be accomplished by clearing the content and then adding the
     * desired attribute definitions.
     * 
     * In order for these changes to take effect, an action must be performed on the document (such as "save").
     */
    public void clearAttributeContent() {
        getRouteHeader().getDocumentContent().setAttributeContent("");
    }

    /**
     * Returns the attribute-generated document content.
     */
    public String getAttributeContent() {
        return getRouteHeader().getDocumentContent().getAttributeContent();
    }

    /**
     * Adds an attribute definition which defines creation parameters for a WorkflowAttribute
     * implementation.  The created attribute will be used to generate attribute document content.
     * When the document is sent to the server, this will be appended to the existing attribute
     * doc content.  If it is required to replace the attribute document content, then the 
     * clearAttributeContent() method should be invoked prior to adding attribute definitions.
     */
    public void addAttributeDefinition(WorkflowAttributeDefinitionVO attributeDefinition) {
        getRouteHeader().getDocumentContent()
            .addAttributeDefinition(attributeDefinition);
    }

    /**
     * Validate the WorkflowAttributeDefinition against it's attribute on the server.  This will validate 
     * the inputs that will eventually become xml.  
     * 
     * Only applies to attributes implementing WorkflowAttributeXmlValidator.
     * 
     * This is a call through to the WorkflowInfo object and is here for convenience.
     * 
     * @param attributeDefinition
     * @return WorkflowAttributeValidationErrorVO[] of error from the attribute
     * @throws WorkflowException when attribute doesn't implement WorkflowAttributeXmlValidator
     */
    public WorkflowAttributeValidationErrorVO[] validateAttributeDefinition(WorkflowAttributeDefinitionVO attributeDefinition)
        throws WorkflowException {
        try {
            return getWorkflowUtility()
                       .validateWorkflowAttributeDefinitionVO(attributeDefinition);
        } catch (Exception e) {
            throw handleException(e);
        }
    }

    public void removeAttributeDefinition(WorkflowAttributeDefinitionVO attributeDefinition) {
        getRouteHeader().getDocumentContent()
            .removeAttributeDefinition(attributeDefinition);
    }

    public void clearAttributeDefinitions() {
        getRouteHeader().getDocumentContent()
            .setAttributeDefinitions(new WorkflowAttributeDefinitionVO[0]);
    }

    public WorkflowAttributeDefinitionVO[] getAttributeDefinitions() {
        return getRouteHeader().getDocumentContent().getAttributeDefinitions();
    }

    /**
     * Adds a searchable attribute definition which defines creation parameters for a SearchableAttribute
     * implementation.  The created attribute will be used to generate searchable document content.
     * When the document is sent to the server, this will be appended to the existing searchable
     * doc content.  If it is required to replace the searchable document content, then the 
     * clearSearchableContent() method should be invoked prior to adding definitions.
     */
    public void addSearchableDefinition(WorkflowAttributeDefinitionVO searchableDefinition) {
        getRouteHeader().getDocumentContent()
            .addSearchableDefinition(searchableDefinition);
    }

    public void removeSearchableDefinition(WorkflowAttributeDefinitionVO searchableDefinition) {
        getRouteHeader().getDocumentContent()
            .removeSearchableDefinition(searchableDefinition);
    }

    public void clearSearchableDefinitions() {
        getRouteHeader().getDocumentContent()
            .setSearchableDefinitions(new WorkflowAttributeDefinitionVO[0]);
    }

    public void clearSearchableContent() {
        getRouteHeader().getDocumentContent().setSearchableContent("");
    }

    public WorkflowAttributeDefinitionVO[] getSearchableDefinitions() {
        return getRouteHeader().getDocumentContent().getSearchableDefinitions();
    }

    // ########################
    // END Document Content methods
    // ########################
    public RouteHeaderVO getRouteHeader() {
        return routeHeader;
    }

    public Long getRouteHeaderId() throws WorkflowException {
        try {
            createDocumentIfNeccessary();

            return getRouteHeader().getRouteHeaderId();
        } catch (Exception e) {
            throw handleException(e);
        }
    }

    public ActionRequestVO[] getActionRequests() throws WorkflowException {
        if (getRouteHeaderId() == null) {
            return new ActionRequestVO[0];
        }

        try {
            return getWorkflowUtility().getActionRequests(getRouteHeaderId());
        } catch (Exception e) {
            throw handleException(e);
        }
    }

    public ActionTakenVO[] getActionsTaken() throws WorkflowException {
        if (getRouteHeaderId() == null) {
            return new ActionTakenVO[0];
        }

        try {
            return getWorkflowUtility().getActionsTaken(getRouteHeaderId());
        } catch (RemoteException e) {
            throw handleException(e);
        }
    }

    public void setAppDocId(String appDocId) {
        routeHeader.setAppDocId(appDocId);
    }

    public String getAppDocId() {
        return routeHeader.getAppDocId();
    }

    public Timestamp getDateCreated() {
        return Utilities.convertCalendar(routeHeader.getDateCreated());
    }

    public String getTitle() {
        return getRouteHeader().getDocTitle();
    }

    public void saveDocument(String annotation) throws WorkflowException {
        try {
            createDocumentIfNeccessary();
            routeHeader = getWorkflowDocumentActions()
                              .saveDocument(userId, getRouteHeader(), 
                                            annotation);
        } catch (Exception e) {
            throw handleException(e);
        }
    }

    public void routeDocument(String annotation) throws WorkflowException {
        try {
            createDocumentIfNeccessary();
            routeHeader = getWorkflowDocumentActions()
                              .routeDocument(userId, routeHeader, annotation);
        } catch (Exception e) {
            throw handleException(e);
        }
    }

    public void disapprove(String annotation) throws WorkflowException {
        try {
            createDocumentIfNeccessary();
            routeHeader = getWorkflowDocumentActions()
                              .disapproveDocument(userId, getRouteHeader(), 
                                                  annotation);
        } catch (Exception e) {
            throw handleException(e);
        }
    }

    public void approve(String annotation) throws WorkflowException {
        try {
            createDocumentIfNeccessary();
            routeHeader = getWorkflowDocumentActions()
                              .approveDocument(userId, getRouteHeader(), 
                                               annotation);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    public void cancel(String annotation) throws WorkflowException {
        try {
            createDocumentIfNeccessary();
            routeHeader = getWorkflowDocumentActions()
                              .cancelDocument(userId, getRouteHeader(), 
                                              annotation);
        } catch (Exception e) {
            throw handleException(e);
        }
    }

    public void blanketApprove(String annotation) throws WorkflowException {
        blanketApprove(annotation, (String) null);
    }

    public void saveRoutingData() throws WorkflowException {
        try {
            createDocumentIfNeccessary();
            routeHeader = getWorkflowDocumentActions()
                              .saveRoutingData(userId, getRouteHeader());
        } catch (Exception e) {
            throw handleException(e);
        }
    }

    public void acknowledge(String annotation) throws WorkflowException {
        try {
            createDocumentIfNeccessary();
            routeHeader = getWorkflowDocumentActions()
                              .acknowledgeDocument(userId, getRouteHeader(), 
                                                   annotation);
        } catch (Exception e) {
            throw handleException(e);
        }
    }

    public void fyi() throws WorkflowException {
        try {
            createDocumentIfNeccessary();
            routeHeader = getWorkflowDocumentActions()
                              .clearFYIDocument(userId, getRouteHeader());
        } catch (Exception e) {
            throw handleException(e);
        }
    }

    public void delete() throws WorkflowException {
        try {
            createDocumentIfNeccessary();
            getWorkflowDocumentActions()
                .deleteDocument(userId, getRouteHeader());
        } catch (Exception e) {
            throw handleException(e);
        }
    }

    public void refreshContent() throws WorkflowException {
        try {
            createDocumentIfNeccessary();
            routeHeader = getWorkflowUtility()
                              .getRouteHeader(getRouteHeaderId());
        } catch (Exception e) {
            throw handleException(e);
        }
    }

    /**
     * @deprecated
     */
    public void appSpecificRouteDocumentToUser(String actionRequested, 
                                               String nodeName, int priority, 
                                               String annotation, 
                                               UserIdVO recipient, 
                                               String responsibilityDesc, 
                                               boolean ignorePreviousActions)
                                        throws WorkflowException {
        appSpecificRouteDocumentToUser(actionRequested, nodeName, annotation, 
                                       recipient, responsibilityDesc, 
                                       ignorePreviousActions);
    }

    /**
     * @deprecated
     */
    public void appSpecificRouteDocumentToWorkgroup(String actionRequested, 
                                                    String nodeName, 
                                                    int priority, 
                                                    String annotation, 
                                                    WorkgroupIdVO workgroupId, 
                                                    String responsibilityDesc, 
                                                    boolean ignorePreviousActions)
                                             throws WorkflowException {
        appSpecificRouteDocumentToWorkgroup(actionRequested, nodeName, 
                                            annotation, workgroupId, 
                                            responsibilityDesc, 
                                            ignorePreviousActions);
    }

    /**
     * Sends an ad hoc request to the specified user at the current active node on the document.  If the document is
     * in a terminal state, the request will be attached to the terminal node.
     */
    public void appSpecificRouteDocumentToUser(String actionRequested, 
                                               String annotation, 
                                               UserIdVO recipient, 
                                               String responsibilityDesc, 
                                               boolean ignorePreviousActions)
                                        throws WorkflowException {
        appSpecificRouteDocumentToUser(actionRequested, null, annotation, 
                                       recipient, responsibilityDesc, 
                                       ignorePreviousActions);
    }

    public void appSpecificRouteDocumentToUser(String actionRequested, 
                                               String nodeName, 
                                               String annotation, 
                                               UserIdVO recipient, 
                                               String responsibilityDesc, 
                                               boolean ignorePreviousActions)
                                        throws WorkflowException {
        try {
            createDocumentIfNeccessary();
            routeHeader = getWorkflowDocumentActions()
                              .appSpecificRouteDocument(userId, 
                                                        getRouteHeader(), 
                                                        actionRequested, 
                                                        nodeName, annotation, 
                                                        new ResponsiblePartyVO(
                                                                recipient), 
                                                        responsibilityDesc, 
                                                        ignorePreviousActions);
        } catch (Exception e) {
            throw handleException(e);
        }
    }

    /**
     * Sends an ad hoc request to the specified workgroup at the current active node on the document.  If the document is 
     * in a terminal state, the request will be attached to the terminal node.
     */
    public void appSpecificRouteDocumentToWorkgroup(String actionRequested, 
                                                    String annotation, 
                                                    WorkgroupIdVO workgroupId, 
                                                    String responsibilityDesc, 
                                                    boolean ignorePreviousActions)
                                             throws WorkflowException {
        appSpecificRouteDocumentToWorkgroup(actionRequested, null, annotation, 
                                            workgroupId, responsibilityDesc, 
                                            ignorePreviousActions);
    }

    public void appSpecificRouteDocumentToWorkgroup(String actionRequested, 
                                                    String nodeName, 
                                                    String annotation, 
                                                    WorkgroupIdVO workgroupId, 
                                                    String responsibilityDesc, 
                                                    boolean ignorePreviousActions)
                                             throws WorkflowException {
        try {
            createDocumentIfNeccessary();
            routeHeader = getWorkflowDocumentActions()
                              .appSpecificRouteDocument(userId, 
                                                        getRouteHeader(), 
                                                        actionRequested, 
                                                        nodeName, annotation, 
                                                        new ResponsiblePartyVO(
                                                                workgroupId), 
                                                        responsibilityDesc, 
                                                        ignorePreviousActions);
        } catch (Exception e) {
            throw handleException(e);
        }
    }

    /**
     * Revokes AdHoc request(s) according to the given AdHocRevokeVO which is passed in.
     * 
     * If a specific action request ID is specified on the revoke bean, and that ID is not a valid ID, this method should throw a
     * WorkflowException.
     */
    public void revokeAdHocRequests(AdHocRevokeVO revoke, String annotation)
                             throws WorkflowException {
        if (getRouteHeader().getRouteHeaderId() == null) {
            throw new WorkflowException(
                    "Can't revoke request, the workflow document has not yet been created!");
        }

        try {
            routeHeader = getWorkflowDocumentActions()
                              .revokeAdHocRequests(userId, getRouteHeader(), 
                                                   revoke, annotation);
        } catch (Exception e) {
            throw handleException(e);
        }
    }

    public void setTitle(String title) throws WorkflowException {
        if (title == null) {
            title = "";
        }

        if (title.length() > EdenConstants.TITLE_MAX_LENGTH) {
            title = title.substring(0, EdenConstants.TITLE_MAX_LENGTH);
        }

        getRouteHeader().setDocTitle(title);
    }

    public String getDocumentType() {
        if (getRouteHeader() == null) {
            // HACK: FIXME: we should probably proscribe, or at least handle consistently, these corner cases
            // NPEs are not nice 
            throw new RuntimeException("No such document!");
        }

        return getRouteHeader().getDocTypeName();
    }

    public boolean isAcknowledgeRequested() {
        return getRouteHeader().isAckRequested();
    }

    public boolean isApprovalRequested() {
        return getRouteHeader().isApproveRequested();
    }

    public boolean isCompletionRequested() {
        return getRouteHeader().isCompleteRequested();
    }

    public boolean isFYIRequested() {
        return getRouteHeader().isFyiRequested();
    }

    public boolean isBlanketApproveCapable() {
        return getRouteHeader().isUserBlanketApprover() && 
               (isCompletionRequested() || isApprovalRequested() || 
               stateIsInitiated());
    }

    public void superUserApprove(String annotation) throws WorkflowException {
        try {
            createDocumentIfNeccessary();
            routeHeader = getWorkflowDocumentActions()
                              .superUserApprove(getUserId(), getRouteHeader(), 
                                                annotation);
        } catch (Exception e) {
            throw handleException(e);
        }
    }

    public void superUserDisapprove(String annotation)
                             throws WorkflowException {
        try {
            createDocumentIfNeccessary();
            routeHeader = getWorkflowDocumentActions()
                              .superUserDisapprove(getUserId(), 
                                                   getRouteHeader(), annotation);
        } catch (Exception e) {
            throw handleException(e);
        }
    }

    public void superUserCancel(String annotation) throws WorkflowException {
        try {
            createDocumentIfNeccessary();
            routeHeader = getWorkflowDocumentActions()
                              .superUserCancel(getUserId(), getRouteHeader(), 
                                               annotation);
        } catch (Exception e) {
            throw handleException(e);
        }
    }

    public boolean isSuperUser() throws WorkflowException {
        try {
            createDocumentIfNeccessary();

            return getWorkflowUtility()
                       .isSuperUserForDocumentType(getUserId(), 
                                                   getRouteHeader()
                                                       .getDocTypeId());
        } catch (Exception e) {
            throw handleException(e);
        }
    }

    /**
         * @return if user passed into WorkflowDocument at instantiation can route
         *         the document.
         */
    public boolean isRouteCapable() {
        UserIdVO userId = getUserId();

        if (userId instanceof NetworkIdVO) {
            return userId.toString()
                         .equals(getRouteHeader().getInitiator().getNetworkId()) && 
                   stateIsInitiated();
        } else if (userId instanceof UuIdVO) {
            return userId.toString()
                         .equals(getRouteHeader().getInitiator().getUuId()) && 
                   stateIsInitiated();
        } else if (userId instanceof EmplIdVO) {
            return userId.toString()
                         .equals(getRouteHeader().getInitiator().getEmplId()) && 
                   stateIsInitiated();
        } else if (userId instanceof WorkflowIdVO) {
            return userId.toString()
                         .equals(getRouteHeader().getInitiator()
                                     .getWorkflowId()) && 
                   stateIsInitiated();
        }

        throw new UnsupportedOperationException(
                "UserId type not yet supported on this method.");
    }

    public void clearFYI() throws WorkflowException {
        try {
            createDocumentIfNeccessary();
            getWorkflowDocumentActions()
                .clearFYIDocument(userId, getRouteHeader());
        } catch (Exception e) {
            throw handleException(e);
        }
    }

    public void complete(String annotation) throws WorkflowException {
        try {
            createDocumentIfNeccessary();
            routeHeader = getWorkflowDocumentActions()
                              .completeDocument(userId, getRouteHeader(), 
                                                annotation);
        } catch (Exception e) {
            throw handleException(e);
        }
    }

    public void logDocumentAction(String annotation) throws WorkflowException {
        try {
            createDocumentIfNeccessary();
            getWorkflowDocumentActions()
                .logDocumentAction(userId, getRouteHeader(), annotation);
        } catch (Exception e) {
            throw handleException(e);
        }
    }

    /**
     * Indicates if the document is in the initated state or not.
     * 
     * @return true if in the specified state
     */
    public boolean stateIsInitiated() {
        return EdenConstants.ROUTE_HEADER_INITIATED_CD.equals(
                       getRouteHeader().getDocRouteStatus());
    }

    /**
     * Indicates if the document is in the saved state or not.
     * 
     * @return true if in the specified state
     */
    public boolean stateIsSaved() {
        return EdenConstants.ROUTE_HEADER_SAVED_CD.equals(
                       getRouteHeader().getDocRouteStatus());
    }

    /**
     * Indicates if the document is in the enroute state or not.
     * 
     * @return true if in the specified state
     */
    public boolean stateIsEnroute() {
        return EdenConstants.ROUTE_HEADER_ENROUTE_CD.equals(
                       getRouteHeader().getDocRouteStatus());
    }

    /**
     * Indicates if the document is in the exception state or not.
     * 
     * @return true if in the specified state
     */
    public boolean stateIsException() {
        return EdenConstants.ROUTE_HEADER_EXCEPTION_CD.equals(
                       getRouteHeader().getDocRouteStatus());
    }

    /**
     * Indicates if the document is in the canceled state or not.
     * 
     * @return true if in the specified state
     */
    public boolean stateIsCanceled() {
        return EdenConstants.ROUTE_HEADER_CANCEL_CD.equals(
                       getRouteHeader().getDocRouteStatus());
    }

    /**
     * Indicates if the document is in the disapproved state or not.
     * 
     * @return true if in the specified state
     */
    public boolean stateIsDisapproved() {
        return EdenConstants.ROUTE_HEADER_DISAPPROVED_CD.equals(
                       getRouteHeader().getDocRouteStatus());
    }

    /**
     * Indicates if the document is in the approved state or not. Will answer true is document is in Processed or Finalized state.
     * 
     * @return true if in the specified state
     */
    public boolean stateIsApproved() {
        return EdenConstants.ROUTE_HEADER_APPROVED_CD.equals(
                       getRouteHeader().getDocRouteStatus()) || 
               stateIsProcessed() || 
               EdenConstants.ROUTE_HEADER_FINAL_CD.equals(
                       getRouteHeader().getDocRouteStatus());
    }

    /**
     * Indicates if the document is in the processed state or not.
     * 
     * @return true if in the specified state
     */
    public boolean stateIsProcessed() {
        return EdenConstants.ROUTE_HEADER_PROCESSED_CD.equals(
                       getRouteHeader().getDocRouteStatus());
    }

    public boolean stateIsFinal() {
        return EdenConstants.ROUTE_HEADER_FINAL_CD.equals(
                       getRouteHeader().getDocRouteStatus());
    }

    public String getStatusDisplayValue() {
        return (String) EdenConstants.DOCUMENT_STATUSES.get(
                       getRouteHeader().getDocRouteStatus());
    }

    public UserIdVO getUserId() {
        return userId;
    }

    public void setUserId(UserIdVO userId) {
        this.userId = userId;
    }

    /**
     * Checks if the document has been created or not (i.e. has a route header id or not) and issues
     * a call to the server to create the document if it has not yet been created.
     */
    private void createDocumentIfNeccessary() throws RemoteException, 
                                                     WorkflowException {
        if (getRouteHeader().getRouteHeaderId() == null) {
            routeHeader = getWorkflowDocumentActions()
                              .createDocument(userId, getRouteHeader());
        }
    }

    /**
     * Helper to prevent us from needlessly wrapping a WorkflowException in another WorkflowException.
     */
    private WorkflowException handleException(Exception e) {
        if (e instanceof WorkflowException) {
            return (WorkflowException) e;
        }

        return new WorkflowException(e);
    }

    // WORKFLOW 2.1: new methods
    public void blanketApprove(String annotation, String nodeName)
                        throws WorkflowException {
        blanketApprove(annotation, 
                       ((nodeName == null)                
                        ? null : new String[] { nodeName }));
    }

    public void blanketApprove(String annotation, String[] nodeNames)
                        throws WorkflowException {
        try {
            createDocumentIfNeccessary();
            routeHeader = getWorkflowDocumentActions()
                              .blanketApprovalToNodes(userId, getRouteHeader(), 
                                                      annotation, nodeNames);
        } catch (Exception e) {
            throw handleException(e);
        }
    }

    /**
     * The user taking action removes the action items for this workgroup and document from all other 
     * group members' action lists
     * 
     * @param annotation
     * @param workgroupId
     * @throws WorkflowException user taking action is not in workgroup
     */
    public void takeWorkgroupAuthority(String annotation, 
                                       WorkgroupIdVO workgroupId)
                                throws WorkflowException {
        try {
            createDocumentIfNeccessary();
            routeHeader = getWorkflowDocumentActions()
                              .takeWorkgroupAuthority(userId, getRouteHeader(), 
                                                      workgroupId, annotation);
        } catch (Exception e) {
            throw handleException(e);
        }
    }

    /**
     * The user that took the group authority is putting the action items back in the other users action lists
     * 
     * @param annotation
     * @param workgroupId
     * @throws WorkflowException user taking action is not in workgroup or did not take workgroup authority
     */
    public void releaseWorkgroupAuthority(String annotation, 
                                          WorkgroupIdVO workgroupId)
                                   throws WorkflowException {
        try {
            createDocumentIfNeccessary();
            routeHeader = getWorkflowDocumentActions()
                              .releaseWorkgroupAuthority(userId, 
                                                         getRouteHeader(), 
                                                         workgroupId, 
                                                         annotation);
        } catch (Exception e) {
            throw handleException(e);
        }
    }

    /**
     * Returns names of all active nodes the document is currently at.
     * 
     * @return
     * @throws WorkflowException
     */
    public String[] getNodeNames() throws WorkflowException {
        try {
            RouteNodeInstanceVO[] activeNodeInstances = 
                    getWorkflowUtility()
                        .getActiveNodeInstances(getRouteHeaderId());
            String[] nodeNames = new String[((activeNodeInstances == null)                                 
                                             ? 0 : activeNodeInstances.length)];

            for (int index = 0; index < activeNodeInstances.length; index++) {
                nodeNames[index] = activeNodeInstances[index].getName();
            }

            return nodeNames;
        } catch (Exception e) {
            throw handleException(e);
        }
    }

    public void returnToPreviousNode(String annotation, String nodeName)
                              throws WorkflowException {
        ReturnPointVO returnPoint = new ReturnPointVO(nodeName);
        returnToPreviousNode(annotation, returnPoint);
    }

    public void returnToPreviousNode(String annotation, 
                                     ReturnPointVO returnPoint)
                              throws WorkflowException {
        try {
            createDocumentIfNeccessary();
            routeHeader = getWorkflowDocumentActions()
                              .returnDocumentToPreviousNode(userId, 
                                                            getRouteHeader(), 
                                                            returnPoint, 
                                                            annotation);
        } catch (Exception e) {
            throw handleException(e);
        }
    }

    /**
     * Moves the document from a current node in it's route to another node.
     */
    public void moveDocument(MovePointVO movePoint, String annotation)
                      throws WorkflowException {
        try {
            createDocumentIfNeccessary();
            routeHeader = getWorkflowDocumentActions()
                              .moveDocument(userId, getRouteHeader(), movePoint, 
                                            annotation);
        } catch (Exception e) {
            throw handleException(e);
        }
    }

    public RouteNodeInstanceVO[] getRouteNodeInstances()
                                                throws WorkflowException {
        try {
            return getWorkflowUtility()
                       .getDocumentRouteNodeInstances(getRouteHeaderId());
        } catch (Exception e) {
            throw handleException(e);
        }
    }

    /**
     * Returns Array of Route Nodes Names that can be safely returned to using the 'returnToPreviousXXX' methods.
     * Names are sorted in reverse chronological order. 
     * 
     * @return
     * @throws WorkflowException
     */
    public String[] getPreviousNodeNames() throws WorkflowException {
        try {
            return getWorkflowUtility()
                       .getPreviousRouteNodeNames(getRouteHeaderId());
        } catch (Exception e) {
            throw new WorkflowException(e);
        }
    }

    public DocumentDetailVO getDetail() throws WorkflowException {
        try {
            return getWorkflowUtility().getDocumentDetail(getRouteHeaderId());
        } catch (Exception e) {
            throw handleException(e);
        }
    }

    // DEPRECATED: as of Workflow 2.0

    /**
     * @deprecated use getRouteHeader.getInitiator
     */
    public String getInitiatorNetworkId() {
        if (routeHeader.getInitiator() != null) {
            return routeHeader.getInitiator().getNetworkId();
        } else {
            return "";
        }
    }

    // DEPRECATED: as of Workflow 2.1

    /**
     * @deprecated use blanketApprove(String annotation, String nodeName) instead
     */
    public void blanketApprove(String annotation, Integer routeLevel)
                        throws WorkflowException {
        try {
            createDocumentIfNeccessary();
            routeHeader = getWorkflowDocumentActions()
                              .blanketApproval(userId, getRouteHeader(), 
                                               annotation, routeLevel);
        } catch (Exception e) {
            throw handleException(e);
        }
    }

    /**
     * @deprecated use getNodeNames() instead
     */
    public Integer getDocRouteLevel() {
        return routeHeader.getDocRouteLevel();
    }

    /**
     * TODO this method still needs to be updated to work properly for Workflow 2.1
     * it would probably be easier to just put this info on bean from the server
     * 
     * @deprecated use getNodeNames() instead
     */
    public String getDocRouteLevelName() throws WorkflowException {
        try {
            if (getDocumentType() == null) {
                throw new DocumentTypeNotFoundException(
                        "Document Type Name is null");
            }

            RouteTemplateEntryVO[] routeLevels = getWorkflowUtility()
                                                     .getDocRoute(getDocumentType());

            for (int i = 0; i < routeLevels.length; i++) {
                if (routeLevels[i].getRouteLevel().equals(getDocRouteLevel())) {
                    return routeLevels[i].getRouteLevelName();
                }
            }
        } catch (Exception e) {
            throw handleException(e);
        }

        throw new WorkflowException("Did not find a route level");
    }

    /**
     * TODO this method still needs to be updated to work properly for Workflow 2.1
     * it would probably be easier to just put this info on bean from the server
     * 
     * @deprecated use getRouteMethodNames instead
     */
    public String getRouteMethodName() throws WorkflowException {
        if (getDocumentType() == null) {
            throw new WorkflowException("Document Type Name is null");
        }

        try {
            RouteTemplateEntryVO[] routeLevels = getWorkflowUtility()
                                                     .getDocRoute(getDocumentType());

            for (int i = 0; i < routeLevels.length; i++) {
                if (routeLevels[i].getRouteLevel().equals(getDocRouteLevel())) {
                    return routeLevels[i].getRouteMethodName();
                }
            }
        } catch (Exception e) {
            throw handleException(e);
        }

        throw new WorkflowException("Did not find a route level");
    }

    /**
     * @deprecated use returnToPreviousNode(String annotation, String nodeName) instead
     */
    public void returnToPreviousRouteLevel(String annotation, 
                                           Integer destRouteLevel)
                                    throws WorkflowException {
        try {
            createDocumentIfNeccessary();
            getWorkflowDocumentActions()
                .returnDocumentToPreviousRouteLevel(userId, getRouteHeader(), 
                                                    destRouteLevel, annotation);
        } catch (Exception e) {
            throw handleException(e);
        }
    }

    public List getNoteList() {
        List notesList = new ArrayList();
        NoteVO[] notes = routeHeader.getNotes();

        if (notes != null) {
            for (int i = 0; i < notes.length; i++) {
                if (!isDeletedNote(notes[i])) {
                    notesList.add(notes[i]);
                }
            }
        }

        return notesList;
    }

    public void deleteNote(NoteVO noteVO) {
        if ((noteVO != null) && (noteVO.getNoteId() != null)) {
            NoteVO noteToDelete = new NoteVO();
            noteToDelete.setNoteId(new Long(noteVO.getNoteId().longValue()));


            /*noteToDelete.setRouteHeaderId(noteVO.getRouteHeaderId());
            noteToDelete.setNoteAuthorWorkflowId(noteVO.getNoteAuthorWorkflowId());
            noteToDelete.setNoteCreateDate(noteVO.getNoteCreateDate());
            noteToDelete.setNoteText(noteVO.getNoteText());
            noteToDelete.setLockVerNbr(noteVO.getLockVerNbr());*/
            increaseNotesToDeleteArraySizeByOne();
            routeHeader.getNotesToDelete()[routeHeader.getNotesToDelete().length - 1] = noteToDelete;
        }
    }

    public void updateNote(NoteVO noteVO) {
        boolean isUpdateNote = false;

        if (noteVO != null) {
            NoteVO[] notes = routeHeader.getNotes();
            NoteVO copyNote = new NoteVO();

            if (noteVO.getNoteId() != null) {
                copyNote.setNoteId(new Long(noteVO.getNoteId().longValue()));
            }

            if (noteVO.getRouteHeaderId() != null) {
                copyNote.setRouteHeaderId(
                        new Long(noteVO.getRouteHeaderId().longValue()));
            } else {
                copyNote.setRouteHeaderId(routeHeader.getRouteHeaderId());
            }

            if (noteVO.getNoteAuthorWorkflowId() != null) {
                copyNote.setNoteAuthorWorkflowId(
                        new String(noteVO.getNoteAuthorWorkflowId()));
            } else {
                copyNote.setNoteAuthorWorkflowId(userId.toString());
            }

            if (noteVO.getNoteCreateDate() != null) {
                Calendar cal = Calendar.getInstance();
                cal.setTimeInMillis(noteVO.getNoteCreateDate()
                                          .getTimeInMillis());
                copyNote.setNoteCreateDate(cal);
            } else {
                copyNote.setNoteCreateDate(Calendar.getInstance());
            }

            if (noteVO.getNoteText() != null) {
                copyNote.setNoteText(new String(noteVO.getNoteText()));
            }

            if (noteVO.getLockVerNbr() != null) {
                copyNote.setLockVerNbr(
                        new Integer(noteVO.getLockVerNbr().intValue()));
            }

            if (notes != null) {
                for (int i = 0; i < notes.length; i++) {
                    if ((notes[i].getNoteId() != null) && 
                            notes[i].getNoteId().equals(copyNote.getNoteId())) {
                        notes[i] = copyNote;
                        isUpdateNote = true;

                        break;
                    }
                }
            }

            // add new note to the notes array
            if (!isUpdateNote) {
                copyNote.setNoteId(null);
                increaseNotesArraySizeByOne();
                routeHeader.getNotes()[routeHeader.getNotes().length - 1] = copyNote;
            }
        }
    }

    private boolean isDeletedNote(NoteVO noteVO) {
        NoteVO[] notesToDelete = routeHeader.getNotesToDelete();

        if (notesToDelete != null) {
            for (int i = 0; i < notesToDelete.length; i++) {
                if (notesToDelete[i].getNoteId().equals(noteVO.getNoteId())) {
                    return true;
                }
            }
        }

        return false;
    }

    private void increaseNotesArraySizeByOne() {
        NoteVO[] tempArray;
        NoteVO[] notes = routeHeader.getNotes();

        if (notes == null) {
            tempArray = new NoteVO[1];
        } else {
            tempArray = new NoteVO[notes.length + 1];

            for (int i = 0; i < notes.length; i++) {
                tempArray[i] = notes[i];
            }
        }

        routeHeader.setNotes(tempArray);
    }

    private void increaseNotesToDeleteArraySizeByOne() {
        NoteVO[] tempArray;
        NoteVO[] notesToDelete = routeHeader.getNotesToDelete();

        if (notesToDelete == null) {
            tempArray = new NoteVO[1];
        } else {
            tempArray = new NoteVO[notesToDelete.length + 1];

            for (int i = 0; i < notesToDelete.length; i++) {
                tempArray[i] = notesToDelete[i];
            }
        }

        routeHeader.setNotesToDelete(tempArray);
    }
}