
/*
 * Copyright (c) 2004, 2005, 2006 Trustees of Indiana University and Cornell University.
 *
 * Licensed under the Educational Community License Version 1.0 (the "License"); By obtaining,
 * using and/or copying this Original Work, you agree that you have read, understand, and will
 * comply with the terms and conditions of the Educational Community License.
 *
 * For the full text of the license, see the LICENSE.txt file or visit:
 * 
 * http://kew.indiana.edu/workflow/LICENSE.txt
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING
 * BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE
 * AND NONINFRINGEMENT.
 * IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES
 * OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 */
            
package edu.iu.uis.eden.applicationconstants;

import edu.iu.uis.eden.util.Utilities;


public class ApplicationConstant {
    private String applicationConstantName;
    private String applicationConstantValue;
    private Integer lockVerNbr;

    /**
     * @return Returns the applicationConstantName.
     */
    public String getApplicationConstantName() {
        return applicationConstantName;
    }

    /**
     * @param applicationConstantName
     *            The applicationConstantName to set.
     */
    public void setApplicationConstantName(String applicationConstantName) {
        this.applicationConstantName = applicationConstantName;
    }

    /**
     * @return Returns the applicationConstantValue.
     */
    public String getApplicationConstantValue() {
        return applicationConstantValue;
    }

    /**
     * @param applicationConstantValue
     *            The applicationConstantValue to set.
     */
    public void setApplicationConstantValue(String applicationConstantValue) {
        this.applicationConstantValue = applicationConstantValue;
    }

    /**
     * @return Returns the lockVerNbr.
     */
    public Integer getLockVerNbr() {
        return lockVerNbr;
    }

    /**
     * @param lockVerNbr
     *            The lockVerNbr to set.
     */
    public void setLockVerNbr(Integer lockVerNbr) {
        this.lockVerNbr = lockVerNbr;
    }

    public int hashCode() {
        return (applicationConstantName + ":" + applicationConstantValue).hashCode();
    }

    public boolean equals(Object o) {
        if (!(o instanceof ApplicationConstant)) {
            return false;
        }

        ApplicationConstant ac = (ApplicationConstant) o;

        return Utilities.equals(applicationConstantName, 
                                ac.applicationConstantName) && 
               Utilities.equals(applicationConstantValue, 
                                ac.applicationConstantValue);
    }

    public String toString() {
        return "[ApplicationConstant: name=" + applicationConstantName + 
               ", value=" + applicationConstantValue + ", lockVerNbr=" + 
               lockVerNbr + "]";
    }
}