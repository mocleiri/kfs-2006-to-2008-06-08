
/*
 * Copyright (c) 2004, 2005, 2006 Trustees of Indiana University and Cornell University.
 *
 * Licensed under the Educational Community License Version 1.0 (the "License"); By obtaining,
 * using and/or copying this Original Work, you agree that you have read, understand, and will
 * comply with the terms and conditions of the Educational Community License.
 *
 * For the full text of the license, see the LICENSE.txt file or visit:
 * 
 * http://kew.indiana.edu/workflow/LICENSE.txt
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING
 * BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE
 * AND NONINFRINGEMENT.
 * IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES
 * OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 */
            
package edu.iu.uis.eden.applicationconstants.web;

import edu.iu.uis.eden.applicationconstants.ApplicationConstant;

import java.util.List;

import org.apache.struts.action.ActionForm;


public class ApplicationConstantsForm extends ActionForm {
    private static final long serialVersionUID = -8441254491845120955L;
    private List applicationConstants;
    private ApplicationConstant constant = new ApplicationConstant();
    private String methodToCall = "";

    public List getApplicationConstants() {
        return applicationConstants;
    }

    public void setApplicationConstants(List applicationConstants) {
        this.applicationConstants = applicationConstants;
    }

    public ApplicationConstant getConstant() {
        return constant;
    }

    public void setConstant(ApplicationConstant constant) {
        this.constant = constant;
    }

    public void setApplicationConstantName(String applicationConstantName) {
        constant.setApplicationConstantName(applicationConstantName);
    }

    public void setApplicationConstantValue(String applicationConstantValue) {
        constant.setApplicationConstantValue(applicationConstantValue);
    }

    public String getMethodToCall() {
        return methodToCall;
    }

    public void setMethodToCall(String methodToCall) {
        this.methodToCall = methodToCall;
    }
}