
/*
 * Copyright (c) 2004, 2005, 2006 Trustees of Indiana University and Cornell University.
 *
 * Licensed under the Educational Community License Version 1.0 (the "License"); By obtaining,
 * using and/or copying this Original Work, you agree that you have read, understand, and will
 * comply with the terms and conditions of the Educational Community License.
 *
 * For the full text of the license, see the LICENSE.txt file or visit:
 * 
 * http://kew.indiana.edu/workflow/LICENSE.txt
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING
 * BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE
 * AND NONINFRINGEMENT.
 * IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES
 * OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 */
            
package edu.iu.uis.eden.applicationconstants.web;

import edu.iu.uis.eden.SpringServiceLocator;
import edu.iu.uis.eden.WorkflowServiceErrorException;
import edu.iu.uis.eden.applicationconstants.ApplicationConstant;
import edu.iu.uis.eden.applicationconstants.ApplicationConstantsService;
import edu.iu.uis.eden.web.WorkflowAction;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.action.ActionMessages;


public class ApplicationConstantsAction extends WorkflowAction {
    public ActionForward start(ActionMapping mapping, ActionForm form, 
                               HttpServletRequest request, 
                               HttpServletResponse response)
                        throws IOException, ServletException {
        return mapping.findForward("start");
    }

    public ActionForward cancel(ActionMapping mapping, ActionForm form, 
                                HttpServletRequest request, 
                                HttpServletResponse response)
                         throws IOException, ServletException {
        return mapping.findForward("restart");
    }

    public ActionForward clear(ActionMapping mapping, ActionForm form, 
                               HttpServletRequest request, 
                               HttpServletResponse response)
                        throws IOException, ServletException {
        ApplicationConstantsForm applicationConstantsForm = 
                (ApplicationConstantsForm) form;
        clearFields(applicationConstantsForm);

        return mapping.findForward("restart");
    }

    public ActionForward create(ActionMapping mapping, ActionForm form, 
                                HttpServletRequest request, 
                                HttpServletResponse response)
                         throws IOException, ServletException {
        ApplicationConstantsForm applicationConstantsForm = 
                (ApplicationConstantsForm) form;

        try {
            getService().save(applicationConstantsForm.getConstant());
        } catch (WorkflowServiceErrorException e) {
            applicationConstantsForm.setMethodToCall("create");
            throw e;
        }

        return mapping.findForward("restart");
    }

    public ActionForward edit(ActionMapping mapping, ActionForm form, 
                              HttpServletRequest request, 
                              HttpServletResponse response)
                       throws IOException, ServletException {
        ApplicationConstantsForm applicationConstantsForm = 
                (ApplicationConstantsForm) form;
        ApplicationConstant constant = getService()
                                           .findByName(request.getParameter(
                                                               "applicationConstantName"));
        applicationConstantsForm.setApplicationConstantName(
                constant.getApplicationConstantName());
        applicationConstantsForm.setApplicationConstantValue(
                constant.getApplicationConstantValue());

        return mapping.findForward("edit");
    }

    public ActionForward save(ActionMapping mapping, ActionForm form, 
                              HttpServletRequest request, 
                              HttpServletResponse response)
                       throws IOException, ServletException {
        ApplicationConstantsForm applicationConstantsForm = 
                (ApplicationConstantsForm) form;
        ApplicationConstant constant = getService()
                                           .findByName(applicationConstantsForm.getConstant()
                                                                               .getApplicationConstantName());
        constant.setApplicationConstantValue(applicationConstantsForm.getConstant()
                                                                     .getApplicationConstantValue());

        try {
            getService().save(constant);
        } catch (WorkflowServiceErrorException e) {
            applicationConstantsForm.setMethodToCall("edit");
            throw e;
        }

        return mapping.findForward("restart");
    }

    public ActionForward delete(ActionMapping mapping, ActionForm form, 
                                HttpServletRequest request, 
                                HttpServletResponse response)
                         throws IOException, ServletException {
        ApplicationConstantsForm applicationConstantsForm = 
                (ApplicationConstantsForm) form;
        getService().delete(applicationConstantsForm.getConstant());

        return mapping.findForward("restart");
    }

    public ActionForward confirmDelete(ActionMapping mapping, ActionForm form, 
                                       HttpServletRequest request, 
                                       HttpServletResponse response)
                                throws IOException, ServletException {
        ApplicationConstantsForm applicationConstantsForm = 
                (ApplicationConstantsForm) form;
        ApplicationConstant constant = getService()
                                           .findByName(request.getParameter(
                                                               "applicationConstantName"));
        applicationConstantsForm.setConstant(constant);

        return mapping.findForward("confirmDelete");
    }

    public ActionMessages establishRequiredState(HttpServletRequest request, 
                                                 ActionForm form)
                                          throws Exception {
        ApplicationConstantsService service = (ApplicationConstantsService) SpringServiceLocator.getService(
                                                      SpringServiceLocator.APPLICATION_CONSTANTS_SRV);
        ApplicationConstantsForm applicationConstantsForm = 
                (ApplicationConstantsForm) form;
        applicationConstantsForm.setApplicationConstants(service.findAll());

        return null;
    }

    private ApplicationConstantsService getService() {
        return (ApplicationConstantsService) SpringServiceLocator.getService(
                       SpringServiceLocator.APPLICATION_CONSTANTS_SRV);
    }

    public ActionMessages establishFinalState(HttpServletRequest request, 
                                              ActionForm form) {
        return null;
    }

    private void clearFields(ApplicationConstantsForm applicationConstantsForm) {
        applicationConstantsForm.getConstant().setApplicationConstantName(null);
        applicationConstantsForm.getConstant()
                        .setApplicationConstantValue(null);
    }
}