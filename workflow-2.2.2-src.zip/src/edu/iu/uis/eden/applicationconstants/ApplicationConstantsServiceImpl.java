
/*
 * Copyright (c) 2004, 2005, 2006 Trustees of Indiana University and Cornell University.
 *
 * Licensed under the Educational Community License Version 1.0 (the "License"); By obtaining,
 * using and/or copying this Original Work, you agree that you have read, understand, and will
 * comply with the terms and conditions of the Educational Community License.
 *
 * For the full text of the license, see the LICENSE.txt file or visit:
 * 
 * http://kew.indiana.edu/workflow/LICENSE.txt
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING
 * BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE
 * AND NONINFRINGEMENT.
 * IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES
 * OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 */
            
package edu.iu.uis.eden.applicationconstants;

import edu.iu.uis.eden.EdenConstants;
import edu.iu.uis.eden.WorkflowServiceErrorException;
import edu.iu.uis.eden.WorkflowServiceErrorImpl;
import edu.iu.uis.eden.applicationconstants.dao.ApplicationConstantsDAO;
import edu.iu.uis.eden.applicationconstants.xml.ApplicationConstantsXmlParser;
import edu.iu.uis.eden.user.WorkflowUser;

import java.io.InputStream;

import java.util.ArrayList;
import java.util.List;


public class ApplicationConstantsServiceImpl
    implements ApplicationConstantsService {
    private static final org.apache.log4j.Logger LOG = 
            org.apache.log4j.Logger.getLogger(
                    ApplicationConstantsServiceImpl.class);
    private static final String NAME_EMPTY = "applicationconstants.error.emptyname";
    private static final String MANE_HAS_WHITE_SPACE = 
            "applicationconstants.error.namehaswhitespace";
    private static final String VALUE_EMPTY = "applicationconstants.error.emptyvalue";
    private ApplicationConstantsDAO applicationConstantsDAO;

    public void save(ApplicationConstant applicationConstant) {
        validateApplicationConstant(applicationConstant);
        getApplicationConstantsDAO().saveConstant(applicationConstant);
    }

    public void delete(ApplicationConstant applicationConstant) {
        getApplicationConstantsDAO().deleteConstant(applicationConstant);
    }

    public ApplicationConstant findByName(String applicationConstantName) {
        return getApplicationConstantsDAO().findByName(applicationConstantName);
    }

    public List findAll() {
        return getApplicationConstantsDAO().findAll();
    }

    /**
     * @return
     */
    public ApplicationConstantsDAO getApplicationConstantsDAO() {
        return applicationConstantsDAO;
    }

    /**
     * @param historyDAO
     */
    public void setApplicationConstantsDAO(ApplicationConstantsDAO historyDAO) {
        applicationConstantsDAO = historyDAO;
    }

    private void validateApplicationConstant(ApplicationConstant constant) {
        LOG.debug("Enter validateApplicationConstant(..)...");

        List errors = new ArrayList();

        if ((constant.getApplicationConstantName() == null) || 
                "".equals(constant.getApplicationConstantName().trim())) {
            errors.add(new WorkflowServiceErrorImpl(
                               "Application constant name is empty.", 
                               NAME_EMPTY));
        } else {
            constant.setApplicationConstantName(constant.getApplicationConstantName()
                                                        .trim());
        }

        if ((constant.getApplicationConstantName() != null) && 
                (constant.getApplicationConstantName().trim().indexOf(" ") > 0)) {
            errors.add(new WorkflowServiceErrorImpl(
                               "Application constant name has white space(s)", 
                               MANE_HAS_WHITE_SPACE));
        }

        if ((constant.getApplicationConstantValue() == null) || 
                "".equals(constant.getApplicationConstantValue().trim())) {
            errors.add(new WorkflowServiceErrorImpl(
                               "Application constant value is empty.", 
                               VALUE_EMPTY));
        } else {
            constant.setApplicationConstantValue(constant.getApplicationConstantValue()
                                                         .trim());
        }

        LOG.debug("Exit validateApplicationConstant(..) ");

        if (!errors.isEmpty()) {
            throw new WorkflowServiceErrorException(
                    "Application Constant Validation Error", errors);
        }
    }

    public void loadXml(InputStream inputStream, WorkflowUser user) {
        ApplicationConstantsXmlParser parser = new ApplicationConstantsXmlParser();

        try {
            parser.parseAppConstEntries(inputStream);
        } catch (Exception e) {
            WorkflowServiceErrorException wsee = new WorkflowServiceErrorException(
                                                         "Error parsing Application Constants  XML file", 
                                                         new WorkflowServiceErrorImpl(
                                                                 "Error parsing XML file.", 
                                                                 EdenConstants.XML_FILE_PARSE_ERROR));
            wsee.initCause(e);
            throw wsee;
        }
    }
}