
/*
 * Copyright (c) 2004, 2005, 2006 Trustees of Indiana University and Cornell University.
 *
 * Licensed under the Educational Community License Version 1.0 (the "License"); By obtaining,
 * using and/or copying this Original Work, you agree that you have read, understand, and will
 * comply with the terms and conditions of the Educational Community License.
 *
 * For the full text of the license, see the LICENSE.txt file or visit:
 * 
 * http://kew.indiana.edu/workflow/LICENSE.txt
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING
 * BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE
 * AND NONINFRINGEMENT.
 * IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES
 * OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 */
            
package edu.iu.uis.eden.applicationconstants.xml;

import edu.iu.uis.eden.SpringServiceLocator;
import edu.iu.uis.eden.applicationconstants.ApplicationConstant;
import edu.iu.uis.eden.cache.ApplicationConstantsCache;
import edu.iu.uis.eden.util.Utilities;

import java.io.IOException;
import java.io.InputStream;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.FactoryConfigurationError;
import javax.xml.parsers.ParserConfigurationException;

import org.apache.log4j.Logger;

import org.jdom.Document;
import org.jdom.Element;
import org.jdom.JDOMException;
import org.jdom.Namespace;

import org.jdom.input.DOMBuilder;

import org.xml.sax.SAXException;


/*
 * A sax parser for application constant data.  The xml file format is:
 * <ApplicationConstants>
 *   <ApplicationConstant>
 *          <ConstantName>name 1</ConstantName>
 *                 <ConstantValue>value 1</ConstantValue>
 *   </ApplicationConstant>
 * 
 *  <ApplicationConstant>
 *          <ConstantName>name 2</ConstantName>
 *                 <ConstantValue>value 2</ConstantValue>
 *   </ApplicationConstant>
 *   ...
 * </ApplicationConstants>
 * 
 */
public class ApplicationConstantsXmlParser {
    private static final Logger LOG = Logger.getLogger(
                                              ApplicationConstantsXmlParser.class);
    private static final Namespace NAMESPACE = Namespace.getNamespace("", 
                                                                      "ns:workflow/ApplicationConstants");
    private static final String APP_CONSTANTS_ELEMENT = "ApplicationConstants";
    private static final String APP_CONSTANT_ELEMENT = "ApplicationConstant";
    private static final String CONSTANT_NAME_ELEMENT = "ConstantName";
    private static final String CONSTANT_VALUE_ELEMENT = "ConstantValue";

    public List parseAppConstEntries(InputStream file)
                              throws JDOMException, SAXException, IOException, 
                                     ParserConfigurationException, 
                                     FactoryConfigurationError {
        List constEntries = new ArrayList();

        org.w3c.dom.Document w3cDocument = DocumentBuilderFactory.newInstance()
                                                                 .newDocumentBuilder()
                                                                 .parse(file);
        Document document = new DOMBuilder().build(w3cDocument);
        Element root = document.getRootElement();

        for (Iterator constantsIt = root.getChildren(APP_CONSTANTS_ELEMENT, 
                                                     NAMESPACE).iterator();
             constantsIt.hasNext();) {
            Element constantsElement = (Element) constantsIt.next();

            for (Iterator iterator = constantsElement.getChildren(
                                             APP_CONSTANT_ELEMENT, NAMESPACE)
                                                     .iterator();
                 iterator.hasNext();) {
                Element constElement = (Element) iterator.next();

                String name = constElement.getChildTextTrim(
                                      CONSTANT_NAME_ELEMENT, NAMESPACE);
                String value = constElement.getChildTextTrim(
                                       CONSTANT_VALUE_ELEMENT, NAMESPACE);

                LOG.info("Processing constant: " + name);

                ApplicationConstant constant = null;
                ;

                try {
                    LOG.debug("Looking up Application Constant: " + name);
                    constant = SpringServiceLocator.getApplicationConstantsService()
                                                   .findByName(name);

                    if (constant != null) {
                        LOG.debug("Found existing Application Constant: " + 
                                  name);
                        constant.setApplicationConstantValue(value);
                    } else {
                        constant = new ApplicationConstant();
                        constant.setApplicationConstantName(name);
                        constant.setApplicationConstantValue(value);
                    }

                    LOG.debug("Saving Application Constant: " + 
                              constant.getApplicationConstantName());
                    SpringServiceLocator.getApplicationConstantsService()
                                        .save(constant);
                } catch (Exception e) {
                    LOG.error("error saving Application Constant", e);
                }


                // NOTE: should we move this into the try/catch block, or do we want to preserve a constant
                // in memory even when it has not been persisted successfully?
                constEntries.add(constant);
            }
        }

        ((ApplicationConstantsCache) Utilities.getCache()
                                              .getCachedObjectById(ApplicationConstantsCache.APPLICATION_CONSTANTS_CACHE_ID)).reload();

        return constEntries;
    }
}