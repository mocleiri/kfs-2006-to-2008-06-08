
/*
 * Copyright (c) 2004, 2005, 2006 Trustees of Indiana University and Cornell University.
 *
 * Licensed under the Educational Community License Version 1.0 (the "License"); By obtaining,
 * using and/or copying this Original Work, you agree that you have read, understand, and will
 * comply with the terms and conditions of the Educational Community License.
 *
 * For the full text of the license, see the LICENSE.txt file or visit:
 * 
 * http://kew.indiana.edu/workflow/LICENSE.txt
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING
 * BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE
 * AND NONINFRINGEMENT.
 * IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES
 * OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 */
            
package edu.iu.uis.eden.actiontaken;

import edu.iu.uis.eden.EdenConstants;
import edu.iu.uis.eden.SpringServiceLocator;
import edu.iu.uis.eden.WorkflowPersistable;
import edu.iu.uis.eden.actionrequests.ActionRequestService;
import edu.iu.uis.eden.exception.EdenUserNotFoundException;
import edu.iu.uis.eden.routeheader.DocumentRouteHeaderValue;
import edu.iu.uis.eden.user.Recipient;
import edu.iu.uis.eden.user.UserService;
import edu.iu.uis.eden.user.WorkflowUser;
import edu.iu.uis.eden.user.WorkflowUserId;
import edu.iu.uis.eden.util.CodeTranslator;
import edu.iu.uis.eden.workgroup.WorkflowGroupId;
import edu.iu.uis.eden.workgroup.Workgroup;
import edu.iu.uis.eden.workgroup.WorkgroupService;

import java.sql.Timestamp;

import java.util.ArrayList;
import java.util.Collection;

import org.apache.commons.beanutils.BeanUtils;


public class ActionTakenValue implements WorkflowPersistable {
    /**
         * 
         */
    private static final long serialVersionUID = -81505450567067594L;
    private Long actionTakenId;
    private Long routeHeaderId;
    private String actionTaken;
    private Timestamp actionDate;
    private String annotation = "";
    private Integer docVersion;
    private Integer lockVerNbr;
    private String workflowId;
    private String delegatorWorkflowId;
    private Long delegatorWorkgroupId;
    private DocumentRouteHeaderValue routeHeader;
    private Collection actionRequests;
    private Boolean currentIndicator = new Boolean(true);
    private String actionDateString;

    public WorkflowUser getWorkflowUser() throws EdenUserNotFoundException {
        return getWorkflowUserForWorkflowId(workflowId);
    }

    public WorkflowUser getDelegatorUser() throws EdenUserNotFoundException {
        return getWorkflowUserForWorkflowId(delegatorWorkflowId);
    }

    public Workgroup getDelegatorWorkgroup() {
        return getWorkgroupService()
                   .getWorkgroup(new WorkflowGroupId(delegatorWorkgroupId));
    }

    public void setDelegator(Recipient recipient) {
        if (recipient instanceof WorkflowUser) {
            setDelegatorWorkflowId(((WorkflowUser) recipient).getWorkflowUserId()
                                                           .getWorkflowId());
        } else if (recipient instanceof Workgroup) {
            setDelegatorWorkgroupId(((Workgroup) recipient).getWorkflowGroupId()
                                                         .getGroupId());
        } else {
            setDelegatorWorkflowId(null);
            setDelegatorWorkgroupId(null);
        }
    }

    public boolean isForDelegator() {
        return (getDelegatorWorkflowId() != null) || 
               (getDelegatorWorkgroupId() != null);
    }

    public String getDelegatorDisplayName() throws EdenUserNotFoundException {
        if (!isForDelegator()) {
            return "";
        }

        if (getDelegatorWorkflowId() != null) {
            return getDelegatorUser().getDisplayName();
        } else {
            return getDelegatorWorkgroup().getGroupNameId().getNameId();
        }
    }

    private WorkflowUser getWorkflowUserForWorkflowId(String id)
                                               throws EdenUserNotFoundException {
        WorkflowUser w = null;

        if ((id != null) && (id.trim().length() > 0)) {
            w = getUserService().getWorkflowUser(new WorkflowUserId(id));
        }

        return w;
    }

    public String getActionTakenLabel() {
        return CodeTranslator.getActionTakenLabel(actionTaken);
    }

    public Collection getActionRequests() {
        if (actionRequests == null) {
            setActionRequests(new ArrayList());
        }

        return actionRequests;
    }

    public void setActionRequests(Collection actionRequests) {
        this.actionRequests = actionRequests;
    }

    public DocumentRouteHeaderValue getRouteHeader() {
        return routeHeader;
    }

    public void setRouteHeader(DocumentRouteHeaderValue routeHeader) {
        this.routeHeader = routeHeader;
    }

    public Timestamp getActionDate() {
        return actionDate;
    }

    public void setActionDate(Timestamp actionDate) {
        this.actionDate = actionDate;
    }

    public String getActionTaken() {
        return actionTaken;
    }

    public void setActionTaken(String actionTaken) {
        this.actionTaken = actionTaken;
    }

    public Long getActionTakenId() {
        return actionTakenId;
    }

    public void setActionTakenId(Long actionTakenId) {
        this.actionTakenId = actionTakenId;
    }

    public String getAnnotation() {
        return annotation;
    }

    public void setAnnotation(String annotation) {
        this.annotation = annotation;
    }

    public String getDelegatorWorkflowId() {
        return delegatorWorkflowId;
    }

    public void setDelegatorWorkflowId(String delegatorWorkflowId) {
        this.delegatorWorkflowId = delegatorWorkflowId;
    }

    public Long getDelegatorWorkgroupId() {
        return delegatorWorkgroupId;
    }

    public void setDelegatorWorkgroupId(Long delegatorWorkgroupId) {
        this.delegatorWorkgroupId = delegatorWorkgroupId;
    }

    public Integer getDocVersion() {
        return docVersion;
    }

    public void setDocVersion(Integer docVersion) {
        this.docVersion = docVersion;
    }

    public Integer getLockVerNbr() {
        return lockVerNbr;
    }

    public void setLockVerNbr(Integer lockVerNbr) {
        this.lockVerNbr = lockVerNbr;
    }

    public Long getRouteHeaderId() {
        return routeHeaderId;
    }

    public void setRouteHeaderId(Long routeHeaderId) {
        this.routeHeaderId = routeHeaderId;
    }

    public String getWorkflowId() {
        return workflowId;
    }

    public void setWorkflowId(String workflowId) {
        this.workflowId = workflowId;
    }

    public Boolean getCurrentIndicator() {
        return currentIndicator;
    }

    public void setCurrentIndicator(Boolean currentIndicator) {
        this.currentIndicator = currentIndicator;
    }

    public Collection getRootActionRequests() {
        return getActionRequestService().getRootRequests(getActionRequests());
    }

    public Object copy(boolean preserveKeys) {
        ActionTakenValue clone = new ActionTakenValue();

        try {
            BeanUtils.copyProperties(clone, this);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }

        if (!preserveKeys) {
            clone.setActionTakenId(null);
        }

        return clone;
    }

    private UserService getUserService() {
        return (UserService) SpringServiceLocator.getService(
                       SpringServiceLocator.USER_SERVICE);
    }

    private WorkgroupService getWorkgroupService() {
        return (WorkgroupService) SpringServiceLocator.getService(
                       SpringServiceLocator.WORKGROUP_SRV);
    }

    private ActionRequestService getActionRequestService() {
        return (ActionRequestService) SpringServiceLocator.getService(
                       SpringServiceLocator.ACTION_REQUEST_SRV);
    }

    public String getActionDateString() {
        if ((actionDateString == null) || 
                actionDateString.trim().equals("")) {
            return EdenConstants.getDefaultDateFormat().format(getActionDate());
        } else {
            return actionDateString;
        }
    }

    public void setActionDateString(String actionDateString) {
        this.actionDateString = actionDateString;
    }

    public boolean isApproval() {
        return EdenConstants.ACTION_TAKEN_APPROVED_CD.equals(getActionTaken());
    }

    public boolean isCompletion() {
        return EdenConstants.ACTION_TAKEN_COMPLETED_CD.equals(getActionTaken());
    }
}