
/*
 * Copyright (c) 2004, 2005, 2006 Trustees of Indiana University and Cornell University.
 *
 * Licensed under the Educational Community License Version 1.0 (the "License"); By obtaining,
 * using and/or copying this Original Work, you agree that you have read, understand, and will
 * comply with the terms and conditions of the Educational Community License.
 *
 * For the full text of the license, see the LICENSE.txt file or visit:
 * 
 * http://kew.indiana.edu/workflow/LICENSE.txt
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING
 * BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE
 * AND NONINFRINGEMENT.
 * IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES
 * OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 */
            
package edu.iu.uis.eden.actiontaken.dao;

import edu.iu.uis.eden.actionrequests.ActionRequestValue;
import edu.iu.uis.eden.actiontaken.ActionTakenValue;

import java.sql.Timestamp;

import java.util.Collection;
import java.util.List;

import org.apache.ojb.broker.query.Criteria;
import org.apache.ojb.broker.query.QueryByCriteria;

import org.springframework.orm.ojb.PersistenceBrokerTemplate;


public class ActionTakenDAOOjbImpl extends PersistenceBrokerTemplate
    implements ActionTakenDAO {
    private static final org.apache.log4j.Logger LOG = 
            org.apache.log4j.Logger.getLogger(ActionTakenDAOOjbImpl.class);

    public ActionTakenValue load(Long id) {
        LOG.debug("Loading Action Taken for the given id " + id);

        Criteria crit = new Criteria();
        crit.addEqualTo("actionTakenId", id);

        return (ActionTakenValue) getObjectByQuery(
                       new QueryByCriteria(ActionTakenValue.class, crit));
    }

    public void deleteActionTaken(ActionTakenValue actionTaken) {
        LOG.debug("deleting ActionTaken " + actionTaken.getActionTakenId());
        delete(actionTaken);
    }

    public ActionTakenValue findByActionTakenId(Long actionTakenId) {
        LOG.debug("finding Action Taken by actionTakenId " + actionTakenId);

        Criteria crit = new Criteria();
        crit.addEqualTo("actionTakenId", actionTakenId);
        crit.addEqualTo("currentIndicator", new Boolean(true));

        return (ActionTakenValue) getObjectByQuery(
                       new QueryByCriteria(ActionTakenValue.class, crit));
    }

    public Collection findByDocIdAndAction(Long routeHeaderId, String action) {
        LOG.debug("finding Action Taken by routeHeaderId " + routeHeaderId + 
                  " and action " + action);

        Criteria crit = new Criteria();
        crit.addEqualTo("routeHeaderId", routeHeaderId);
        crit.addEqualTo("actionTaken", action);
        crit.addEqualTo("currentIndicator", new Boolean(true));

        return getCollectionByQuery(
                       new QueryByCriteria(ActionTakenValue.class, crit));
    }

    public Collection findByRouteHeaderId(Long routeHeaderId) {
        LOG.debug("finding Action Takens by routeHeaderId " + routeHeaderId);

        Criteria crit = new Criteria();
        crit.addEqualTo("routeHeaderId", routeHeaderId);
        crit.addEqualTo("currentIndicator", new Boolean(true));

        return getCollectionByQuery(
                       new QueryByCriteria(ActionTakenValue.class, crit));
    }

    public List findByRouteHeaderIdWorkflowId(Long routeHeaderId, 
                                              String workflowId) {
        LOG.debug("finding Action Takens by routeHeaderId " + routeHeaderId + 
                  " and workflowId" + workflowId);

        Criteria crit = new Criteria();
        crit.addEqualTo("routeHeaderId", routeHeaderId);
        crit.addEqualTo("workflowId", workflowId);
        crit.addEqualTo("currentIndicator", new Boolean(true));

        return (List) getCollectionByQuery(
                       new QueryByCriteria(ActionTakenValue.class, crit));
    }

    public List findByRouteHeaderIdIgnoreCurrentInd(Long routeHeaderId) {
        LOG.debug("finding ActionsTaken ignoring currentInd by routeHeaderId:" + 
                  routeHeaderId);

        Criteria crit = new Criteria();
        crit.addEqualTo("routeHeaderId", routeHeaderId);

        return (List) getCollectionByQuery(
                       new QueryByCriteria(ActionTakenValue.class, crit));
    }

    public void saveActionTaken(ActionTakenValue actionTaken) {
        LOG.debug("saving ActionTaken");
        checkNull(actionTaken.getRouteHeaderId(), "Document ID");
        checkNull(actionTaken.getActionTaken(), "action taken code");
        checkNull(actionTaken.getDocVersion(), "doc version");
        checkNull(actionTaken.getWorkflowId(), "user workflowId");

        if (actionTaken.getActionDate() == null) {
            actionTaken.setActionDate(new Timestamp(System.currentTimeMillis()));
        }

        if (actionTaken.getCurrentIndicator() == null) {
            actionTaken.setCurrentIndicator(new Boolean(true));
        }

        LOG.debug("saving ActionTaken: routeHeader " + 
                  actionTaken.getRouteHeaderId() + ", actionTaken " + 
                  actionTaken.getActionTaken() + ", workflowId " + 
                  actionTaken.getWorkflowId());
        store(actionTaken);
    }

    //TODO perhaps runtime isn't the best here, maybe a dao runtime exception
    private void checkNull(Object value, String valueName)
                    throws RuntimeException {
        if (value == null) {
            throw new RuntimeException("Null value for " + valueName);
        }
    }

    public void deleteByRouteHeaderId(Long routeHeaderId) {
        Criteria crit = new Criteria();
        crit.addEqualTo("routeHeaderId", routeHeaderId);
        deleteByQuery(new QueryByCriteria(ActionRequestValue.class, crit));
    }
}