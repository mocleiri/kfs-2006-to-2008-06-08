
/*
 * Copyright (c) 2004, 2005, 2006 Trustees of Indiana University and Cornell University.
 *
 * Licensed under the Educational Community License Version 1.0 (the "License"); By obtaining,
 * using and/or copying this Original Work, you agree that you have read, understand, and will
 * comply with the terms and conditions of the Educational Community License.
 *
 * For the full text of the license, see the LICENSE.txt file or visit:
 * 
 * http://kew.indiana.edu/workflow/LICENSE.txt
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING
 * BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE
 * AND NONINFRINGEMENT.
 * IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES
 * OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 */
            
package edu.iu.uis.eden.routetemplate.attribute;

import edu.iu.uis.eden.WorkflowServiceErrorImpl;
import edu.iu.uis.eden.lookupable.Field;
import edu.iu.uis.eden.lookupable.Row;
import edu.iu.uis.eden.plugin.attributes.WorkflowAttribute;
import edu.iu.uis.eden.routeheader.DocumentContent;
import edu.iu.uis.eden.routetemplate.RuleExtension;
import edu.iu.uis.eden.routetemplate.RuleExtensionValue;
import edu.iu.uis.eden.util.Utilities;
import edu.iu.uis.eden.util.XmlHelper;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.jdom.Document;
import org.jdom.Element;


public class AccountRuleAttribute implements WorkflowAttribute {
    private static final org.apache.log4j.Logger LOG = 
            org.apache.log4j.Logger.getLogger(AccountRuleAttribute.class);
    private static final String ACCOUNT_NBR_KEY = "account_nbr";
    private static final String ACCOUNT_NBR_LOOKABLE_NAME = "accountNbr";
    private static final String ACCOUNT_ATTRIBUTE = "ACCOUNT_ATTRIBUTE";
    private static final String LOOKUPABLE_CLASS = "AccountLookupableImplService";
    private String accountNbr;
    private boolean required;

    public AccountRuleAttribute() {
    }

    public AccountRuleAttribute(String accountNbr) {
        this.accountNbr = accountNbr;
    }

    public boolean isMatch(DocumentContent docContent, List ruleExtensions) {
        for (Iterator iter = ruleExtensions.iterator(); iter.hasNext();) {
            RuleExtension ruleExtension = (RuleExtension) iter.next();

            for (Iterator iterator = ruleExtension.getExtensionValues()
                                                  .iterator();
                 iterator.hasNext();) {
                RuleExtensionValue ruleKeyValue = (RuleExtensionValue) iterator.next();

                if (ruleKeyValue.getKey().equals(ACCOUNT_NBR_KEY)) {
                    this.accountNbr = ruleKeyValue.getValue();
                }
            }
        }

        Document doc = null;


        //try {
        doc = XmlHelper.buildJDocument(docContent.getDocument());

        List accountElements = XmlHelper.findElements(doc.getRootElement(), 
                                                      ACCOUNT_ATTRIBUTE);

        for (Iterator iter = accountElements.iterator(); iter.hasNext();) {
            Element accountElement = (Element) iter.next();
            Element accountNbrElement = accountElement.getChild(ACCOUNT_NBR_KEY);
            String xmlAccountNbr = accountNbrElement.getText();

            if (xmlAccountNbr.equals(accountNbr)) {
                return true;
            }
        }

        /*} catch (InvalidXmlException e) {
            LOG.warn("Caught exception parsing xml", e);
        }*/
        return false;
    }

    public List getRuleRows() {
        List rows = new ArrayList();
        List fields = new ArrayList();
        fields.add(new Field("Account", "", Field.TEXT, false, ACCOUNT_NBR_KEY, 
                             "", null, LOOKUPABLE_CLASS, 
                             ACCOUNT_NBR_LOOKABLE_NAME));
        fields.add(new Field("", "", Field.QUICKFINDER, false, "", "", null, 
                             LOOKUPABLE_CLASS));
        rows.add(new Row(fields));

        return rows;
    }

    public List getRoutingDataRows() {
        return getRuleRows();
    }

    public String getDocContent() {
        return "<" + ACCOUNT_ATTRIBUTE + "><" + ACCOUNT_NBR_KEY + ">" + 
               getAccountNbr() + "</" + ACCOUNT_NBR_KEY + "></" + 
               ACCOUNT_ATTRIBUTE + ">";
    }

    public List getRuleExtensionValues() {
        List ruleExtensionValues = new ArrayList();
        ruleExtensionValues.add(
                new RuleExtensionValue(ACCOUNT_NBR_KEY, accountNbr));

        return ruleExtensionValues;
    }

    public List validateRoutingData(Map paramMap) {
        return validateRuleData(paramMap);
    }

    public List validateRuleData(Map paramMap) {
        //TODO goto suds and verify that this is a correct account
        List errors = new ArrayList();
        this.accountNbr = (String) paramMap.get(ACCOUNT_NBR_KEY);

        if (isRequired() && Utilities.isEmpty(this.accountNbr)) {
            errors.add(new WorkflowServiceErrorImpl(
                               "The account can not be empty", 
                               "routetemplate.accountruleattribute.account.invalid"));
        }

        return errors;
    }

    public void setRequired(boolean required) {
        this.required = required;
    }

    public boolean isRequired() {
        return required;
    }

    public String getAccountNbr() {
        return accountNbr;
    }

    public void setAccountNbr(String accountNbr) {
        this.accountNbr = accountNbr;
    }
}