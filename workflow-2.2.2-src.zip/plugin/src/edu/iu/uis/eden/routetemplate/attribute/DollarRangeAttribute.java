
/*
 * Copyright (c) 2004, 2005, 2006 Trustees of Indiana University and Cornell University.
 *
 * Licensed under the Educational Community License Version 1.0 (the "License"); By obtaining,
 * using and/or copying this Original Work, you agree that you have read, understand, and will
 * comply with the terms and conditions of the Educational Community License.
 *
 * For the full text of the license, see the LICENSE.txt file or visit:
 * 
 * http://kew.indiana.edu/workflow/LICENSE.txt
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING
 * BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE
 * AND NONINFRINGEMENT.
 * IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES
 * OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 */
            
package edu.iu.uis.eden.routetemplate.attribute;

import edu.iu.uis.eden.WorkflowServiceErrorImpl;
import edu.iu.uis.eden.lookupable.Field;
import edu.iu.uis.eden.lookupable.Row;
import edu.iu.uis.eden.plugin.attributes.WorkflowAttribute;
import edu.iu.uis.eden.routeheader.DocumentContent;
import edu.iu.uis.eden.routetemplate.RuleExtension;
import edu.iu.uis.eden.routetemplate.RuleExtensionValue;
import edu.iu.uis.eden.util.Utilities;
import edu.iu.uis.eden.util.XmlHelper;

import java.math.BigDecimal;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.jdom.Document;
import org.jdom.Element;


/**
 * fis.ca_acct_delegate_t is where these keys are found
 */
public class DollarRangeAttribute implements WorkflowAttribute {
    private static final String MIN_DOLLAR_KEY = "fdoc_aprv_from_amt";
    private static final String MAX_DOLLAR_KEY = "fdoc_aprv_to_amt";
    private static final String TOTAL_DOLLAR_AMOUNT = "total_dollar_amt";
    private static final String ID_KEY = "fdoc_aprv_from_amt_fdoc_aprv_to_amt_id";
    private static final String LOCK_KEY = "fdoc_aprv_from_amt_fdoc_aprv_to_amt_locknbr";
    private BigDecimal min;
    private BigDecimal max;
    private BigDecimal totalDollarAmount;
    private boolean required;
    private List ruleRows;
    private List routingRows;

    // TODO this is a hack added to get the ChartOrgDollarRangeAttribute working, is there a better way?
    private String classNameOverride = null;

    public DollarRangeAttribute(String totalDollarAmount) {
        this();
        this.totalDollarAmount = (Utilities.isEmpty(totalDollarAmount)
                                  ? null : new BigDecimal(totalDollarAmount));
    }

    public DollarRangeAttribute(String min, String max) {
        this();
        this.min = (Utilities.isEmpty(min) ? null : new BigDecimal(min));
        this.max = (Utilities.isEmpty(max) ? null : new BigDecimal(max));
    }

    public DollarRangeAttribute() {
        ruleRows = new ArrayList();
        routingRows = new ArrayList();

        List ruleFields = new ArrayList();
        ruleFields.add(
                new Field("From amount", "", Field.TEXT, false, MIN_DOLLAR_KEY, 
                          "", null, null));
        ruleFields.add(
                new Field("", "", Field.HIDDEN, false, ID_KEY, "", null, null));
        ruleFields.add(
                new Field("", "", Field.HIDDEN, false, LOCK_KEY, "", null, null));
        ruleRows.add(new Row(ruleFields, "Dollar Range", 2));

        ruleFields = new ArrayList();
        ruleFields.add(
                new Field("To amount", "", Field.TEXT, false, MAX_DOLLAR_KEY, 
                          "", null, null));
        ruleRows.add(new Row(ruleFields, "Dollar Range", 2));

        List routingFields = new ArrayList();
        routingFields.add(
                new Field("Total Dollar Amount", "", Field.TEXT, false, 
                          TOTAL_DOLLAR_AMOUNT, "", null, null));
        routingRows.add(new Row(routingFields));
    }

    public List getRuleExtensionValues() {
        List ruleExtensionValues = new ArrayList();

        if (min != null) {
            RuleExtensionValue minVal = new RuleExtensionValue();
            minVal.setKey(MIN_DOLLAR_KEY);
            minVal.setValue(this.min.toString());
            ruleExtensionValues.add(minVal);
        }

        if (max != null) {
            RuleExtensionValue maxVal = new RuleExtensionValue();
            maxVal.setKey(MAX_DOLLAR_KEY);
            maxVal.setValue(this.max.toString());
            ruleExtensionValues.add(maxVal);
        }

        return ruleExtensionValues;
    }

    //    public RuleExtension parseParametersForRuleSave(Map parameters, RuleTemplateAttribute ruleTemplateAttribute) {
    //        
    //        RuleExtension ruleExt = new RuleExtension();
    //        List ruleExtVals = new ArrayList();
    //        
    //        RuleExtensionValue minVal = new RuleExtensionValue();
    //        minVal.setKey(MIN_DOLLAR_KEY);
    //        minVal.setValue(this.min.toString());
    //        ruleExtVals.add(minVal);
    //        
    //        RuleExtensionValue maxVal = new RuleExtensionValue();
    //        maxVal.setKey(MAX_DOLLAR_KEY);
    //        maxVal.setValue(this.max.toString());
    //        ruleExtVals.add(maxVal);
    //        
    //        ruleExt.setExtensionValues(ruleExtVals);
    //        ruleExt.setRuleTemplateAttribute(ruleTemplateAttribute);
    //        if (parameters.get(LOCK_KEY) != null && ! parameters.get(LOCK_KEY).equals("")) {
    //            ruleExt.setLockVerNbr(new Integer((String)parameters.get(LOCK_KEY)));
    //        }
    //        if (parameters.get(ID_KEY) != null && ! parameters.get(ID_KEY).equals("")) {
    //            ruleExt.setLockVerNbr(new Integer((String)parameters.get(ID_KEY)));
    //        }
    //        return ruleExt;
    //    }
    //    public List validateTypeNpopulateRoutingDataFromParamMap(Map paramMap) {
    //        List errors = new ArrayList();
    //        String totalDollarValue = (String) paramMap.get(TOTAL_DOLLAR_AMOUNT);
    //        if (!Utilities.isEmpty(totalDollarValue)) {
    //            try {
    //                this.totalDollarAmount = new BigDecimal(totalDollarValue);
    //            } catch (Exception e) {
    //                errors.add(new WorkflowServiceErrorImpl("Total Dollar amount is not a valid number.", "routetemplate.dollarrangeattribute.totalamount.invalid"));
    //            }
    //        } else if (isRequired()) {
    //            errors.add(new WorkflowServiceErrorImpl("Total Dollar amount is required.", "routetemplate.dollarrangeattribute.totalamount.required"));
    //        }
    //        return errors;
    //    }
    //
    //    public List validateTypeNpopulateRuleDataFromParamMap(Map paramMap) {
    //        List errors = new ArrayList();
    //        String minDollarValue = (String) paramMap.get(MIN_DOLLAR_KEY);
    //        String maxDollarValue = (String) paramMap.get(MAX_DOLLAR_KEY);
    //        if (!Utilities.isEmpty(minDollarValue)) {
    //            try {
    //                this.min = new BigDecimal(minDollarValue);
    //            } catch (Exception e) {
    //                errors.add(new WorkflowServiceErrorImpl("From amount is not valid.", "routetemplate.dollarrangeattribute.fromamount.invalid"));
    //            }
    //        } else if (isRequired()) {
    //            errors.add(new WorkflowServiceErrorImpl("From amount is not valid.", "routetemplate.dollarrangeattribute.fromamount.required"));
    //        }
    //
    //        if (!Utilities.isEmpty(maxDollarValue)) {
    //            try {
    //                this.max = new BigDecimal(maxDollarValue);
    //            } catch (Exception e) {
    //                errors.add(new WorkflowServiceErrorImpl("To amount is not a valid number.", "routetemplate.dollarrangeattribute.toamount.invalid"));
    //            }
    //        } else if (isRequired()) {
    //            errors.add(new WorkflowServiceErrorImpl("To amount is required.", "routetemplate.dollarrangeattribute.toamount.required"));
    //        }
    //
    //        return errors;
    //    }
    public List validateRoutingData(Map paramMap) {
        List errors = new ArrayList();
        String totalDollarValue = (String) paramMap.get(TOTAL_DOLLAR_AMOUNT);

        if (!Utilities.isEmpty(totalDollarValue)) {
            try {
                this.totalDollarAmount = new BigDecimal(totalDollarValue);
            } catch (Exception e) {
                errors.add(new WorkflowServiceErrorImpl(
                                   "Total Dollar amount is not a valid number.", 
                                   "routetemplate.dollarrangeattribute.totalamount.invalid"));
            }
        } else if (isRequired()) {
            errors.add(new WorkflowServiceErrorImpl(
                               "Total Dollar amount is required.", 
                               "routetemplate.dollarrangeattribute.totalamount.required"));
        }

        if ((totalDollarAmount != null) && 
                (totalDollarAmount.compareTo(
                         new BigDecimal(new Double(0).doubleValue())) == -1)) {
            errors.add(new WorkflowServiceErrorImpl(
                               "Total Dollar amount must be 0 or greater", 
                               "routetemplate.dollarrangeattribute.totalamount.negative"));
        }

        return errors;
    }

    public List validateRuleData(Map paramMap) {
        List errors = new ArrayList();
        String minDollarValue = (String) paramMap.get(MIN_DOLLAR_KEY);
        String maxDollarValue = (String) paramMap.get(MAX_DOLLAR_KEY);

        if (!Utilities.isEmpty(minDollarValue)) {
            try {
                this.min = new BigDecimal(minDollarValue);
            } catch (Exception e) {
                errors.add(new WorkflowServiceErrorImpl(
                                   "From amount is not valid.", 
                                   "routetemplate.dollarrangeattribute.fromamount.invalid"));
            }
        } else if (isRequired()) {
            errors.add(new WorkflowServiceErrorImpl("From amount is not valid.", 
                                                    "routetemplate.dollarrangeattribute.fromamount.required"));
        }

        if (!Utilities.isEmpty(maxDollarValue)) {
            try {
                this.max = new BigDecimal(maxDollarValue);
            } catch (Exception e) {
                errors.add(new WorkflowServiceErrorImpl(
                                   "To amount is not a valid number.", 
                                   "routetemplate.dollarrangeattribute.toamount.invalid"));
            }
        } else if (isRequired()) {
            errors.add(new WorkflowServiceErrorImpl("To amount is required.", 
                                                    "routetemplate.dollarrangeattribute.toamount.required"));
        }

        if ((min != null) && 
                (min.compareTo(new BigDecimal(new Double(0).doubleValue())) == -1)) {
            errors.add(new WorkflowServiceErrorImpl(
                               "From Dollar amount must be 0 or greater", 
                               "routetemplate.dollarrangeattribute.fromamount.negative"));
        }

        if ((max != null) && (max.compareTo(min) <= 0)) {
            errors.add(new WorkflowServiceErrorImpl(
                               "To Dollar amount must be greater than from dollar amount.", 
                               "routetemplate.dollarrangeattribute.range.invalid"));
        }

        return errors;
    }

    public boolean isMatch(DocumentContent docContent, List ruleExtensions) {
        boolean foundDollarRangeExtension = false;

        for (Iterator iter = ruleExtensions.iterator(); iter.hasNext();) {
            RuleExtension extension = (RuleExtension) iter.next();

            // TODO this is a hack added to get the ChartOrgDollarRangeAttribute working, is there a better way?
            String className = ((classNameOverride != null)                    
                                ? classNameOverride : getClass().getName());

            if (extension.getRuleTemplateAttribute().getRuleAttribute()
                         .getClassName().equals(className)) {
                for (Iterator iterator = extension.getExtensionValues()
                                                  .iterator();
                     iterator.hasNext();) {
                    RuleExtensionValue value = (RuleExtensionValue) iterator.next();

                    if (value.getKey().equals(MIN_DOLLAR_KEY)) {
                        foundDollarRangeExtension = true;
                        setMin((Utilities.isEmpty(value.getValue())
                                ? null : new BigDecimal(value.getValue())));
                    }

                    if (value.getKey().equals(MAX_DOLLAR_KEY)) {
                        foundDollarRangeExtension = true;
                        setMax((Utilities.isEmpty(value.getValue())
                                ? null : new BigDecimal(value.getValue())));
                    }
                }
            }
        }

        List totalDollarAmounts = parseDocContent(docContent);

        if (totalDollarAmounts.iterator().hasNext()) {
            this.totalDollarAmount = ((DollarRangeAttribute) totalDollarAmounts.iterator()
                                                                               .next()).getTotalDollarAmount();
        }

        if ((getMin() != null) && (getMax() != null)) {
            if ((getTotalDollarAmount().compareTo(getMin()) == 1 || 
                        getTotalDollarAmount().compareTo(getMin()) == 0) && 
                    (getTotalDollarAmount().compareTo(getMax()) == -1 || 
                        getTotalDollarAmount().compareTo(getMax()) == 0)) {
                return true;
            }
        }

        if (ruleExtensions.isEmpty() || !foundDollarRangeExtension) {
            //TODO FLEXRM should determine this.
            return true;
        }

        return false;
    }

    public String getDocContent() {
        if (totalDollarAmount == null) {
            return "";
        }

        return "<totalDollarAmount>" + totalDollarAmount.toString() + 
               "</totalDollarAmount>";
    }

    public List parseDocContent(DocumentContent docContent) {
        try {
            Document doc = XmlHelper.buildJDocument(docContent.getDocument());
            Element totalDollarElement = XmlHelper.findElement(
                                                 doc.getRootElement(), 
                                                 "totalDollarAmount");
            List dollarRangeAttributes = new ArrayList();

            if (totalDollarElement != null) {
                dollarRangeAttributes.add(
                        new DollarRangeAttribute(totalDollarElement.getText()));
            }

            return dollarRangeAttributes;
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    public String getIdFieldName() {
        return ID_KEY;
    }

    public String getLockFieldName() {
        return LOCK_KEY;
    }

    public List getRuleRows() {
        return ruleRows;
    }

    public List getRoutingDataRows() {
        return routingRows;
    }

    public void setTotalDollarAmount(BigDecimal totalDollarAmount) {
        this.totalDollarAmount = totalDollarAmount;
    }

    public void setTotalDollarAmount(String totalDollarAmount) {
        this.totalDollarAmount = (Utilities.isEmpty(totalDollarAmount)
                                  ? null : new BigDecimal(totalDollarAmount));
    }

    public BigDecimal getTotalDollarAmount() {
        return this.totalDollarAmount;
    }

    public BigDecimal getMax() {
        return max;
    }

    public void setMax(BigDecimal max) {
        this.max = max;
    }

    public void setMax(String max) {
        this.max = (Utilities.isEmpty(max) ? null : new BigDecimal(max));
    }

    public BigDecimal getMin() {
        return min;
    }

    public void setMin(BigDecimal min) {
        this.min = min;
    }

    public void setMin(String min) {
        this.min = (Utilities.isEmpty(min) ? null : new BigDecimal(min));
    }

    public boolean isRequired() {
        return required;
    }

    public void setRequired(boolean required) {
        this.required = required;
    }

    public void setClassNameOverride(String classNameOverride) {
        this.classNameOverride = classNameOverride;
    }
}