
/*
 * Copyright (c) 2004, 2005, 2006 Trustees of Indiana University and Cornell University.
 *
 * Licensed under the Educational Community License Version 1.0 (the "License"); By obtaining,
 * using and/or copying this Original Work, you agree that you have read, understand, and will
 * comply with the terms and conditions of the Educational Community License.
 *
 * For the full text of the license, see the LICENSE.txt file or visit:
 * 
 * http://kew.indiana.edu/workflow/LICENSE.txt
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING
 * BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE
 * AND NONINFRINGEMENT.
 * IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES
 * OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 */
            
package edu.iu.uis.eden.routetemplate.attribute;

import edu.iu.uis.eden.IUServiceLocator;
import edu.iu.uis.eden.WorkflowServiceErrorImpl;
import edu.iu.uis.eden.fiscalsub.FiscalSubAccount;
import edu.iu.uis.eden.fiscalsub.FiscalSubAccountService;
import edu.iu.uis.eden.lookupable.Field;
import edu.iu.uis.eden.lookupable.Row;
import edu.iu.uis.eden.plugin.attributes.WorkflowAttribute;
import edu.iu.uis.eden.routeheader.DocumentContent;
import edu.iu.uis.eden.routetemplate.RuleExtension;
import edu.iu.uis.eden.routetemplate.RuleExtensionValue;
import edu.iu.uis.eden.services.docelements.FiscalSubAccountElement;
import edu.iu.uis.eden.util.Utilities;
import edu.iu.uis.eden.util.XmlHelper;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.jdom.Element;

import org.jdom.output.XMLOutputter;


public class SubAccountAttribute implements WorkflowAttribute {
    private static final org.apache.log4j.Logger LOG = 
            org.apache.log4j.Logger.getLogger(SubAccountAttribute.class);
    private static final String FIN_COA_CD_KEY = "fin_coa_cd";
    private static final String SUB_ACCT_FIN_COA_CD_KEY = "sub_acct_fin_coa_cd";
    private static final String SUB_ACCT_ACCOUNT_NBR_KEY = 
            "sub_acct_account_nbr";
    private static final String ACCOUNT_NBR_KEY = "account_nbr";
    private static final String SUB_ACCT_NBR_KEY = "sub_acct_nbr";
    private static final String ID_KEY = "fin_coa_cd_account_nbr_sub_acct_nbr_id";
    private static final String LOCK_KEY = "fin_coa_cd_account_nbr_sub_acct_nbr_locknbr";
    private static final String WILDCARD_VALUE = "*";
    private static final String LOOKUPABLE_CLASS = "SubAccountLookupableImplService";
    private static final String CHART_FIELD_LABEL = "Chart";
    private static final String ACCOUNT_FIELD_LABEL = "Account";
    private static final String SUB_ACCOUNT_FIELD_LABEL = "Sub Account";
    private static final String INVALID_SUB_ACCOUNT_ERROR = 
            "Sub Account is invalid";
    private static final String INVALID_SUB_ACCOUNT_TYPE = 
            "routetemplate.subaccountattribute.subaccount.invalid";
    private static final String REQUIRED_SUB_ACCOUNT_ERROR = 
            "Sub Account is required";
    private static final String REQUIRED_SUB_ACCOUNT_TYPE = 
            "routetemplate.subaccountattribute.subaccount.required";
    private static final String INVALID_XML_ERROR = "Invalid XML submitted";
    private static final String LOAD_SUB_ACCOUNT_ERROR = 
            "Problems loading sub account element from string ";
    private String finCoaCd;
    private String accountNbr;
    private String subAcctNbr;
    private List rows;
    private boolean required;

    public SubAccountAttribute(String finCoaCd, String accountNbr, 
                               String subAcctNbr) {
        this();

        FiscalSubAccountService service = IUServiceLocator.getFiscalSubAccountService();
        FiscalSubAccount account = service.getSubAccount(finCoaCd, accountNbr, 
                                                         subAcctNbr);

        if (account == null) {
            LOG.error("Invalid chart: " + finCoaCd + ", account: " + 
                      accountNbr + ", and subaccount: " + subAcctNbr);
            throw new RuntimeException("Invalid chart: " + finCoaCd + 
                                       ", account: " + accountNbr + 
                                       ", and subaccount: " + subAcctNbr);
        }

        setFinCoaCd(finCoaCd);
        setAccountNbr(accountNbr);
        setSubAcctNbr(subAcctNbr);
    }

    public SubAccountAttribute() {
        buildRows();
    }

    private void buildRows() {
        rows = new ArrayList();

        List fields = new ArrayList();
        fields.add(new Field(CHART_FIELD_LABEL, "", Field.TEXT, true, 
                             SUB_ACCT_FIN_COA_CD_KEY, "", null, 
                             LOOKUPABLE_CLASS, FIN_COA_CD_KEY));
        fields.add(new Field("", "", Field.HIDDEN, true, ID_KEY, "", null, 
                             LOOKUPABLE_CLASS));
        fields.add(new Field("", "", Field.HIDDEN, true, LOCK_KEY, "", null, 
                             LOOKUPABLE_CLASS));
        rows.add(new Row(fields, "Subaccount", 3));

        fields = new ArrayList();
        fields.add(new Field(ACCOUNT_FIELD_LABEL, "", Field.TEXT, true, 
                             SUB_ACCT_ACCOUNT_NBR_KEY, "", null, 
                             LOOKUPABLE_CLASS, ACCOUNT_NBR_KEY));
        rows.add(new Row(fields, "Subaccount", 3));

        fields = new ArrayList();
        fields.add(new Field(SUB_ACCOUNT_FIELD_LABEL, "", Field.TEXT, true, 
                             SUB_ACCT_NBR_KEY, "", null, LOOKUPABLE_CLASS, 
                             SUB_ACCT_NBR_KEY));
        fields.add(new Field("", "", Field.QUICKFINDER, false, "", "", null, 
                             LOOKUPABLE_CLASS));
        rows.add(new Row(fields, "Subaccount", 3));
    }

    public boolean isMatch(DocumentContent docContent, List ruleExtensions) {
        for (Iterator extensionsIterator = ruleExtensions.iterator();
             extensionsIterator.hasNext();) {
            RuleExtension extension = (RuleExtension) extensionsIterator.next();

            if (extension.getRuleTemplateAttribute().getRuleAttribute()
                         .getClassName().equals(getClass().getName())) {
                for (Iterator valuesIterator = extension.getExtensionValues()
                                                        .iterator();
                     valuesIterator.hasNext();) {
                    RuleExtensionValue extensionValue = 
                            (RuleExtensionValue) valuesIterator.next();
                    String key = extensionValue.getKey();
                    String value = extensionValue.getValue();

                    if (key.equals(FIN_COA_CD_KEY)) {
                        setFinCoaCd(value);
                    }

                    if (key.equals(ACCOUNT_NBR_KEY)) {
                        setAccountNbr(value);
                    }

                    if (key.equals(SUB_ACCT_NBR_KEY)) {
                        setSubAcctNbr(value);
                    }
                }
            }
        }

        List subAccountValues = parseDocContent(docContent);

        for (Iterator iterator = subAccountValues.iterator();
             iterator.hasNext();) {
            SubAccountAttribute attribute = (SubAccountAttribute) iterator.next();

            if (attribute.getFinCoaCd().equals(getFinCoaCd()) && 
                    attribute.getAccountNbr().equals(getAccountNbr()) && 
                    (attribute.getSubAcctNbr().equals(getSubAcctNbr()) || getSubAcctNbr()
                                                                              .equals(WILDCARD_VALUE))) {
                return true;
            }
        }

        if (ruleExtensions.isEmpty()) {
            //TODO FLEXRM should determine this. (?)
            return true;
        }

        return false;
    }

    public List getRuleRows() {
        return rows;
    }

    public List getRoutingDataRows() {
        return rows;
    }

    public String getDocContent() {
        if (!hasEmptyData()) {
            FiscalSubAccountElement element = new FiscalSubAccountElement();
            element.setChart(getFinCoaCd());
            element.setAccountNumber(getAccountNbr());
            element.setSubAccountNumber(getSubAcctNbr());

            return new XMLOutputter().outputString(element.getXMLContent());
        } else {
            return "";
        }
    }

    /**
     * Returns true if one or more pieces of attribute data are "empty", false otherwise
     */
    private boolean hasEmptyData() {
        return (Utilities.isEmpty(getFinCoaCd()) || 
               Utilities.isEmpty(getAccountNbr()) || 
               Utilities.isEmpty(getSubAcctNbr()));
    }

    /**
     * Returns true if all of the attribute data is "empty", false otherwise
     */
    private boolean isEmpty() {
        return (Utilities.isEmpty(getFinCoaCd()) && 
               Utilities.isEmpty(getAccountNbr()) && 
               Utilities.isEmpty(getSubAcctNbr()));
    }

    public List parseDocContent(DocumentContent docContent) {
        List subAccountModels = new ArrayList();
        FiscalSubAccountElement element = new FiscalSubAccountElement();
        Element rootElement = null;

        try {
            rootElement = XmlHelper.buildJDocument(docContent.getDocument())
                                   .getRootElement();
        } catch (Exception e) {
            LOG.error("Caught exception parsing xml", e);
            throw new RuntimeException(INVALID_XML_ERROR, e);
        }

        List subAccountElements = XmlHelper.findElements(rootElement, 
                                                         element.getElementName());

        for (Iterator iter = subAccountElements.iterator(); iter.hasNext();) {
            Element subAccountElement = (Element) iter.next();

            try {
                element.loadFromXMLContent(subAccountElement, false);
            } catch (Exception e) {
                throw new RuntimeException(LOAD_SUB_ACCOUNT_ERROR + 
                                           docContent, e);
            }

            subAccountModels.add(
                    new SubAccountAttribute(element.getChart(), 
                                            element.getAccountNumber(), 
                                            element.getSubAccountNumber()));
        }

        return subAccountModels;
    }

    public List getRuleExtensionValues() {
        List extensions = new ArrayList();

        if (!Utilities.isEmpty(getFinCoaCd())) {
            RuleExtensionValue extensionFinCoaCd = new RuleExtensionValue();
            extensionFinCoaCd.setKey(FIN_COA_CD_KEY);
            extensionFinCoaCd.setValue(getFinCoaCd());
            extensions.add(extensionFinCoaCd);
        }

        if (!Utilities.isEmpty(getAccountNbr())) {
            RuleExtensionValue extensionAccountNbr = new RuleExtensionValue();
            extensionAccountNbr.setKey(ACCOUNT_NBR_KEY);
            extensionAccountNbr.setValue(getAccountNbr());
            extensions.add(extensionAccountNbr);
        }

        if (!Utilities.isEmpty(getSubAcctNbr())) {
            RuleExtensionValue extensionSubAcctNbr = new RuleExtensionValue();
            extensionSubAcctNbr.setKey(SUB_ACCT_NBR_KEY);
            extensionSubAcctNbr.setValue(getSubAcctNbr());
            extensions.add(extensionSubAcctNbr);
        }

        return extensions;
    }

    public List validateRoutingData(Map paramMap) {
        List errors = new ArrayList();
        setFinCoaCd((String) paramMap.get(SUB_ACCT_FIN_COA_CD_KEY));
        setAccountNbr((String) paramMap.get(SUB_ACCT_ACCOUNT_NBR_KEY));
        setSubAcctNbr((String) paramMap.get(SUB_ACCT_NBR_KEY));

        if (isRequired() && hasEmptyData()) {
            errors.add(new WorkflowServiceErrorImpl(REQUIRED_SUB_ACCOUNT_ERROR, 
                                                    REQUIRED_SUB_ACCOUNT_TYPE));
        } else if (hasEmptyData() && !isEmpty()) {
            errors.add(new WorkflowServiceErrorImpl(INVALID_SUB_ACCOUNT_ERROR, 
                                                    INVALID_SUB_ACCOUNT_TYPE));
        }

        if (!hasEmptyData()) {
            FiscalSubAccountService service = IUServiceLocator.getFiscalSubAccountService();
            FiscalSubAccount account = service.getSubAccount(getFinCoaCd(), 
                                                             getAccountNbr(), 
                                                             getSubAcctNbr());

            if (account == null) {
                errors.add(new WorkflowServiceErrorImpl(
                                   INVALID_SUB_ACCOUNT_ERROR, 
                                   INVALID_SUB_ACCOUNT_TYPE));
            }
        }

        return errors;
    }

    public List validateRuleData(Map paramMap) {
        return validateRoutingData(paramMap);
    }

    //    public List validateTypeNpopulateRoutingDataFromParamMap(Map paramMap) {
    //        return validateTypeNpopulateRuleDataFromParamMap(paramMap);
    //    }
    //
    //    public List validateTypeNpopulateRuleDataFromParamMap(Map paramMap) {
    //        List errors = new ArrayList();
    //        setFinCoaCd((String) paramMap.get(SUB_ACCT_FIN_COA_CD_KEY));
    //        setAccountNbr((String) paramMap.get(ACCOUNT_NBR_KEY));
    //        setSubAcctNbr((String) paramMap.get(SUB_ACCT_NBR_KEY));
    //        if (isRequired() && hasEmptyData()) {
    //            errors.add(new WorkflowServiceErrorImpl(REQUIRED_SUB_ACCOUNT_ERROR, REQUIRED_SUB_ACCOUNT_TYPE));
    //        } else if (hasEmptyData() && !isEmpty()) {
    //            errors.add(new WorkflowServiceErrorImpl(INVALID_SUB_ACCOUNT_ERROR, INVALID_SUB_ACCOUNT_TYPE));
    //        }
    //        return errors;
    //    }
    public String getIdFieldName() {
        return ID_KEY;
    }

    public String getLockFieldName() {
        return LOCK_KEY;
    }

    public String getFinCoaCd() {
        return this.finCoaCd;
    }

    public String getAccountNbr() {
        return accountNbr;
    }

    public void setAccountNbr(String accountNbr) {
        this.accountNbr = accountNbr;
    }

    public String getSubAcctNbr() {
        return subAcctNbr;
    }

    public void setSubAcctNbr(String subAcctNbr) {
        this.subAcctNbr = subAcctNbr;
    }

    public void setFinCoaCd(String finCoaCd) {
        this.finCoaCd = finCoaCd;
    }

    public void setRequired(boolean required) {
        this.required = required;
    }

    public boolean isRequired() {
        return required;
    }
}