
/*
 * Copyright (c) 2004, 2005, 2006 Trustees of Indiana University and Cornell University.
 *
 * Licensed under the Educational Community License Version 1.0 (the "License"); By obtaining,
 * using and/or copying this Original Work, you agree that you have read, understand, and will
 * comply with the terms and conditions of the Educational Community License.
 *
 * For the full text of the license, see the LICENSE.txt file or visit:
 * 
 * http://kew.indiana.edu/workflow/LICENSE.txt
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING
 * BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE
 * AND NONINFRINGEMENT.
 * IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES
 * OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 */
            
package edu.iu.uis.eden.routetemplate.attribute;

import edu.iu.uis.eden.SpringServiceLocator;
import edu.iu.uis.eden.exception.EdenUserNotFoundException;
import edu.iu.uis.eden.routeheader.DocumentContent;
import edu.iu.uis.eden.routetemplate.AbstractRoleAttribute;
import edu.iu.uis.eden.routetemplate.ResolvedQualifiedRole;
import edu.iu.uis.eden.routetemplate.Role;
import edu.iu.uis.eden.routetemplate.RouteContext;
import edu.iu.uis.eden.user.AuthenticationUserId;
import edu.iu.uis.eden.user.UserService;

import java.util.ArrayList;
import java.util.List;


public class FakeRoleAttribute extends AbstractRoleAttribute {
    public static final String ROLE1_KEY = "ROLE1";
    public static final String ROLE2_KEY = "ROLE2";

    public List getRoleNames() {
        List roles = new ArrayList();
        roles.add(new Role(this.getClass(), ROLE1_KEY, ROLE1_KEY));
        roles.add(new Role(this.getClass(), ROLE2_KEY, ROLE2_KEY));

        return roles;
    }

    public List getQualifiedRoleNames(String roleName, 
                                      DocumentContent docContent) {
        List roleNames = new ArrayList();

        if (roleName.equals(ROLE1_KEY)) {
            roleNames.add(ROLE1_KEY + " ewestfal");

            //            roleNames.add(ROLE1_KEY + " rkirkend");
        } else if (roleName.equals(ROLE2_KEY)) {
            roleNames.add(ROLE2_KEY + " jhopf");
            roleNames.add(ROLE2_KEY + " xqi");
        }

        return roleNames;
    }

    public ResolvedQualifiedRole resolveQualifiedRole(RouteContext context, 
                                                      String roleName, 
                                                      String qualifiedRole)
                                               throws EdenUserNotFoundException {
        List members = new ArrayList();

        if (roleName.equals(ROLE1_KEY)) {
            //            members.add(new GroupNameId("WorkflowAdmin"));
            members.add(new AuthenticationUserId("rkirkend"));
            members.add(new AuthenticationUserId("ewestfal"));
        } else if (roleName.equals(ROLE2_KEY)) {
            members.add(new AuthenticationUserId("jhopf"));
            members.add(new AuthenticationUserId("xqi"));
        }

        return new ResolvedQualifiedRole("Fakey Role", members);
    }

    /* public List getQualifiedRoleNames(String roleName, String docContent) throws EdenUserNotFoundException {
         List members = new ArrayList();
         if (roleName.equals(ROLE1_KEY)) {
             members.add(getUserService().getWorkflowUser(new AuthenticationUserId("ewestfal")));
             members.add(getUserService().getWorkflowUser(new AuthenticationUserId("rkirkend")));
         } else if (roleName.equals(ROLE2_KEY)) {
             members.add(getUserService().getWorkflowUser(new AuthenticationUserId("jhopf")));
             members.add(getUserService().getWorkflowUser(new AuthenticationUserId("xqi")));
         }
         return members;
     }*/
    private UserService getUserService() {
        return (UserService) SpringServiceLocator.getService(
                       SpringServiceLocator.USER_SERVICE);
    }
}