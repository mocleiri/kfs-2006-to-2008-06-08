
/*
 * Copyright (c) 2004, 2005, 2006 Trustees of Indiana University and Cornell University.
 *
 * Licensed under the Educational Community License Version 1.0 (the "License"); By obtaining,
 * using and/or copying this Original Work, you agree that you have read, understand, and will
 * comply with the terms and conditions of the Educational Community License.
 *
 * For the full text of the license, see the LICENSE.txt file or visit:
 * 
 * http://kew.indiana.edu/workflow/LICENSE.txt
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING
 * BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE
 * AND NONINFRINGEMENT.
 * IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES
 * OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 */
            
package edu.iu.uis.eden.routetemplate.attribute;

import edu.iu.uis.eden.routeheader.DocumentContent;
import edu.iu.uis.eden.routeheader.PartialAttributeContent;

import java.math.BigDecimal;

import java.util.ArrayList;
import java.util.List;

import org.w3c.dom.Element;
import org.w3c.dom.NodeList;


public class ChartOrgDollarRangeAttribute extends CompositeAttribute {
    private static final String CHART_ORG_DOLLAR_RANGE_ELEMENT = 
            "chart_org_dollar_range";
    private ChartOrgAttribute chartOrg;
    private DollarRangeAttribute dollarRange;

    public ChartOrgDollarRangeAttribute(String finCoaCd, String orgCd, 
                                        String totalDollarAmount) {
        chartOrg = new ChartOrgAttribute(finCoaCd, orgCd);
        dollarRange = new DollarRangeAttribute(totalDollarAmount);
        addAttribute(chartOrg);
        addAttribute(dollarRange);
        overrideClassNames();
    }

    public ChartOrgDollarRangeAttribute() {
        chartOrg = new ChartOrgAttribute();
        dollarRange = new DollarRangeAttribute();
        addAttribute(chartOrg);
        addAttribute(dollarRange);
        overrideClassNames();
    }

    private void overrideClassNames() {
        chartOrg.setClassNameOverride(getClass().getName());
        dollarRange.setClassNameOverride(getClass().getName());
    }

    // need to do some xml magic
    public String getDocContent() {
        StringBuffer buffer = new StringBuffer();
        buffer.append("<").append(CHART_ORG_DOLLAR_RANGE_ELEMENT).append(">");
        buffer.append(super.getDocContent());
        buffer.append("</").append(CHART_ORG_DOLLAR_RANGE_ELEMENT).append(">");

        return buffer.toString();
    }

    public boolean isMatch(DocumentContent docContent, List ruleExtensions) {
        try {
            // We have to pull out each ChartOrgDollarRange section and match against it...
            NodeList chartOrgDollarElements = docContent.getDocument()
                                                        .getElementsByTagName(CHART_ORG_DOLLAR_RANGE_ELEMENT);

            for (int index = 0;
                 index < chartOrgDollarElements.getLength();
                 index++) {
                Element element = (Element) chartOrgDollarElements.item(index);
                List documentElements = new ArrayList();
                documentElements.add(element);

                DocumentContent partialContent = new PartialAttributeContent(
                                                         documentElements);

                if (super.isMatch(partialContent, ruleExtensions)) {
                    return true;
                }
            }

            return false;
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    // some delegate methods just for fun
    public String getFinCoaCd() {
        return chartOrg.getFinCoaCd();
    }

    public String getOrgCd() {
        return chartOrg.getOrgCd();
    }

    public void setFinCoaCd(String finCoaCd) {
        chartOrg.setFinCoaCd(finCoaCd);
    }

    public void setOrgCd(String orgCd) {
        chartOrg.setOrgCd(orgCd);
    }

    public BigDecimal getMax() {
        return dollarRange.getMax();
    }

    public BigDecimal getMin() {
        return dollarRange.getMin();
    }

    public BigDecimal getTotalDollarAmount() {
        return dollarRange.getTotalDollarAmount();
    }

    public void setMax(BigDecimal max) {
        dollarRange.setMax(max);
    }

    public void setMax(String max) {
        dollarRange.setMax(max);
    }

    public void setMin(BigDecimal min) {
        dollarRange.setMin(min);
    }

    public void setMin(String min) {
        dollarRange.setMin(min);
    }

    public void setTotalDollarAmount(BigDecimal totalDollarAmount) {
        dollarRange.setTotalDollarAmount(totalDollarAmount);
    }

    public void setTotalDollarAmount(String totalDollarAmount) {
        dollarRange.setTotalDollarAmount(totalDollarAmount);
    }
}