
/*
 * Copyright (c) 2004, 2005, 2006 Trustees of Indiana University and Cornell University.
 *
 * Licensed under the Educational Community License Version 1.0 (the "License"); By obtaining,
 * using and/or copying this Original Work, you agree that you have read, understand, and will
 * comply with the terms and conditions of the Educational Community License.
 *
 * For the full text of the license, see the LICENSE.txt file or visit:
 * 
 * http://kew.indiana.edu/workflow/LICENSE.txt
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING
 * BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE
 * AND NONINFRINGEMENT.
 * IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES
 * OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 */
            
package edu.iu.uis.eden.ads;

import edu.iu.uis.sit.util.directory.AdsHelper;

import java.util.List;

import javax.naming.AuthenticationException;
import javax.naming.NamingException;
import javax.naming.directory.DirContext;


/**
 * Service for accessing ADS
 * 
 * Attempts to simplify some of the behind-the-scenes grunt work.  This is really not a very sophisticated service
 * at the moment.  Also, objects in the directory service are currently being represented as DirContext objects.
 * It will probably be a good idea to encapsulate them (i.e. like AdsPerson was done in AdsHelper) 
 */
public interface AdsService {
    /**
     * Establishes a connection with the ADS server using the default authentication method of the service implementation.  
     * Returns an initial DirContext pointing to the root of the hierarchy.
     */
    public DirContext establishConnection() throws NamingException;

    /**
     * Creates an OrganizationalUnit in ADS as a sub context of the given context.
     * 
     * @return the DirContext of the created OrganizationUnit  
     */
    public DirContext createOrganizationalUnit(DirContext context, String name)
                                        throws NamingException;

    /**
     * Creates a Group in ADS as a sub context of the given context.
     * 
     * @return the DirContext of the created Group  
     */
    public DirContext createGroup(DirContext context, String name, List members)
                           throws NamingException;

    /**
     * Finds a Group with the given name inside the given context.
     */
    public DirContext findGroupByName(DirContext context, String groupName)
                               throws NamingException;

    /**
     * Updates the members of a Group
     */
    public DirContext updateGroupMembers(DirContext groupContext, 
                                         List newMembers)
                                  throws NamingException;

    /**
     * Returns the DirContext of the User with the given networkId.
     * Returns null if the user cannot be found.
     */
    public DirContext findUser(String networkId) throws NamingException;

    /**
     * Finds the DirContext for the given distinguised name
     */
    public DirContext find(String distinguishedName) throws NamingException;

    public AdsHelper getAdsHelper() throws AuthenticationException;
}