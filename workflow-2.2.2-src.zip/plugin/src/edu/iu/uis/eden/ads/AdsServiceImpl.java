
/*
 * Copyright (c) 2004, 2005, 2006 Trustees of Indiana University and Cornell University.
 *
 * Licensed under the Educational Community License Version 1.0 (the "License"); By obtaining,
 * using and/or copying this Original Work, you agree that you have read, understand, and will
 * comply with the terms and conditions of the Educational Community License.
 *
 * For the full text of the license, see the LICENSE.txt file or visit:
 * 
 * http://kew.indiana.edu/workflow/LICENSE.txt
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING
 * BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE
 * AND NONINFRINGEMENT.
 * IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES
 * OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 */
            
package edu.iu.uis.eden.ads;

import edu.iu.uis.eden.WorkflowServiceErrorException;
import edu.iu.uis.eden.core.Core;
import edu.iu.uis.sit.util.directory.AdsConnectionFactory;
import edu.iu.uis.sit.util.directory.AdsHelper;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;

import java.util.Iterator;
import java.util.List;
import java.util.Properties;

import javax.naming.AuthenticationException;
import javax.naming.NameNotFoundException;
import javax.naming.NamingException;
import javax.naming.directory.Attribute;
import javax.naming.directory.Attributes;
import javax.naming.directory.BasicAttribute;
import javax.naming.directory.BasicAttributes;
import javax.naming.directory.DirContext;


/**
 * Basic implementation of the AdsService.
 * 
 * TODO right now this class isn't very reusable (uses EdenAppConfig public members, etc.)
 * 
 */
public class AdsServiceImpl implements AdsService {
    private static final org.apache.log4j.Logger LOG = 
            org.apache.log4j.Logger.getLogger(AdsServiceImpl.class);
    private static final String USERNAME = "username";
    private static final String PASSWORD = "password";
    private static final String OU_ATTR = "ou";
    private static final String CN_ATTR = "cn";
    private static final String OBJECT_CLASS_ATTR = "objectClass";
    private static final String MEMBER_ATTR = "member";
    private static final String OU_OBJECT_CLASS = "organizationUnit";
    private static final String GROUP_OBJECT_CLASS = "group";
    private static final String ACCOUNT_OU = "ou=Accounts,dc=ads,dc=iu,dc=edu";
    private AuthenticationInformation authInfo = null;

    public DirContext establishConnection() throws NamingException {
        return AdsConnectionFactory.getDirContext(getAuthInfo().getUsername(), 
                                                  getAuthInfo().getPassword());
    }

    private AuthenticationInformation getAuthInfo() {
        if (authInfo == null) {
            authInfo = new AuthenticationInformation(Core.getCurrentContextConfig()
                                                         .getProperty("ads.security.path"));
        }

        return authInfo;
    }

    public DirContext createOrganizationalUnit(DirContext context, String name)
                                        throws NamingException {
        validateOrganizationalUnitName(name);

        String contextName = buildNodeName(OU_ATTR, name);
        Attributes attributes = new BasicAttributes();
        attributes.put(new BasicAttribute(OU_ATTR, name));
        attributes.put(new BasicAttribute(OBJECT_CLASS_ATTR, OU_OBJECT_CLASS));

        return (DirContext) context.createSubcontext(contextName, attributes);
    }

    public DirContext createGroup(DirContext context, String name, List members)
                           throws NamingException {
        validateGroupName(name);

        String contextName = buildNodeName(CN_ATTR, name);
        Attributes attributes = new BasicAttributes();
        attributes.put(new BasicAttribute(CN_ATTR, name));
        attributes.put(
                new BasicAttribute(OBJECT_CLASS_ATTR, GROUP_OBJECT_CLASS));
        attributes.put(buildMemberAttribute(members));

        return (DirContext) context.createSubcontext(contextName, attributes);
    }

    private Attribute buildMemberAttribute(List members)
                                    throws NamingException {
        Attribute attribute = new BasicAttribute(MEMBER_ATTR);

        for (Iterator iterator = members.iterator(); iterator.hasNext();) {
            String userId = (String) iterator.next();
            attribute.add(buildDistinguishedUserName(userId));
        }

        return attribute;
    }

    public DirContext updateGroupMembers(DirContext groupContext, 
                                         List newMembers)
                                  throws NamingException {
        Attributes attributes = new BasicAttributes();
        Attribute newMemberAttribute = buildMemberAttribute(newMembers);
        attributes.put(newMemberAttribute);
        groupContext.modifyAttributes("", DirContext.REPLACE_ATTRIBUTE, 
                                      attributes);

        return groupContext;
    }

    public DirContext findUser(String networkId) throws NamingException {
        DirContext ctx = establishConnection();

        try {
            return (DirContext) ctx.lookup(buildDistinguishedUserName(networkId));
        } catch (NameNotFoundException e) {
            return null;
        }
    }

    public DirContext findGroupByName(DirContext context, String groupName)
                               throws NamingException {
        String contextName = buildNodeName(CN_ATTR, groupName);

        try {
            return (DirContext) context.lookup(contextName);
        } catch (NameNotFoundException e) {
            return null;
        }
    }

    public DirContext find(String distinguishedName) throws NamingException {
        return (DirContext) establishConnection().lookup(distinguishedName);
    }

    public AdsHelper getAdsHelper() throws AuthenticationException {
        return new AdsHelper(getAuthInfo().getUsername(), 
                             getAuthInfo().getPassword());
    }

    public String buildDistinguishedUserName(String networkId) {
        return buildNodeName(CN_ATTR, networkId) + "," + ACCOUNT_OU;
    }

    private String buildNodeName(String nodeType, String value) {
        return nodeType + "=" + value;
    }

    private void validateGroupName(String groupName) {
        if (groupName == null) {
            throw new WorkflowServiceErrorException(
                    "group name must be non-null");
        } else if ((groupName.length() <= 0) || (groupName.length() > 64)) {
            throw new WorkflowServiceErrorException(
                    "group name must be from 1-64 characters in length: " + 
                    groupName);
        }
    }

    private void validateOrganizationalUnitName(String ouName) {
        if (ouName == null) {
            throw new WorkflowServiceErrorException(
                    "organizational name must be non-null");
        } else if ((ouName.length() <= 0) || (ouName.length() > 64)) {
            throw new WorkflowServiceErrorException(
                    "organizational unit name must be from 1-64 characters in length: " + 
                    ouName);
        }
    }

    /**
     * A little helper class to handle automatic loading and storage of authentication information
     */
    private class AuthenticationInformation {
        private String authenticationPropertiesLocation;
        private String username;
        private String password;

        public AuthenticationInformation(String authenticationPropertiesLocation) {
            this.authenticationPropertiesLocation = authenticationPropertiesLocation;
        }

        public AuthenticationInformation(String username, String password) {
            this.username = username;
            this.password = password;
        }

        public String getUsername() throws AuthenticationException {
            checkAndLoad();

            return username;
        }

        public String getPassword() throws AuthenticationException {
            checkAndLoad();

            return password;
        }

        private void checkAndLoad() throws AuthenticationException {
            if ((this.username == null) || (this.password == null)) {
                Properties properties = new Properties();

                try {
                    LOG.debug("Loading ADS authentication properties from '" + 
                              authenticationPropertiesLocation + "'");
                    properties.load(
                            new FileInputStream(
                                    new File(authenticationPropertiesLocation)));
                } catch (IOException e) {
                    LOG.error("Error loading authentication properties from " + 
                              authenticationPropertiesLocation, e);
                    throw new AuthenticationException(
                            "Error loading authentication properties from " + 
                            authenticationPropertiesLocation);
                }

                String propUsername = properties.getProperty(USERNAME);
                String propPassword = properties.getProperty(PASSWORD);

                if ((propUsername == null) || (propPassword == null)) {
                    throw new AuthenticationException("Invalid username (" + 
                                                      propUsername + 
                                                      ") or password (" + 
                                                      propPassword + ")");
                }

                this.username = propUsername;
                this.password = propPassword;
            }
        }
    }
}