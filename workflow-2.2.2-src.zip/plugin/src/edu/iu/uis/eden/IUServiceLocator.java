
/*
 * Copyright (c) 2004, 2005, 2006 Trustees of Indiana University and Cornell University.
 *
 * Licensed under the Educational Community License Version 1.0 (the "License"); By obtaining,
 * using and/or copying this Original Work, you agree that you have read, understand, and will
 * comply with the terms and conditions of the Educational Community License.
 *
 * For the full text of the license, see the LICENSE.txt file or visit:
 * 
 * http://kew.indiana.edu/workflow/LICENSE.txt
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING
 * BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE
 * AND NONINFRINGEMENT.
 * IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES
 * OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 */
            
package edu.iu.uis.eden;

import edu.iu.uis.eden.account.AccountService;
import edu.iu.uis.eden.ads.AdsService;
import edu.iu.uis.eden.fiscalsub.FiscalSubAccountService;
import edu.iu.uis.eden.fisdata.FISDataService;
import edu.iu.uis.eden.mail.IUAuthenticatedEmailService;
import edu.iu.uis.eden.plugin.attributes.LookupableService;
import edu.iu.uis.eden.user.UserService;
import edu.iu.uis.eden.web.WebAuthenticationService;
import edu.iu.uis.eden.workgroup.WorkgroupService;

import org.springframework.context.ApplicationContext;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;


/**
 * @author ewestfal
 */
public class IUServiceLocator {
    private static ApplicationContext appContext;
    private static boolean initializationBegan = false;
    public static final String USER_SERVICE = "enUserService";
    public static final String WORKGROUP_SERVICE = "enWorkgroupService";
    public static final String WORKGROUP_MEMBER_SERVICE = 
            "enWorkgroupMemberService";
    public static final String LOOKUPABLE_SERVICE = "enLookupableService";
    public static final String ADS_SERVICE = "enAdsService";
    public static final String FISCAL_SUB_ACCOUNT_SERVICE = 
            "enFiscalSubAccountService";
    public static final String FIS_DATA_SERVICE = "FISDataService";
    public static final String ACCOUNT_SERVICE = "enAccountService";
    public static final String WEB_AUTHENTICATION_SERVICE = 
            "enIUWebAuthenticationService";
    public static final String EMAIL_SERVICE = "enEmailService";

    public static Object getService(String serviceName) {
        if ((appContext == null) && !initializationBegan) {
            initializationBegan = true;
            appContext = new ClassPathXmlApplicationContext("IUSpringBeans.xml");
        } else if ((appContext == null) && initializationBegan) {
            throw new RuntimeException(
                    "Spring not initialized properly.  Initialization has begun and the application context is null." + 
                    "Probably spring loaded bean is trying to use SpringServiceLocator before the application context is initialized.");
        }

        return appContext.getBean(serviceName);
    }

    public static void close() {
        if (appContext instanceof ConfigurableApplicationContext) {
            ((ConfigurableApplicationContext) appContext).close();
        }
    }

    public static void setAppContext(ApplicationContext newAppContext) {
        appContext = newAppContext;
    }

    public static ApplicationContext getAppContext() {
        return appContext;
    }

    public static UserService getUserService() {
        return (UserService) getService(USER_SERVICE);
    }

    public static WorkgroupService getWorkgroupService() {
        return (WorkgroupService) getService(WORKGROUP_SERVICE);
    }

    public static LookupableService getLookupableService() {
        return (LookupableService) getService(LOOKUPABLE_SERVICE);
    }

    public static AdsService getAdsService() {
        return (AdsService) getService(ADS_SERVICE);
    }

    public static AccountService getAccountService() {
        return (AccountService) getService(ACCOUNT_SERVICE);
    }

    public static FiscalSubAccountService getFiscalSubAccountService() {
        return (FiscalSubAccountService) getService(FISCAL_SUB_ACCOUNT_SERVICE);
    }

    public static FISDataService getFISDataService() {
        return (FISDataService) getService(FIS_DATA_SERVICE);
    }

    public static WebAuthenticationService getWebAuthenticationService() {
        return (WebAuthenticationService) getService(WEB_AUTHENTICATION_SERVICE);
    }

    public static IUAuthenticatedEmailService getEmailService() {
        return (IUAuthenticatedEmailService) getService(EMAIL_SERVICE);
    }
}