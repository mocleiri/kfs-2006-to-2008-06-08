
/*
 * Copyright (c) 2004, 2005, 2006 Trustees of Indiana University and Cornell University.
 *
 * Licensed under the Educational Community License Version 1.0 (the "License"); By obtaining,
 * using and/or copying this Original Work, you agree that you have read, understand, and will
 * comply with the terms and conditions of the Educational Community License.
 *
 * For the full text of the license, see the LICENSE.txt file or visit:
 * 
 * http://kew.indiana.edu/workflow/LICENSE.txt
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING
 * BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE
 * AND NONINFRINGEMENT.
 * IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES
 * OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 */
            
package edu.iu.uis.eden.user;

import edu.iu.uis.eden.EdenConstants;
import edu.iu.uis.eden.core.Core;
import edu.iu.uis.eden.exception.EdenUserNotFoundException;
import edu.iu.uis.eden.exception.WorkflowRuntimeException;
import edu.iu.uis.eden.util.Utilities;
import edu.iu.uis.my.mygds.GdsClient;
import edu.iu.uis.my.mygds.GdsException;
import edu.iu.uis.sit.util.directory.gds.GdsAttributeCollection;
import edu.iu.uis.sit.util.directory.gds.GdsIdentifiableAttribute;
import edu.iu.uis.sit.util.directory.gds.GdsPerson;
import edu.iu.uis.sit.util.directory.gds.GdsPersonCollection;
import edu.iu.uis.sit.util.directory.gds.GivenName;
import edu.iu.uis.sit.util.directory.gds.IUEduPSEMPLID;
import edu.iu.uis.sit.util.directory.gds.IUEduUUID;
import edu.iu.uis.sit.util.directory.gds.NetworkId;
import edu.iu.uis.sit.util.directory.gds.Sn;

import java.io.FileInputStream;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Properties;


/**
 * IU-specific implementation of the UserService which allows for integration with IU's GDS user repository.
 * 
 * @author Eric Westfall
 */
public class IUUserServiceImpl extends BaseUserService {
    public static final org.apache.log4j.Logger LOG = org.apache.log4j.Logger.getLogger(
                                                              IUUserServiceImpl.class);
    public static final String ERR_KEY_INVALID_USER = "user.userservice.id.invalid";
    private transient static GdsClient gdsClient;
    private static Map workflowIdDateMap = new HashMap();

    /**
     * The IU implementation of getWorkflowUser() integrates with IU's GDS service for user lookup.  The
     * algorithm for retrieving users works as follows:
     * 
     *  <ol>
     *    <li>If an Authentication id is passed in, we normalize it to lowercase</li>
     *    <li>Attempt to fetch user from the cache, return user if found</li>
     *    <li>Check timestamp when user last updated</li>
     *    <li>If user is not stale, fetch from database</li>
     *    <li>If stale, fetch user from GDS, update user in database and then update timestamp</li>
     *    <li>Add user to cache before returning</li>
     *  </ol>
     */
    public WorkflowUser getWorkflowUser(UserId userId)
                                 throws EdenUserNotFoundException {
        userId = normalizeUserId(userId);

        WorkflowUser user = getCache().getFromCache(userId);

        if ((user != null) && !passesDateCheck(user)) {
            LOG.debug("Cached user fails date check with id " + userId);
            user = null;
        }

        if (user == null) {
            user = getUserFromGds(userId);

            if (user == null) {
                throw new EdenUserNotFoundException("User is invalid. userId " + 
                                                    userId.toString());
            } else {
                // Update the date for the user
                workflowIdDateMap.put(user.getWorkflowUserId(), new Date());
                getCache().addToCache(user);
            }
        }

        return user;
    }

    /**
     * The IU implementation of search() searches the GDS for users first and then the database if necessary.
     */
    public List search(WorkflowUser user, boolean useWildCards) {
        try {
            return this.getSearchResults(user.getLastName(), 
                                         user.getGivenName(), 
                                         user.getAuthenticationUserId()
                                             .getAuthenticationId(), 
                                         user.getWorkflowUserId()
                                             .getWorkflowId(), 
                                         user.getEmplId().getEmplId(), 
                                         user.getUuId().getUuId());
        } catch (GdsException e) {
            throw new WorkflowRuntimeException(e);
        }
    }

    private List getSearchResults(String lastName, String firstName, 
                                  String networkId, String workflowId, 
                                  String emplId, String uuId)
                           throws GdsException {
        List results = new ArrayList();

        if ((workflowId != null) && (workflowId.length() > 0)) {
            try {
                WorkflowUser user = getWorkflowUser(
                                            new WorkflowUserId(workflowId));

                if (user != null) {
                    results.add(user);
                }
            } catch (EdenUserNotFoundException e) {
                // could not locate the user with the given workflow id, return empty search results
            }
        } else {
            GdsAttributeCollection collection = new GdsAttributeCollection();

            if ((lastName != null) && (lastName.length() > 0)) {
                collection.add(new Sn(lastName + "*"));
            }

            if ((firstName != null) && (firstName.length() > 0)) {
                collection.add(new GivenName(firstName + "*"));
            }

            if ((networkId != null) && (networkId.length() > 0)) {
                collection.add(new NetworkId(networkId + "*"));
            }

            if ((emplId != null) && (emplId.length() > 0)) {
                collection.add(new IUEduPSEMPLID(emplId));
            }

            if ((uuId != null) && (uuId.length() > 0)) {
                collection.add(new IUEduUUID(uuId));
            }

            //try {
            GdsPersonCollection persons = getGdsClient()
                                              .fetchGdsUsers(collection);

            for (Iterator personIterator = persons.iterator();
                 personIterator.hasNext();) {
                GdsPerson person = (GdsPerson) personIterator.next();

                if (passesMinimunGdsCriteria(person)) {
                    UserId userId = null;

                    if ((person.getIuEduPSEMPLID() != null) && 
                            (person.getIuEduPSEMPLID().length() > 0)) {
                        userId = new EmplId(person.getIuEduPSEMPLID());
                    } else if ((person.getUid() != null) && 
                                   (person.getUid().length() > 0)) {
                        userId = new AuthenticationUserId(person.getUid());
                    } else if ((person.getIuEduUUID() != null) && 
                                   (person.getIuEduUUID().length() > 0)) {
                        userId = new UuId(person.getIuEduUUID());
                    } else {
                        LOG.error("search result returned from gds without an EMPLID, UID, or UUID: abandoning result" + 
                                  userId.toString());
                    }

                    if (userId != null) {
                        try {
                            WorkflowUser fetchedUser = getWorkflowUser(userId);
                            results.add(fetchedUser);
                        } catch (Exception e) {
                            LOG.error("error caught while fetching user based on: " + 
                                      userId.toString(), e);
                        }
                    }
                }
            }

            //} catch (Exception e) {
            //    LOG.error("Error encountered when searching for users: lastName " + lastName + " firstName " + firstName + " networkId " + networkId + " workflowId " + workflowId + " emplId " + emplId + " uuId " + uuId);
            //    throw new EdenUserNotFoundException(e.getMessage());
            //}
        }

        return results;
    }

    /**
     * Puts the userId in the proper form.  More specifically, if an AuthenticationUserId is passed it,
     * it's id will be lowercased.  We do this because IU network ids are not case sensitive so we
     * want to normalize them to a lowercase form for all processing.  The Persistent UserService from
     * which we extend handles AuthenticationUserIds as case-sensitive entities.
     */
    private UserId normalizeUserId(UserId userId) {
        if (userId instanceof AuthenticationUserId && !userId.isEmpty()) {
            AuthenticationUserId authId = (AuthenticationUserId) userId;
            authId.setAuthenticationId(authId.getAuthenticationId()
                                             .toLowerCase());
        }

        return userId;
    }

    private boolean passesDateCheck(WorkflowUser user) {
        Calendar calendar = Calendar.getInstance();
        calendar.add(Calendar.MINUTE, 
                     -Integer.parseInt(Utilities.getApplicationConstant(
                                               "Config.Application.MinutesToCacheUsers")));

        Date date = (Date) workflowIdDateMap.get(user.getWorkflowUserId());

        if (date == null) {
            LOG.warn("Did not find a date for user '" + 
                     user.getWorkflowUserId() + 
                     "' in the date Map.  This could indicate a bug in the service!");

            return false;
        }

        return date.after(calendar.getTime());
    }

    private WorkflowUser getUserFromGds(UserId userId)
                                 throws EdenUserNotFoundException {
        Calendar calendar = Calendar.getInstance();
        calendar.add(Calendar.MINUTE, 
                     -Integer.parseInt(Utilities.getApplicationConstant(
                                               EdenConstants.MINUTES_TO_CACHE_USERS_KEY)));

        // look in the database first
        BaseWorkflowUser user = (BaseWorkflowUser) getUserDAO()
                                                       .getWorkflowUser(userId);

        if ((user == null) || (user.getWorkflowUserId() == null) || 
                (user.getWorkflowUserId().getWorkflowId() == null) || 
                (user.getWorkflowUserId().getWorkflowId().length() < 1) || 
                (user.getLastUpdateDate() == null) || 
                user.getLastUpdateDate().before(calendar.getTime())) {
            try {
                // try to fetch the user and then add them to ojb
                GdsPerson person = null;
                BaseWorkflowUser workflowUser = null;

                if ((user != null) && (user.getWorkflowUserId() != null) && 
                        (user.getWorkflowUserId().getWorkflowId() != null)) {
                    person = getGdsClient().fetchGdsUser(getIdType(user));
                    workflowUser = user;
                } else {
                    person = getGdsClient().fetchGdsUser(getIdType(userId));
                    workflowUser = reconcileExistingUser(person);
                }

                if (passesMinimunGdsCriteria(person)) {
                    workflowUser.setDisplayName(person.getDisplayName());
                    workflowUser.setGivenName(person.getGivenName());
                    workflowUser.setLastName(person.getSn());
                    workflowUser.setEmailAddress(person.getMail());
                    workflowUser.setEmplId(
                            new EmplId(person.getIuEduPSEMPLID()));
                    workflowUser.setAuthenticationUserId(
                            new AuthenticationUserId(person.getUid()
                                                           .toLowerCase()));
                    workflowUser.setUuId(new UuId(person.getIuEduUUID()));

                    try {
                        //make sure we aren't going to blow a constraint violation on insert
                        if (!isViolatingExistingConstraint(workflowUser)) {
                            //this is weak but checking for constraint violations is incrementing the lock nbr making
                            //us blow an OptimisticLock here so we need to refresh to get the latest lock nbr
                            save(workflowUser);
                        } else {
                            LOG.error("Unable to store an expired user because a constraint violation would have been thrown.  " + 
                                      "UserId passed in " + userId + 
                                      " user found " + 
                                      getUserProblemLogString(workflowUser) + 
                                      "  Giving the user a fake workflow Id so they don't blow up the service cache");
                            throw new EdenUserNotFoundException(userId + 
                                                                " cannot be accessed");
                        }
                    } catch (Exception e) {
                        LOG.error("Error storing user to db. " + 
                                  getUserProblemLogString(workflowUser) + 
                                  " user found was " + 
                                  getUserProblemLogString(workflowUser) + 
                                  " UserId passed in " + userId, e);
                        throw new EdenUserNotFoundException(e.getMessage());
                    }

                    user = workflowUser;
                }
            } catch (GdsException e) {
                String message = "Failed to fetch user for " + userId + 
                                 ".  GDS error was '" + e.getMessage() + 
                                 "'.";
                LOG.warn(message + "  Throwing exception if user not in db.");

                //if we didn't find a user there is no alternative but to throw an exception
                if (user == null) {
                    LOG.error("Could not locate user in GDS or the database!", e);
                    throw new EdenUserNotFoundException(message);
                }
            }
        }

        return user;
    }

    private boolean passesMinimunGdsCriteria(GdsPerson person) {
        return ((person != null) && (person.getUid() != null) && 
               (person.getUid().length() > 0) && 
               (person.getIuEduPSEMPLID() != null) && 
               person.getIuEduPSEMPLID().length() > 0);
    }

    private GdsIdentifiableAttribute getIdType(UserId userId)
                                        throws EdenUserNotFoundException {
        if (userId instanceof EmplId) {
            return new IUEduPSEMPLID(((EmplId) userId).getEmplId());
        } else if (userId instanceof UuId) {
            return new IUEduUUID(((UuId) userId).getUuId());
        } else if (userId instanceof AuthenticationUserId) {
            return new NetworkId(((AuthenticationUserId) userId).getAuthenticationId()
                                                              .toLowerCase());
        }

        throw new EdenUserNotFoundException(
                "Invalid userId type to attempt GDS fetch.");
    }

    private GdsIdentifiableAttribute getIdType(WorkflowUser user) {
        if ((user != null) && (user.getEmplId() != null) && 
                (user.getEmplId().getEmplId() != null) && 
                (user.getEmplId().getEmplId().length() > 0)) {
            return new IUEduPSEMPLID(user.getEmplId().getEmplId());
        } else if ((user != null) && (user.getAuthenticationUserId() != null) && 
                       (user.getAuthenticationUserId().getAuthenticationId() != null) && 
                       (user.getAuthenticationUserId().getAuthenticationId()
                            .length() > 0)) {
            return new NetworkId(toLowerCase(user.getAuthenticationUserId())
                                     .getAuthenticationId());
        } else if ((user != null) && (user.getUuId() != null) && 
                       (user.getUuId().getUuId() != null) && 
                       (user.getUuId().getUuId().length() > 0)) {
            return new IUEduUUID(user.getUuId().getUuId());
        }

        throw new RuntimeException("Invalid user type to attempt GDS fetch");
    }

    /**
     * Attempts to reconcile the GdsPerson against existing users in the database.  Keys everything off of the EMPL id (which should be
     * non-null!).  This is to allow for the changing of network ids.  If we can find a user in the database with the given criteria,
     * we will return that user, otherwise we'll create a new user.
     */
    private BaseWorkflowUser reconcileExistingUser(GdsPerson person)
                                            throws EdenUserNotFoundException {
        BaseWorkflowUser reconciledUser = (BaseWorkflowUser) getUserDAO()
                                                                 .getWorkflowUser(new EmplId(person.getIuEduPSEMPLID()));

        if (reconciledUser == null) {
            reconciledUser = (BaseWorkflowUser) getBlankUser();
        } else {
            LOG.warn("Reconciled an existing user for gds person: " + 
                     person.getUid() + 
                     ".  This is most likely the result of a network id change.  Current network id in database is " + 
                     reconciledUser.getAuthenticationUserId().getId() + ".");
        }

        return reconciledUser;
    }

    private boolean isViolatingExistingConstraint(BaseWorkflowUser userToBeSaved)
                                           throws EdenUserNotFoundException {
        boolean isViolatingConstraint = false;

        if (userToBeSaved.getWorkflowUserId().getWorkflowId() == null) {
            BaseWorkflowUser constraintCheckUser = getUserDAO()
                                                       .getWorkflowUser(userToBeSaved.getAuthenticationUserId());

            if (constraintCheckUser != null) {
                LOG.error("User to be saved will throw a constraint violation on networkId not storing user " + 
                          getUserProblemLogString(userToBeSaved));
                isViolatingConstraint = true;
            }

            constraintCheckUser = getUserDAO()
                                      .getWorkflowUser(userToBeSaved.getEmplId());

            if (constraintCheckUser != null) {
                LOG.error("User to be saved will throw a constraint violation on emplId not storing user " + 
                          getUserProblemLogString(userToBeSaved));
                isViolatingConstraint = true;
            }

            //these don't have to come back from GDS with UUID populated
            if (userToBeSaved.getUuId().getUuId() != null) {
                constraintCheckUser = getUserDAO()
                                          .getWorkflowUser(userToBeSaved.getUuId());

                if (constraintCheckUser != null) {
                    LOG.error("User to be saved will throw a constraint violation on uuId not storing user " + 
                              getUserProblemLogString(userToBeSaved));
                    isViolatingConstraint = true;
                }
            }
        }

        return isViolatingConstraint;
    }

    private String getUserProblemLogString(WorkflowUser example) {
        String comment = "User ";

        if ((example.getWorkflowUserId() != null) && 
                (example.getWorkflowUserId().getWorkflowId() != null)) {
            comment += ("workflowId = '" + example.getWorkflowUserId()
                                                  .getWorkflowId() + "' ");
        }

        if ((example.getAuthenticationUserId() != null) && 
                (example.getAuthenticationUserId().getAuthenticationId() != null)) {
            comment += ("networkId = '" + example.getAuthenticationUserId()
                                                 .getAuthenticationId() + "' ");
        }

        if ((example.getEmplId() != null) && 
                (example.getEmplId().getEmplId() != null)) {
            comment += ("emplId = '" + example.getEmplId().getEmplId() + "' ");
        }

        return comment;
    }

    private AuthenticationUserId toLowerCase(AuthenticationUserId userId) {
        return new AuthenticationUserId(userId.getAuthenticationId()
                                              .toLowerCase());
    }

    private GdsClient getGdsClient() {
        if (gdsClient == null) {
            try {
                String gdsSettingsLoc = Core.getRootConfig()
                                            .getProperty("gds.settings.path");
                String gdsSecurityLoc = Core.getRootConfig()
                                            .getProperty("gds.security.path");
                Properties settingsProperties = new Properties();
                Properties securityProperties = new Properties();
                settingsProperties.load(new FileInputStream(gdsSettingsLoc));
                securityProperties.load(new FileInputStream(gdsSecurityLoc));
                gdsClient = GdsClient.initGdsClient(
                                    settingsProperties.getProperty("ldapUrl"), 
                                    securityProperties.getProperty("username"), 
                                    securityProperties.getProperty("password"));
            } catch (Exception e) {
                LOG.error("Error initing GDS Client", e);
                throw new RuntimeException("Error initing GDS Client");
            }
        }

        return gdsClient;
    }
}