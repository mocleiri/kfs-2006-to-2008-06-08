
/*
 * Copyright (c) 2004, 2005, 2006 Trustees of Indiana University and Cornell University.
 *
 * Licensed under the Educational Community License Version 1.0 (the "License"); By obtaining,
 * using and/or copying this Original Work, you agree that you have read, understand, and will
 * comply with the terms and conditions of the Educational Community License.
 *
 * For the full text of the license, see the LICENSE.txt file or visit:
 * 
 * http://kew.indiana.edu/workflow/LICENSE.txt
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING
 * BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE
 * AND NONINFRINGEMENT.
 * IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES
 * OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 */
            
package edu.iu.uis.eden.services.docelements;

import edu.iu.uis.eden.WorkflowServiceErrorImpl;
import edu.iu.uis.eden.exception.InvalidXmlException;
import edu.iu.uis.eden.exception.ResourceUnavailableException;
import edu.iu.uis.eden.services.IDocElement;
import edu.iu.uis.eden.services.InconsistentDocElementStateException;
import edu.iu.uis.eden.services.ServiceErrorConstants;

import org.jdom.Element;


/**
 * <p>Title: UniversityOrganizationElement</p>
 * <p>Description: Compound Doc Element.  Brings ChartElement and
 * OrgCodeElement together into a single route control.</p>
 * <p>Copyright: Copyright (c) 2002</p>
 * <p>Company: Indiana University</p>
 * @author Ryan Kirkendall
 * @version 1.0
 */
public class FiscalSubAccountElement implements IDocElement {
    // TODO needs implemented!
    private static final org.apache.log4j.Logger LOG = 
            org.apache.log4j.Logger.getLogger(FiscalSubAccountElement.class);
    private static final String ELEMENT_NAME = "fiscal_sub_account_eok";
    private boolean routeControl;
    private ChartElement chartElement;
    private AccountNumberElement accountNumberElement;
    private SubAccountNumberElement subAccountNumberElement;

    public FiscalSubAccountElement() {
        LOG.debug("constructing . . .");
        this.routeControl = true;
        chartElement = new ChartElement();
        accountNumberElement = new AccountNumberElement();
        subAccountNumberElement = new SubAccountNumberElement();
    }

    public Element getXMLContent() {
        LOG.debug("getXMLContent");

        if (this.isEmpty()) {
            return null;
        }

        Element me = new Element(ELEMENT_NAME);

        if (!this.chartElement.isEmpty()) {
            LOG.debug("inserting chart element");
            me.addContent(chartElement.getXMLContent());
        }

        if (!this.accountNumberElement.isEmpty()) {
            LOG.debug("inserting account element");
            me.addContent(accountNumberElement.getXMLContent());
        }

        if (!this.subAccountNumberElement.isEmpty()) {
            LOG.debug("inserting sub account element");
            me.addContent(subAccountNumberElement.getXMLContent());
        }

        LOG.debug("return XMLContent " + me.toString());

        return me;
    }

    public void loadFromXMLContent(Element element, boolean allowBlank)
                            throws InvalidXmlException, 
                                   InconsistentDocElementStateException {
        LOG.debug("loadFromXMLContent");

        if (DocElementValidator.returnWithNoWorkDone(this, element, allowBlank)) {
            LOG.debug("returning without setting");

            return;
        }


        //it's good loading kiddies with their elements
        chartElement.loadFromXMLContent(element.getChild(
                                                chartElement.getElementName()), 
                                        allowBlank);

        accountNumberElement.loadFromXMLContent(element.getChild(
                                                        accountNumberElement.getElementName()), 
                                                allowBlank);

        subAccountNumberElement.loadFromXMLContent(element.getChild(
                                                           subAccountNumberElement.getElementName()), 
                                                   allowBlank);

        LOG.debug("loaded FiscalSubAccountElement");
    }

    public WorkflowServiceErrorImpl validate() {
        LOG.debug("validate");

        boolean inError = false;

        WorkflowServiceErrorImpl myErrors = new WorkflowServiceErrorImpl(
                                                    "Fiscal Sub Account Children In Error", 
                                                    ServiceErrorConstants.CHILDREN_IN_ERROR);

        WorkflowServiceErrorImpl chartError = chartElement.validate();

        if (chartError != null) {
            LOG.debug("chart is in error");
            inError = true;
            myErrors.addChild(chartError);
        }

        WorkflowServiceErrorImpl accountError = accountNumberElement.validate();

        if (accountError != null) {
            LOG.debug("account is in error");
            inError = true;
            myErrors.addChild(accountError);
        }

        WorkflowServiceErrorImpl subAccountError = subAccountNumberElement.validate();

        if (subAccountError != null) {
            LOG.debug("sub account is in error");
            inError = true;
            myErrors.addChild(subAccountError);
        }

        if (inError) {
            LOG.debug("in error returning a DocElementError");

            return myErrors;
        }

        LOG.debug("valid returning null");

        return null;
    }

    public boolean isEmpty() {
        return this.chartElement.isEmpty() && 
               this.accountNumberElement.isEmpty() && 
               this.subAccountNumberElement.isEmpty();
    }

    public String getElementName() {
        return ELEMENT_NAME;
    }

    public void setRouteControl(boolean routeControl) {
    }

    public boolean isRouteControl() {
        return this.routeControl;
    }

    /**
     * Validates that the chart and org exist within the IU Hierarchy.
     *
     * @return true if the object is valid false if not
     * @throws ResourceUnavailableException
     */
    protected boolean databaseValidate() {
        // TODO implement this for the fiscal sub account stuff

        /*try {
          EdenInfo info = new EdenInfo(EdenDocumentConfig.edenAppCode);
        
          return info.isValidOrg(this.getChart(), this.getOrgCode());
        } catch (Exception ex) {
          LOG.warn(ex, ex);
          throw new ResourceUnavailableException(ex.getMessage());
        }*/
        return false;
    }

    public void setChart(String chart) {
        this.chartElement.setChart(chart);
    }

    public String getChart() {
        return this.chartElement.getChart();
    }

    public void setAccountNumber(String accountNumber) {
        this.accountNumberElement.setAccountNumber(accountNumber);
    }

    public String getAccountNumber() {
        return accountNumberElement.getAccountNumber();
    }

    public void setSubAccountNumber(String subAccountNumber) {
        this.subAccountNumberElement.setSubAccountNumber(subAccountNumber);
    }

    public String getSubAccountNumber() {
        return subAccountNumberElement.getSubAccountNumber();
    }

    /**
     * validates underlying chart outside of the context of being in a
     * UniversityOrganizationElement
     *
     * @return DocElementError of underlying chart's error(s)
     */
    public WorkflowServiceErrorImpl validateChart() {
        return this.chartElement.validate();
    }

    public WorkflowServiceErrorImpl validateAccountNumber() {
        return this.accountNumberElement.validate();
    }

    public WorkflowServiceErrorImpl validateSubAccountNumber() {
        return this.subAccountNumberElement.validate();
    }
}

/*
 * Copyright 2003 The Trustees of Indiana University.  All rights reserved.
 *
 * This file is part of the EDEN software package.
 * For license information, see the LICENSE file in the top level directory
 * of the EDEN source distribution.
 */
