
/*
 * Copyright (c) 2004, 2005, 2006 Trustees of Indiana University and Cornell University.
 *
 * Licensed under the Educational Community License Version 1.0 (the "License"); By obtaining,
 * using and/or copying this Original Work, you agree that you have read, understand, and will
 * comply with the terms and conditions of the Educational Community License.
 *
 * For the full text of the license, see the LICENSE.txt file or visit:
 * 
 * http://kew.indiana.edu/workflow/LICENSE.txt
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING
 * BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE
 * AND NONINFRINGEMENT.
 * IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES
 * OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 */
            
package edu.iu.uis.eden.services.docelements;

import edu.iu.uis.eden.WorkflowServiceErrorImpl;
import edu.iu.uis.eden.exception.InvalidXmlException;
import edu.iu.uis.eden.services.IDocElement;
import edu.iu.uis.eden.services.InconsistentDocElementStateException;
import edu.iu.uis.eden.services.ServiceErrorConstants;

import org.jdom.Element;


/**
 * <p>Title: PriorityElement </p>
 * <p>Description: Represents a PriorityElement element both in xml for documents
 * and as a PriorityElement entity itself concerning validation. <br><BR>
 * See IDocElement documentation for
 * further explanation.</p>
 * <p>Copyright: Copyright (c) 2002</p>
 * <p>Company: Indiana University</p>
 * @author Ryan Kirkendall
 * @version 1.0
 */
public class PriorityElement implements IDocElement {
    private static final org.apache.log4j.Logger LOG = 
            org.apache.log4j.Logger.getLogger(PriorityElement.class);
    private static final String ATTRIBUTE_NAME = "value";
    private static final String ELEMENT_NAME = "priority";
    private boolean routeControl;
    private int priority;
    private boolean hasBeenSet;

    public PriorityElement() {
        LOG.debug("constructing . . .");
        this.routeControl = false;
    }

    public Element getXMLContent() {
        LOG.debug("getXMLContent");

        if (this.isEmpty()) {
            LOG.debug("empty returning null");

            return null;
        }

        //make element and output it
        Element me = new Element(ELEMENT_NAME);
        me.setAttribute(ATTRIBUTE_NAME, new Long(this.priority).toString());

        LOG.debug("return XMLContent " + me.toString());

        return me;
    }

    public void loadFromXMLContent(Element element, boolean allowBlank)
                            throws InvalidXmlException, 
                                   InconsistentDocElementStateException {
        LOG.debug("loadFromXMLContent");

        if (DocElementValidator.returnWithNoWorkDone(this, element, allowBlank)) {
            LOG.debug("returning without setting");

            return;
        }

        //it's good load from element
        String elementValue = element.getAttributeValue(ATTRIBUTE_NAME);

        Integer val = null;

        try {
            val = new Integer(elementValue);
        } catch (Exception ex) {
            throw new InvalidXmlException("Element " + ELEMENT_NAME + 
                                          " attribute " + ATTRIBUTE_NAME + 
                                          " value is of the wrong " + 
                                          "type.  Must be convertible to long.");
        }

        this.priority = val.intValue();
        LOG.debug("loaded. priority =" + this.priority);
    }

    public WorkflowServiceErrorImpl validate() {
        LOG.debug("validate");

        /* must be an int greater than 0 */
        if (this.priority <= 0) {
            LOG.debug("priority not greater than 0 returning error object");

            return new WorkflowServiceErrorImpl("priority not greater than 0", 
                                                ServiceErrorConstants.PRIORITY_INVALID);
        }

        LOG.debug("valid returning null");

        return null;
    }

    public String getElementName() {
        return ELEMENT_NAME;
    }

    public void setRouteControl(boolean routeControl) {
    }

    public boolean isRouteControl() {
        return this.routeControl;
    }

    /**
     *
     * @return boolean indicating if object has been set.
     */
    public boolean isEmpty() {
        LOG.debug("isEmpty()");

        if (this.hasBeenSet) {
            LOG.debug("not Empty returning false");

            return false;
        }

        return true;
    }

    /**
     *
     * @param priority long value of the priority
     */
    public void setPriority(int priority) {
        this.priority = priority;
        this.hasBeenSet = true;
    }

    /**
     *
     * @return long value of the priority
     */
    public int getPriority() {
        return this.priority;
    }
}

/*
 * Copyright 2003 The Trustees of Indiana University.  All rights reserved.
 *
 * This file is part of the EDEN software package.
 * For license information, see the LICENSE file in the top level directory
 * of the EDEN source distribution.
 */
