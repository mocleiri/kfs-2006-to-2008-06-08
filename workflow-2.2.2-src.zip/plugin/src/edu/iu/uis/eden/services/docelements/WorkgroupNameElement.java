
/*
 * Copyright (c) 2004, 2005, 2006 Trustees of Indiana University and Cornell University.
 *
 * Licensed under the Educational Community License Version 1.0 (the "License"); By obtaining,
 * using and/or copying this Original Work, you agree that you have read, understand, and will
 * comply with the terms and conditions of the Educational Community License.
 *
 * For the full text of the license, see the LICENSE.txt file or visit:
 * 
 * http://kew.indiana.edu/workflow/LICENSE.txt
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING
 * BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE
 * AND NONINFRINGEMENT.
 * IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES
 * OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 */
            
package edu.iu.uis.eden.services.docelements;

import edu.iu.uis.eden.WorkflowServiceErrorImpl;
import edu.iu.uis.eden.exception.InvalidXmlException;
import edu.iu.uis.eden.services.IDocElement;
import edu.iu.uis.eden.services.InconsistentDocElementStateException;
import edu.iu.uis.eden.services.ServiceErrorConstants;

import org.jdom.Element;


/**
 * <p>Title: NameElement</p>
 * <p>Description: Element that validates empty and writes itself as
 * name in xml.</p>
 * <p>Copyright: Copyright (c) 2005</p>
 * <p>Company: Indiana University</p>
 * @author Bryan Hutchinson
 * @version 1.0
 */
public class WorkgroupNameElement implements IDocElement {
    private static final org.apache.log4j.Logger LOG = 
            org.apache.log4j.Logger.getLogger(WorkgroupNameElement.class);
    private static String ELEMENT_NAME = "workgroup_name";
    private GenericStringElement stringElement;

    public WorkgroupNameElement() {
        LOG.debug("constructing . . .");
        this.stringElement = new GenericStringElement(ELEMENT_NAME, 
                                                      ServiceErrorConstants.NAME_BLANK, 
                                                      false);
    }

    public Element getXMLContent() {
        LOG.debug("getXMLContent");

        return this.stringElement.getXMLContent();
    }

    public void loadFromXMLContent(Element element, boolean allowBlank)
                            throws InvalidXmlException, 
                                   InconsistentDocElementStateException {
        LOG.debug("loadFromXMLContent allowBlank = " + allowBlank);
        this.stringElement.loadFromXMLContent(element, allowBlank);
    }

    public boolean isEmpty() {
        LOG.debug("isEmpty");

        return this.stringElement.isEmpty();
    }

    public WorkflowServiceErrorImpl validate() {
        LOG.debug("validate()");

        return this.stringElement.validate();
    }

    public String getElementName() {
        return ELEMENT_NAME;
    }

    public void setRouteControl(boolean routeControl) {
    }

    public boolean isRouteControl() {
        return this.stringElement.isRouteControl();
    }

    /**
     *
     * @param name value of the workgroup name element
     */
    public void setWorkgroupName(String name) {
        this.stringElement.setMyValue(name);
    }

    /**
     *
     * @return value workgroup name element was set with
     */
    public String getWorkgroupName() {
        return this.stringElement.getMyValue();
    }
}

/*
 * Copyright 2003 The Trustees of Indiana University.  All rights reserved.
 *
 * This file is part of the EDEN software package.
 * For license information, see the LICENSE file in the top level directory
 * of the EDEN source distribution.
 */
