
/*
 * Copyright (c) 2004, 2005, 2006 Trustees of Indiana University and Cornell University.
 *
 * Licensed under the Educational Community License Version 1.0 (the "License"); By obtaining,
 * using and/or copying this Original Work, you agree that you have read, understand, and will
 * comply with the terms and conditions of the Educational Community License.
 *
 * For the full text of the license, see the LICENSE.txt file or visit:
 * 
 * http://kew.indiana.edu/workflow/LICENSE.txt
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING
 * BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE
 * AND NONINFRINGEMENT.
 * IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES
 * OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 */
            
package edu.iu.uis.eden.services.docelements;

import edu.iu.uis.eden.WorkflowServiceErrorImpl;
import edu.iu.uis.eden.exception.InvalidXmlException;
import edu.iu.uis.eden.services.IDocElement;
import edu.iu.uis.eden.services.InconsistentDocElementStateException;
import edu.iu.uis.eden.services.ServiceErrorConstants;

import java.util.Date;

import org.jdom.Element;


/**
 * <p>Title: DateElement</p>
 * <p>Description: Represents a Date element both in xml for documents and as a
 * Date entity itself concerning validation. Can be a to_date, from_date or
 * date.  Differences in implementation are minor except for xml expected and
 * rendered<br><br>
 * See IDocElement documentation for
 * further explanation.</p>
 * <p>Copyright: Copyright (c) 2002</p>
 * <p>Company: Indiana University</p>
 * @author Ryan Kirkendall
 * @version 1.0
 */
public class DateElement implements IDocElement {
    private static final org.apache.log4j.Logger LOG = 
            org.apache.log4j.Logger.getLogger(DateElement.class);
    private static final String ATTRIBUTE_NAME = "value";
    private static final String ELEMENT_NAME = "date";
    protected static String DATE_FORMAT = "MM/dd/yyyy";
    private boolean routeControl;
    private Date date;

    public DateElement() {
        LOG.debug("constructing . . .");
        this.routeControl = false;
    }

    public Element getXMLContent() {
        LOG.debug("getXMLContent");

        if (date == null) {
            LOG.debug("date null returning empty String");

            return null;
        }

        //make element
        Element me = new Element(ELEMENT_NAME);

        me.setAttribute(ATTRIBUTE_NAME, 
                        new Long(this.getDate().getTime()).toString());

        LOG.debug("returning XMLContent = " + me.toString());

        return me;
    }

    public void loadFromXMLContent(Element element, boolean allowBlank)
                            throws InvalidXmlException, 
                                   InconsistentDocElementStateException {
        LOG.debug("loadFromXMLContent");

        if (DocElementValidator.returnWithNoWorkDone(this, element, allowBlank)) {
            return;
        }

        //get the string value of the date
        String stringDate = element.getAttributeValue(ATTRIBUTE_NAME);

        //get a formatter and turn the strin into a date
        try {
            this.date = new Date(new Long(stringDate).longValue());
        } catch (Exception ex) {
            throw new InvalidXmlException("Date in XML Content element " + 
                                          ELEMENT_NAME + " attribute " + 
                                          ATTRIBUTE_NAME + 
                                          " is invalid value = " + 
                                          stringDate);
        }

        LOG.debug("loaded date = " + stringDate);
    }

    public WorkflowServiceErrorImpl validate() {
        LOG.debug("validate");

        if (this.isEmpty()) {
            LOG.debug("invalid");

            return new WorkflowServiceErrorImpl("Blank Date", 
                                                ServiceErrorConstants.DATE_BLANK);
        }

        LOG.debug("valid returning null");

        return null;
    }

    /**
     * Tell whether the objects value property/properties have values
     *
     * @return true when object is empty
     */
    public boolean isEmpty() {
        LOG.debug("isEmpty()");

        if (this.date == null) {
            LOG.debug("empty");

            return true;
        }

        LOG.debug("false");

        return false;
    }

    public String getElementName() {
        return ELEMENT_NAME;
    }

    public void setRouteControl(boolean routeControl) {
        this.routeControl = false;
    }

    public boolean isRouteControl() {
        return this.routeControl;
    }

    /**
     * @return Date this object is loaded with
     */
    public Date getDate() {
        LOG.debug("getDate()");

        return this.date;
    }

    /**
     * @param date to load this object
     */
    public void setDate(Date date) {
        this.date = date;
    }
}

/*
 * Copyright 2003 The Trustees of Indiana University.  All rights reserved.
 *
 * This file is part of the EDEN software package.
 * For license information, see the LICENSE file in the top level directory
 * of the EDEN source distribution.
 */
