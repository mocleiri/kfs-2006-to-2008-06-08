
/*
 * Copyright (c) 2004, 2005, 2006 Trustees of Indiana University and Cornell University.
 *
 * Licensed under the Educational Community License Version 1.0 (the "License"); By obtaining,
 * using and/or copying this Original Work, you agree that you have read, understand, and will
 * comply with the terms and conditions of the Educational Community License.
 *
 * For the full text of the license, see the LICENSE.txt file or visit:
 * 
 * http://kew.indiana.edu/workflow/LICENSE.txt
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING
 * BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE
 * AND NONINFRINGEMENT.
 * IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES
 * OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 */
            
package edu.iu.uis.eden.services.docelements;

import edu.iu.uis.eden.WorkflowServiceErrorImpl;
import edu.iu.uis.eden.exception.InvalidXmlException;
import edu.iu.uis.eden.routing.OrgCodeEOK;
import edu.iu.uis.eden.services.IDocElement;
import edu.iu.uis.eden.services.InconsistentDocElementStateException;
import edu.iu.uis.eden.services.ServiceErrorConstants;

import org.jdom.Element;


/**
 * <p>Title: OrgCodeElement </p>
 * <p>Description: Business respresentation of a OrgCode both in XML and \
 * business rules.  <br><BR>
 *  See IDocElement documentation for
 * further explanation.</p>
 *
 * <p>Copyright: Copyright (c) 2002</p>
 * <p>Company: Indiana University</p>
 * @author Ryan Kirkendall
 * @version 1.0
 */
public class OrgCodeElement implements IDocElement {
    private static final org.apache.log4j.Logger LOG = 
            org.apache.log4j.Logger.getLogger(OrgCodeElement.class);
    private static final String ATTRIBUTE_NAME = "value";
    private boolean routeControl;
    private String orgCode;

    public OrgCodeElement() {
        LOG.debug("constructing . . .");
        this.routeControl = false;
    }

    public Element getXMLContent() {
        LOG.debug("getXMLContent");

        //no eok representation of this fine grain of an element so if org is null
        // or empty return an empty string
        if (this.isEmpty()) {
            LOG.debug("empty returning empty String");

            return null;
        }

        //make the element
        Element me = new Element(OrgCodeEOK.ORG_CD_TAG);
        me.setAttribute(ATTRIBUTE_NAME, orgCode);

        LOG.debug("returning XMLContent = " + me.toString());

        return me;
    }

    public void loadFromXMLContent(Element element, boolean allowBlank)
                            throws InvalidXmlException, 
                                   InconsistentDocElementStateException {
        LOG.debug("loadFromXMLContent allowBlank = " + allowBlank);

        if (DocElementValidator.returnWithNoWorkDone(this, element, allowBlank)) {
            return;
        }

        this.orgCode = element.getAttributeValue(ATTRIBUTE_NAME);
        LOG.debug("element found setting value");
    }

    public WorkflowServiceErrorImpl validate() {
        LOG.debug("validate");

        if (this.isEmpty()) {
            LOG.debug("invalid return DocElementError");

            return new WorkflowServiceErrorImpl("Org Code blank", 
                                                ServiceErrorConstants.ORG_BLANK);
        }

        LOG.debug("valid returning null");

        return null;
    }

    /**
     * Tell whether the objects value property/properties have values
     *
     * @return true when object is empty
     */
    public boolean isEmpty() {
        LOG.debug("isEmpty()");

        if ((this.orgCode == null) || this.orgCode.trim().equals("")) {
            LOG.debug("empty");

            return true;
        }

        LOG.debug("not empty");

        return false;
    }

    /**
     *
     * @param orgCode An Org Code
     */
    public void setOrgCode(String orgCode) {
        this.orgCode = orgCode;
    }

    /**
     *
     * @return String or an Org Code
     */
    public String getOrgCode() {
        return this.orgCode;
    }

    public String getElementName() {
        return OrgCodeEOK.ORG_CD_TAG;
    }

    public void setRouteControl(boolean routeControl) {
        this.routeControl = false;
    }

    public boolean isRouteControl() {
        return this.routeControl;
    }
}

/*
 * Copyright 2003 The Trustees of Indiana University.  All rights reserved.
 *
 * This file is part of the EDEN software package.
 * For license information, see the LICENSE file in the top level directory
 * of the EDEN source distribution.
 */
