
/*
 * Copyright (c) 2004, 2005, 2006 Trustees of Indiana University and Cornell University.
 *
 * Licensed under the Educational Community License Version 1.0 (the "License"); By obtaining,
 * using and/or copying this Original Work, you agree that you have read, understand, and will
 * comply with the terms and conditions of the Educational Community License.
 *
 * For the full text of the license, see the LICENSE.txt file or visit:
 * 
 * http://kew.indiana.edu/workflow/LICENSE.txt
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING
 * BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE
 * AND NONINFRINGEMENT.
 * IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES
 * OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 */
            
package edu.iu.uis.eden.services.docelements;

import edu.iu.uis.eden.WorkflowServiceErrorImpl;
import edu.iu.uis.eden.exception.InvalidXmlException;
import edu.iu.uis.eden.routing.DocumentTypeEOK;
import edu.iu.uis.eden.services.IDocElement;
import edu.iu.uis.eden.services.InconsistentDocElementStateException;
import edu.iu.uis.eden.services.ServiceErrorConstants;

import org.jdom.Element;


/**
 * <p>Title: DocumentTypeElement</p>
 * <p>Description: Represents a DocumentTypeElement element both in xml for
 * documents and as a DocumentTypeElement entity itself concerning validation.
 * <br><br>
 * See IDocElement documentation for
 * further explanation.</p>
 * <p>Copyright: Copyright (c) 2002</p>
 * <p>Company: Indiana University</p>
 * @author Ryan Kirkendall
 * @version 1.0
 */
public class DocumentTypeElement implements IDocElement {
    private static final org.apache.log4j.Logger LOG = 
            org.apache.log4j.Logger.getLogger(DocumentTypeElement.class);
    private boolean routeControl;
    private String documentType;

    public DocumentTypeElement() {
        LOG.debug("constructing . . .");
        this.routeControl = true;
    }

    public Element getXMLContent() {
        LOG.debug("getXMLContent");

        if (this.isEmpty()) {
            LOG.debug("empty returning null");

            return null;
        }

        //TODO remove dependency on this EOK as it is never used and delete the EOK.
        DocumentTypeEOK docTypeEOK = null;

        try {
            docTypeEOK = new DocumentTypeEOK(this.documentType, 
                                             this.isRouteControl());
        } catch (Exception ex) {
            LOG.error("programmatic error this should never have happened. " + 
                      "the DocumentTypeEOK threw an error loading internal " + 
                      "information.  Treating this object as empty", ex);

            return null;
        }

        return docTypeEOK.buildJdom();
    }

    public void loadFromXMLContent(Element element, boolean allowBlank)
                            throws InvalidXmlException, 
                                   InconsistentDocElementStateException {
        LOG.debug("loadFromXMLContent allowBlank = " + allowBlank);

        if (DocElementValidator.returnWithNoWorkDone(this, element, allowBlank)) {
            return;
        }

        //load up with a DocumentTypeEOK
        DocumentTypeEOK docTypeEOK = null;

        try {
            docTypeEOK = new DocumentTypeEOK(element);
        } catch (Exception ex) {
            LOG.error("DocumentTypeEOK threw exception loading from passed in " + 
                      "element.  Throwing InvalidXmlException", ex);
            throw new InvalidXmlException(
                    "Invalid element given to DocumentTypeElement");
        }

        this.documentType = docTypeEOK.getDoc_type();
        this.routeControl = docTypeEOK.isRouteControl();
    }

    public WorkflowServiceErrorImpl validate() {
        LOG.debug("validate()");

        if (this.isEmpty()) {
            LOG.debug("invalid");

            return new WorkflowServiceErrorImpl("DocumentType is empty", 
                                                ServiceErrorConstants.DOC_TYPE_BLANK);
        }

        LOG.debug("valid returning null");

        return null;
    }

    public String getElementName() {
        return DocumentTypeEOK.DOC_TYPE_EOK;
    }

    public void setRouteControl(boolean routeControl) {
    }

    public boolean isRouteControl() {
        return this.routeControl;
    }

    /**
     * Tell whether the objects value property/properties have values
     *
     * @return true when object is empty
     */
    public boolean isEmpty() {
        LOG.debug("isEmpty()");

        if ((this.documentType == null) || 
                this.documentType.trim().equals("")) {
            LOG.debug("empty");

            return true;
        }

        LOG.debug("not empty");

        return false;
    }

    /**
     *
     * @param documentType the document type full name
     */
    public void setDocumentType(String documentType) {
        this.documentType = documentType;
    }

    /**
     *
     * @return document type full name
     */
    public String getDocumentType() {
        return this.documentType;
    }
}

/*
 * Copyright 2003 The Trustees of Indiana University.  All rights reserved.
 *
 * This file is part of the EDEN software package.
 * For license information, see the LICENSE file in the top level directory
 * of the EDEN source distribution.
 */
