
/*
 * Copyright (c) 2004, 2005, 2006 Trustees of Indiana University and Cornell University.
 *
 * Licensed under the Educational Community License Version 1.0 (the "License"); By obtaining,
 * using and/or copying this Original Work, you agree that you have read, understand, and will
 * comply with the terms and conditions of the Educational Community License.
 *
 * For the full text of the license, see the LICENSE.txt file or visit:
 * 
 * http://kew.indiana.edu/workflow/LICENSE.txt
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING
 * BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE
 * AND NONINFRINGEMENT.
 * IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES
 * OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 */
            
package edu.iu.uis.eden.services.docelements;

import edu.iu.uis.eden.WorkflowServiceErrorImpl;
import edu.iu.uis.eden.exception.InvalidXmlException;
import edu.iu.uis.eden.services.IDocElement;
import edu.iu.uis.eden.services.InconsistentDocElementStateException;
import edu.iu.uis.eden.services.ServiceErrorConstants;

import java.util.Date;

import org.jdom.Element;


/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2002</p>
 * <p>Company: Indiana University</p>
 * @author unascribed
 * @version revision
 */
public class DateRangeElement implements IDocElement {
    private static final org.apache.log4j.Logger LOG = 
            org.apache.log4j.Logger.getLogger(DateRangeElement.class);
    private static String ELEMENT_NAME = "dateRange";
    private static String TO_DATE_WRAPPER_TAG = "toDate";
    private static String FROM_DATE_WRAPPER_TAG = "fromDate";
    private static String NOW_DATE_WRAPPER_TAG = "nowDate";
    private boolean routeControl;
    private DateElement toDate;
    private DateElement fromDate;
    private DateElement nowDate;

    public DateRangeElement() {
        LOG.debug("constructing . . .");
        this.routeControl = false;
        toDate = new DateElement();
        fromDate = new DateElement();
        nowDate = new DateElement();
        nowDate.setDate(new Date());
    }

    public Element getXMLContent() {
        LOG.debug("getXMLContent");

        if (this.isEmpty()) {
            LOG.debug("empty returning null");

            return null;
        }

        Element me = new Element(ELEMENT_NAME);

        /** get individual object Elements if they're not empty */
        if (!this.toDate.isEmpty()) {
            LOG.debug("creating to date element");

            Element toDateWrapperElement = new Element(TO_DATE_WRAPPER_TAG);
            toDateWrapperElement.addContent(this.toDate.getXMLContent());
            me.addContent(toDateWrapperElement);
        }

        if (!this.fromDate.isEmpty()) {
            LOG.debug("creating from date element");

            Element fromDateWrapperElement = new Element(FROM_DATE_WRAPPER_TAG);
            fromDateWrapperElement.addContent(this.fromDate.getXMLContent());
            me.addContent(fromDateWrapperElement);
        }

        LOG.debug("creating now date element");

        Element nowDateWrapperElement = new Element(NOW_DATE_WRAPPER_TAG);
        nowDateWrapperElement.addContent(this.nowDate.getXMLContent());
        me.addContent(nowDateWrapperElement);

        return me;
    }

    public void loadFromXMLContent(Element element, boolean allowBlank)
                            throws InvalidXmlException, 
                                   InconsistentDocElementStateException {
        LOG.debug("loadFromXMLContent allowBlank = " + allowBlank);

        if (DocElementValidator.returnWithNoWorkDone(this, element, allowBlank)) {
            return;
        }

        /** use the returnWithNoWorkDone method to tell us if the wrapper elements
           are present and give us a nice exception if they aren't */
        /** test and load toDate based on the presence of the wrapper element */
        if (DocElementValidator.isElementPresent(TO_DATE_WRAPPER_TAG, 
                                                 element.getChild(
                                                         TO_DATE_WRAPPER_TAG), 
                                                 allowBlank)) {
            /** the wrapper isn't here but we have blown must be allowing blanks */
        } else {
            LOG.debug("loading toDate element");

            /** the wrapper is here we've got a value */
            /** get the wrapper */
            Element wrapper = element.getChild(TO_DATE_WRAPPER_TAG);
            toDate.loadFromXMLContent(wrapper.getChild(toDate.getElementName()), 
                                      allowBlank);
        }

        /** test and load fromDate based on the presence of the wrapper element */
        if (DocElementValidator.isElementPresent(FROM_DATE_WRAPPER_TAG, 
                                                 element.getChild(
                                                         FROM_DATE_WRAPPER_TAG), 
                                                 allowBlank)) {
            /** the wrapper isn't here but we have blown must be allowing blanks */
        } else {
            LOG.debug("loading fromDate element");

            /** the wrapper is here we've got a value */
            Element wrapper = element.getChild(FROM_DATE_WRAPPER_TAG);
            fromDate.loadFromXMLContent(wrapper.getChild(
                                                fromDate.getElementName()), 
                                        allowBlank);
        }

        /* test and load nowDate don't allow blank here as that would mean
           programmatic error */
        if (DocElementValidator.isElementPresent(NOW_DATE_WRAPPER_TAG, 
                                                 element.getChild(
                                                         NOW_DATE_WRAPPER_TAG), 
                                                 false)) {
            LOG.debug("loading nowDate element");

            Element wrapper = element.getChild(NOW_DATE_WRAPPER_TAG);
            nowDate.loadFromXMLContent(wrapper.getChild(
                                               nowDate.getElementName()), false);
        }
    }

    public WorkflowServiceErrorImpl validate() {
        LOG.debug("validate");

        /** see if the kids are valid */
        WorkflowServiceErrorImpl toDateError = this.toDate.validate();
        WorkflowServiceErrorImpl fromDateError = this.fromDate.validate();

        WorkflowServiceErrorImpl dateRangeError = new WorkflowServiceErrorImpl(
                                                          "Children in error", 
                                                          ServiceErrorConstants.CHILDREN_IN_ERROR);

        /* if one is in error wrap it in a single error object
           marked as kiddy only error */
        if ((toDateError != null) || (fromDateError != null)) {
            LOG.debug("child is in error");

            if (toDateError != null) {
                LOG.debug("toDate is in error");
                dateRangeError.addChild(toDateError);
            }

            if (fromDateError != null) {
                LOG.debug("fromDate is in error");
                dateRangeError.addChild(fromDateError);
            }

            return dateRangeError;
        }

        /* both dates must be after now date */
        if (toDate.getDate().before(nowDate.getDate())) {
            dateRangeError.addChild(
                    new WorkflowServiceErrorImpl("To Date is before now", 
                                                 ServiceErrorConstants.TO_DATE_BEFORENOW));
        }

        if (fromDate.getDate().before(fromDate.getDate())) {
            dateRangeError.addChild(
                    new WorkflowServiceErrorImpl("From Date is before now", 
                                                 ServiceErrorConstants.FROM_DATE_BEFORENOW));
        }

        /* return the child error wrapper error if we have a count */
        if (dateRangeError.getChildren().size() > 0) {
            return dateRangeError;
        }

        /* both the kiddies are valid apply date range logic */
        /* to from date must be before the to date */
        if (toDate.getDate().before(fromDate.getDate())) {
            return new WorkflowServiceErrorImpl("To Date is before From Date", 
                                                ServiceErrorConstants.DATE_RANGE_INVALID);
        }

        LOG.debug("valid returning null");

        return null;
    }

    public String getElementName() {
        return ELEMENT_NAME;
    }

    public void setRouteControl(boolean routeControl) {
    }

    public boolean isRouteControl() {
        return this.routeControl;
    }

    /**
     *
     * @return boolean indicating if DateRange has no properties set
     */
    public boolean isEmpty() {
        LOG.debug("isEmpty()");

        if (this.fromDate.isEmpty() && this.toDate.isEmpty()) {
            LOG.debug("empty");

            return true;
        }

        return false;
    }

    /**
     *
     * @param toDate Date of To Date
     */
    public void setToDate(Date toDate) {
        this.toDate.setDate(toDate);
    }

    /**
     *
     * @return Date of To Date
     */
    public Date getToDate() {
        return this.toDate.getDate();
    }

    /**
     *
     * @param fromDate Date of the From Date
     */
    public void setFromDate(Date fromDate) {
        this.fromDate.setDate(fromDate);
    }

    /**
     *
     * @return Date of From Date
     */
    public Date getFromDate() {
        return this.fromDate.getDate();
    }

    /**
     * Validate the ToDate outside the context of the DateRangeElement
     * @return DocElementError representing error, null if valid
     */
    public WorkflowServiceErrorImpl validateToDate() {
        return this.toDate.validate();
    }

    /**
     * Validate the From Date outside the context of the DateRangeElement
     * @return DocElementError representing error, null if valid
     */
    public WorkflowServiceErrorImpl validateFromDate() {
        return this.fromDate.validate();
    }
}

/*
 * Copyright 2003 The Trustees of Indiana University.  All rights reserved.
 *
 * This file is part of the EDEN software package.
 * For license information, see the LICENSE file in the top level directory
 * of the EDEN source distribution.
 */
