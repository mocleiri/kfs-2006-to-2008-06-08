
/*
 * Copyright (c) 2004, 2005, 2006 Trustees of Indiana University and Cornell University.
 *
 * Licensed under the Educational Community License Version 1.0 (the "License"); By obtaining,
 * using and/or copying this Original Work, you agree that you have read, understand, and will
 * comply with the terms and conditions of the Educational Community License.
 *
 * For the full text of the license, see the LICENSE.txt file or visit:
 * 
 * http://kew.indiana.edu/workflow/LICENSE.txt
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING
 * BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE
 * AND NONINFRINGEMENT.
 * IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES
 * OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 */
            
package edu.iu.uis.eden.web;

import edu.iu.uis.eden.web.session.Authentication;
import edu.iu.uis.eden.web.session.BasicAuthentication;
import edu.iu.uis.eden.web.session.UserSession;

import java.util.Iterator;


/**
 * A set of utility methods relating to UserSession within the IU Enterprise
 * environment.  Provides convienance methods for determining if a user is
 * Kerberos or Safeword authenticated.  Also includes a utility for
 * accessing the current authenticated user.
 * 
 * @author Eric Westfall
 */
public class IUUserSessionUtils {
    public static final String KERBEROS_AUTHORITY = "KERBEROS";
    public static final String SAFEWORD_AUTHORITY = "SAFEWORD_AUTHORITY";

    /**
     * Returns the UserSession of the currently authenticated user or null if
     * there is no currently authenticated user.
     */
    public static UserSession getCurrentAuthenticatedUser() {
        return UserSession.getAuthenticatedUser();
    }

    /**
     * Returns true if the currently logged in user is Kerberos authenticated
     * through CAS.  Will throw an IllegalArgumentException if there is 
     * no current authenticated user.
     */
    public static boolean isKerberosAuthenticated() {
        return isKerberosAuthenticated(UserSession.getAuthenticatedUser());
    }

    /**
     * Returns true if the given UserSession is Kerberos authenticated through CAS.
     */
    public static boolean isKerberosAuthenticated(UserSession userSession) {
        if (userSession == null) {
            throw new IllegalArgumentException("UserSession cannot be null.");
        }

        return isAuthenticatedWithAuthority(userSession, KERBEROS_AUTHORITY);
    }

    /**
     * Returns true if the currently logged in user is Safeword authenticated
     * through CAS.  Will throw an IllegalArgumentException if there is 
     * no current authenticated user.
     */
    public static boolean isSafewordAuthenticated() {
        return isSafewordAuthenticated(UserSession.getAuthenticatedUser());
    }

    /**
     * Returns true if the given UserSession is Safeword authenticated through CAS.
     */
    public static boolean isSafewordAuthenticated(UserSession userSession) {
        if (userSession == null) {
            throw new IllegalArgumentException("UserSession cannot be null.");
        }

        return isAuthenticatedWithAuthority(userSession, SAFEWORD_AUTHORITY);
    }

    public static void setKerberosAuthenticated(UserSession userSession, 
                                                boolean isKerberosAuthenticated) {
        boolean isCurrentlyKerberosAuthenticated = isKerberosAuthenticated(
                                                           userSession);

        if (isKerberosAuthenticated && !isCurrentlyKerberosAuthenticated) {
            userSession.addAuthentication(
                    new BasicAuthentication(KERBEROS_AUTHORITY));
        } else if (!isKerberosAuthenticated && 
                       isCurrentlyKerberosAuthenticated) {
            userSession.removeAuthentication(getAuthenticationByAuthority(
                                                     userSession, 
                                                     KERBEROS_AUTHORITY));
        }
    }

    public static void setSafewordAuthenticated(UserSession userSession, 
                                                boolean isSafewordAuthenticated) {
        boolean isCurrentlySafewordAuthenticated = isSafewordAuthenticated(
                                                           userSession);

        if (isSafewordAuthenticated && !isCurrentlySafewordAuthenticated) {
            userSession.addAuthentication(
                    new BasicAuthentication(SAFEWORD_AUTHORITY));
        } else if (!isSafewordAuthenticated && 
                       isCurrentlySafewordAuthenticated) {
            userSession.removeAuthentication(getAuthenticationByAuthority(
                                                     userSession, 
                                                     SAFEWORD_AUTHORITY));
        }
    }

    /**
     * Returns true if the given UserSession is authenticated with the given authority.
     */
    public static boolean isAuthenticatedWithAuthority(UserSession userSession, 
                                                       String authority) {
        return getAuthenticationByAuthority(userSession, authority) != null;
    }

    public static Authentication getAuthenticationByAuthority(UserSession userSession, 
                                                              String authority) {
        for (Iterator iterator = userSession.getAuthentications().iterator();
             iterator.hasNext();) {
            Authentication authentication = (Authentication) iterator.next();

            if (authentication.getAuthority().equals(authority)) {
                return authentication;
            }
        }

        return null;
    }
}