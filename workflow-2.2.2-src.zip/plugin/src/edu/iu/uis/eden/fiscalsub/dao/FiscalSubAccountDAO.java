
/*
 * Copyright (c) 2004, 2005, 2006 Trustees of Indiana University and Cornell University.
 *
 * Licensed under the Educational Community License Version 1.0 (the "License"); By obtaining,
 * using and/or copying this Original Work, you agree that you have read, understand, and will
 * comply with the terms and conditions of the Educational Community License.
 *
 * For the full text of the license, see the LICENSE.txt file or visit:
 * 
 * http://kew.indiana.edu/workflow/LICENSE.txt
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING
 * BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE
 * AND NONINFRINGEMENT.
 * IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES
 * OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 */
            
package edu.iu.uis.eden.fiscalsub.dao;

import edu.iu.uis.eden.fiscalsub.FiscalSubAccount;

import java.util.Collection;
import java.util.List;


/**
 * A Data Access Object for accessing Fiscal Sub Account data.
 * 
 * @author Eric Westfall
 */
public interface FiscalSubAccountDAO {
    /**
     * Retrieves the FiscalSubAccount from the data source for the given chart, account number, and
     * sub account number.  These three data elements represent a primary key, therefore, there should
     * not exist more than one entry in the data store for the given parameters.
     * 
     * @return the FiscalSubAccount from the data store or null if one can not be found for the given
     * parameters
     */
    public FiscalSubAccount getSubAccount(String chart, String accountNumber, 
                                          String subAccountNumber);

    public List searchForSubAccount(String chart, String accountNumber, 
                                    String subAccountNumber, 
                                    String subAccountName, 
                                    String activeIndicator);

    /**
     * Retrieves all the fiscal sub accounts from the data source.
     */
    public Collection findAll();
}