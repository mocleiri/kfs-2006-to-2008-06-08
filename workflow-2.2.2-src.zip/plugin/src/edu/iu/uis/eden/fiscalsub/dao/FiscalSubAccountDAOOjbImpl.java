
/*
 * Copyright (c) 2004, 2005, 2006 Trustees of Indiana University and Cornell University.
 *
 * Licensed under the Educational Community License Version 1.0 (the "License"); By obtaining,
 * using and/or copying this Original Work, you agree that you have read, understand, and will
 * comply with the terms and conditions of the Educational Community License.
 *
 * For the full text of the license, see the LICENSE.txt file or visit:
 * 
 * http://kew.indiana.edu/workflow/LICENSE.txt
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING
 * BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE
 * AND NONINFRINGEMENT.
 * IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES
 * OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 */
            
package edu.iu.uis.eden.fiscalsub.dao;

import edu.iu.uis.eden.fiscalsub.FiscalSubAccount;
import edu.iu.uis.eden.util.Utilities;

import java.util.Collection;
import java.util.List;

import org.apache.ojb.broker.query.Criteria;
import org.apache.ojb.broker.query.QueryByCriteria;

import org.springframework.orm.ojb.PersistenceBrokerTemplate;


/**
 * OJB implementation of the FiscalSubAccountDAO.
 * 
 * @author Eric Westfall
 */
public class FiscalSubAccountDAOOjbImpl extends PersistenceBrokerTemplate
    implements FiscalSubAccountDAO {
    public FiscalSubAccount getSubAccount(String chart, String accountNumber, 
                                          String subAccountNumber) {
        Criteria criteria = new Criteria();
        criteria.addEqualTo("finCoaCd", chart);
        criteria.addLike("accountNbr", accountNumber);
        criteria.addEqualTo("subAcctNbr", subAccountNumber);

        return (FiscalSubAccount) getObjectByQuery(
                       new QueryByCriteria(FiscalSubAccount.class, criteria));
    }

    public List searchForSubAccount(String chart, String accountNumber, 
                                    String subAccountNumber, 
                                    String subAccountName, 
                                    String activeIndicator) {
        Criteria criteria = new Criteria();

        if (!Utilities.isEmpty(chart)) {
            criteria.addEqualTo("finCoaCd", chart);
        }

        if (!Utilities.isEmpty(accountNumber)) {
            accountNumber = accountNumber.replace('*', '%');
            criteria.addLike("accountNbr", "%" + accountNumber + "%");
        }

        if (!Utilities.isEmpty(activeIndicator)) {
            criteria.addEqualTo("activeInd", activeIndicator);
        }

        if (!Utilities.isEmpty(subAccountNumber)) {
            subAccountNumber = subAccountNumber.replace('*', '%');
            criteria.addLike("UPPER(subAcctNbr)", 
                             "%" + subAccountNumber.trim().toUpperCase() + 
                             "%");
        }

        if (!Utilities.isEmpty(subAccountName)) {
            subAccountName = subAccountName.replace('*', '%');
            criteria.addLike("UPPER(subAccountName)", 
                             "%" + subAccountName.trim().toUpperCase() + "%");
        }

        return (List) getCollectionByQuery(
                       new QueryByCriteria(FiscalSubAccount.class, criteria));
    }

    public Collection findAll() {
        return getCollectionByQuery(new QueryByCriteria(FiscalSubAccount.class));
    }
}