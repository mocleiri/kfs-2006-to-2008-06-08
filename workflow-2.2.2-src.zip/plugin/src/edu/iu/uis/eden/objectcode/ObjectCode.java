
/*
 * Copyright (c) 2004, 2005, 2006 Trustees of Indiana University and Cornell University.
 *
 * Licensed under the Educational Community License Version 1.0 (the "License"); By obtaining,
 * using and/or copying this Original Work, you agree that you have read, understand, and will
 * comply with the terms and conditions of the Educational Community License.
 *
 * For the full text of the license, see the LICENSE.txt file or visit:
 * 
 * http://kew.indiana.edu/workflow/LICENSE.txt
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING
 * BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE
 * AND NONINFRINGEMENT.
 * IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES
 * OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 */
            
package edu.iu.uis.eden.objectcode;

import edu.iu.uis.eden.WorkflowPersistable;


public class ObjectCode implements WorkflowPersistable {
    private static final org.apache.log4j.Logger LOG = 
            org.apache.log4j.Logger.getLogger(ObjectCode.class);
    private String objectCd;
    private String finCoaCd;
    private String objectCdName;
    private Integer fiscalYear;
    private String returnUrl;

    public Object copy(boolean preserveKeys) {
        ObjectCode copy = new ObjectCode();
        copy.setFinCoaCd(getFinCoaCd());
        copy.setObjectCd(getObjectCd());
        copy.setObjectCdName(getObjectCdName());

        return copy;
    }

    public String getFinCoaCd() {
        return finCoaCd;
    }

    public void setFinCoaCd(String finCoaCd) {
        this.finCoaCd = finCoaCd;
    }

    public String getObjectCd() {
        return objectCd;
    }

    public void setObjectCd(String objectCd) {
        this.objectCd = objectCd;
    }

    public String getObjectCdName() {
        return objectCdName;
    }

    public void setObjectCdName(String objectCdName) {
        this.objectCdName = objectCdName;
    }

    public String getReturnUrl() {
        return returnUrl;
    }

    public void setReturnUrl(String returnUrl) {
        this.returnUrl = returnUrl;
    }

    public Integer getFiscalYear() {
        return fiscalYear;
    }

    public void setFiscalYear(Integer fiscalYear) {
        this.fiscalYear = fiscalYear;
    }
}