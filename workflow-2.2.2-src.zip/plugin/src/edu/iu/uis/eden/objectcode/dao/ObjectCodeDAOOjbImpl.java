
/*
 * Copyright (c) 2004, 2005, 2006 Trustees of Indiana University and Cornell University.
 *
 * Licensed under the Educational Community License Version 1.0 (the "License"); By obtaining,
 * using and/or copying this Original Work, you agree that you have read, understand, and will
 * comply with the terms and conditions of the Educational Community License.
 *
 * For the full text of the license, see the LICENSE.txt file or visit:
 * 
 * http://kew.indiana.edu/workflow/LICENSE.txt
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING
 * BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE
 * AND NONINFRINGEMENT.
 * IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES
 * OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 */
            
package edu.iu.uis.eden.objectcode.dao;

import edu.iu.uis.eden.objectcode.ObjectCode;

import java.util.List;

import org.apache.ojb.broker.query.Criteria;
import org.apache.ojb.broker.query.QueryByCriteria;

import org.springframework.orm.ojb.PersistenceBrokerTemplate;


public class ObjectCodeDAOOjbImpl extends PersistenceBrokerTemplate
    implements ObjectCodeDAO {
    public ObjectCode findByObjectCd(String objectCd) {
        Criteria crit = new Criteria();
        crit.addEqualTo("objectCd", objectCd);

        return (ObjectCode) getObjectByQuery(
                       new QueryByCriteria(ObjectCode.class, crit));
    }

    public List search(String objectCd, String objectCdName, String finCoaCd, 
                       Integer fiscalYear) {
        Criteria crit = new Criteria();

        if (objectCd != null) {
            crit.addEqualTo("objectCd", objectCd);
        }

        if (objectCdName != null) {
            crit.addEqualTo("objectCdName", objectCdName);
        }

        if (finCoaCd != null) {
            crit.addEqualTo("finCoaCd", finCoaCd);
        }

        if (fiscalYear != null) {
            crit.addEqualTo("fiscalYear", fiscalYear);
        }

        return (List) getCollectionByQuery(
                       new QueryByCriteria(ObjectCode.class, crit));
    }
}