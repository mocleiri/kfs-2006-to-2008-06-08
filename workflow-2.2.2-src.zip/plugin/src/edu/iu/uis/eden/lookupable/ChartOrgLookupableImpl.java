
/*
 * Copyright (c) 2004, 2005, 2006 Trustees of Indiana University and Cornell University.
 *
 * Licensed under the Educational Community License Version 1.0 (the "License"); By obtaining,
 * using and/or copying this Original Work, you agree that you have read, understand, and will
 * comply with the terms and conditions of the Educational Community License.
 *
 * For the full text of the license, see the LICENSE.txt file or visit:
 * 
 * http://kew.indiana.edu/workflow/LICENSE.txt
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING
 * BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE
 * AND NONINFRINGEMENT.
 * IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES
 * OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 */
            
package edu.iu.uis.eden.lookupable;

import edu.iu.uis.eden.IUServiceLocator;
import edu.iu.uis.eden.fisdata.FiscalChart;
import edu.iu.uis.eden.fisdata.Organization;
import edu.iu.uis.eden.plugin.attributes.WorkflowLookupable;
import edu.iu.uis.eden.util.KeyLabelPair;
import edu.iu.uis.eden.util.Utilities;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;


/**
 * <p>
 * Title: ChartOrgLookupableImpl
 * </p>
 * <p>
 * Description: sets up a chart and organization search for the jsp form.
 * </p>
 * <p>
 * Copyright: Copyright (c) 2002
 * </p>
 * <p>
 * Company: Indiana University
 * </p>
 * 
 * @author Eden team
 * @version 1.0
 */
public class ChartOrgLookupableImpl implements WorkflowLookupable {
    private static final org.apache.log4j.Logger LOG = 
            org.apache.log4j.Logger.getLogger(ChartOrgLookupableImpl.class);
    private static List columns = establishColumns();
    private static final String title = "Chart/Org Lookup";
    private static final String returnLocation = "Lookup.do";
    private static final String CHART_FIELD_LABEL = "Chart";
    private static final String ORG_FIELD_LABEL = "Org Code";
    private static final String ORG_NAME_FIELD_LABEL = "Name";
    private static final String ACTIVE_IND_FIELD_LABEL = "Active";
    private static final String CHART_FIELD_HELP = "";
    private static final String ORG_FIELD_HELP = "";
    private static final String ORG_NAME_FIELD_HELP = "";
    private static final String ACTIVE_IND_FIELD_HELP = "";
    private static final String CHART_PROPERTY_NAME = "fin_coa_cd";
    private static final String ORG_PROPERTY_NAME = "org_cd";
    private static final String ORG_NAME_PROPERTY_NAME = "orgNm";
    private static final String ACTIVE_IND_PROPERTY_NAME = "activeCd";
    private static final String BACK_LOCATION = "backLocation";
    private static final String DOC_FORM_KEY = "docFormKey";
    private List rows;

    /**
     * ChartOrgLookupableImpl - constructor that sets up the values of what the form on the jsp will look like.
     */
    public ChartOrgLookupableImpl() {
        rows = new ArrayList();

        List fields = new ArrayList();
        fields.add(new Field(CHART_FIELD_LABEL, CHART_FIELD_HELP, 
                             Field.DROPDOWN, false, CHART_PROPERTY_NAME, "", 
                             getChartOptions(), null));
        rows.add(new Row(fields));

        fields = new ArrayList();
        fields.add(new Field(ORG_FIELD_LABEL, ORG_FIELD_HELP, Field.TEXT, false, 
                             ORG_PROPERTY_NAME, "", null, null));
        rows.add(new Row(fields));

        fields = new ArrayList();
        fields.add(new Field(ORG_NAME_FIELD_LABEL, ORG_NAME_FIELD_HELP, 
                             Field.TEXT, false, ORG_NAME_PROPERTY_NAME, "", 
                             null, null));
        rows.add(new Row(fields));

        List options = new ArrayList();
        options.add(new KeyLabelPair("Y", "Active"));
        options.add(new KeyLabelPair("N", "Inactive"));
        options.add(new KeyLabelPair("ALL", "Show All"));

        fields = new ArrayList();
        fields.add(new Field(ACTIVE_IND_FIELD_LABEL, ACTIVE_IND_FIELD_HELP, 
                             Field.RADIO, false, ACTIVE_IND_PROPERTY_NAME, "Y", 
                             options, null));
        rows.add(new Row(fields));
    }

    private static List getChartOptions() {
        List options = new ArrayList();
        List charts = IUServiceLocator.getFISDataService().findAllCharts();

        for (Iterator iter = charts.iterator(); iter.hasNext();) {
            FiscalChart chart = (FiscalChart) iter.next();
            options.add(
                    new KeyLabelPair(chart.getFinCoaCd(), 
                                     chart.getFinCoaCd() + " : " + 
                                         chart.getFinCoaDesc()));
        }

        return options;
    }

    private static List establishColumns() {
        List columns = new ArrayList();
        columns.add(new Column(CHART_FIELD_LABEL, "true", "finCoaCd"));
        columns.add(new Column(ORG_FIELD_LABEL, "true", "orgCd"));
        columns.add(new Column(ORG_NAME_FIELD_LABEL, "true", "name"));
        columns.add(new Column(ACTIVE_IND_FIELD_LABEL, "true", "activeCd"));

        return columns;
    }

    public void changeIdToName(Map fieldValues) {
    }

    /**
     * getSearchResults - searches for a fiscal organization information based on the criteria passed in by the map.
     * 
     * @return Returns a list of FiscalOrganization objects that match the result.
     */
    public List getSearchResults(Map fieldValues, Map fieldConversions)
                          throws Exception {
        String chart = (String) fieldValues.get(CHART_PROPERTY_NAME);
        String org = ((String) fieldValues.get(ORG_PROPERTY_NAME)).toUpperCase();
        String orgNm = (String) fieldValues.get(ORG_NAME_PROPERTY_NAME);
        String activeInd = (String) fieldValues.get(ACTIVE_IND_PROPERTY_NAME);

        String backLocation = (String) fieldValues.get(BACK_LOCATION);
        String docFormKey = (String) fieldValues.get(DOC_FORM_KEY);

        String chartReturn = (String) fieldConversions.get(CHART_PROPERTY_NAME);
        String orgReturn = (String) fieldConversions.get(ORG_PROPERTY_NAME);

        if (!Utilities.isEmpty(chart)) {
            chart = chart.replace('*', '%');
            chart = "%" + chart.trim() + "%";
        }

        if (!Utilities.isEmpty(org)) {
            org = org.replace('*', '%');
            org = "%" + org.trim() + "%";
        }

        if (!Utilities.isEmpty(orgNm)) {
            orgNm = orgNm.replace('*', '%');
            orgNm = "%" + orgNm.trim() + "%";
        }

        if ((activeInd != null) && activeInd.equals("ALL")) {
            activeInd = null;
        }

        Iterator orgs = IUServiceLocator.getFISDataService()
                                        .findOrganization(chart, org, orgNm, 
                                                          activeInd).iterator();
        List displayList = new ArrayList();

        while (orgs.hasNext()) {
            Organization orgRecord = (Organization) orgs.next();

            StringBuffer returnUrl = new StringBuffer("<a href=\"");
            returnUrl.append(backLocation)
                     .append("?methodToCall=refresh&docFormKey=")
                     .append(docFormKey).append("&");

            if (!Utilities.isEmpty(chartReturn)) {
                returnUrl.append(chartReturn);
            } else {
                returnUrl.append(CHART_PROPERTY_NAME);
            }

            returnUrl.append("=").append(orgRecord.getFinCoaCd()).append("&");

            if (!Utilities.isEmpty(orgReturn)) {
                returnUrl.append(orgReturn);
            } else {
                returnUrl.append(ORG_PROPERTY_NAME);
            }

            returnUrl.append("=").append(orgRecord.getOrgCd())
                     .append("\">return value</a>");
            orgRecord.setReturnUrl(returnUrl.toString());

            displayList.add(orgRecord);
        }

        return displayList;
    }

    public boolean checkForAdditionalFields(Map fieldValues, 
                                            HttpServletRequest request)
                                     throws Exception {
        return false;
    }

    public List getDefaultReturnType() {
        List returnTypes = new ArrayList();
        returnTypes.add(CHART_PROPERTY_NAME);
        returnTypes.add(ORG_PROPERTY_NAME);

        return returnTypes;
    }

    public String getNoReturnParams(Map fieldConversions) {
        String chartReturn = (String) fieldConversions.get(CHART_PROPERTY_NAME);
        String orgReturn = (String) fieldConversions.get(ORG_PROPERTY_NAME);

        StringBuffer noReturnParams = new StringBuffer("&");

        if (!Utilities.isEmpty(chartReturn)) {
            noReturnParams.append(chartReturn);
        } else {
            noReturnParams.append(CHART_PROPERTY_NAME);
        }

        noReturnParams.append("=").append("&");

        if (!Utilities.isEmpty(orgReturn)) {
            noReturnParams.append(orgReturn);
        } else {
            noReturnParams.append(ORG_PROPERTY_NAME);
        }

        noReturnParams.append("=");

        return noReturnParams.toString();
    }

    /**
     * @return Returns the title.
     */
    public String getTitle() {
        return title;
    }

    /**
     * @return Returns the instructions.
     */
    public String getLookupInstructions() {
        return "Enter criteria to search for a chart and org.";
    }

    /**
     * @return Returns the returnLocation.
     */
    public String getReturnLocation() {
        return returnLocation;
    }

    /**
     * @return Returns the columns.
     */
    public List getColumns() {
        return columns;
    }

    public String getHtmlMenuBar() {
        return "";
    }

    public List getRows() {
        return rows;
    }
}