
/*
 * Copyright (c) 2004, 2005, 2006 Trustees of Indiana University and Cornell University.
 *
 * Licensed under the Educational Community License Version 1.0 (the "License"); By obtaining,
 * using and/or copying this Original Work, you agree that you have read, understand, and will
 * comply with the terms and conditions of the Educational Community License.
 *
 * For the full text of the license, see the LICENSE.txt file or visit:
 * 
 * http://kew.indiana.edu/workflow/LICENSE.txt
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING
 * BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE
 * AND NONINFRINGEMENT.
 * IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES
 * OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 */
            
package edu.iu.uis.eden.lookupable;

import edu.iu.uis.eden.IUServiceLocator;
import edu.iu.uis.eden.fisdata.FiscalChart;
import edu.iu.uis.eden.objectcode.ObjectCode;
import edu.iu.uis.eden.plugin.attributes.WorkflowLookupable;
import edu.iu.uis.eden.util.KeyLabelPair;
import edu.iu.uis.eden.util.Utilities;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;


public class ObjectCodeLookupableImpl implements WorkflowLookupable {
    private static final org.apache.log4j.Logger LOG = 
            org.apache.log4j.Logger.getLogger(ObjectCodeLookupableImpl.class);
    private static List columns = establsihColumns();
    private static final String OBJECT_CD_FIELD_LABEL = "Object Code";
    private static final String OBJECT_CD_NAME_FIELD_LABEL = "Object Code Name";
    private static final String CHART_FIELD_LABEL = "Chart";
    private static final String FISCAL_YEAR_FIELD_LABEL = "Fiscal year";
    private static final String OBJECT_CD_FIELD_HELP = "";
    private static final String OBJECT_CD_NAME_FIELD_HELP = "";
    private static final String CHART_FIELD_HELP = "";
    private static final String FISCAL_YEAR_FIELD_HELP = "";
    private static final String OBJECT_CD_PROPERTY_NAME = "objectCd";
    private static final String OBJECT_CD_NAME_PROPERTY_NAME = "objectCdName";
    private static final String CHART_PROPERTY_NAME = "fin_coa_cd";
    private static final String FISCAL_YEAR_PROPERTY_NAME = "fiscal_year";
    private static final String BACK_LOCATION = "backLocation";
    private static final String DOC_FORM_KEY = "docFormKey";
    private List rows;

    public ObjectCodeLookupableImpl() {
        rows = new ArrayList();

        List fields = new ArrayList();
        fields.add(new Field(OBJECT_CD_FIELD_LABEL, OBJECT_CD_FIELD_HELP, 
                             Field.TEXT, false, OBJECT_CD_PROPERTY_NAME, "", 
                             null, null));
        rows.add(new Row(fields));

        fields = new ArrayList();
        fields.add(new Field(OBJECT_CD_NAME_FIELD_LABEL, 
                             OBJECT_CD_NAME_FIELD_HELP, Field.TEXT, false, 
                             OBJECT_CD_NAME_PROPERTY_NAME, "", null, null));
        rows.add(new Row(fields));

        fields = new ArrayList();
        fields.add(new Field(CHART_FIELD_LABEL, CHART_FIELD_HELP, 
                             Field.DROPDOWN, false, CHART_PROPERTY_NAME, "", 
                             getChartOptions(), null));
        rows.add(new Row(fields));

        fields = new ArrayList();
        fields.add(new Field(FISCAL_YEAR_FIELD_LABEL, FISCAL_YEAR_FIELD_HELP, 
                             Field.TEXT, false, FISCAL_YEAR_PROPERTY_NAME, "", 
                             null, null));
        rows.add(new Row(fields));
    }

    private static List getChartOptions() {
        List options = new ArrayList();
        List charts = IUServiceLocator.getFISDataService().findAllCharts();

        for (Iterator iter = charts.iterator(); iter.hasNext();) {
            FiscalChart fiscalChart = (FiscalChart) iter.next();
            options.add(
                    new KeyLabelPair(fiscalChart.getFinCoaCd(), 
                                     fiscalChart.getFinCoaCd() + " : " + 
                                         fiscalChart.getFinCoaDesc()));
        }

        return options;
    }

    public String getHtmlMenuBar() {
        return "";
    }

    public List getRows() {
        return rows;
    }

    public String getTitle() {
        return "Object Code Lookup";
    }

    public String getReturnLocation() {
        return "Lookup.do";
    }

    public List getColumns() {
        return columns;
    }

    public static List establsihColumns() {
        List columns = new ArrayList();
        columns.add(new Column("Object Code", "true", "objectCd"));
        columns.add(new Column("Object Code Name", "true", "objectCdName"));
        columns.add(new Column("Chart", "true", "finCoaCd"));
        columns.add(new Column("Fiscal Year", "true", "fiscalYear"));

        return columns;
    }

    public void changeIdToName(Map fieldValues) {
    }

    public List getSearchResults(Map fieldValues, Map fieldConversions)
                          throws Exception {
        String paramObjectCode = (String) fieldValues.get(
                                         OBJECT_CD_PROPERTY_NAME);
        String paramObjectCodeNm = (String) fieldValues.get(
                                           OBJECT_CD_NAME_PROPERTY_NAME);
        String paramFinCoaCd = (String) fieldValues.get(CHART_PROPERTY_NAME);
        String paramFiscalYear = (String) fieldValues.get(
                                         FISCAL_YEAR_PROPERTY_NAME);
        String backLocation = (String) fieldValues.get(BACK_LOCATION);
        String docFormKey = (String) fieldValues.get(DOC_FORM_KEY);

        String objectCdReturn = (String) fieldConversions.get(
                                        OBJECT_CD_PROPERTY_NAME);
        String fiscalYearReturn = (String) fieldConversions.get(
                                          FISCAL_YEAR_PROPERTY_NAME);
        String chartReturn = (String) fieldConversions.get(CHART_PROPERTY_NAME);

        if (Utilities.isEmpty(paramObjectCode)) {
            paramObjectCode = null;
        }

        if (Utilities.isEmpty(paramObjectCodeNm)) {
            paramObjectCodeNm = null;
        }

        if (Utilities.isEmpty(paramFinCoaCd)) {
            paramFinCoaCd = null;
        }

        if (Utilities.isEmpty(paramFiscalYear)) {
            paramFiscalYear = null;
        }

        // TODO move object code service and lookupable to the Kuali plugin, fix commented out code below;
        if (true) {
            throw new UnsupportedOperationException(
                    "The object code lookupable needs to be moved to the Kuali Plugin.");
        }

        Iterator objectCds = null; //((ObjectCodeService) SpringServiceLocator.getService(SpringServiceLocator.OBJECT_CD_SERVICE)).search(paramObjectCode, paramObjectCodeNm, paramFinCoaCd, new Integer(paramFiscalYear)).iterator();
        List displayList = new ArrayList();

        while (objectCds.hasNext()) {
            ObjectCode record = (ObjectCode) objectCds.next();

            StringBuffer returnUrl = new StringBuffer("<a href=\"");
            returnUrl.append(backLocation)
                     .append("?methodToCall=refresh&docFormKey=")
                     .append(docFormKey).append("&");

            if (!Utilities.isEmpty(objectCdReturn)) {
                returnUrl.append(objectCdReturn);
            } else {
                returnUrl.append(OBJECT_CD_PROPERTY_NAME);
            }

            returnUrl.append("=").append(record.getObjectCd()).append("&");

            if (!Utilities.isEmpty(fiscalYearReturn)) {
                returnUrl.append(fiscalYearReturn);
            } else {
                returnUrl.append(FISCAL_YEAR_PROPERTY_NAME);
            }

            returnUrl.append("=").append(record.getFiscalYear()).append("&");

            if (!Utilities.isEmpty(chartReturn)) {
                returnUrl.append(chartReturn);
            } else {
                returnUrl.append(CHART_PROPERTY_NAME);
            }

            returnUrl.append("=").append(record.getFinCoaCd())
                     .append("\">return value</a>");
            record.setReturnUrl(returnUrl.toString());
            displayList.add(record);
        }

        return displayList;
    }

    public boolean checkForAdditionalFields(Map fieldValues, 
                                            HttpServletRequest request)
                                     throws Exception {
        return false;
    }

    public List getDefaultReturnType() {
        List returnTypes = new ArrayList();
        returnTypes.add(OBJECT_CD_PROPERTY_NAME);
        returnTypes.add(FISCAL_YEAR_PROPERTY_NAME);
        returnTypes.add(CHART_PROPERTY_NAME);

        return returnTypes;
    }

    public String getNoReturnParams(Map fieldConversions) {
        String objectCdReturn = (String) fieldConversions.get(
                                        OBJECT_CD_PROPERTY_NAME);
        String fiscalYearReturn = (String) fieldConversions.get(
                                          FISCAL_YEAR_PROPERTY_NAME);
        String chartReturn = (String) fieldConversions.get(CHART_PROPERTY_NAME);

        StringBuffer noReturnParams = new StringBuffer("&");

        if (!Utilities.isEmpty(objectCdReturn)) {
            noReturnParams.append(objectCdReturn);
        } else {
            noReturnParams.append(OBJECT_CD_PROPERTY_NAME);
        }

        noReturnParams.append("=&");

        if (!Utilities.isEmpty(fiscalYearReturn)) {
            noReturnParams.append(fiscalYearReturn);
        } else {
            noReturnParams.append(FISCAL_YEAR_PROPERTY_NAME);
        }

        noReturnParams.append("=&");

        if (!Utilities.isEmpty(chartReturn)) {
            noReturnParams.append(chartReturn);
        } else {
            noReturnParams.append(CHART_PROPERTY_NAME);
        }

        noReturnParams.append("=");

        return noReturnParams.toString();
    }

    public String getLookupInstructions() {
        return "Search for Object Code by object code, object code name, and chart.";
    }
}