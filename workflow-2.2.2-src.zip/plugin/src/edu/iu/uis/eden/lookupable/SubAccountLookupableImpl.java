
/*
 * Copyright (c) 2004, 2005, 2006 Trustees of Indiana University and Cornell University.
 *
 * Licensed under the Educational Community License Version 1.0 (the "License"); By obtaining,
 * using and/or copying this Original Work, you agree that you have read, understand, and will
 * comply with the terms and conditions of the Educational Community License.
 *
 * For the full text of the license, see the LICENSE.txt file or visit:
 * 
 * http://kew.indiana.edu/workflow/LICENSE.txt
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING
 * BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE
 * AND NONINFRINGEMENT.
 * IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES
 * OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 */
            
package edu.iu.uis.eden.lookupable;

import edu.iu.uis.eden.IUServiceLocator;
import edu.iu.uis.eden.fiscalsub.FiscalSubAccount;
import edu.iu.uis.eden.fiscalsub.FiscalSubAccountService;
import edu.iu.uis.eden.fisdata.FiscalChart;
import edu.iu.uis.eden.plugin.attributes.WorkflowLookupable;
import edu.iu.uis.eden.util.KeyLabelPair;
import edu.iu.uis.eden.util.Utilities;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;


public class SubAccountLookupableImpl implements WorkflowLookupable {
    private static final org.apache.log4j.Logger LOG = 
            org.apache.log4j.Logger.getLogger(SubAccountLookupableImpl.class);
    private static List columns = establishColumns();
    private static final String title = "Sub Account Lookup";
    private static final String returnLocation = "Lookup.do";
    private static final String CHART_FIELD_LABEL = "Chart";
    private static final String ACCOUNT_FIELD_LABEL = "Account Number";
    private static final String SUB_ACCOUNT_FIELD_LABEL = "Sub Account Number";
    private static final String SUB_ACCOUNT_NAME_FIELD_LABEL = 
            "Sub Account Name";
    private static final String SUB_ACCOUNT_ACTIVE_IND_FIELD_LABEL = 
            "Active Indicator";
    private static final String CHART_FIELD_HELP = "";
    private static final String ACCOUNT_FIELD_HELP = "";
    private static final String SUB_ACCOUNT_FIELD_HELP = "";
    private static final String SUB_ACCOUNT_NAME_FIELD_HELP = "";
    private static final String SUB_ACCOUNT_ACTIVE_IND_FIELD_HELP = "";
    private static final String CHART_PROPERTY_NAME = "finCoaCd";
    private static final String ACCOUNT_PROPERTY_NAME = "accountNbr";
    private static final String SUB_ACCOUNT_PROPERTY_NAME = "subAcctNbr";
    private static final String SUB_ACCOUNT_NAME_PROPERTY_NAME = 
            "subAccountName";
    private static final String SUB_ACCOUNT_ACTIVE_IND_PROPERTY_NAME = 
            "activeInd";
    private static final String CHART_KEY_NAME = "fin_coa_cd";
    private static final String ACCOUNT_KEY_NAME = "account_nbr";
    private static final String SUB_ACCOUNT_KEY_NAME = "sub_acct_nbr";
    private static final String BACK_LOCATION_KEY_NAME = "backLocation";
    private static final String DOC_FORM_KEY_NAME = "docFormKey";
    private static final String TRUE_VALUE = "true";
    private List rows;

    public SubAccountLookupableImpl() {
        rows = new ArrayList();

        List fields = new ArrayList();
        fields.add(new Field(CHART_FIELD_LABEL, CHART_FIELD_HELP, 
                             Field.DROPDOWN, false, CHART_KEY_NAME, "", 
                             getChartOptions(), null));
        rows.add(new Row(fields));

        fields = new ArrayList();
        fields.add(new Field(ACCOUNT_FIELD_LABEL, ACCOUNT_FIELD_HELP, 
                             Field.TEXT, false, ACCOUNT_KEY_NAME, "", null, 
                             null));
        rows.add(new Row(fields));

        fields = new ArrayList();
        fields.add(new Field(SUB_ACCOUNT_FIELD_LABEL, SUB_ACCOUNT_FIELD_HELP, 
                             Field.TEXT, false, SUB_ACCOUNT_KEY_NAME, "", null, 
                             null));
        rows.add(new Row(fields));

        fields = new ArrayList();
        fields.add(new Field(SUB_ACCOUNT_NAME_FIELD_LABEL, 
                             SUB_ACCOUNT_NAME_FIELD_HELP, Field.TEXT, false, 
                             SUB_ACCOUNT_NAME_PROPERTY_NAME, "", null, null));
        rows.add(new Row(fields));

        List options = new ArrayList();
        options.add(new KeyLabelPair("Y", "Active"));
        options.add(new KeyLabelPair("N", "Inactive"));
        options.add(new KeyLabelPair("ALL", "Show All"));

        fields = new ArrayList();
        fields.add(new Field(SUB_ACCOUNT_ACTIVE_IND_FIELD_LABEL, 
                             SUB_ACCOUNT_ACTIVE_IND_FIELD_HELP, Field.RADIO, 
                             false, SUB_ACCOUNT_ACTIVE_IND_PROPERTY_NAME, "Y", 
                             options, null));
        rows.add(new Row(fields));
    }

    private static List getChartOptions() {
        List options = new ArrayList();
        List charts = IUServiceLocator.getFISDataService().findAllCharts();

        for (Iterator iter = charts.iterator(); iter.hasNext();) {
            FiscalChart fiscalChart = (FiscalChart) iter.next();
            options.add(
                    new KeyLabelPair(fiscalChart.getFinCoaCd(), 
                                     fiscalChart.getFinCoaCd() + " : " + 
                                         fiscalChart.getFinCoaDesc()));
        }

        return options;
    }

    private static List establishColumns() {
        List columns = new ArrayList();
        columns.add(
                new Column(CHART_FIELD_LABEL, TRUE_VALUE, CHART_PROPERTY_NAME));
        columns.add(
                new Column(ACCOUNT_FIELD_LABEL, TRUE_VALUE, 
                           ACCOUNT_PROPERTY_NAME));
        columns.add(
                new Column(SUB_ACCOUNT_FIELD_LABEL, TRUE_VALUE, 
                           SUB_ACCOUNT_PROPERTY_NAME));
        columns.add(
                new Column(SUB_ACCOUNT_NAME_FIELD_LABEL, TRUE_VALUE, 
                           SUB_ACCOUNT_NAME_PROPERTY_NAME));
        columns.add(
                new Column(SUB_ACCOUNT_ACTIVE_IND_FIELD_LABEL, TRUE_VALUE, 
                           SUB_ACCOUNT_ACTIVE_IND_PROPERTY_NAME));

        return columns;
    }

    public void changeIdToName(Map fieldValues) {
    }

    /**
     * getSearchResults - searches for fiscal sub account information based on the criteria passed in by the map.
     * 
     * @return Returns a list of FiscalSubAccount objects that match the result.
     */
    public List getSearchResults(Map fieldValues, Map fieldConversions)
                          throws Exception {
        String chart = (String) fieldValues.get(CHART_KEY_NAME);
        String accountNumber = (String) fieldValues.get(ACCOUNT_KEY_NAME);
        String subAccountNumber = (String) fieldValues.get(SUB_ACCOUNT_KEY_NAME);
        String subAccountName = (String) fieldValues.get(
                                        SUB_ACCOUNT_NAME_PROPERTY_NAME);
        String activeIndicator = (String) fieldValues.get(
                                         SUB_ACCOUNT_ACTIVE_IND_PROPERTY_NAME);

        String backLocation = (String) fieldValues.get(BACK_LOCATION_KEY_NAME);
        String docFormKey = (String) fieldValues.get(DOC_FORM_KEY_NAME);

        String chartReturn = (String) fieldConversions.get(CHART_KEY_NAME);
        String accountReturn = (String) fieldConversions.get(ACCOUNT_KEY_NAME);
        String subAccountReturn = (String) fieldConversions.get(
                                          SUB_ACCOUNT_KEY_NAME);

        FiscalSubAccountService service = getService();

        if ((activeIndicator != null) && activeIndicator.equals("ALL")) {
            activeIndicator = null;
        }

        List accounts = service.searchForSubAccount(chart, accountNumber, 
                                                    subAccountNumber, 
                                                    subAccountName, 
                                                    activeIndicator);

        for (Iterator iterator = accounts.iterator(); iterator.hasNext();) {
            FiscalSubAccount account = (FiscalSubAccount) iterator.next();

            StringBuffer returnUrl = new StringBuffer("<a href=\"");
            returnUrl.append(backLocation)
                     .append("?methodToCall=refresh&docFormKey=")
                     .append(docFormKey).append("&");

            if (!Utilities.isEmpty(chartReturn)) {
                returnUrl.append(chartReturn);
            } else {
                returnUrl.append(CHART_KEY_NAME);
            }

            returnUrl.append("=").append(account.getFinCoaCd()).append("&");

            if (!Utilities.isEmpty(accountReturn)) {
                returnUrl.append(accountReturn);
            } else {
                returnUrl.append(ACCOUNT_KEY_NAME);
            }

            returnUrl.append("=").append(account.getAccountNbr()).append("&");

            if (!Utilities.isEmpty(subAccountReturn)) {
                returnUrl.append(subAccountReturn);
            } else {
                returnUrl.append(SUB_ACCOUNT_KEY_NAME);
            }

            returnUrl.append("=").append(account.getSubAcctNbr())
                     .append("\">return value</a>");
            account.setReturnUrl(returnUrl.toString());
        }

        return accounts;
    }

    public boolean checkForAdditionalFields(Map fieldValues, 
                                            HttpServletRequest request)
                                     throws Exception {
        return false;
    }

    public List getDefaultReturnType() {
        List returnTypes = new ArrayList();
        returnTypes.add(CHART_KEY_NAME);
        returnTypes.add(ACCOUNT_KEY_NAME);
        returnTypes.add(SUB_ACCOUNT_KEY_NAME);

        return returnTypes;
    }

    public String getNoReturnParams(Map fieldConversions) {
        String chartReturn = (String) fieldConversions.get(CHART_KEY_NAME);
        String accountReturn = (String) fieldConversions.get(ACCOUNT_KEY_NAME);
        String subAccountReturn = (String) fieldConversions.get(
                                          SUB_ACCOUNT_KEY_NAME);

        StringBuffer buffer = new StringBuffer();
        buffer.append("&");

        if (!Utilities.isEmpty(chartReturn)) {
            buffer.append(chartReturn);
        } else {
            buffer.append(CHART_KEY_NAME);
        }

        buffer.append("=&");

        if (!Utilities.isEmpty(accountReturn)) {
            buffer.append(accountReturn);
        } else {
            buffer.append(ACCOUNT_KEY_NAME);
        }

        buffer.append("=&");

        if (!Utilities.isEmpty(subAccountReturn)) {
            buffer.append(subAccountReturn);
        } else {
            buffer.append(SUB_ACCOUNT_KEY_NAME);
        }

        buffer.append("=");

        return buffer.toString();
    }

    /**
     * @return Returns the title.
     */
    public String getTitle() {
        return title;
    }

    /**
     * @return Returns the instructions.
     */
    public String getLookupInstructions() {
        //TODO put instructions here
        return "Put instructions in getLookupInstructions of lookupable implementation";
    }

    /**
     * @return Returns the returnLocation.
     */
    public String getReturnLocation() {
        return returnLocation;
    }

    /**
     * @return Returns the columns.
     */
    public List getColumns() {
        return columns;
    }

    public String getHtmlMenuBar() {
        return "";
    }

    public List getRows() {
        return rows;
    }

    private static FiscalSubAccountService getService() {
        return (FiscalSubAccountService) IUServiceLocator.getFiscalSubAccountService();
    }
}