
/*
 * Copyright (c) 2004, 2005, 2006 Trustees of Indiana University and Cornell University.
 *
 * Licensed under the Educational Community License Version 1.0 (the "License"); By obtaining,
 * using and/or copying this Original Work, you agree that you have read, understand, and will
 * comply with the terms and conditions of the Educational Community License.
 *
 * For the full text of the license, see the LICENSE.txt file or visit:
 * 
 * http://kew.indiana.edu/workflow/LICENSE.txt
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING
 * BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE
 * AND NONINFRINGEMENT.
 * IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES
 * OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 */
            
package edu.iu.uis.eden.lookupable;

import edu.iu.uis.eden.IUServiceLocator;
import edu.iu.uis.eden.account.Account;
import edu.iu.uis.eden.account.AccountService;
import edu.iu.uis.eden.fisdata.FiscalChart;
import edu.iu.uis.eden.plugin.attributes.WorkflowLookupable;
import edu.iu.uis.eden.util.KeyLabelPair;
import edu.iu.uis.eden.util.Utilities;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;


public class AccountLookupableImpl implements WorkflowLookupable {
    private static final org.apache.log4j.Logger LOG = 
            org.apache.log4j.Logger.getLogger(AccountLookupableImpl.class);
    private static List columns = establishColumns();
    private static final String ACCOUNT_NBR_FIELD_LABEL = "Account";
    private static final String ACCOUNT_NAME_FIELD_LABEL = "Account Name";
    private static final String CHART_FIELD_LABEL = "Chart";
    private static final String CLOSED_IND_FIELD_LABEL = "Account Open";
    private static final String ACCOUNT_NBR_FIELD_HELP = "";
    private static final String ACCOUNT_NAME_FIELD_HELP = "";
    private static final String CHART_FIELD_HELP = "";
    private static final String CLOSED_IND_FIELD_HELP = "";
    private static final String ACCOUNT_NBR_PROPERTY_NAME = "accountNbr";
    private static final String ACCOUNT_NAME_PROPERTY_NAME = "accountName";
    private static final String CHART_PROPERTY_NAME = "fin_coa_cd";
    private static final String CLOSED_IND_PROPERTY_NAME = "closedInd";
    private static final String BACK_LOCATION = "backLocation";
    private static final String DOC_FORM_KEY = "docFormKey";
    private List rows;

    public AccountLookupableImpl() {
        rows = new ArrayList();

        List fields = new ArrayList();
        fields.add(new Field(ACCOUNT_NBR_FIELD_LABEL, ACCOUNT_NBR_FIELD_HELP, 
                             Field.TEXT, false, ACCOUNT_NBR_PROPERTY_NAME, "", 
                             null, null));
        rows.add(new Row(fields));

        fields = new ArrayList();
        fields.add(new Field(ACCOUNT_NAME_FIELD_LABEL, ACCOUNT_NAME_FIELD_HELP, 
                             Field.TEXT, false, ACCOUNT_NAME_PROPERTY_NAME, "", 
                             null, null));
        rows.add(new Row(fields));

        fields = new ArrayList();
        fields.add(new Field(CHART_FIELD_LABEL, CHART_FIELD_HELP, 
                             Field.DROPDOWN, false, CHART_PROPERTY_NAME, "", 
                             getChartOptions(), null));
        rows.add(new Row(fields));

        List options = new ArrayList();
        options.add(new KeyLabelPair("N", "Open"));
        options.add(new KeyLabelPair("Y", "Closed"));
        options.add(new KeyLabelPair("ALL", "Show All"));

        fields = new ArrayList();
        fields.add(new Field(CLOSED_IND_FIELD_LABEL, CLOSED_IND_FIELD_HELP, 
                             Field.RADIO, false, CLOSED_IND_PROPERTY_NAME, "N", 
                             options, null));
        rows.add(new Row(fields));
    }

    private static List getChartOptions() {
        List options = new ArrayList();
        List charts = IUServiceLocator.getFISDataService().findAllCharts();

        for (Iterator iter = charts.iterator(); iter.hasNext();) {
            FiscalChart fiscalChart = (FiscalChart) iter.next();
            options.add(
                    new KeyLabelPair(fiscalChart.getFinCoaCd(), 
                                     fiscalChart.getFinCoaCd() + " : " + 
                                         fiscalChart.getFinCoaDesc()));
        }

        return options;
    }

    private static List establishColumns() {
        List columns = new ArrayList();
        columns.add(new Column("Account", "true", "accountNbr"));
        columns.add(new Column("Account Name", "true", "accountName"));
        columns.add(new Column("Chart", "true", "finCoaCd"));
        columns.add(new Column("Account Open", "true", "closedInd"));

        return columns;
    }

    public String getHtmlMenuBar() {
        return "";
    }

    public List getRows() {
        return rows;
    }

    public String getTitle() {
        return "Account Lookup";
    }

    public String getReturnLocation() {
        return "Lookup.do";
    }

    public List getColumns() {
        return columns;
    }

    public boolean checkForAdditionalFields(Map fieldValues, 
                                            HttpServletRequest request)
                                     throws Exception {
        return false;
    }

    public void changeIdToName(Map fieldValues) {
    }

    public List getSearchResults(Map fieldValues, Map fieldConversions)
                          throws Exception {
        String paramAccountNumber = (String) fieldValues.get(
                                            ACCOUNT_NBR_PROPERTY_NAME);
        String paramAccountNm = (String) fieldValues.get(
                                        ACCOUNT_NAME_PROPERTY_NAME);
        String paramFinCoaCd = (String) fieldValues.get(CHART_PROPERTY_NAME);
        String paramClosedInd = (String) fieldValues.get(
                                        CLOSED_IND_PROPERTY_NAME);

        String backLocation = (String) fieldValues.get(BACK_LOCATION);
        String docFormKey = (String) fieldValues.get(DOC_FORM_KEY);

        String chartReturn = (String) fieldConversions.get(CHART_PROPERTY_NAME);
        String accountReturn = (String) fieldConversions.get(
                                       ACCOUNT_NBR_PROPERTY_NAME);

        if (Utilities.isEmpty(paramAccountNumber)) {
            paramAccountNumber = null;
        }

        if (Utilities.isEmpty(paramAccountNm)) {
            paramAccountNm = null;
        }

        if (Utilities.isEmpty(paramFinCoaCd)) {
            paramFinCoaCd = null;
        }

        if ((paramClosedInd != null) && paramClosedInd.equals("ALL")) {
            paramClosedInd = null;
        }

        Iterator accounts = ((AccountService) IUServiceLocator.getAccountService()).search(
                                    paramAccountNumber, paramAccountNm, 
                                    paramFinCoaCd, paramClosedInd).iterator();
        List displayList = new ArrayList();

        while (accounts.hasNext()) {
            Account record = (Account) accounts.next();

            if (!Utilities.isEmpty(record.getClosedInd())) {
                if (record.getClosedInd().equals("N")) {
                    record.setClosedInd("yes");
                } else {
                    record.setClosedInd("no");
                }
            }

            StringBuffer returnUrl = new StringBuffer("<a href=\"");
            returnUrl.append(backLocation)
                     .append("?methodToCall=refresh&docFormKey=")
                     .append(docFormKey).append("&");

            if (!Utilities.isEmpty(chartReturn)) {
                returnUrl.append(chartReturn);
            } else {
                returnUrl.append(CHART_PROPERTY_NAME);
            }

            returnUrl.append("=").append(record.getFinCoaCd()).append("&");

            if (!Utilities.isEmpty(accountReturn)) {
                returnUrl.append(accountReturn);
            } else {
                returnUrl.append(ACCOUNT_NBR_PROPERTY_NAME);
            }

            returnUrl.append("=").append(record.getAccountNbr())
                     .append("\">return value</a>");
            record.setReturnUrl(returnUrl.toString());
            displayList.add(record);
        }

        return displayList;
    }

    public List getDefaultReturnType() {
        List returnTypes = new ArrayList();
        returnTypes.add(CHART_PROPERTY_NAME);
        returnTypes.add(ACCOUNT_NBR_PROPERTY_NAME);

        return returnTypes;
    }

    public String getNoReturnParams(Map fieldConversions) {
        String chartReturn = (String) fieldConversions.get(CHART_PROPERTY_NAME);
        String accountReturn = (String) fieldConversions.get(
                                       ACCOUNT_NBR_PROPERTY_NAME);

        StringBuffer noReturnParams = new StringBuffer("&");

        if (!Utilities.isEmpty(chartReturn)) {
            noReturnParams.append(chartReturn);
        } else {
            noReturnParams.append(CHART_PROPERTY_NAME);
        }

        noReturnParams.append("=&");

        if (!Utilities.isEmpty(accountReturn)) {
            noReturnParams.append(accountReturn);
        } else {
            noReturnParams.append(ACCOUNT_NBR_PROPERTY_NAME);
        }

        noReturnParams.append("=");

        return noReturnParams.toString();
    }

    public String getLookupInstructions() {
        return "Search for Account by account number, account name, and chart.";
    }
}