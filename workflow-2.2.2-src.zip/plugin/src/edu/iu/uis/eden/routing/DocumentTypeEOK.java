
/*
 * Copyright (c) 2004, 2005, 2006 Trustees of Indiana University and Cornell University.
 *
 * Licensed under the Educational Community License Version 1.0 (the "License"); By obtaining,
 * using and/or copying this Original Work, you agree that you have read, understand, and will
 * comply with the terms and conditions of the Educational Community License.
 *
 * For the full text of the license, see the LICENSE.txt file or visit:
 * 
 * http://kew.indiana.edu/workflow/LICENSE.txt
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING
 * BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE
 * AND NONINFRINGEMENT.
 * IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES
 * OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 */
            
package edu.iu.uis.eden.routing;

import org.jdom.Element;

import org.jdom.output.XMLOutputter;


/**
 * EdenDocumentTypeKey is the key class for the DocumentType class. It is used to find DocumentType's or as a
 * stand in for a document type.
 * <p>Title: Enterprise Development ENvironment</p>
 * <p>Description: EDEN is the infrastructure components that are common to most IU Enterprise applications.</p>
 * <p>Copyright: Copyright (c) 2001</p>
 * <p>Company: UIS - Indiana University</p>
 * @author <a href="mailto:seiffert@indiana.edu">Kurt A. Seiffert</a>
 * @version $Revision: 1.1 $ - $Date: 2006/04/28 12:57:38 $
 */
/** @todo Create a wrapper class to use keyJDOM so that this can become a sub-class of Element and function
 *  whereever an Element can */
public class DocumentTypeEOK {
    public final static String DOC_TYPE_EOK = "eden_document_type_eok";
    public final static String FULL_NAME_TAGE = "doc_type_full_name";
    public final static String VALUE = "value";
    private final String INVALID_KEY_MSG = "doc_type_id is null resulting in an invalid key";
    private final String ROUTE_CONTROL_ATTR = "route-control";
    private final String ROUTE_CONTROL_TRUE = "yes";
    private final String INDENT = "\t";

    /** The shortname for this document type */
    public String docType = "";

    /** Indicates if the key is being used as a route control - true by default*/
    public boolean routeControl = true;

    public DocumentTypeEOK(String docType, boolean rcFlag)
                    throws Exception {
        if ((docType == null) || docType.equals("")) {
            throw new Exception("Empty key not allowed");
        }

        this.docType = docType;
        routeControl = rcFlag;
    }

    /**
     * Construct the key from a JDOM element that begins with the appropriate tag
     * @param keyElement
     */
    public DocumentTypeEOK(Element keyElement) throws Exception {
        // check if the element is a valid one for us
        if (!keyElement.getName().equals(DOC_TYPE_EOK)) {
            throw new Exception("Invalid DocumentTypeEOK element");
        }

        try {
            // get the route-control attribute
            String routeCtrl = keyElement.getAttributeValue(
                                       this.ROUTE_CONTROL_ATTR);

            if ((routeCtrl != null) && 
                    routeCtrl.equals(this.ROUTE_CONTROL_TRUE)) {
                this.routeControl = true;
            } else {
                this.routeControl = false;
            }

            // get the children tag
            Element dtName = keyElement.getChild(FULL_NAME_TAGE);

            if (dtName != null) {
                docType = dtName.getAttributeValue(VALUE);

                if (docType == null) {
                    throw new Exception(
                            "Invalid DocumentTypeEOK element -- expected value for doc_type_shortname");
                }
            } else {
                throw new Exception("No doc type name found");
            }
        } catch (Exception e) {
            throw new Exception(e.getMessage() + INVALID_KEY_MSG);
        }
    }

    /**
     * Returns the doc type key in the XML format.
     * @return String representing XML for key.
     */
    public String getSerializedForm() throws Exception {
        try {
            XMLOutputter out = new XMLOutputter(INDENT, true);

            return out.outputString(buildJdom());
        } catch (Exception e) {
            throw new Exception("Unable to serialize EOK" + e.getMessage());
        }
    }

    /**
     * Construct the JDOM Element for this key
     *
     * <!ELEMENT eden_document_type_eok (doc_type_shortname) >
     * <!ATTLIST eden_document_type_eok route-control (yes) #IMPLIED >
     * <!ELEMENT doc_type_shortname EMPTY>
     * <!ATTLIST doc_type_shortname value CDATA #REQUIRED >
     *
     * @return Element
     */
    public Element buildJdom() {
        Element keyJDOM = new Element(DOC_TYPE_EOK);

        if (this.routeControl) {
            keyJDOM.setAttribute(ROUTE_CONTROL_ATTR, ROUTE_CONTROL_TRUE);
        }

        Element nameChild = new Element(FULL_NAME_TAGE);
        nameChild.setAttribute(VALUE, docType);
        keyJDOM.addContent(nameChild);

        return keyJDOM;
    }

    public boolean isRouteControl() {
        return routeControl;
    }

    public String getDoc_type() {
        return docType;
    }
}

/*
 * Copyright 2003 The Trustees of Indiana University.  All rights reserved.
 *
 * This file is part of the EDEN software package.
 * For license information, see the LICENSE file in the top level directory
 * of the EDEN source distribution.
 */
