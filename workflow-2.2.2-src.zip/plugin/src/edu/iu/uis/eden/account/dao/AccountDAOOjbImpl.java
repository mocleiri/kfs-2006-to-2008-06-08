
/*
 * Copyright (c) 2004, 2005, 2006 Trustees of Indiana University and Cornell University.
 *
 * Licensed under the Educational Community License Version 1.0 (the "License"); By obtaining,
 * using and/or copying this Original Work, you agree that you have read, understand, and will
 * comply with the terms and conditions of the Educational Community License.
 *
 * For the full text of the license, see the LICENSE.txt file or visit:
 * 
 * http://kew.indiana.edu/workflow/LICENSE.txt
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING
 * BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE
 * AND NONINFRINGEMENT.
 * IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES
 * OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 */
            
package edu.iu.uis.eden.account.dao;

import edu.iu.uis.eden.account.Account;
import edu.iu.uis.eden.account.AccountDelegation;
import edu.iu.uis.eden.util.Utilities;

import java.util.ArrayList;
import java.util.List;

import org.apache.ojb.broker.query.Criteria;
import org.apache.ojb.broker.query.QueryByCriteria;

import org.springframework.orm.ojb.PersistenceBrokerTemplate;


public class AccountDAOOjbImpl extends PersistenceBrokerTemplate
    implements AccountDAO {
    public Account findByChartAccount(String finCoaCd, String accountNbr) {
        Criteria crit = new Criteria();
        crit.addEqualTo("accountNbr", accountNbr);
        crit.addEqualTo("finCoaCd", finCoaCd);

        return (Account) getObjectByQuery(
                       new QueryByCriteria(Account.class, crit));
    }

    public List findDelegationsByChartAccount(String finCoaCd, 
                                              String accountNbr) {
        Criteria crit = new Criteria();
        crit.addEqualTo("accountNbr", accountNbr);
        crit.addEqualTo("finCoaCd", finCoaCd);

        return (List) getCollectionByQuery(
                       new QueryByCriteria(AccountDelegation.class, crit));
    }

    public List search(String accountNbr, String accountName, String finCoaCd, 
                       String closedInd) {
        Criteria crit = new Criteria();

        if (!Utilities.isEmpty(accountNbr)) {
            accountNbr = accountNbr.replace('*', '%');
            crit.addLike("accountNbr", "%" + accountNbr.trim() + "%");
        }

        if (!Utilities.isEmpty(accountName)) {
            accountName = accountName.replace('*', '%');
            crit.addLike("UPPER(accountName)", 
                         "%" + accountName.trim().toUpperCase() + "%");
        }

        if (!Utilities.isEmpty(finCoaCd)) {
            finCoaCd = finCoaCd.replace('*', '%');
            crit.addLike("UPPER(finCoaCd)", 
                         "%" + finCoaCd.trim().toUpperCase() + "%");
        }

        if (!Utilities.isEmpty(closedInd)) {
            crit.addEqualTo("closedInd", closedInd);
        }

        return (List) getCollectionByQuery(
                       new QueryByCriteria(Account.class, crit));
    }

    public List getAllAccounts() {
        Criteria crit = new Criteria();
        crit.addEqualTo("closedInd", "N");

        return new ArrayList(getCollectionByQuery(
                                     new QueryByCriteria(Account.class, crit)));
    }
}