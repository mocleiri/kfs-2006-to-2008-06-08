
/*
 * Copyright (c) 2004, 2005, 2006 Trustees of Indiana University and Cornell University.
 *
 * Licensed under the Educational Community License Version 1.0 (the "License"); By obtaining,
 * using and/or copying this Original Work, you agree that you have read, understand, and will
 * comply with the terms and conditions of the Educational Community License.
 *
 * For the full text of the license, see the LICENSE.txt file or visit:
 * 
 * http://kew.indiana.edu/workflow/LICENSE.txt
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING
 * BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE
 * AND NONINFRINGEMENT.
 * IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES
 * OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 */
            
package edu.iu.uis.eden.account;

import edu.iu.uis.eden.WorkflowPersistable;

import java.sql.Timestamp;


public class AccountDelegation implements WorkflowPersistable {
    private String finCoaCd;
    private String accountNbr;
    private String fdocTypCd;
    private String acctDlgtUnvlId;
    private Long fdocAprvFromAmt;
    private String acctDlgtPrmrtCd;
    private String acctDlgtActvCd;
    private Timestamp acctDlgtStartDt;
    private Long fdocAprvToAmt;

    /**
     * @return Returns the accountNbr.
     */
    public String getAccountNbr() {
        return accountNbr;
    }

    /**
     * @param accountNbr The accountNbr to set.
     */
    public void setAccountNbr(String accountNbr) {
        this.accountNbr = accountNbr;
    }

    /**
     * @return Returns the acctDlgtActvCd.
     */
    public String getAcctDlgtActvCd() {
        return acctDlgtActvCd;
    }

    /**
     * @param acctDlgtActvCd The acctDlgtActvCd to set.
     */
    public void setAcctDlgtActvCd(String acctDlgtActvCd) {
        this.acctDlgtActvCd = acctDlgtActvCd;
    }

    /**
     * @return Returns the acctDlgtPrmrtCd.
     */
    public String getAcctDlgtPrmrtCd() {
        return acctDlgtPrmrtCd;
    }

    /**
     * @param acctDlgtPrmrtCd The acctDlgtPrmrtCd to set.
     */
    public void setAcctDlgtPrmrtCd(String acctDlgtPrmrtCd) {
        this.acctDlgtPrmrtCd = acctDlgtPrmrtCd;
    }

    /**
     * @return Returns the acctDlgtStartDt.
     */
    public Timestamp getAcctDlgtStartDt() {
        return acctDlgtStartDt;
    }

    /**
     * @param acctDlgtStartDt The acctDlgtStartDt to set.
     */
    public void setAcctDlgtStartDt(Timestamp acctDlgtStartDt) {
        this.acctDlgtStartDt = acctDlgtStartDt;
    }

    /**
     * @return Returns the acctDlgtUnvlId.
     */
    public String getAcctDlgtUnvlId() {
        return acctDlgtUnvlId;
    }

    /**
     * @param acctDlgtUnvlId The acctDlgtUnvlId to set.
     */
    public void setAcctDlgtUnvlId(String acctDlgtUnvlId) {
        this.acctDlgtUnvlId = acctDlgtUnvlId;
    }

    /**
     * @return Returns the fdocAprvFromAmt.
     */
    public Long getFdocAprvFromAmt() {
        return fdocAprvFromAmt;
    }

    /**
     * @param fdocAprvFromAmt The fdocAprvFromAmt to set.
     */
    public void setFdocAprvFromAmt(Long fdocAprvFromAmt) {
        this.fdocAprvFromAmt = fdocAprvFromAmt;
    }

    /**
     * @return Returns the fdocAprvToAmt.
     */
    public Long getFdocAprvToAmt() {
        return fdocAprvToAmt;
    }

    /**
     * @param fdocAprvToAmt The fdocAprvToAmt to set.
     */
    public void setFdocAprvToAmt(Long fdocAprvToAmt) {
        this.fdocAprvToAmt = fdocAprvToAmt;
    }

    /**
     * @return Returns the fdocTypCd.
     */
    public String getFdocTypCd() {
        return fdocTypCd;
    }

    /**
     * @param fdocTypCd The fdocTypCd to set.
     */
    public void setFdocTypCd(String fdocTypCd) {
        this.fdocTypCd = fdocTypCd;
    }

    /**
     * @return Returns the finCoaCd.
     */
    public String getFinCoaCd() {
        return finCoaCd;
    }

    /**
     * @param finCoaCd The finCoaCd to set.
     */
    public void setFinCoaCd(String finCoaCd) {
        this.finCoaCd = finCoaCd;
    }

    public Object copy(boolean preserveKeys) {
        preserveKeys = true; // always true because this is read only...

        AccountDelegation copy = new AccountDelegation();
        copy.setAccountNbr(this.accountNbr);
        copy.setAcctDlgtActvCd(this.acctDlgtActvCd);
        copy.setAcctDlgtPrmrtCd(this.acctDlgtPrmrtCd);
        copy.setAcctDlgtStartDt(this.acctDlgtStartDt);
        copy.setAcctDlgtUnvlId(this.acctDlgtUnvlId);
        copy.setFdocAprvFromAmt(this.fdocAprvFromAmt);
        copy.setFdocAprvToAmt(this.fdocAprvToAmt);
        copy.setFdocTypCd(this.fdocTypCd);
        copy.setFinCoaCd(this.finCoaCd);

        return copy;
    }
}