
/*
 * Copyright (c) 2004, 2005, 2006 Trustees of Indiana University and Cornell University.
 *
 * Licensed under the Educational Community License Version 1.0 (the "License"); By obtaining,
 * using and/or copying this Original Work, you agree that you have read, understand, and will
 * comply with the terms and conditions of the Educational Community License.
 *
 * For the full text of the license, see the LICENSE.txt file or visit:
 * 
 * http://kew.indiana.edu/workflow/LICENSE.txt
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING
 * BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE
 * AND NONINFRINGEMENT.
 * IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES
 * OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 */
            
package edu.iu.uis.eden.workgroup;

import edu.iu.uis.eden.IUServiceLocator;
import edu.iu.uis.eden.SpringServiceLocator;
import edu.iu.uis.eden.ads.AdsService;
import edu.iu.uis.eden.exception.EdenUserNotFoundException;
import edu.iu.uis.eden.exception.WorkflowRuntimeException;
import edu.iu.uis.eden.user.AuthenticationUserId;
import edu.iu.uis.eden.user.UserService;
import edu.iu.uis.eden.user.WorkflowUser;
import edu.iu.uis.eden.util.Utilities;
import edu.iu.uis.sit.util.directory.AdsHelper;

import java.util.Iterator;
import java.util.List;
import java.util.Vector;

import javax.naming.AuthenticationException;
import javax.naming.NamingException;


/**
 * An a Workgroup implementation which is backed by an ADS group.  This implementation wraps an existing
 * SimpleWorkgroup.
 * 
 * @author Eric Westfall
 */
public class ADSWorkgroup extends BaseWorkgroup {
    private static final long serialVersionUID = -243171768448572648L;
    private static final org.apache.log4j.Logger LOG = 
            org.apache.log4j.Logger.getLogger(ADSWorkgroup.class);
    public static final String ADS_TYPE = "A";
    private boolean adsMembersPopulated = false;

    public ADSWorkgroup() {
        setWorkgroupType(ADS_TYPE);
    }

    /**
     * Creates an ADSWorkgroup out of the given SimpleWorkgroup.
     */
    public ADSWorkgroup(BaseWorkgroup simpleWorkgroup) {
        if (!simpleWorkgroup.getWorkgroupType().equals(ADS_TYPE)) {
            throw new IllegalArgumentException(
                    "Workgroup is not an ADS workgroup.  Instead type was: " + 
                    simpleWorkgroup.getWorkgroupType());
        }

        setActiveInd(simpleWorkgroup.getActiveInd());
        setCurrentInd(simpleWorkgroup.getCurrentInd());
        setDescription(simpleWorkgroup.getDescription());
        setDocumentId(simpleWorkgroup.getDocumentId());
        setGroupNameId(simpleWorkgroup.getGroupNameId());
        setLockVerNbr(simpleWorkgroup.getLockVerNbr());
        setMembers(simpleWorkgroup.getMembers());
        setVersionNumber(simpleWorkgroup.getVersionNumber());
        setWorkflowGroupId(simpleWorkgroup.getWorkflowGroupId());
        setWorkgroupMembers(simpleWorkgroup.getWorkgroupMembers());
        setWorkgroupType(simpleWorkgroup.getWorkgroupType());
    }

    public List getMembers() {
        populateAdsMembers();

        return super.getMembers();
    }

    /**
     * Workgroups can be accessed by multiple threads if they are cached.
     */
    private synchronized void populateAdsMembers() {
        if (!adsMembersPopulated) {
            try {
                if (!Utilities.isEmpty(getWorkgroupName())) {
                    AdsHelper adsHelper = getAdsService().getAdsHelper();
                    Vector users = adsHelper.getGroupUsers(getWorkgroupName(), 
                                                           AdsHelper.INFINITE_GROUP_DEPTH);

                    for (Iterator iterator = users.iterator();
                         iterator.hasNext();) {
                        String userName = (String) iterator.next();
                        userName = userName.toLowerCase();

                        try {
                            WorkflowUser workflowUser = 
                                    getUserService()
                                        .getWorkflowUser(new AuthenticationUserId(
                                                                 userName));


                            //SimpleWorkgroupMember member = new SimpleWorkgroupMember();
                            //member.setWorkflowId(workflowUser.getWorkflowUserId().getWorkflowId());
                            super.getMembers().add(workflowUser);
                        } catch (EdenUserNotFoundException e) {
                            LOG.warn("Could not locate ADS person: name=" + 
                                     userName + ", in workgroup: name=" + 
                                     getWorkgroupName() + ", id=" + 
                                     getWorkgroupId());
                        }
                    }
                }

                adsMembersPopulated = true;
            } catch (AuthenticationException e) {
                throw new WorkflowRuntimeException(
                        "Error authenticating with ADS to resolve workgroup users, workgroupName=" + 
                        getWorkgroupName(), e);
            } catch (NamingException e) {
                throw new WorkflowRuntimeException(
                        "Error resolving users for workgroup from ADS, workgroupName=" + 
                        getWorkgroupName(), e);
            }
        }
    }

    private AdsService getAdsService() {
        return (AdsService) IUServiceLocator.getAdsService();
    }

    private UserService getUserService() {
        return (UserService) SpringServiceLocator.getService(
                       SpringServiceLocator.USER_SERVICE);
    }
}