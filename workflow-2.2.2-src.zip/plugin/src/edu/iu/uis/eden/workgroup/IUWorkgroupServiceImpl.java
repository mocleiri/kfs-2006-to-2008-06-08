
/*
 * Copyright (c) 2004, 2005, 2006 Trustees of Indiana University and Cornell University.
 *
 * Licensed under the Educational Community License Version 1.0 (the "License"); By obtaining,
 * using and/or copying this Original Work, you agree that you have read, understand, and will
 * comply with the terms and conditions of the Educational Community License.
 *
 * For the full text of the license, see the LICENSE.txt file or visit:
 * 
 * http://kew.indiana.edu/workflow/LICENSE.txt
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING
 * BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE
 * AND NONINFRINGEMENT.
 * IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES
 * OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 */
            
package edu.iu.uis.eden.workgroup;

import edu.iu.uis.eden.IUServiceLocator;
import edu.iu.uis.eden.ads.AdsService;
import edu.iu.uis.eden.exception.EdenUserNotFoundException;
import edu.iu.uis.eden.exception.WorkflowRuntimeException;

import javax.naming.NamingException;


/**
 * Workgroup service implementation for Indiana University.  Allows us to hook into our
 * ADS directory service for groups.
 * 
 * @author Eric Westfall
 */
public class IUWorkgroupServiceImpl extends BaseWorkgroupService {
    private static final org.apache.log4j.Logger LOG = 
            org.apache.log4j.Logger.getLogger(IUWorkgroupServiceImpl.class);

    protected BaseWorkgroup initializeLoadedWorkgroup(BaseWorkgroup workgroup)
                                               throws EdenUserNotFoundException {
        workgroup = super.initializeLoadedWorkgroup(workgroup);

        if (workgroup.getWorkgroupType().equals(ADSWorkgroup.ADS_TYPE) && 
                !(workgroup instanceof ADSWorkgroup)) {
            workgroup = new ADSWorkgroup(workgroup);
        }

        return workgroup;
    }

    protected BaseWorkgroup getExternalWorkgroup(GroupId groupId, 
                                                 boolean loadWorkgroupExtensions) {
        ADSWorkgroup workgroup = null;

        if (loadWorkgroupExtensions && groupId instanceof GroupNameId) {
            GroupNameId groupName = (GroupNameId) groupId;

            try {
                workgroup = getAdsWorkgroup(groupName);

                if (workgroup != null) {
                    save(workgroup);
                    addToCache(workgroup);
                    LOG.info("Loaded ADS workgroup with name '" + 
                             groupName.getNameId());
                }
            } catch (NamingException e) {
                throw new WorkflowRuntimeException(
                        "Problem locating ads workgroup, groupName=" + 
                        groupName.getNameId(), e);
            }
        }

        return workgroup;
    }

    /**
     * Creates an ADS Workgroup for the given workgroup name.  If no ADS workgroup can be found
     * with the given name, then null is returned.  The ADSWorkgroup returned from this method
     * is an unsaved and unmaterialized workgroup.  In other words, it has no primary key and
     * the members have not actually been loaded from the ADS server yet.  This is handled
     * lazily by the ADSWorkgroup class.
     */
    protected ADSWorkgroup getAdsWorkgroup(GroupNameId groupNameId)
                                    throws NamingException {
        ADSWorkgroup workgroup = null;

        if (getAdsService().getAdsHelper()
                .isValidGroupName(groupNameId.getNameId())) {
            workgroup = new ADSWorkgroup();
            workgroup.setActiveInd(Boolean.TRUE);
            workgroup.setGroupNameId(groupNameId);
            workgroup.setCurrentInd(Boolean.TRUE);
            workgroup.setDescription("Workgroup for ADS Group " + 
                                     groupNameId.getNameId());
            workgroup.setWorkgroupType(ADSWorkgroup.ADS_TYPE);
            workgroup.setVersionNumber(new Integer(0));
        }

        return workgroup;
    }

    private AdsService getAdsService() {
        return IUServiceLocator.getAdsService();
    }
}