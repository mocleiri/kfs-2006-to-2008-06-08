
/*
 * Copyright (c) 2004, 2005, 2006 Trustees of Indiana University and Cornell University.
 *
 * Licensed under the Educational Community License Version 1.0 (the "License"); By obtaining,
 * using and/or copying this Original Work, you agree that you have read, understand, and will
 * comply with the terms and conditions of the Educational Community License.
 *
 * For the full text of the license, see the LICENSE.txt file or visit:
 * 
 * http://kew.indiana.edu/workflow/LICENSE.txt
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING
 * BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE
 * AND NONINFRINGEMENT.
 * IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES
 * OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 */
            
package edu.iu.uis.eden.mail;

import edu.iu.uis.eden.core.Core;
import edu.iu.uis.sit.util.mail.AuthenticatedMailer;

import java.io.FileInputStream;
import java.io.IOException;

import java.util.Properties;

import org.apache.log4j.Logger;

import org.springframework.beans.factory.InitializingBean;


public class IUAuthenticatedEmailService implements EmailService,
                                                    InitializingBean {
    private static final Logger LOG = Logger.getLogger(
                                              IUAuthenticatedEmailService.class);
    private static final String USERNAME_PROPERTY = "username";
    private static final String PASSWORD_PROPERTY = "password";
    private Properties emailProperties;

    public void afterPropertiesSet() throws Exception {
        try {
            emailProperties = new Properties();
            emailProperties.load(
                    new FileInputStream(Core.getCurrentContextConfig()
                                            .getEmailConfigurationPath()));
        } catch (Exception e) {
            emailProperties = null;
            LOG.error("Failed to load email properties file!  Email will be disabled.  Error was: " + 
                      e.getMessage());
        }
    }

    public void sendEmail(EmailFrom from, EmailTo to, EmailSubject subject, 
                          EmailBody body, boolean htmlMessage) {
        if (emailProperties == null) {
            LOG.error("Email is disabled, please check configuration!");
        } else {
            try {
                AuthenticatedMailer mailer = new AuthenticatedMailer(
                                                     from.getFromAddress(), 
                                                     emailProperties.getProperty(
                                                             USERNAME_PROPERTY), 
                                                     emailProperties.getProperty(
                                                             PASSWORD_PROPERTY));
                mailer.setHtmlMessage(htmlMessage);
                mailer.sendMessage(to.getToAddress(), subject.getSubject(), 
                                   body.getBody());
            } catch (Exception e) {
                LOG.error("Error sending email.", e);
            }
        }
    }
}