
/*
 * Copyright (c) 2004, 2005, 2006 Trustees of Indiana University and Cornell University.
 *
 * Licensed under the Educational Community License Version 1.0 (the "License"); By obtaining,
 * using and/or copying this Original Work, you agree that you have read, understand, and will
 * comply with the terms and conditions of the Educational Community License.
 *
 * For the full text of the license, see the LICENSE.txt file or visit:
 * 
 * http://kew.indiana.edu/workflow/LICENSE.txt
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING
 * BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE
 * AND NONINFRINGEMENT.
 * IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES
 * OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 */
            
package edu.iu.uis.eden.fisdata.dao;

import edu.iu.uis.eden.fisdata.FiscalChart;
import edu.iu.uis.eden.fisdata.Organization;

import java.util.List;

import org.apache.ojb.broker.query.Criteria;
import org.apache.ojb.broker.query.QueryByCriteria;

import org.springframework.orm.ojb.PersistenceBrokerTemplate;


public class FISDataDAOOjbImpl extends PersistenceBrokerTemplate
    implements FISDataDAO {
    public List findAllCharts() {
        return (List) getCollectionByQuery(
                       new QueryByCriteria(FiscalChart.class));
    }

    public Organization findOrganization(String chart, String org) {
        Criteria crit = new Criteria();
        crit.addEqualTo("finCoaCd", chart);
        crit.addEqualTo("orgCd", org);

        return (Organization) getObjectByQuery(
                       new QueryByCriteria(Organization.class, crit));
    }

    public List findOrganizations(String finCoaCd, String orgCd, 
                                  String organizationName, String activeInd) {
        Criteria criteria = new Criteria();

        if ((finCoaCd != null) && !"".equals(finCoaCd.trim())) {
            criteria.addLike("UPPER(finCoaCd)", finCoaCd.toUpperCase());
        }

        if ((orgCd != null) && !"".equals(orgCd.trim())) {
            criteria.addLike("UPPER(orgCd)", orgCd.toUpperCase());
        }

        if ((organizationName != null) && 
                !"".equals(organizationName.trim())) {
            criteria.addLike("UPPER(name)", organizationName.toUpperCase());
        }

        if ((activeInd != null) && !"".equals(activeInd.trim())) {
            criteria.addEqualTo("activeCd", activeInd);
        }

        return (List) getCollectionByQuery(
                       new QueryByCriteria(Organization.class, criteria));
    }

    public List findOrganizations(String chart) {
        Criteria crit = new Criteria();

        return (List) getCollectionByQuery(
                       new QueryByCriteria(Organization.class, crit));
    }
}