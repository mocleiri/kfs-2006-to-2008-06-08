package edu.iu.uis.eden.lookupable;

import java.lang.reflect.Field;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import junit.framework.TestCase;
import edu.iu.uis.eden.SpringServiceLocator;
import edu.iu.uis.eden.account.Account;
import edu.iu.uis.eden.plugin.attributes.WorkflowLookupable;


public class AccountTestPENDING extends TestCase {
    private WorkflowLookupable workflowLookupable;
    private Map conversionFields;

    protected void setUp() throws Exception {
        SpringServiceLocator.setToTestMode(null);
        workflowLookupable = new AccountLookupableImpl();

        conversionFields = new HashMap();
        conversionFields.put("accountNbr", "test_accountNbr");
        conversionFields.put("fin_coa_cd", "test_fin_coa_cd");
    }
    public void testGetColumns() {
        for (Iterator iter = workflowLookupable.getColumns().iterator(); iter.hasNext();) {
            Column column = (Column) iter.next();
            try {
                Field field = Account.class.getDeclaredField(column.getPropertyName());
            } catch (NoSuchFieldException e) {
                assertTrue("Column property name on Account does not equal a property on the Account bean. Column: "+column.getPropertyName(), false);                
            }
        }
    }
    
    public void testGetNoReturnParams() {
        String parameters = workflowLookupable.getNoReturnParams(conversionFields);

        assertTrue("Return parameter accountNbr is not correct.", parameters.indexOf("test_accountNbr=") > 0);
        assertTrue("Return parameter fin_coa_cd is not correct.", parameters.indexOf("test_fin_coa_cd=") > 0);
        
    }

}
