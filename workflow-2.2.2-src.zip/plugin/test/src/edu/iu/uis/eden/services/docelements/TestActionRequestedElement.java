package edu.iu.uis.eden.services.docelements;

import java.io.StringReader;

import junit.framework.TestCase;

import org.jdom.Document;
import org.jdom.Element;

import edu.iu.uis.eden.EdenConstants;
import edu.iu.uis.eden.WorkflowServiceErrorImpl;
import edu.iu.uis.eden.exception.InvalidXmlException;
import edu.iu.uis.eden.services.IDocElement;
import edu.iu.uis.eden.services.InconsistentDocElementStateException;
import edu.iu.uis.eden.services.ServiceErrorConstants;
import edu.iu.uis.eden.util.XmlHelper;


public class TestActionRequestedElement extends TestCase {
  private ActionRequestedElement actionRequested;

  public TestActionRequestedElement(String s) {
    super(s);
  }

  protected void setUp() {
    actionRequested = new ActionRequestedElement();
  }

  protected void tearDown() {
  }

  /**
   * is this returning true when the object is empty
   */
  public void testIsEmpty() {
    assertTrue("new object not returning true", actionRequested.isEmpty());

    //set something and try again
    actionRequested.setActionRequested("hello");
    assertEquals("set ActionRequested returning true on isEmpty()", false, actionRequested.isEmpty());
  }

  /**
   * loaded with an invalid actionrequested (on that's not in EdenConstants
   * ActionRequested ActionRequestedElement should give a corrects error msg
   */
  public void testInvalidActionRequested() {
    /* try catch added after api change surrounding all logic might not be
       best approach */
    try {
      this.actionRequested.setActionRequested("Z");

      WorkflowServiceErrorImpl error = this.actionRequested.validate();
      assertEquals("Didn't give proper error for invalid actionrequested",
        ServiceErrorConstants.ACTION_REQUESTED_INVALID, error.getKey());

      /* load it with a valid and retest should be null */
      this.actionRequested.setActionRequested(EdenConstants.ACTION_REQUEST_ACKNOWLEDGE_REQ);
      error = this.actionRequested.validate();
      assertNull("valid ActionRequested didn't return null on validation",
        this.actionRequested.validate());
    } catch (Exception ex) {
      fail("threw exception validating");
    }
  }

  /**
   * this is not a route control
   */
  public void testIsRouteControl() {
    assertEquals("ActionRequested returning true on isRouteControl", false,
      actionRequested.isRouteControl());
    actionRequested.setRouteControl(true);
    assertEquals("ActionRequested allowing true to set RouteControl", false,
      actionRequested.isRouteControl());
  }

  /**
   * given a jdom element of the correct type it should load itself to the value
   * of the given jdom element
   *
   * if the jdom element is null and allowBlanks true it should return
   *
   * if the jdom element is null and allowBlanks is false its should throw
   * an InconsistentDocElementStateException
   *
   * if the element is of the incorrect type it should throw an
   * InvalidXmlException
   */
  public void testLoadFromXMLContent() {
    //test loading a normal date
    String ackRequested = "A";
    Element ackRequestedEl = new Element(actionRequested.getElementName());
    ackRequestedEl.setAttribute("value", ackRequested);

    try {
      actionRequested.loadFromXMLContent(ackRequestedEl, false);
      assertEquals("didn't properly load props from valid element", ackRequested,
        actionRequested.getActionRequested());
    } catch (Exception ex) {
      fail("threw exception loading from valid element");
    }

    //test implementation of interface
    this.nonClassSpecificLoadFromXMLTests(actionRequested);
  }

  /**
   * is the correct constant coming back for the correct error
   */
  public void testValidate() {
    //check an empty one
    try {
      WorkflowServiceErrorImpl error = actionRequested.validate();
      assertEquals("validate returned the wrong constant on the DocElementError " + "object",
        ServiceErrorConstants.ACTION_REQUESTED_BLANK, error.getKey());

      //this should pass
      actionRequested.setActionRequested("A");
      assertNull("validate on good ActionRequested didn't return null", actionRequested.validate());
    } catch (Exception ex) {
      fail("threw exception validating");
    }
  }

  /**
   * does it give back good xml
   */
  public void testGetXMLContent() {
    Element xml = new Element(actionRequested.getElementName());
    xml.setAttribute("value", "A");

    actionRequested.setActionRequested("a");
    assertEquals("Didn't make XMLContent correctly", xml.getAttributeValue("value"),
      actionRequested.getXMLContent().getAttributeValue("value"));
  }

  /**
   * he should return caps regardless of what he's set w/
   */
  public void testGetActionRequested() {
    actionRequested.setActionRequested("a");
    assertEquals("GetActionRequested not properly capitalizing the " + "actionRequested set with",
      "A", actionRequested.getActionRequested());
  }

  /**
   * can this guy populate himself w/ xml he made.
   */
  public void testCanFeedOnOwnXML() {
    String action = "A";
    actionRequested.setActionRequested(action);

    Element ackReqEl = actionRequested.getXMLContent();

    try {
      actionRequested.loadFromXMLContent(ackReqEl, false);
      assertEquals("Didn't properly set properties from self made XML", action,
        actionRequested.getActionRequested());
    } catch (Exception ex) {
      fail("threw exception loading from self generated xml");
    }
  }

  /**
   * utility method that is not object specific
   *
   * @param docElement the docElement being tested
   */
  public void nonClassSpecificLoadFromXMLTests(IDocElement docElement) {
    //give null allow blanks
    try {
      docElement.loadFromXMLContent(null, true);
    } catch (Exception ex) {
      fail("threw exception loading null element set to allow blanks");
    }

    //give null dont allow blanks
    try {
      docElement.loadFromXMLContent(null, false);
      fail("didn't throw InconsistentDocElementStateException " +
        "loaded with null element allowBlanks set to false");
    } catch (InconsistentDocElementStateException ex) {
    } catch (InvalidXmlException ex) {
      fail("didn't throw InconsistentDocElementStateException " +
        "loaded with null element allowBlanks set to false");
    }

    //give element of wrong type
    try {
      docElement.loadFromXMLContent(new Element("Imbad"), false);
      fail("Didn't throw InvalidXmlException when loaded with " + "element of the wrong type");
    } catch (InconsistentDocElementStateException ex) {
      fail("Didn't throw InvalidXmlException when loaded with " + "element of the wrong type");
    } catch (InvalidXmlException ex) {
    }
  }

  public Element makeStringElement(String xmlContent) {
    Document doc = null;

    try {
      doc = new Document(XmlHelper.buildJDocument(new StringReader(xmlContent), false)
                                  .getRootElement());
    } catch (InvalidXmlException ex) {
      fail("Generated invalid xml");
    }

    return doc.getRootElement();
  }
}





/*
 * Copyright 2003 The Trustees of Indiana University.  All rights reserved.
 *
 * This file is part of the EDEN software package.
 * For license information, see the LICENSE file in the top level directory
 * of the EDEN source distribution.
 */
