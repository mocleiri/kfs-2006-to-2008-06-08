package edu.iu.uis.eden.services.docelements;

import java.io.StringReader;

import org.jdom.Document;
import org.jdom.Element;

import edu.iu.uis.eden.exception.InvalidXmlException;
import edu.iu.uis.eden.services.IDocElement;
import edu.iu.uis.eden.services.InconsistentDocElementStateException;
import edu.iu.uis.eden.util.XmlHelper;


public class TestActiveIndicatorElement extends IDocInterfaceTestTemplate {
  private ActiveIndicatorElement activeInd;

  public TestActiveIndicatorElement(String s) {
    super(s);
  }

  protected void setUp() {
    activeInd = new ActiveIndicatorElement();
  }

  protected void tearDown() {
  }

  public IDocElement getIDocElement() {
    return this.activeInd;
  }

  /**
   * true or false should be valid
   */
  public void testValidate() {
    try {
      assertNull("valid object didn't return null", activeInd.validate());

      //set activeInd to true and recheck
      assertNull("valid object didn't return null", activeInd.validate());
    } catch (Exception ex) {
      fail("threw exception validating");
    }
  }

  /**
   * should always be false
   */
  public void testIsRouteControl() {
    assertEquals("ActiveIndicator returned true on isRouteControl", false,
      activeInd.isRouteControl());

    //set routeControl to true and recheck;
    activeInd.setRouteControl(true);
    assertEquals("ActiveIndicator returned true on isRouteControl", false,
      activeInd.isRouteControl());
  }

  /**
   * given a jdom element of the correct type it should load itself to the value
   * of the given jdom element
   *
   * if the jdom element is null and allowBlanks true it should return
   *
   * if the jdom element is null and allowBlanks is false its should throw
   * an InconsistentDocElementStateException
   *
   * if the element is of the incorrect type it should throw an
   * InvalidXmlException
   */
  public void testLoadFromXMLContent() {
    String XMLContentActive = "<active_ind value=\"Y\" />";
    String XMLContentInActive = "<active_ind value=\"N\" />";

    try {
      activeInd.loadFromXMLContent(this.makeStringElement(XMLContentActive), false);
      assertEquals("didn't properly load props from valid xml", true, activeInd.getActiveIndicator());
    } catch (Exception e) {
      fail("threw exception loading from good xml content");
    }

    //do same for inactive
    try {
      activeInd.loadFromXMLContent(this.makeStringElement(XMLContentInActive), false);
      assertEquals("didn't properly load props from valid xml", false,
        activeInd.getActiveIndicator());
    } catch (Exception e) {
      fail("threw exception loading from good xml content");
    }

    //test implementation of interface
    this.nonClassSpecificLoadFromXMLTests(activeInd);
  }

  /**
   * does ActiveIndicator render the correct xml representation when set to
   * true and false
   */
  public void testGetXMLContent() {
    //    String XMLContentActive = "<active_ind value=\"Y\" />";
    //    String XMLContentInActive = "<active_ind value=\"N\" />";
    assertNotNull("Returned null Element when loaded", activeInd.getXMLContent());
    activeInd.setActiveIndicator(true);
    assertNotNull("Returned null Element when loaded", activeInd.getXMLContent());
  }

  /**
   * can this guy populate himself w/ xml he made.
   */
  public void testCanFeedOnOwnXML() {
    activeInd.setActiveIndicator(true);

    Element activeIndEl = activeInd.getXMLContent();

    try {
      activeInd.loadFromXMLContent(activeIndEl, false);
      assertEquals("Didn't properly set properties from self made XML", true,
        activeInd.getActiveIndicator());
    } catch (Exception ex) {
      fail("threw exception loading from self generated xml");
    }

    //try w/ a false value
    activeInd.setActiveIndicator(false);
    activeIndEl = activeInd.getXMLContent();

    try {
      activeInd.loadFromXMLContent(activeIndEl, false);
      assertEquals("Didn't properly set properties from self made XML", false,
        activeInd.getActiveIndicator());
    } catch (Exception ex) {
      fail("threw exception loading from self generated xml");
    }
  }

  /**
   * utility method that is not object specific
   *
   * @param docElement the docElement being tested
   */
  public void nonClassSpecificLoadFromXMLTests(IDocElement docElement) {
    //give null allow blanks
    try {
      docElement.loadFromXMLContent(null, true);
    } catch (Exception ex) {
      fail("threw exception loading null element set to allow blanks");
    }

    //give null dont allow blanks
    try {
      docElement.loadFromXMLContent(null, false);
      fail("didn't throw InconsistentDocElementStateException " +
        "loaded with null element allowBlanks set to false");
    } catch (InconsistentDocElementStateException ex) {
    } catch (InvalidXmlException ex) {
      fail("didn't throw InconsistentDocElementStateException " +
        "loaded with null element allowBlanks set to false");
    }

    //give element of wrong type
    try {
      docElement.loadFromXMLContent(new Element("Imbad"), false);
      fail("Didn't throw InvalidXmlException when loaded with " + "element of the wrong type");
    } catch (InconsistentDocElementStateException ex) {
      fail("Didn't throw InvalidXmlException when loaded with " + "element of the wrong type");
    } catch (InvalidXmlException ex) {
    }
  }

  public Element makeStringElement(String xmlContent) {
    Document doc = null;

    try {
      doc = new Document(XmlHelper.buildJDocument(new StringReader(xmlContent), false)
                                  .getRootElement());
    } catch (InvalidXmlException ex) {
      fail("Generated invalid xml");
    }

    return doc.getRootElement();
  }
}





/*
 * Copyright 2003 The Trustees of Indiana University.  All rights reserved.
 *
 * This file is part of the EDEN software package.
 * For license information, see the LICENSE file in the top level directory
 * of the EDEN source distribution.
 */
