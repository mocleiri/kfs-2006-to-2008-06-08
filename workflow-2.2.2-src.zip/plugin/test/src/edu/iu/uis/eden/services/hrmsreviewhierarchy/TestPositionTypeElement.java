package edu.iu.uis.eden.services.hrmsreviewhierarchy;

import java.sql.SQLException;

import org.jdom.Element;

import edu.iu.uis.eden.WorkflowServiceErrorImpl;
import edu.iu.uis.eden.routemodules.hrmsreviewhierarchy.PositionTypeElement;
import edu.iu.uis.eden.routing.PositionTypeCodeEOK;
import edu.iu.uis.eden.services.IDocElement;
import edu.iu.uis.eden.services.ServiceErrorConstants;
import edu.iu.uis.eden.services.docelements.IDocInterfaceTestTemplate;


public class TestPositionTypeElement extends IDocInterfaceTestTemplate {
  private PositionTypeElement positionType;

  public TestPositionTypeElement(String s) {
    super(s);
  }

  protected void setUp() {
    try {
      positionType = new PositionTypeElement();
    } catch (SQLException e) {
      fail(e.getMessage());
    }
  }

  protected void tearDown() {
  }

  /**
   * for super class' Interface tests
   *
   * @return this test instance of IDocElement interface
   */
  public IDocElement getIDocElement() {
    return this.positionType;
  }

  /**
   * should be empty when instantiated not when a prop is set
   */
  public void testIsEmpty() {
    assertTrue("new instantiated object returning false on isEmpty()", this.positionType.isEmpty());

    //load a prop and test again
    this.positionType.setPositionType("LL");
    assertEquals("object with prop set returning true on isEmpty()", false,
      this.positionType.isEmpty());
  }

  /**
   * given a good element will this chap load his props correctly
   */
  public void testGetXMLContent() {
    //load the props
    String positionVal = "LL";
    this.positionType.setPositionType(positionVal);

    Element positionEl = positionType.getXMLContent();

    //check the element's contents
    assertEquals("didn't correctly make element from props", PositionTypeCodeEOK.POSITION_TYPE_EOK,
      positionEl.getName());

    Element innEl = positionEl.getChild(PositionTypeCodeEOK.POSITION_TYPE_CD);

    assertNotNull("didn't correctly make element from props", positionEl);

    //check the value
    assertEquals("didn't correctly make element from props", positionVal,
      innEl.getAttributeValue(PositionTypeCodeEOK.VALUE));
  }

  /**
   * yes it is
   */
  public void testIsRouteControl() {
    assertTrue("PositionType is a routeControl", this.positionType.isRouteControl());
  }

  public void testLoadFromXMLContent() {
    //this positionTypeEOK makes the valid XML so we'll use him
    PositionTypeCodeEOK positionTypeCodeEOK = null;
    String positionValue = "LL";

    try {
      positionTypeCodeEOK = new PositionTypeCodeEOK(positionValue, true);
    } catch (Exception ex) {
      fail("positionTypeCodeEOK threw exception loading");
    }

    try {
      this.positionType.loadFromXMLContent(positionTypeCodeEOK.buildJdom(), false);
    } catch (Exception ex) {
      fail("threw exception loading from valid element");
    }

    assertEquals("didn't properly load props from valid xml", positionValue,
      this.positionType.getPositionType());
  }

  /**
   * currently valid if has a value
   */
  public void testValidate() throws Exception {
    //should not be valid and should return the correct constant
    WorkflowServiceErrorImpl error = this.positionType.validate();
    assertNotNull("Blank positionType returned null on validate()", error);
    assertEquals("Blank positionType returned error of wrong type",
      ServiceErrorConstants.POSITION_TYPE_BLANK, error.getKey());

    //set a valid prop and recheck
    this.positionType.setPositionType("LL");
    assertNull("positionType with prop set didn't return null", this.positionType.validate());

    /* test with an invalid prop */
    this.positionType.setPositionType("YO");
    error = this.positionType.validate();
    assertEquals("invalid positionType returned error of wrong type",
      ServiceErrorConstants.POSITION_TYPE_INVALID, error.getKey());
  }
}





/*
 * Copyright 2003 The Trustees of Indiana University.  All rights reserved.
 *
 * This file is part of the EDEN software package.
 * For license information, see the LICENSE file in the top level directory
 * of the EDEN source distribution.
 */
