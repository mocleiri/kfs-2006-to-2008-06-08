package edu.iu.uis.eden.workgroup;

import java.util.Iterator;
import java.util.List;

import junit.framework.TestCase;
import edu.iu.uis.eden.SpringServiceLocator;
import edu.iu.uis.eden.user.UserService;
import edu.iu.uis.eden.user.WorkflowUser;
import edu.iu.uis.eden.user.WorkflowUserId;

public class WorkgroupServiceTest extends TestCase {
    
    public static final int CURRENT_NUMBER_OF_GROUPS = 37;
    
    private WorkflowGroupId groupId = new WorkflowGroupId(new Long(3121));
    private GroupNameId groupName = new GroupNameId("HRE Technical Team");
    private WorkflowUserId workflowUserId = new WorkflowUserId("100000000401");
    private WorkgroupService workgroupService;
    private UserService userService;

    protected void setUp() throws Exception {
        SpringServiceLocator.setToTestMode(null);
        workgroupService = (WorkgroupService) SpringServiceLocator.getService(SpringServiceLocator.WORKGROUP_SRV);
        userService = (UserService) SpringServiceLocator.getService(SpringServiceLocator.USER_SERVICE);
    }

    protected void tearDown() throws Exception {
        super.tearDown();
    }

    public void testGetWorkgroup() throws Exception {
        
        Workgroup workgroupById = workgroupService.getWorkgroup(groupId);
        Workgroup workgroupByName = workgroupService.getWorkgroup(groupName);
        
        assertNotNull(workgroupById);
        assertNotNull(workgroupByName);
        
        assertEquals("Didn't fetch the same workgroup", workgroupById.getWorkflowGroupId(), workgroupByName.getWorkflowGroupId());
        assertEquals("Didn't fetch the same workgroup", workgroupById.getGroupNameId(), workgroupByName.getGroupNameId());
        verifyMembersWorkflowUsers(workgroupById);
        verifyMembersWorkflowUsers(workgroupByName);
    }

    public void testGetUsersGroups() throws Exception {
        
        WorkflowUser user = userService.getWorkflowUser(workflowUserId);
        List groups = workgroupService.getUsersGroups(user);
        
        assertEquals("Didn't return correct number of groups", CURRENT_NUMBER_OF_GROUPS, groups.size());
        for (Iterator iter = groups.iterator(); iter.hasNext();) {
            verifyMembersWorkflowUsers((Workgroup) iter.next());
        }
    }

    public void testSearch() throws Exception {
        
        Workgroup workgroup = workgroupService.getWorkgroup(groupId);
        List groups = workgroupService.search(workgroup, false);
        
        boolean found = false;
        for (Iterator iter = groups.iterator(); iter.hasNext();) {
            Workgroup foundGroup = (Workgroup) iter.next();
            if (foundGroup.getWorkflowGroupId().equals(workgroup.getWorkflowGroupId())) {
                found = true;
            }
            verifyMembersWorkflowUsers(foundGroup);
        }
        
        assertTrue("Didn't find correct group", found);
        assertEquals("Returned more than object group", 1, groups.size());
    }

    public void testIsUserMemberOfGroup() throws Exception {
        
        WorkflowUser member = userService.getWorkflowUser(workflowUserId);
        assertTrue("IsUserMemberOfGroup didn't return true", workgroupService.isUserMemberOfGroup(groupId, member));
    }
    
    private void verifyMembersWorkflowUsers(Workgroup workgroup) {
        assertTrue("Workgroup must have member(s)", workgroup.getMembers().size() > 0);
        for (Iterator iter = workgroup.getMembers().iterator(); iter.hasNext();) {
            assertTrue("WorkflowUser not used as group member", iter.next() instanceof WorkflowUser);
        }
    }
}