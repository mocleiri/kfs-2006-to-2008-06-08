package edu.iu.uis.eden.lookupable;

import java.lang.reflect.Field;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import junit.framework.TestCase;
import edu.iu.uis.eden.SpringServiceLocator;
import edu.iu.uis.eden.plugin.attributes.WorkflowLookupable;
import edu.iu.uis.eden.user.web.WebWorkflowUser;


public class UserLookupableImplTestPENDING extends TestCase {
    private WorkflowLookupable workflowLookupable;
    private Map fieldValues;
    private Map conversionFields;

    protected void setUp() throws Exception {
        SpringServiceLocator.setToTestMode(null);
        workflowLookupable = new UserLookupableImpl();

        fieldValues = new HashMap();
        fieldValues.put("lastName", "hopf");
        fieldValues.put("firstName", "jeremy");

        conversionFields = new HashMap();
        conversionFields.put("networkId", "test_networkId");
    }

    public void testGetSearchResults() throws Exception {
        List results = workflowLookupable.getSearchResults(fieldValues, conversionFields);
        assertEquals("Too many results listed.", 1, results.size());
        WebWorkflowUser user = (WebWorkflowUser) results.get(0);

        assertEquals("AuthenticationId is incorrect.", "jhopf", user.getAuthenticationUserId().getAuthenticationId());
        assertEquals("Display Name is incorrect.", "Jeremy R Hopf", user.getDisplayName());
        assertTrue("Return parameter networkId is not correct.", user.getReturnUrl().indexOf("test_networkId=jhopf") > 0);

        
        Map fieldValues2 = new HashMap();
        fieldValues2.put("networkId", "rkirkend");

        WorkflowLookupable workflowLookupable2 = new UserLookupableImpl();
        
        List results2 = workflowLookupable2.getSearchResults(fieldValues2, new HashMap());
        assertEquals("Too many results listed.", 1, results2.size());
        WebWorkflowUser user2 = (WebWorkflowUser) results2.get(0);

        assertEquals("AuthenticationId is incorrect.", "rkirkend", user2.getAuthenticationUserId().getAuthenticationId());
        assertEquals("Display Name is incorrect.", "Ryan Andrew Kirkendall", user2.getDisplayName());
        assertTrue("Return parameter approver is not correct.", user2.getReturnUrl().indexOf("approver=rkirkend") > 0);
    }

    public void testGetColumns() {
        for (Iterator iter = workflowLookupable.getColumns().iterator(); iter.hasNext();) {
            Column column = (Column) iter.next();
            try {
                if(column.getPropertyName().equals("authenticationUserId.authenticationId")){
                    column.setPropertyName("authenticationId");
                }
                Field field = WebWorkflowUser.class.getDeclaredField(column.getPropertyName());
            } catch (NoSuchFieldException e) {
                assertTrue("Column property name on UserLookupableImpl does not equal a property on the WebWorkflowUser bean. Column: "+column.getPropertyName(), false);                
            }
        }
    }
    
    public void testGetNoReturnParams() {
        String parameters = workflowLookupable.getNoReturnParams(conversionFields);
        assertTrue("Return parameter networkId is not correct.", parameters.indexOf("test_networkId=") > 0);
    }
}
