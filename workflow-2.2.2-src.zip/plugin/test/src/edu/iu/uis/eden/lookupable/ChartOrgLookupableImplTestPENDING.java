package edu.iu.uis.eden.lookupable;

import java.lang.reflect.Field;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import junit.framework.TestCase;
import edu.iu.uis.eden.SpringServiceLocator;
//import edu.iu.uis.eden.fiscalorg.FiscalOrganization;
import edu.iu.uis.eden.plugin.attributes.WorkflowLookupable;

public class ChartOrgLookupableImplTestPENDING extends TestCase {
    private WorkflowLookupable workflowLookupable;
    private Map fieldValues;
    private Map conversionFields;

    protected void setUp() throws Exception {
        SpringServiceLocator.setToTestMode(null);
        workflowLookupable = new ChartOrgLookupableImpl();

        fieldValues = new HashMap();
        fieldValues.put("fin_coa_cd", "BL");
        fieldValues.put("org_cd", "BL");

        conversionFields = new HashMap();
        conversionFields.put("fin_coa_cd", "test_fin_coa_cd");
        conversionFields.put("org_cd", "test_org_cd");
    }

    public void testGetSearchResults() throws Exception {
        List results = workflowLookupable.getSearchResults(fieldValues, conversionFields);
        assertEquals("Too many results listed.", 1, results.size());
        /*FiscalOrganization orgRecord = (FiscalOrganization) results.get(0);

        assertEquals("Chart value is incorrect.", "BL", orgRecord.getFinCoaCd());
        assertEquals("Org Code value is incorrect.", "BL", orgRecord.getOrgCd());
        assertEquals("Org name is incorrect.", "BLOOMINGTON CAMPUS", orgRecord.getOrganizationName());
        assertTrue("Return parameter chart not correct.", orgRecord.getReturnUrl().indexOf("test_fin_coa_cd=BL") > 0);
        assertTrue("Return parameter org not correct.", orgRecord.getReturnUrl().indexOf("test_org_cd=BL") > 0);*/

    }

    public void testGetColumns() {
        for (Iterator iter = workflowLookupable.getColumns().iterator(); iter.hasNext();) {
            Column column = (Column) iter.next();
            /*try {
                Field field = FiscalOrganization.class.getDeclaredField(column.getPropertyName());
            } catch (NoSuchFieldException e) {
                assertTrue("Column property name on ChartOrgLookupableImpl does not equal a property on the FiscalOrganization bean.", false);                
            }*/
        }
    }
    
    public void testGetNoReturnParams() {
        String parameters = workflowLookupable.getNoReturnParams(conversionFields);

        assertTrue("Return parameter chart not correct.", parameters.indexOf("test_fin_coa_cd=") > 0);
        assertTrue("Return parameter org not correct.", parameters.indexOf("test_org_cd=") > 0);
    }
}