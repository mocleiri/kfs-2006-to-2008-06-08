package edu.iu.uis.eden.services;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;

import junit.framework.TestCase;
import edu.iu.uis.eden.WorkflowServiceError;
import edu.iu.uis.eden.WorkflowServiceErrorImpl;


public class TestDocElementError extends TestCase {
  private WorkflowServiceError busError;

  public TestDocElementError(String s) {
    super(s);
  }

  protected void setUp() {
    busError = new WorkflowServiceErrorImpl("message", "0");
  }

  protected void tearDown() {
  }

  /**
   * test that what goes in constructor comes out
   */
  public void testConstructor() {
    String message = "message";
    String type = "1";
    WorkflowServiceError busError = new WorkflowServiceErrorImpl(message, type);
    assertEquals("Message was altered during construction or getting", message,
      busError.getMessage());
    assertEquals("type was altered during construction or getting", type, busError.getKey());
  }

  /**
   * test that when we add a list of children they are added.  Use
   * default DocElementError made in setup.
   */
  public void testAddChildren() {
    //make a list of kiddie DocElementErrors
    ArrayList kiddies = new ArrayList();
    kiddies.add(new WorkflowServiceErrorImpl("a message", "1"));
    kiddies.add(new WorkflowServiceErrorImpl("a message", "2"));

    //add the kiddies
    busError.addChildren(kiddies);
    assertEquals("Wrong number of children DocElementErrors", 2, busError.getChildren().size());
  }

  /**
   * test that if I add a child it's in the list
   */
  public void testAddChild() {
    WorkflowServiceError errorChild = new WorkflowServiceErrorImpl("childMessage", "3");
    busError.addChild(errorChild);

    ArrayList kiddies = (ArrayList) busError.getChildren();

    //Iterate the list the one DocElementError in there should be errorChild
    Iterator iter = kiddies.iterator();

    while (iter.hasNext()) {
      Object item = (WorkflowServiceErrorImpl) iter.next();
      assertEquals("Child placed in DocElementError was not retrieved", errorChild, item);
    }
  }

  /**
   * test that a tree is properly flatenned
   */
  public void testGetFlatChildrenList() {
    WorkflowServiceErrorImpl error = new WorkflowServiceErrorImpl("parent", ServiceErrorConstants.CHILDREN_IN_ERROR);

    WorkflowServiceErrorImpl errorChild1 = new WorkflowServiceErrorImpl("child1",
        ServiceErrorConstants.ACTIVE_INDICATOR_NAN);
    WorkflowServiceErrorImpl errorChild11 = new WorkflowServiceErrorImpl("child11",
        ServiceErrorConstants.ACTION_REQUESTED_BLANK);

    errorChild1.addChild(errorChild11);
    error.addChild(new WorkflowServiceErrorImpl("child2", ServiceErrorConstants.DATE_BEFORE_NOW));
    error.addChild(errorChild1);

    Collection flatList = error.getFlatChildrenList();
    Iterator iter = flatList.iterator();
    int i = 0;

    while (iter.hasNext()) {
      i++;

      WorkflowServiceErrorImpl daError = (WorkflowServiceErrorImpl) iter.next();
      System.out.println(daError.getMessage() + " " + i);
    }

    assertEquals("didn't flatten error tree correctly", 3, error.getFlatChildrenList().size());
  }
}





/*
 * Copyright 2003 The Trustees of Indiana University.  All rights reserved.
 *
 * This file is part of the EDEN software package.
 * For license information, see the LICENSE file in the top level directory
 * of the EDEN source distribution.
 */
