package edu.iu.uis.eden.services.docelements;

import edu.iu.uis.eden.services.IDocElement;


/**
 *
 * <p>Title: TestDescriptionElement</p>
 * <p>Description: Just about everything in the DescriptionElement test
 * is covered in the Test for generic String</p>
 * <p>Copyright: Copyright (c) 2002</p>
 * <p>Company: Indiana University</p>
 * @author Ryan Kirkendall
 * @version 1.0
 */
public class TestDescriptionElement extends IDocInterfaceTestTemplate {
  private DescriptionElement description;

  public TestDescriptionElement(String s) {
    super(s);
  }

  protected void setUp() {
    description = new DescriptionElement();
  }

  protected void tearDown() {
  }

  public IDocElement getIDocElement() {
    return this.description;
  }

  /**
   * no it isn't
   */
  public void testIsRouteControl() {
    assertEquals("Description element is not a routeControl", false,
      this.description.isRouteControl());

    //try to set true and retest
    this.description.setRouteControl(true);
    assertEquals("Description element is not a routeControl", false,
      this.description.isRouteControl());
  }

  /**
   * always valid
   */
  public void testValidate() {
    try {
      assertNull("Description element is always valid", this.description.validate());

      //set and recheck
      this.description.setDescription("a description");
      assertNull("Description element is always valid", this.description.validate());
    } catch (Exception ex) {
      fail("threw exception validating");
    }
  }
}





/*
 * Copyright 2003 The Trustees of Indiana University.  All rights reserved.
 *
 * This file is part of the EDEN software package.
 * For license information, see the LICENSE file in the top level directory
 * of the EDEN source distribution.
 */
