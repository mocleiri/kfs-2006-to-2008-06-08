package edu.iu.uis.eden.services.docelements;

import junit.framework.TestCase;

import org.jdom.Element;

import edu.iu.uis.eden.EdenConstants;
import edu.iu.uis.eden.WorkflowServiceErrorImpl;
import edu.iu.uis.eden.exception.InvalidXmlException;
import edu.iu.uis.eden.services.IDocElement;
import edu.iu.uis.eden.services.InconsistentDocElementStateException;
import edu.iu.uis.eden.services.ServiceErrorConstants;


public class TestPartyTypeElement extends TestCase {
  private PartyTypeElement partyTypeEl = new PartyTypeElement();

  public TestPartyTypeElement(String s) {
    super(s);
  }

  protected void setUp() {
    partyTypeEl = new PartyTypeElement();
    partyTypeEl.setPartyType("U");
  }

  protected void tearDown() {
  }

  /**
   * given a jdom element of the correct type it should load itself to the value
   * of the given jdom element
   *
   * if the jdom element is null and allowBlanks true it should return
   *
   * if the jdom element is null and allowBlanks is false its should throw
   * an InconsistentDocElementStateException
   *
   * if the element is of the incorrect type it should throw an
   * InvalidXmlException
   */
  public void testLoadFromXMLContent() {
    PartyTypeElement partyType = new PartyTypeElement();
    String partyVal = "U";

    //make a good element and load
    Element partyEl = new Element(partyType.getElementName());
    partyEl.setAttribute("value", partyVal);

    try {
      partyType.loadFromXMLContent(partyEl, false);
      assertEquals("didn't properly load props from valid element", partyVal,
        partyType.getPartyType());
    } catch (Exception ex) {
      fail("loaded with good element and threw exception");
    }

    nonClassSpecificLoadFromXMLTests(partyType);
  }

  /**
   * if props are blank or null a DocElementError should return otherwise
   * null should
   */
  public void testValidate() {
    try {
      //test the good default PartTypeElement
      assertNull("DocElementError returned on valid object", partyTypeEl.validate());

      /* that was user now set for workgroup */
      this.partyTypeEl.setPartyType("W");
      assertNull("PartyTypeElement returning error on valid object set to " + "workgroup",
        partyTypeEl.validate());

      //make and test a bad dude
      partyTypeEl = new PartyTypeElement();

      WorkflowServiceErrorImpl error = (WorkflowServiceErrorImpl) partyTypeEl.validate();
      assertNotNull("Null returned on invalid object", partyTypeEl.validate());

      //set partType to blank and retest
      partyTypeEl.setPartyType("");
      assertNotNull("Null returned on invalid object", partyTypeEl.validate());

      /* test that only the proper constants are valid */
      this.partyTypeEl.setPartyType(EdenConstants.ACTION_REQUEST_USER_RECIPIENT_CD);
      error = this.partyTypeEl.validate();
      assertNull("returning error object on valid partyType", error);

      this.partyTypeEl.setPartyType("X"); //this is bad
      error = this.partyTypeEl.validate();
      assertEquals("incorrect type assigned to partyType w/ invalid " + "value",
        ServiceErrorConstants.PARTY_TYPE_INVALID, error.getKey());
    } catch (Exception ex) {
      fail("threw exception validating");
    }
  }

  /**
   * this is not a route control according to bus rules
   */
  public void testIsRouteControl() {
    assertEquals("Party Type Element is not a routeControl", false, partyTypeEl.isRouteControl());
  }

  public void testGetXMLContent() {
    partyTypeEl.setPartyType("U");
    assertNotNull("Loaded partyType returned null", partyTypeEl.getXMLContent());
  }

  /**
   * can the object load from the same xml in generates and arrive at the same
   * property value
   */
  public void testFeedFromOwnXML() {
    Element xmlContent = partyTypeEl.getXMLContent();
    PartyTypeElement aPartyType = new PartyTypeElement();

    try {
      aPartyType.loadFromXMLContent(xmlContent, false);
    } catch (Exception ex) {
      fail("XML generated from OrgCodeElement invalid could not be loaded " + "by itself");
    }

    assertEquals("OrgCodeElement could not find value from XML it generated", "U",
      aPartyType.getPartyType());
  }

  public void nonClassSpecificLoadFromXMLTests(IDocElement docElement) {
    //give null allow blanks
    try {
      docElement.loadFromXMLContent(null, true);
    } catch (Exception ex) {
      fail("threw exception loading null element set to allow blanks");
    }

    //give null dont allow blanks
    try {
      docElement.loadFromXMLContent(null, false);
      fail("didn't throw InconsistentDocElementStateException " +
        "loaded with null element allowBlanks set to false");
    } catch (InconsistentDocElementStateException ex) {
    } catch (InvalidXmlException ex) {
      fail("didn't throw InconsistentDocElementStateException " +
        "loaded with null element allowBlanks set to false");
    }

    //give element of wrong type
    try {
      docElement.loadFromXMLContent(new Element("Imbad"), false);
      fail("Didn't throw InvalidXmlException when loaded with " + "element of the wrong type");
    } catch (InconsistentDocElementStateException ex) {
      fail("Didn't throw InvalidXmlException when loaded with " + "element of the wrong type");
    } catch (InvalidXmlException ex) {
    }
  }

  /**
   * we should be converting to the ultimately valid caps
   */
  public void testCaseInsensitivity() {
    this.partyTypeEl.setPartyType("u");
    assertEquals("PartyType not setting itself to all caps", "U", this.partyTypeEl.getPartyType());
  }

  /**
   * set to a workgroup isWorkGroup() should be true the same goes for
   * user.  They are mutually exclusive.
   */
  public void testIsStateDescriptors() {
    this.partyTypeEl.setPartyType("u");
    assertTrue("PartyType set to user is not reporting it isUser()", this.partyTypeEl.isUser());
    assertEquals("PartyType reporting (correctly) isUser() is reporting " + "isWorkGroup()", false,
      this.partyTypeEl.isWorkGroup());

    /* try again with workgroup */
    this.partyTypeEl.setPartyType("w");
    assertTrue("PartyType set to workgroup is not reporting it isWorkGroup()",
      this.partyTypeEl.isWorkGroup());
    assertEquals("PartyType reporting (correctly) isWorkGroup() is reporting " + "isUser()", false,
      this.partyTypeEl.isUser());

    /* set to bogus they should be be false */
    this.partyTypeEl.setPartyType("bogus dude");
    assertEquals("PartyType set to bogus is reporting true on isWorkGroup()", false,
      this.partyTypeEl.isWorkGroup());
    assertEquals("PartyType set to bogus is reporting true on isUser()", false,
      this.partyTypeEl.isUser());
  }
}





/*
 * Copyright 2003 The Trustees of Indiana University.  All rights reserved.
 *
 * This file is part of the EDEN software package.
 * For license information, see the LICENSE file in the top level directory
 * of the EDEN source distribution.
 */
