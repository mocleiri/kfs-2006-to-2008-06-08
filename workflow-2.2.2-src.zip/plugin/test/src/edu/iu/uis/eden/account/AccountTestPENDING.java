
package edu.iu.uis.eden.account;

import java.util.Iterator;

import edu.iu.uis.eden.SpringServiceLocator;
import edu.iu.uis.eden.test.WorkflowTestCase;
import edu.iu.uis.eden.user.UserService;


public class AccountTestPENDING extends WorkflowTestCase {

	private AccountService accountService;
	private UserService userService;
	
	protected void setUpTransaction() throws Exception {
	    super.setUpTransaction();
		//SpringServiceLocator.setToTestMode(null);
		userService = (UserService) SpringServiceLocator
				.getService(SpringServiceLocator.USER_SERVICE);
		//accountService = (AccountService) SpringServiceLocator
		//		.getService(SpringServiceLocator.ACCOUNT_SERVICE);
	}
	
//	public void testHitAllAccounts() throws Exception {
//		List accounts = accountService.getAllAccounts();
//		System.out.println(accounts.size() + " accounts retrieved");
//		Set usersNotFound = new HashSet();
//		for (Iterator iter = accounts.iterator(); iter.hasNext();) {
//			Account account = (Account) iter.next();
//			try {
//				WorkflowUser user = userService.getWorkflowUser(new IUUserId(IUUserId.UUID, account.getFiscalOfficerUnvlId()));
//				if (user == null
//						|| user.getWorkflowUserId() == null
//						|| user.getWorkflowUserId().getWorkflowId() == null
//						|| user.getWorkflowUserId().getWorkflowId().length() < 1) {
//					usersNotFound.add(account.getFiscalOfficerUnvlId());
//				}
//			} catch (Throwable e) {
//				usersNotFound.add(account.getFiscalOfficerUnvlId());
//			}
//		}
//		System.out.println("listing users not found");
//		for (Iterator iter = usersNotFound.iterator(); iter.hasNext();) {
//			String uuid = (String) iter.next();
//			System.out.println(uuid);
//		}
//	}
	
	public void testFetchAccount() throws Exception {
		Account account = accountService.findByChartAccount("UA","1912610");
		for (Iterator iter = account.getAccountDelegations().iterator(); iter.hasNext();) {
			AccountDelegation delegation = (AccountDelegation) iter.next();
			System.out.println("delegation: "+delegation.getFdocTypCd());
			
		}
		assertNotNull(account);
	}
	

}
