package edu.iu.uis.eden.lookupable;

import java.lang.reflect.Field;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import junit.framework.TestCase;
import edu.iu.uis.eden.SpringServiceLocator;
import edu.iu.uis.eden.fiscalsub.FiscalSubAccount;
import edu.iu.uis.eden.plugin.attributes.WorkflowLookupable;


public class SubAccountLookupableImplTestPENDING extends TestCase {
    private WorkflowLookupable workflowLookupable;
    private Map conversionFields;

    protected void setUp() throws Exception {
        SpringServiceLocator.setToTestMode(null);
        workflowLookupable = new SubAccountLookupableImpl();

        conversionFields = new HashMap();
        conversionFields.put("fin_coa_cd", "test_fin_coa_cd");
    }

    public void testGetColumns() {
        for (Iterator iter = workflowLookupable.getColumns().iterator(); iter.hasNext();) {
            Column column = (Column) iter.next();
            try {
                Field field = FiscalSubAccount.class.getDeclaredField(column.getPropertyName());
            } catch (NoSuchFieldException e) {
                assertTrue("Column property name on SubAccountLookupableImpl does not equal a property on the FiscalSubAccount bean. Column: "+column.getPropertyName(), false);                
            }
        }
    }
    
    public void testGetNoReturnParams() {
        String parameters = workflowLookupable.getNoReturnParams(conversionFields);

        assertTrue("Return parameter chart is not correct.", parameters.indexOf("test_fin_coa_cd=") > 0);
        assertTrue("Return parameter account is not correct.", parameters.indexOf("account_nbr=") > 0);
        assertTrue("Return parameter subaccount is not correct.", parameters.indexOf("sub_acct_nbr=") > 0);
    }
}
