package edu.iu.uis.eden.services.docelements;

import org.jdom.Element;

import edu.iu.uis.eden.WorkflowServiceErrorImpl;
import edu.iu.uis.eden.services.IDocElement;
import edu.iu.uis.eden.services.ServiceErrorConstants;


public class TestRuleIdElement extends IDocInterfaceTestTemplate {
  private RuleIdElement ruleId;

  public TestRuleIdElement(String s) {
    super(s);
  }

  protected void setUp() {
    ruleId = new RuleIdElement();
  }

  protected void tearDown() {
  }

  public IDocElement getIDocElement() {
    return this.ruleId;
  }

  /**
   * set a value get the xml and load another ruleIdElement from that it shouldn't
   * throw exceptions and it should have the same value.
   */
  public void testLoadFromXMLContent() {
    long valueToTest = 1;
    this.ruleId.setRuleId(valueToTest);

    Element element = this.ruleId.getXMLContent();

    RuleIdElement aruleId = new RuleIdElement();

    try {
      aruleId.loadFromXMLContent(element, false);
      assertEquals("didn't properly load props from self generated xml", valueToTest,
        aruleId.getRuleId());
    } catch (Exception ex) {
      fail("threw exception loading from self generated XML");
    }
  }

  /**
   * when empty it shoul come back w/ the correct type
   */
  public void testValidate() {
    try {
      WorkflowServiceErrorImpl err = this.ruleId.validate();
      assertEquals("DocElementError returning incorrect Error Constant",
        ServiceErrorConstants.RULE_ID_BLANK, err.getKey());

      //load with value shouldn't return an error on validate
      this.ruleId.setRuleId(1);
      assertNull("Valid object returned error", this.ruleId.validate());
    } catch (Exception ex) {
      fail("threw exception validating");
    }
  }

  /**
   * no it's not
   */
  public void testIsRouteControl() {
    assertEquals("ruleId is not a route control", false, this.ruleId.isRouteControl());

    //try to set and retest
    this.ruleId.setRouteControl(true);
    assertEquals("ruleId allows routeControl to be set true", false, this.ruleId.isRouteControl());
  }

  /**
   * just check that the correct root element is being returned
   * GenericLongElement guarantees the rest
   */
  public void testGetXMLContent() {
    this.ruleId.setRuleId(1);

    //check the root tag name
    Element element = this.ruleId.getXMLContent();
    assertEquals("ruleId Element is the wrong name", this.ruleId.getElementName(), element.getName());
  }
}





/*
 * Copyright 2003 The Trustees of Indiana University.  All rights reserved.
 *
 * This file is part of the EDEN software package.
 * For license information, see the LICENSE file in the top level directory
 * of the EDEN source distribution.
 */
