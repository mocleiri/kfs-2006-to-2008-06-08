package edu.iu.uis.eden.fiscalupaadelegation;

import java.sql.Timestamp;
import java.util.Collection;
import java.util.Date;

import junit.framework.TestCase;
import edu.iu.uis.eden.SpringServiceLocator;
//import edu.iu.uis.eden.routemodules.fiscaluppadelegation.FiscalUpaaDelegation;
//import edu.iu.uis.eden.routemodules.fiscaluppadelegation.FiscalUpaaDelegationService;

public class TestFiscalUpaaDelegationServicePENDING extends TestCase {

    /*private String userName = "rkirkend";

    private FiscalUpaaDelegation fiscUpaaDel;
    private FiscalUpaaDelegation fiscUpaaDel2;
    private FiscalUpaaDelegation fiscUpaaDel3;

    protected void setUp() {
        SpringServiceLocator.setToTestMode(null);        
        fiscUpaaDel = new FiscalUpaaDelegation();
        fiscUpaaDel.setFiscalUpaaCd("U");
        fiscUpaaDel.setActiveInd("Y");
        fiscUpaaDel.setFinCoaCd("UA");
        fiscUpaaDel.setFromDate(new Timestamp(new Date().getTime() - 10000));
        fiscUpaaDel.setToDate(new Timestamp(new Date().getTime() + 10000));
        fiscUpaaDel.setOrgCd("BUDU");
        fiscUpaaDel.setDelegateTypeCd("U");
        fiscUpaaDel.setResponsibilityId(new Long(1));
        fiscUpaaDel.setRuleId(new Long(1));
        fiscUpaaDel.setWorkflowId(this.userName);
        fiscUpaaDel.setPositionType("SB");
        fiscUpaaDel.setDelegateWorkgroupId(null);
        
        this.getFiscalUpaaDelegationService().save(fiscUpaaDel);

        fiscUpaaDel2 = new FiscalUpaaDelegation();
        fiscUpaaDel2.setFiscalUpaaCd("A");
        fiscUpaaDel2.setActiveInd("Y");
        fiscUpaaDel2.setFinCoaCd("UA");
        fiscUpaaDel2.setFromDate(new Timestamp(new Date().getTime() - 10000));
        fiscUpaaDel2.setToDate(new Timestamp(new Date().getTime() + 10000));
        fiscUpaaDel2.setOrgCd("BDOT");
        fiscUpaaDel2.setDelegateTypeCd("W");
        fiscUpaaDel2.setResponsibilityId(new Long(2));
        fiscUpaaDel2.setRuleId(new Long(2));
        fiscUpaaDel2.setDelegateWorkgroupId(new Long(1));
        fiscUpaaDel2.setPositionType("SM");
        fiscUpaaDel2.setWorkflowId(null);
        
        this.getFiscalUpaaDelegationService().save(fiscUpaaDel2);

        fiscUpaaDel3 = new FiscalUpaaDelegation();
        fiscUpaaDel3.setFiscalUpaaCd("A");
        fiscUpaaDel3.setActiveInd("N");
        fiscUpaaDel3.setFinCoaCd("BL");
        fiscUpaaDel3.setFromDate(new Timestamp(new Date().getTime() - 10000));
        fiscUpaaDel3.setToDate(new Timestamp(new Date().getTime() + 10000));
        fiscUpaaDel3.setOrgCd("BL");
        fiscUpaaDel3.setDelegateTypeCd("U");
        fiscUpaaDel3.setResponsibilityId(new Long(3));
        fiscUpaaDel3.setRuleId(new Long(3));
        fiscUpaaDel3.setWorkflowId(this.userName);
        fiscUpaaDel3.setPositionType("HR");
        fiscUpaaDel3.setDelegateWorkgroupId(null);
        
        this.getFiscalUpaaDelegationService().save(fiscUpaaDel3);
    }

    protected void tearDown() throws Exception {
        this.getFiscalUpaaDelegationService().delete(fiscUpaaDel);
        this.getFiscalUpaaDelegationService().delete(fiscUpaaDel2);
        this.getFiscalUpaaDelegationService().delete(fiscUpaaDel3);

        fiscUpaaDel = this.getFiscalUpaaDelegationService().findByRuleId(fiscUpaaDel.getRuleId());
        fiscUpaaDel2 = this.getFiscalUpaaDelegationService().findByRuleId(fiscUpaaDel2.getRuleId());
        fiscUpaaDel3 = this.getFiscalUpaaDelegationService().findByRuleId(fiscUpaaDel3.getRuleId());

        if (fiscUpaaDel != null || fiscUpaaDel2 != null || fiscUpaaDel3 != null) {
            throw new Exception("The fiscal upaa delegation data has not been deleted from the database");
        }
    }

    public void testFindByResponsibilityIdPosType() throws Exception {
        Collection fiscalUpaaDelegations = this.getFiscalUpaaDelegationService().findByResponsibilityIdPosType(fiscUpaaDel.getResponsibilityId(), fiscUpaaDel.getPositionType());
        assertFalse("Database rows were not retrieved for responsibility id and position type", fiscalUpaaDelegations.isEmpty());
        assertFalse("Too many database rows returned for responsibility id and position type", fiscalUpaaDelegations.size() > 1);
        assertEquals("Wrong database row retrieved for responsibility id and position type", fiscUpaaDel.getOrgCd(), ((FiscalUpaaDelegation) fiscalUpaaDelegations.iterator().next()).getOrgCd());
    }

    public void testFindByRuleId() throws Exception {
        FiscalUpaaDelegation fiscUpaaDel4 = this.getFiscalUpaaDelegationService().findByRuleId(fiscUpaaDel2.getRuleId());
        assertNotNull("A fiscal upaa delegation database row was not retrieved for rule id", fiscUpaaDel4);
        assertEquals("Wrong database row retrieved for rule id", fiscUpaaDel2.getOrgCd(), fiscUpaaDel4.getOrgCd());
    }

    public void testNarrowingFind() throws Exception {
        Collection fiscalUpaaDelegations = this.getFiscalUpaaDelegationService().narrowingFind(fiscUpaaDel3);
        assertFalse("Database rows were not retrieved for narrowing find", fiscalUpaaDelegations.isEmpty());
        assertFalse("Too many database rows returned for narrowing find", fiscalUpaaDelegations.size() > 1);
        assertEquals("Wrong database row retrieved for narrowing find", fiscUpaaDel3.getOrgCd(), ((FiscalUpaaDelegation) fiscalUpaaDelegations.iterator().next()).getOrgCd());
    }

    private FiscalUpaaDelegationService getFiscalUpaaDelegationService() {
        return (FiscalUpaaDelegationService) SpringServiceLocator.getService(SpringServiceLocator.FISCAL_UPAA_DELEGATION_SRV);
    }*/

}

/*
 * Copyright 2003 The Trustees of Indiana University. All rights reserved. This file is part of the EDEN software package. For license information, see the LICENSE file in the top level directory of the EDEN source distribution.
 */
