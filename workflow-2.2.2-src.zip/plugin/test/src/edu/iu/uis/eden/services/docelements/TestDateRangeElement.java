package edu.iu.uis.eden.services.docelements;

import java.util.Date;

import org.jdom.Element;

import edu.iu.uis.eden.WorkflowServiceErrorImpl;
import edu.iu.uis.eden.exception.InvalidXmlException;
import edu.iu.uis.eden.services.IDocElement;
import edu.iu.uis.eden.services.InconsistentDocElementStateException;
import edu.iu.uis.eden.services.ServiceErrorConstants;


public class TestDateRangeElement extends IDocInterfaceTestTemplate {
  private DateRangeElement dateRange;

  public TestDateRangeElement(String s) {
    super(s);
  }

  protected void setUp() {
    dateRange = new DateRangeElement();
  }

  protected void tearDown() {
  }

  public IDocElement getIDocElement() {
    return dateRange;
  }

  /**
   * with no props loaded should be empty (i.e. instantiation)
   *
   * with any prop loaded it's not empty
   */
  public void testIsEmpty() {
    assertTrue("Empty DateRangeElement returning false on isEmpty", this.dateRange.isEmpty());

    //load it with a prop and retest
    dateRange.setFromDate(new Date());
    assertEquals("Loaded DateRange returned true on isEmpty", false, dateRange.isEmpty());
  }

  /**
   * check that it's picking up missing kids and is not allowing
   * a from date that is after a todate
   */
  public void testValidate() {
    try {
      //test blank
      assertNotNull("empty Date Range is reporting valid", dateRange.validate());

      //load with a date
      WorkflowServiceErrorImpl error = dateRange.validate();
      dateRange.setFromDate(new Date());
      assertNotNull("Date Range with just from date set is reporting valid", error);

      //is the error of the correct type
      assertEquals("blank from date reporting wrong error",
        ServiceErrorConstants.CHILDREN_IN_ERROR, error.getKey());

      //just to date
      dateRange.setFromDate(null);
      dateRange.setToDate(new Date());
      error = dateRange.validate();
      assertNotNull("Date Range with just to date set is reporting valid", error);

      //is the error of the correct type
      assertEquals("blank from date reporting wrong error",
        ServiceErrorConstants.CHILDREN_IN_ERROR, error.getKey());

      //set both but to before from
      dateRange.setToDate(new Date());
      dateRange.setFromDate(new Date(new Date().getTime() + 10000));
      error = dateRange.validate();
      assertNotNull("Date Range with to date set before from date is " + "reporting valid", error);

      //is the error of the correct type
      assertEquals("invalid date range reporting wrong error",
        ServiceErrorConstants.DATE_RANGE_INVALID, error.getKey());

      //test the valid scenary
      dateRange.setToDate(new Date());
      dateRange.setFromDate(new Date(new Date().getTime() - 1000000));
      assertNull("valid date range reporting error", dateRange.validate());

      //no date can be before now let's try
      dateRange.setToDate(new Date(new Date().getTime() - 100000));
      error = dateRange.validate();
      assertEquals("to date before now returned incorrect to date",
        ServiceErrorConstants.CHILDREN_IN_ERROR, error.getKey());
    } catch (Exception ex) {
      fail("threw exception validating");
    }
  }

  /**
   * loaded and unload does date range give back the correct xml
   */
  public void testGetXMLContent() {
    //nothing loaded should give us null
    super.testGetXMLContent();

    //load with a to Date should have a to Date wrapper
    dateRange.setToDate(new Date());

    Element dateRangeEl = dateRange.getXMLContent();
    Element toDateWrapper = dateRangeEl.getChild("toDate");
    assertEquals("date range loaded with to date didn't return valid " + "toDate element",
      "toDate", toDateWrapper.getName());

    //load with from date and check for wrapper
    dateRange.setFromDate(new Date());
    dateRangeEl = dateRange.getXMLContent();

    Element fromDateWrapper = dateRangeEl.getChild("fromDate");
    assertEquals("date range load with from date didn't return valid " + "fromDate element",
      "fromDate", fromDateWrapper.getName());
  }

  /**
   * given a root element with just a from date wrapper and just a
   * toDate wrapper element we should get just those poperties
   *
   * if we give wrappers that are not what they should be we should
   * get and invalidxmlexception
   */
  public void testLoadFromXMLContent() {
    //make a root with just a toDate
    Element element = new Element(dateRange.getElementName());
    Element toDateWrapper = new Element("toDate");
    Element nowDateWrapper = new Element("nowDate");
    DateElement nowDate = new DateElement();
    nowDate.setDate(new Date());
    nowDateWrapper.addContent(nowDate.getXMLContent());

    DateElement toDate = new DateElement();
    Date daDate = new Date();

    toDate.setDate(daDate);

    toDateWrapper.addContent(toDate.getXMLContent());
    element.addContent(toDateWrapper);
    element.addContent(nowDateWrapper);

    try {
      dateRange.loadFromXMLContent(element, true);
      assertEquals("didn't properly load props from valid element", daDate.getTime(),
        dateRange.getToDate().getTime());
    } catch (Exception ex) {
      fail("threw exception loading valid element with toDate element");
    }

    //load with but don't allow blanks
    try {
      dateRange.loadFromXMLContent(element, false);
      fail("incomplete dateRange didn't throw " +
        "InconsistentDocElementStateException when loading from " + "incomplete xml");
    } catch (InvalidXmlException ex) {
      fail("incomplete dateRange didn't throw " +
        "InconsistentDocElementStateException when loading from " + "incomplete xml");
    } catch (InconsistentDocElementStateException ex) {
    }

    //make a root with just fromDate
    element = new Element(dateRange.getElementName());

    Element fromDateWrapper = new Element("fromDate");
    DateElement fromDate = new DateElement();
    Date daFromDate = new Date();

    fromDate.setDate(daFromDate);

    fromDateWrapper.addContent(fromDate.getXMLContent());
    element.addContent(nowDateWrapper.detach());
    element.addContent(fromDateWrapper);

    try {
      dateRange.loadFromXMLContent(element, true);
      assertEquals("didn't properly load props from valid xml", daFromDate.getTime(),
        dateRange.getFromDate().getTime());
    } catch (Exception ex) {
      fail("threw exception loading from valid element with fromDate element");
    }

    //load but don't allow blanks
    try {
      dateRange.loadFromXMLContent(element, false);
      fail("incomplete dateRange didn't throw " +
        "InconsistentDocElementStateException when loading from " + "incomplete xml");
    } catch (InvalidXmlException ex) {
      fail("incomplete dateRange didn't throw " +
        "InconsistentDocElementStateException when loading from " + "incomplete xml");
    } catch (InconsistentDocElementStateException ex) {
    }
  }

  /**
   * set the dateRange values, make xml, load a new dateRange with those values
   * they should be the same.
   */
  public void testCanFeedOnOwnXML() {
    Date fromDate = new Date(new Date().getTime() - 10000000);
    Date toDate = new Date();

    dateRange.setFromDate(fromDate);
    dateRange.setToDate(toDate);

    Element dateRangeEl = dateRange.getXMLContent();

    DateRangeElement aDateRange = new DateRangeElement();

    try {
      aDateRange.loadFromXMLContent(dateRangeEl, false);
    } catch (Exception ex) {
      fail("threw exception loading from self generated element");
    }

    assertEquals("didn't properly load props from self generated element", toDate.getTime(),
      aDateRange.getToDate().getTime());

    assertEquals("didn't properly load props from self generated element", fromDate.getTime(),
      aDateRange.getFromDate().getTime());
  }
}





/*
 * Copyright 2003 The Trustees of Indiana University.  All rights reserved.
 *
 * This file is part of the EDEN software package.
 * For license information, see the LICENSE file in the top level directory
 * of the EDEN source distribution.
 */
