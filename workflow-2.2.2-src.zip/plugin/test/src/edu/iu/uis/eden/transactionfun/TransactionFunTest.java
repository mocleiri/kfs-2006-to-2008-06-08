package edu.iu.uis.eden.transactionfun;

import junit.framework.TestCase;
import edu.iu.uis.eden.SpringServiceLocator;

public class TransactionFunTest extends TestCase {

    protected void setUp() throws Exception {
        SpringServiceLocator.setToTestMode(null);
    }
    
    protected void tearDown() throws Exception {
        super.tearDown();
    }
    
    public void testdoIt() {
        new TransactionFun().doIt(true);
    }   
}