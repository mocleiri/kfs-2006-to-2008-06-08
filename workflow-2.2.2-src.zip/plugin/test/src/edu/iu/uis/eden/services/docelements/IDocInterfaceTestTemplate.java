package edu.iu.uis.eden.services.docelements;

import junit.framework.Assert;
import junit.framework.TestCase;

import org.jdom.Element;

import edu.iu.uis.eden.exception.InvalidXmlException;
import edu.iu.uis.eden.services.IDocElement;
import edu.iu.uis.eden.services.InconsistentDocElementStateException;


/**
 * <p>Title: TestIDocInterface</p>
 * <p>Description: To be extended by all classes implementing
 * the IDocElement Interface.  This will work the non-class specific
 * implementation of the interface, insuring consistent behavior
 * accross all classes.</p>
 * <p>Copyright: Copyright (c) 2002</p>
 * <p>Company: Indiana University</p>
 * @author Ryan Kirkendall
 * @version 1.0
 */
public abstract class IDocInterfaceTestTemplate extends TestCase {
  public IDocInterfaceTestTemplate(String s) {
    super(s);
  }

  protected void setUp() {
  }

  protected void tearDown() {
  }

  /**
   * test the first scenario, which is the object has just been
   * intaniated and is empty this will return null
   */
  public void testGetXMLContent() {
    IDocElement docElement = getIDocElement();
    Assert.assertNull("Newly instantiated object not returning null " +
      "when generating XMLContent", docElement.getXMLContent());
  }

  public void testLoadFromXMLContentDefaultBehavior() {
    IDocElement docElement = this.getIDocElement();

    //give null allow blanks
    try {
      docElement.loadFromXMLContent(null, true);
    } catch (Exception ex) {
      Assert.fail("threw exception loading null element set to allow blanks");
    }

    //give null dont allow blanks
    try {
      docElement.loadFromXMLContent(null, false);
      Assert.fail("didn't throw InconsistentDocElementStateException " +
        "loaded with null element allowBlanks set to false");
    } catch (InconsistentDocElementStateException ex) {
    } catch (InvalidXmlException ex) {
      Assert.fail("didn't throw InconsistentDocElementStateException " +
        "loaded with null element allowBlanks set to false");
    }

    //give element of wrong type
    try {
      docElement.loadFromXMLContent(new Element("Imbad"), false);
      Assert.fail("Didn't throw InvalidXmlException when loaded with " +
        "element of the wrong type");
    } catch (InconsistentDocElementStateException ex) {
      Assert.fail("Didn't throw InvalidXmlException when loaded with " +
        "element of the wrong type");
    } catch (InvalidXmlException ex) {
    }
  }

  public abstract IDocElement getIDocElement();
}





/*
 * Copyright 2003 The Trustees of Indiana University.  All rights reserved.
 *
 * This file is part of the EDEN software package.
 * For license information, see the LICENSE file in the top level directory
 * of the EDEN source distribution.
 */
