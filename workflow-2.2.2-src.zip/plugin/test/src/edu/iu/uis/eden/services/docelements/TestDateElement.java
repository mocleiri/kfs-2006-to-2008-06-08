package edu.iu.uis.eden.services.docelements;

import java.io.StringReader;
import java.text.SimpleDateFormat;
import java.util.Date;

import junit.framework.TestCase;

import org.jdom.Document;
import org.jdom.Element;

import edu.iu.uis.eden.exception.InvalidXmlException;
import edu.iu.uis.eden.services.IDocElement;
import edu.iu.uis.eden.services.InconsistentDocElementStateException;
import edu.iu.uis.eden.services.ServiceErrorConstants;
import edu.iu.uis.eden.util.XmlHelper;


public class TestDateElement extends TestCase {
  private DateElement dateElement;

  public TestDateElement(String s) {
    super(s);
  }

  protected void setUp() {
    this.dateElement = new DateElement();
  }

  protected void tearDown() {
  }

  /**
   * test the xml content for to_date, from_date and date
   */
  public void testGetXMLContent() throws Exception {
    SimpleDateFormat df = new SimpleDateFormat("MM/dd/yyyy");
    Date daDate = df.parse("11/05/2102");

    //    String xmlDate = "<date value=\"" + daDate.toString() + "\" />";
    DateElement date = new DateElement();

    //set to toDate
    date.setDate(daDate);
    assertNotNull("Returned null when loaded", date.getXMLContent());
  }

  /**
   * can this guy populate himself w/ xml he made.
   */
  public void testCanFeedOnOwnXML() {
    //start w/ to date
    DateElement date = new DateElement();

    //    String daDate = "11/05/2102";
    //    date.setDate(new Date(daDate));
    date.setDate(new Date());

    Element dateEl = date.getXMLContent();

    try {
      date.loadFromXMLContent(dateEl, false);
      assertNotNull("didn't properly load props from valid element", date.getDate());
    } catch (Exception ex) {
      fail("threw exception loading from self generated xml");
    }
  }

  /**
   * given a jdom element of the correct type it should load itself to the value
   * of the given jdom element
   *
   * if the jdom element is null and allowBlanks true it should return
   *
   * if the jdom element is null and allowBlanks is false its should throw
   * an InconsistentDocElementStateException
   *
   * if the element is of the incorrect type it should throw an
   * InvalidXmlException
   */
  public void testLoadFromXMLContent() throws Exception {
    //test loading a normal date
    SimpleDateFormat df = new SimpleDateFormat("MM/dd/yyyy");
    Date daDate = df.parse("9/9/99");

    Element dateEl = new Element("date");
    dateEl.setAttribute("value", new Long(daDate.getTime()).toString());

    try {
      dateElement.loadFromXMLContent(dateEl, false);
      assertEquals("didn't properly load props from valid element", daDate, dateElement.getDate());
    } catch (Exception ex) {
      fail("threw exception loading from valid element");
    }

    //test implementation of interface
    this.nonClassSpecificLoadFromXMLTests(dateElement);
  }

  /**
   * an object with a blank date should give a blank error specific to the
   * type of date it is
   *
   * a loaded object w/ a bad date should give an invalid error specific to the
   * type of date it is
   */
  public void testValidate() {
    try {
      //check for blank
      assertEquals("gave an error object with an incorrect error constant",
        ServiceErrorConstants.DATE_BLANK, dateElement.validate().getKey());

      //make valid and check types should all be null
      dateElement.setDate(new Date());
      assertNull("valid date didn't return null on validate", dateElement.validate());
    } catch (Exception ex) {
      fail("threw exception validating");
    }
  }

  /**
   * this should not be a route control according to now business rules
   */
  public void testIsRouteControl() {
    assertEquals("This should not be a routeControl", false, this.dateElement.isRouteControl());
  }

  /**
   * utility method that is not object specific
   *
   * @param docElement the docElement being tested
   */
  public void nonClassSpecificLoadFromXMLTests(IDocElement docElement) {
    //give null allow blanks
    try {
      docElement.loadFromXMLContent(null, true);
    } catch (Exception ex) {
      fail("threw exception loading null element set to allow blanks");
    }

    //give null dont allow blanks
    try {
      docElement.loadFromXMLContent(null, false);
      fail("didn't throw InconsistentDocElementStateException " +
        "loaded with null element allowBlanks set to false");
    } catch (InconsistentDocElementStateException ex) {
    } catch (InvalidXmlException ex) {
      fail("didn't throw InconsistentDocElementStateException " +
        "loaded with null element allowBlanks set to false");
    }

    //give element of wrong type
    try {
      docElement.loadFromXMLContent(new Element("Imbad"), false);
      fail("Didn't throw InvalidXmlException when loaded with " + "element of the wrong type");
    } catch (InconsistentDocElementStateException ex) {
      fail("Didn't throw InvalidXmlException when loaded with " + "element of the wrong type");
    } catch (InvalidXmlException ex) {
    }
  }

  public Element makeStringElement(String xmlContent) {
    Document doc = null;

    try {
      doc = new Document(XmlHelper.buildJDocument(new StringReader(xmlContent), false)
                                  .getRootElement());
    } catch (InvalidXmlException ex) {
      fail("Generated invalid xml");
    }

    return doc.getRootElement();
  }
}





/*
 * Copyright 2003 The Trustees of Indiana University.  All rights reserved.
 *
 * This file is part of the EDEN software package.
 * For license information, see the LICENSE file in the top level directory
 * of the EDEN source distribution.
 */
