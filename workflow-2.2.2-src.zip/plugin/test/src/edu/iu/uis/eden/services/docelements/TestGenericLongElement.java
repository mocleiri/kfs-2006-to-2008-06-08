package edu.iu.uis.eden.services.docelements;

import org.jdom.Element;

import edu.iu.uis.eden.WorkflowServiceErrorImpl;
import edu.iu.uis.eden.services.IDocElement;
import edu.iu.uis.eden.services.ServiceErrorConstants;


public class TestGenericLongElement extends IDocInterfaceTestTemplate {
  private GenericLongElement longEl;
  private String elementName = "longElement";
  private boolean routeControl = false;
  private String errorType = ServiceErrorConstants.CHART_BLANK;

  public TestGenericLongElement(String s) {
    super(s);
  }

  protected void setUp() {
    longEl = new GenericLongElement(elementName, errorType, routeControl);
  }

  protected void tearDown() {
  }

  public IDocElement getIDocElement() {
    return this.longEl;
  }

  /**
   * is this thing building the element with the name we want
   */
  public void testGetXMLContent() {
    this.longEl.setMyValue(1);

    Element element = this.longEl.getXMLContent();
    assertNotNull("loaded but returned null on getXMLContent()", element);

    assertEquals("didn't correctly make xml", this.elementName, element.getName());
  }

  /**
   * this is more flexible than your normal Element and we can set route-control
   * on and off at will providing implementation flexibility.
   */
  public void testIsRouteControl() {
    assertEquals("didn't properly set routeControl prop from constructor", this.routeControl,
      this.longEl.isRouteControl());

    //set it true and recheck
    this.longEl.setRouteControl(true);
    assertTrue("doesn't allow routeControl to be given a new value", this.longEl.isRouteControl());
  }

  public void testIsEmpty() {
    assertTrue("empty just intantiated object returned false on isEmpty()", this.longEl.isEmpty());

    //set a prop and retest
    this.longEl.setMyValue(1);
    assertEquals("loaded object returned true on isEmpty()", false, this.longEl.isEmpty());
  }

  /**
   * given valid xml does GenericLongElement load correctly
   */
  public void testLoadFromXMLContent() {
    long daValue = 1;
    this.longEl.setMyValue(daValue);
    this.longEl.getXMLContent();

    //make a new GenericLongElement and test for values
    new GenericLongElement(this.elementName, this.errorType, this.routeControl);

    assertEquals("didn't correctly load props from self generated xml", daValue,
      this.longEl.getMyValue());
  }

  /**
   * is validate returning the correct error code;
   */
  public void testValidate() {
    try {
      WorkflowServiceErrorImpl error = this.longEl.validate();
      assertEquals("didnt' return error code constructed with", this.errorType, error.getKey());

      //load w/ a value should return null on validate
      this.longEl.setMyValue(1);
      assertNull("didn't return null on validate() when valid", this.longEl.validate());
    } catch (Exception ex) {
      fail("threw exception validating");
    }
  }
}





/*
 * Copyright 2003 The Trustees of Indiana University.  All rights reserved.
 *
 * This file is part of the EDEN software package.
 * For license information, see the LICENSE file in the top level directory
 * of the EDEN source distribution.
 */
