Onestart Workflow Quickstart Instructions

1. Copy the following into this directory:

   * jakarta-tomcat-5.0.28.zip
   * mckoi1.0.3.zip

2. Run 'ant quickstart' on the plugin build.xml.  This will create a root /workflow_quickstart directory, populate it,
   and create and initialize the database (you must have onestart_workflow checked out in a peer directory).

3. You can then start the workflow engine with:

   ant

   (you can also configure Mckoi to run in a standalone server process and run the database independent of the workflow engine.
    the default configuration however runs the database embedded in-process)

4. Open a browser to: http://localhost:8080/en-dev/Backdoor.do

Defined users are:

quickstart (default)
huey
dewey
louie

Defined workgroups are:

Group0: quickstart, huey, louie
Group1: dewey
WorkflowAdmin: quickstart
