Workflow Quickstart

The Quickstart workflow engine can be started and managed by running the ant 'build.xml' script.

e.g. to start the workflow engine, just run 'ant':

ant

Script help:

Targets:

      help         print this help text
      run          (default) runs the workflow engine from within Ant
      exec         executes the workflow engine via Ant 'exec' task
      start        spawns the workflow engine asynchronously
      stop         stops a running workflow engine
      deletedb     deletes the Mckoi db
      backupdb     backs up the Mckoi db
      restoredb    restores the backed-up Mckoi db (if it exists)
      deletebackup deletes the backed-up Mckoi db
