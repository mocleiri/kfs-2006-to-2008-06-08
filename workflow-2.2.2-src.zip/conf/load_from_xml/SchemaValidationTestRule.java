package edu.iu.uis.eden.xml;

import org.jdom.*;
import org.jdom.input.*;
import java.io.*;

public class SchemaValidationTestRule {

    public static void main(String[] args) {
        try {
            SAXBuilder builder = new SAXBuilder("org.apache.xerces.parsers.SAXParser", true);

            builder.setFeature("http://apache.org/xml/features/validation/schema", true);

            builder.setFeature("http://xml.org/sax/features/validation", true);

            builder.setFeature("http://apache.org/xml/features/validation/schema-full-checking", true); 
            
            builder.setProperty("http://apache.org/xml/properties/schema/external-noNamespaceSchemaLocation", "file:///C:/java/projects/workflow/test/data/RuleSchema.xsd");

            Document doc = builder.build(new File("test/data/RuleContent.xml"));

            System.out.println("XML is validated");
        } catch (Exception e) {
            System.out.println("Caught exception: " + e.toString());
            e.printStackTrace(System.out);
        }
    }
}
