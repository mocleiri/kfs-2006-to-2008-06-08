#!/bin/bash
#****h* oracle2mckoi.sh
# PURPOSE
#   converts Oracle DDL syntax to Mckoi
# AUTHOR
#   Aaron Hamid (arh14 at cornell dot edu)
# ARGUMENTS
#   The file to convert.  Output is to stdout, messages are to stderr.
#***

if [ $# -lt 1 ]; then
  echo
  echo "Usage: oracle2mckoi.sh {filename}"
  echo
  exit 1
fi

echo "Converting $1 from Oracle to Mckoi syntax" 1>&2

# the really big regex is to transpose the clauses in the CREATE SEQUENCE statement
# so that Mckoi likes it.  It demands the order: INCREMENT,MINVALUE,MAXVALUE,START,CYCLE
sed -re '
  s/([ \t]+)NUMBER([ \t]*\(.*\))?([ \t]*)/\1INTEGER\3/gI
  s/VARCHAR2/VARCHAR/gI
  s/([ \t]+)LONG([ \t]+)/\1LONGVARCHAR\2/gI
  s/USING([ \t]+)INDEX//gI
  s/[ \t]+ENABLE[ \t]*(,?)[ \t]*$/\1/gI
  s/CREATE SEQUENCE([ \t]+.*)([ \t]+INCREMENT[ \t]+(BY)?[ \t]+[0-9]+)([ \t]+START[ \t]+(WITH)?[ \t]+[0-9]+)([ \t]+MINVALUE[ \t]+[0-9]+)([ \t]+MAXVALUE[ \t]+[0-9]+)([ \t]+CYCLE)?/CREATE SEQUENCE\1\2\6\7\4\8/gI;
  s/INCREMENT[\ t]+BY/INCREMENT/gI
  s/START[ \t]+WITH/START/gI
  s/TABLESPACE[ \t]+[a-z0-9_-]*//gI
' $1
