delete EN_ACTN_ITM_T where doc_hdr_id in (select doc_hdr_id from en_doc_hdr_t where doc_rte_lvl_nbr = 1 and doc_rte_stat_cd = 'R'and 
doc_typ_id in (select doc_typ_id from EN_DOC_TYP_T where doc_typ_nm like 'HREDOC%'));


delete en_actn_rqst_t where doc_hdr_id in (select doc_hdr_id from en_doc_hdr_t where doc_rte_lvl_nbr = 1 and doc_rte_stat_cd = 'R'and 
doc_typ_id in (select doc_typ_id from EN_DOC_TYP_T where doc_typ_nm like 'HREDOC%'));


insert into en_doc_rte_que_t select doc_hdr_id, sysdate, 1, 'Q', 0, '1', 0 from en_doc_hdr_t where doc_rte_lvl_nbr = 1 and doc_rte_stat_cd = 'R'and 
doc_typ_id in (select doc_typ_id from EN_DOC_TYP_T where doc_typ_nm like 'HREDOC%');


update en_doc_hdr_t set doc_rte_lvl_nbr = 0 where doc_hdr_id in (select doc_hdr_id from en_doc_hdr_t where doc_rte_lvl_nbr = 1 and doc_rte_stat_cd = 'R'and 
doc_typ_id in (select doc_typ_id from EN_DOC_TYP_T where doc_typ_nm like 'HREDOC%')); 