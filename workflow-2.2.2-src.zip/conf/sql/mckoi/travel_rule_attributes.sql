insert into EN_WRKGRP_T (WRKGRP_ID, WRKGRP_VER_NBR, WRKGRP_NM, WRKGRP_ACTV_IND, WRKGRP_TYP_CD, WRKGRP_DESC, WRKGRP_CUR_IND, DOC_HDR_ID, DB_LOCK_VER_NBR) values (900, 1, 'TravelBlanketWorkgroup', 1, 'W', 'Blanket approvers for Travel Documents', 1, 0, 0);
insert into EN_WRKGRP_T (WRKGRP_ID, WRKGRP_VER_NBR, WRKGRP_NM, WRKGRP_ACTV_IND, WRKGRP_TYP_CD, WRKGRP_DESC, WRKGRP_CUR_IND, DOC_HDR_ID, DB_LOCK_VER_NBR) values (901, 1, 'TravelExceptionWorkgroup', 1, 'W', 'Exception workgroup for Travel Documents', 1, 0, 0);
insert into EN_WRKGRP_T (WRKGRP_ID, WRKGRP_VER_NBR, WRKGRP_NM, WRKGRP_ACTV_IND, WRKGRP_TYP_CD, WRKGRP_DESC, WRKGRP_CUR_IND, DOC_HDR_ID, DB_LOCK_VER_NBR) values (902, 1, 'TravelSuperUserWorkgroup', 1, 'W', 'Super User workgroup for Travel Documents', 1, 0, 0);

-- insert into EN_USR_T (PRSN_EN_ID, PRSN_UNIV_ID, PRSN_NTWRK_ID, PRSN_UNVL_USR_ID, PRSN_EMAIL_ADDR, PRSN_NM, PRSN_GVN_NM, PRSN_LST_NM, USR_CRTE_DT, USR_LST_UPDT_DT, PRSN_ID_MSNG_IND, DB_LOCK_VER_NBR) values ('000000000999', '0000394389', 'jitrue', '1000054218', 'jitrue@indiana.edu', 'James S True', 'James S', 'True', to_date('2005/01/01:08:00:00AM', 'yyyy/mm/dd:hh:mi:ssam'), to_date('2005/01/01:08:00:00AM', 'yyyy/mm/dd:hh:mi:ssam'), 0, 0);

insert into EN_WRKGRP_MBR_T select PRSN_EN_ID, 900, 1, 0 from EN_USR_T where PRSN_NTWRK_ID in ('jitrue');
insert into EN_WRKGRP_MBR_T select PRSN_EN_ID, 901, 1, 0 from EN_USR_T where PRSN_NTWRK_ID in ('jitrue');
insert into EN_WRKGRP_MBR_T select PRSN_EN_ID, 902, 1, 0 from EN_USR_T where PRSN_NTWRK_ID in ('jitrue');

insert into EN_DOC_TYP_T (DOC_TYP_ID, DOC_TYP_PARNT_ID, DOC_TYP_NM, DOC_TYP_VER_NBR, DOC_TYP_ACTV_IND, DOC_TYP_CUR_IND, DOC_TYP_LBL_TXT, DOC_TYP_DESC, DOC_TYP_HDLR_URL_ADDR, DOC_TYP_POST_PRCSR_NM, WRKGRP_ID, BLNKT_APPR_WRKGRP_ID, DB_LOCK_VER_NBR) values (900, NULL, 'TRAVELDOCS', 1, 1, 1,'Travel Parent Document', 'Parent Document for all travel documents', NULL, NULL, 902, 900, 0);
insert into EN_DOC_TYP_T (DOC_TYP_ID, DOC_TYP_PARNT_ID, DOC_TYP_NM, DOC_TYP_VER_NBR, DOC_TYP_ACTV_IND, DOC_TYP_CUR_IND, DOC_TYP_LBL_TXT, DOC_TYP_DESC, DOC_TYP_HDLR_URL_ADDR, DOC_TYP_POST_PRCSR_NM, WRKGRP_ID, BLNKT_APPR_WRKGRP_ID, DB_LOCK_VER_NBR) values (901, 900, 'TRAVELDOCS.TravelAuthorization', 1, 1, 1,'Travel Authorization', 'Travel Authorization Document', '&1.TravelDocHandler.do?methodToCall=docHandler', 'edu.iu.uis.travel.routing.TravelPostProcessor', 902, 900, 0);
insert into EN_DOC_TYP_T (DOC_TYP_ID, DOC_TYP_PARNT_ID, DOC_TYP_NM, DOC_TYP_VER_NBR, DOC_TYP_ACTV_IND, DOC_TYP_CUR_IND, DOC_TYP_LBL_TXT, DOC_TYP_DESC, DOC_TYP_HDLR_URL_ADDR, DOC_TYP_POST_PRCSR_NM, WRKGRP_ID, BLNKT_APPR_WRKGRP_ID, DB_LOCK_VER_NBR) values (902, 900, 'TRAVELDOCS.TravelPrepaidExpenses', 1, 1, 1,'Travel Prepaid Expenses', 'Travel Prepaid Expenses Document', '&1.TravelDocHandler.do?methodToCall=docHandler', 'edu.iu.uis.travel.routing.TravelPostProcessor', 902, 900, 0);
insert into EN_DOC_TYP_T (DOC_TYP_ID, DOC_TYP_PARNT_ID, DOC_TYP_NM, DOC_TYP_VER_NBR, DOC_TYP_ACTV_IND, DOC_TYP_CUR_IND, DOC_TYP_LBL_TXT, DOC_TYP_DESC, DOC_TYP_HDLR_URL_ADDR, DOC_TYP_POST_PRCSR_NM, WRKGRP_ID, BLNKT_APPR_WRKGRP_ID, DB_LOCK_VER_NBR) values (903, 900, 'TRAVELDOCS.TravelReimbursement', 1, 1, 1,'Travel Reimbursement', 'Travel Reimbursement Document', '&1.TravelDocHandler.do?methodToCall=docHandler', 'edu.iu.uis.travel.routing.TravelPostProcessor', 902, 900, 0);
insert into EN_DOC_TYP_T (DOC_TYP_ID, DOC_TYP_PARNT_ID, DOC_TYP_NM, DOC_TYP_VER_NBR, DOC_TYP_ACTV_IND, DOC_TYP_CUR_IND, DOC_TYP_LBL_TXT, DOC_TYP_DESC, DOC_TYP_HDLR_URL_ADDR, DOC_TYP_POST_PRCSR_NM, WRKGRP_ID, BLNKT_APPR_WRKGRP_ID, DB_LOCK_VER_NBR) values (904, 900, 'TRAVELDOCS.TravelSupplementalReimbursement', 1, 1, 1,'Travel Supplemental Reimbursement', 'Travel Supplemental Reimbursement Document', '&1.TravelDocHandler.do?methodToCall=docHandler', 'edu.iu.uis.travel.routing.TravelPostProcessor', 902, 900, 0);

insert into EN_RULE_ATTRIB_T (RULE_ATTRIB_ID, RULE_ATTRIB_NM, RULE_ATTRIB_LBL_TXT, RULE_ATTRIB_TYP, RULE_ATTRIB_DESC, RULE_ATTRIB_CLS_NM, DB_LOCK_VER_NBR) values (900, 'SubAccount', 'SubAccount Rule Attribute', 'foo', 'SubAccount Rule Attribute', 'edu.iu.uis.eden.routetemplate.attribute.SubAccountAttribute', 0);
insert into EN_RULE_ATTRIB_T (RULE_ATTRIB_ID, RULE_ATTRIB_NM, RULE_ATTRIB_LBL_TXT, RULE_ATTRIB_TYP, RULE_ATTRIB_DESC, RULE_ATTRIB_CLS_NM, DB_LOCK_VER_NBR) values (901, 'AccountRule', 'Account Rule Attribute', 'foo', 'Account Rule Attribute', 'edu.iu.uis.eden.routetemplate.attribute.AccountRuleAttribute', 0);
insert into EN_RULE_ATTRIB_T (RULE_ATTRIB_ID, RULE_ATTRIB_NM, RULE_ATTRIB_LBL_TXT, RULE_ATTRIB_TYP, RULE_ATTRIB_DESC, RULE_ATTRIB_CLS_NM, DB_LOCK_VER_NBR) values (902, 'FiscalOfficer', 'Fiscal Officer Rule Attribute', 'foo', 'Fiscal Officer Rule Attribute', 'edu.iu.uis.eden.routetemplate.attribute.AccountAttribute', 0);
insert into EN_RULE_ATTRIB_T (RULE_ATTRIB_ID, RULE_ATTRIB_NM, RULE_ATTRIB_LBL_TXT, RULE_ATTRIB_TYP, RULE_ATTRIB_DESC, RULE_ATTRIB_CLS_NM, DB_LOCK_VER_NBR) values (903, 'ChartOrg', 'Chart Org Rule Attribute', 'foo', 'Chart Org Rule Attribute', 'edu.iu.uis.eden.routetemplate.attribute.ChartOrgAttribute', 0);

insert into EN_RULE_TMPL_T (RULE_TMPL_ID, RULE_TMPL_NM, RULE_TMPL_DESC, DB_LOCK_VER_NBR) values (900, 'TravelSubAccountTemplate', 'Template for subaccount criteria', 0);
insert into EN_RULE_TMPL_T (RULE_TMPL_ID, RULE_TMPL_NM, RULE_TMPL_DESC, DB_LOCK_VER_NBR) values (901, 'TravelAccountRuleTemplate', 'Template for account criteria', 0);
insert into EN_RULE_TMPL_T (RULE_TMPL_ID, RULE_TMPL_NM, RULE_TMPL_DESC, DB_LOCK_VER_NBR) values (902, 'TravelFiscalOfficerTemplate', 'Template for Fiscal Officer criteria', 0);
insert into EN_RULE_TMPL_T (RULE_TMPL_ID, RULE_TMPL_NM, RULE_TMPL_DESC, DB_LOCK_VER_NBR) values (903, 'TravelChartOrgTemplate', 'Template for Chart and Org criteria', 0);
insert into EN_RULE_TMPL_T (RULE_TMPL_ID, RULE_TMPL_NM, RULE_TMPL_DESC, DB_LOCK_VER_NBR) values (904, 'TravelFinalApproverTemplate', 'Template for Final Approver', 0);

insert into EN_RULE_TMPL_ATTRIB_T (RULE_TMPL_ATTRIB_ID, RULE_TMPL_ID, RULE_ATTRIB_ID, REQ_IND, DSPL_ORD, DFLT_VAL, DB_LOCK_VER_NBR) values (900, 900, 900, 1, 1, NULL, 0);

insert into EN_RULE_TMPL_ATTRIB_T (RULE_TMPL_ATTRIB_ID, RULE_TMPL_ID, RULE_ATTRIB_ID, REQ_IND, DSPL_ORD, DFLT_VAL, DB_LOCK_VER_NBR) values (901, 901, 901, 2, 1, NULL, 0);
    
insert into EN_RULE_TMPL_ATTRIB_T (RULE_TMPL_ATTRIB_ID, RULE_TMPL_ID, RULE_ATTRIB_ID, REQ_IND, DSPL_ORD, DFLT_VAL, DB_LOCK_VER_NBR) values (902, 902, 902, 3, 1, NULL, 0);
    
insert into EN_RULE_TMPL_ATTRIB_T (RULE_TMPL_ATTRIB_ID, RULE_TMPL_ID, RULE_ATTRIB_ID, REQ_IND, DSPL_ORD, DFLT_VAL, DB_LOCK_VER_NBR) values (903, 903, 903, 4, 1, NULL, 0);

insert into EN_DOC_TYP_RTE_LVL_T (DOC_RTE_LVL_ID, DOC_TYP_ID, DOC_RTE_LVL_NM, DOC_RTE_LVL_PRIO_NBR, DOC_RTE_MTHD_NM, DOC_FNL_APRVR_IND, DOC_MNDTRY_RTE_IND, WRKGRP_ID, DOC_RTE_MTHD_CD, DOC_ACTVN_TYP_TXT, DB_LOCK_VER_NBR) values (900, 900, 'Exception', -1, 'edu.iu.uis.eden.routemodule.ExceptionRouteModule', 0, 0, 901, 'RM', 'S', 0);

insert into EN_DOC_TYP_RTE_LVL_T (DOC_RTE_LVL_ID, DOC_TYP_ID, DOC_RTE_LVL_NM, DOC_RTE_LVL_PRIO_NBR, DOC_RTE_MTHD_NM, DOC_FNL_APRVR_IND, DOC_MNDTRY_RTE_IND, WRKGRP_ID, DOC_RTE_MTHD_CD, DOC_ACTVN_TYP_TXT, DB_LOCK_VER_NBR) values (901, 900, 'AdHoc', 0, 'edu.iu.uis.eden.routemodule.AdHocRouteModule', 0, 0, 901, 'RM', 'S', 0);

insert into EN_DOC_TYP_RTE_LVL_T (DOC_RTE_LVL_ID, DOC_TYP_ID, DOC_RTE_LVL_NM, DOC_RTE_LVL_PRIO_NBR, DOC_RTE_MTHD_NM, DOC_FNL_APRVR_IND, DOC_MNDTRY_RTE_IND, WRKGRP_ID, DOC_RTE_MTHD_CD, DOC_ACTVN_TYP_TXT, DB_LOCK_VER_NBR) values (902, 900, 'SubAccount Action', 1, 'TravelSubAccountTemplate', 0, 0, 901, 'FR', 'S', 0);

insert into EN_DOC_TYP_RTE_LVL_T (DOC_RTE_LVL_ID, DOC_TYP_ID, DOC_RTE_LVL_NM, DOC_RTE_LVL_PRIO_NBR, DOC_RTE_MTHD_NM, DOC_FNL_APRVR_IND, DOC_MNDTRY_RTE_IND, WRKGRP_ID, DOC_RTE_MTHD_CD, DOC_ACTVN_TYP_TXT, DB_LOCK_VER_NBR) values (903, 900, 'Account Rule Action', 2, 'TravelAccountRuleTemplate', 0, 0, 901, 'FR', 'S', 0);
    
insert into EN_DOC_TYP_RTE_LVL_T (DOC_RTE_LVL_ID, DOC_TYP_ID, DOC_RTE_LVL_NM, DOC_RTE_LVL_PRIO_NBR, DOC_RTE_MTHD_NM, DOC_FNL_APRVR_IND, DOC_MNDTRY_RTE_IND, WRKGRP_ID, DOC_RTE_MTHD_CD, DOC_ACTVN_TYP_TXT, DB_LOCK_VER_NBR) values (904, 900, 'Fiscal Officer Action', 3, 'TravelFiscalOfficerTemplate', 0, 0, 901, 'FR', 'S', 0);
 
insert into EN_DOC_TYP_RTE_LVL_T (DOC_RTE_LVL_ID, DOC_TYP_ID, DOC_RTE_LVL_NM, DOC_RTE_LVL_PRIO_NBR, DOC_RTE_MTHD_NM, DOC_FNL_APRVR_IND, DOC_MNDTRY_RTE_IND, WRKGRP_ID, DOC_RTE_MTHD_CD, DOC_ACTVN_TYP_TXT, DB_LOCK_VER_NBR) values (905, 900, 'Chart and Org Action', 4, 'TravelChartOrgTemplate', 0, 0, 901, 'FR', 'S', 0); 
    
insert into EN_DOC_TYP_RTE_LVL_T (DOC_RTE_LVL_ID, DOC_TYP_ID, DOC_RTE_LVL_NM, DOC_RTE_LVL_PRIO_NBR, DOC_RTE_MTHD_NM, DOC_FNL_APRVR_IND, DOC_MNDTRY_RTE_IND, WRKGRP_ID, DOC_RTE_MTHD_CD, DOC_ACTVN_TYP_TXT, DB_LOCK_VER_NBR) values (906, 900, 'Final Approver Action', 5, 'TravelFinalApproverTemplate', 1, 0, 901, 'FR', 'S', 0);
    
insert into EN_DOC_TYP_PLCY_RELN_T (DOC_TYP_ID, DOC_PLCY_NM, DOC_PLCY_VAL, DB_LOCK_VER_NBR) VALUES (900, 'DEFAULT_APPROVE', '0', 0);
insert into EN_DOC_TYP_PLCY_RELN_T (DOC_TYP_ID, DOC_PLCY_NM, DOC_PLCY_VAL, DB_LOCK_VER_NBR) VALUES (900, 'PRE_APPROVE', '0', 0);
insert into EN_DOC_TYP_PLCY_RELN_T (DOC_TYP_ID, DOC_PLCY_NM, DOC_PLCY_VAL, DB_LOCK_VER_NBR) VALUES (900, 'SU_ACTION_REQUEST_APPROVE', '1', 0);
insert into EN_DOC_TYP_PLCY_RELN_T (DOC_TYP_ID, DOC_PLCY_NM, DOC_PLCY_VAL, DB_LOCK_VER_NBR) VALUES (900, 'SU_APPROVE', '1', 0);
insert into EN_DOC_TYP_PLCY_RELN_T (DOC_TYP_ID, DOC_PLCY_NM, DOC_PLCY_VAL, DB_LOCK_VER_NBR) VALUES (900, 'SU_CANCEL', '1', 0);
insert into EN_DOC_TYP_PLCY_RELN_T (DOC_TYP_ID, DOC_PLCY_NM, DOC_PLCY_VAL, DB_LOCK_VER_NBR) VALUES (900, 'SU_DISAPPROVE', '1', 0);
insert into EN_DOC_TYP_PLCY_RELN_T (DOC_TYP_ID, DOC_PLCY_NM, DOC_PLCY_VAL, DB_LOCK_VER_NBR) VALUES (900, 'SU_ROUTE_LEVEL_APPROVE', '1', 0);	
commit; 