Here is the sql for the tablespace creation:

 

SPOOL en_tablespaces.out

CREATE TABLESPACE EN01

    DATAFILE '/opt/oracle/d01/oradata/GEN2PRD/en01a.dbf' SIZE 512008K AUTOEXTEND  OFF

    LOGGING

    DEFAULT STORAGE(INITIAL 1M

                    NEXT 1M

                    MINEXTENTS 1

                    MAXEXTENTS UNLIMITED

                    PCTINCREASE 0)

    ONLINE

    PERMANENT;

 

CREATE TABLESPACE EN_IDX01

    DATAFILE '/opt/oracle/d02/oradata/GEN2PRD/en_idx01a.dbf' SIZE 512008K AUTOEX TEND OFF

    LOGGING

    DEFAULT STORAGE(INITIAL 1M

                    NEXT 1M

                    MINEXTENTS 1

                    MAXEXTENTS UNLIMITED

                    PCTINCREASE 0)

    ONLINE

    PERMANENT;

 

SPOOL OFF

 

 

here is the sql for the mt_ort role:

 

create role mt_ort

/

 

connect as sysdba:

 

RANT SELECT ON SYS.TS$ TO MT_ORT ;                                             

GRANT SELECT ON SYS.OBJ$ TO MT_ORT ;                                            

GRANT SELECT ON SYS.V_$PROCESS TO MT_ORT ;                                      

GRANT SELECT ON SYS.V_$SESSION TO MT_ORT ;                                      

GRANT SELECT ON SYS.V_$TRANSACTION TO MT_ORT ;                                  

GRANT SELECT ON SYS.V_$SESSTAT TO MT_ORT ;                                      

GRANT SELECT ON SYS.V_$MYSTAT TO MT_ORT ;                                       

GRANT SELECT ON SYS.V_$STATNAME TO MT_ORT ;                                     

GRANT SELECT ON SYS.V_$ACCESS TO MT_ORT ;                                       

GRANT SELECT ON SYS.V_$FILESTAT TO MT_ORT ;                                     

GRANT SELECT ON SYS.V_$PARAMETER TO MT_ORT ;                                    

GRANT SELECT ON SYS.V_$INSTANCE TO MT_ORT ;                                     

GRANT SELECT ON SYS.V_$SQLAREA TO MT_ORT ;                                      

GRANT SELECT ON SYS.V_$SQLTEXT TO MT_ORT ;                                      

GRANT SELECT ON SYS.V_$SQL TO MT_ORT ;                                          

GRANT SELECT ON SYS.V_$OPEN_CURSOR TO MT_ORT ;                                  

GRANT SELECT ON SYS.V_$VERSION TO MT_ORT ;                                      

GRANT SELECT ON SYS.V_$DATAFILE TO MT_ORT ;                                     

GRANT SELECT ON SYS.V_$SESSION_WAIT TO MT_ORT ;                                 

GRANT SELECT ON SYS.V_$SESS_IO TO MT_ORT ;                                      

GRANT SELECT ON SYS.V_$COMPATIBILITY TO MT_ORT ;                                

GRANT SELECT ON SYS.GV_$SESSION TO MT_ORT ;                                     

GRANT SELECT ON SYS.GV_$LOCKED_OBJECT TO MT_ORT ;                               

GRANT SELECT ON SYS.GV_$INSTANCE TO MT_ORT ;                                    

GRANT SELECT ON SYS.GV_$SQLTEXT TO MT_ORT ;                                     

GRANT SELECT ON SYS.GV_$LOCK_ACTIVITY TO MT_ORT ;                               

GRANT SELECT ON SYS.SESSION_PRIVS TO MT_ORT ;                                   

GRANT SELECT ON SYS.DBA_ROLES TO MT_ORT ;                                       

GRANT SELECT ON SYS.DBA_CLUSTERS TO MT_ORT ;                                    

GRANT SELECT ON SYS.DBA_DB_LINKS TO MT_ORT ;                                    

GRANT SELECT ON SYS.DBA_INDEXES TO MT_ORT ;                                     

GRANT SELECT ON SYS.DBA_IND_COLUMNS TO MT_ORT ;                                 

GRANT SELECT ON SYS.INDEX_STATS TO MT_ORT ;                                     

GRANT SELECT ON SYS.INDEX_HISTOGRAM TO MT_ORT ;                                 

GRANT SELECT ON SYS.DBA_OBJECTS TO MT_ORT ;                                     

GRANT SELECT ON SYS.DBA_ROLLBACK_SEGS TO MT_ORT ;                               

GRANT SELECT ON SYS.DBA_ROLE_PRIVS TO MT_ORT ;                                  

GRANT SELECT ON SYS.DBA_SYS_PRIVS TO MT_ORT ;                                   

GRANT SELECT ON SYS.DBA_SEQUENCES TO MT_ORT ;                                   

GRANT SELECT ON SYS.DBA_SYNONYMS TO MT_ORT ;                                    

GRANT SELECT ON SYS.DBA_TABLES TO MT_ORT ;                                      

GRANT SELECT ON SYS.DBA_TAB_COLUMNS TO MT_ORT ;                                 

GRANT SELECT ON SYS.DBA_TAB_PRIVS TO MT_ORT ;                                   

GRANT SELECT ON SYS.DBA_TS_QUOTAS TO MT_ORT ;                                   

GRANT SELECT ON SYS.DBA_USERS TO MT_ORT ;                                       

GRANT SELECT ON SYS.DBA_VIEWS TO MT_ORT ;                                       

GRANT SELECT ON SYS.DBA_CONSTRAINTS TO MT_ORT ;                                 

GRANT SELECT ON SYS.DBA_CONS_COLUMNS TO MT_ORT ;                                

GRANT SELECT ON SYS.DBA_DIRECTORIES TO MT_ORT ;                                 

GRANT SELECT ON SYS.DBA_LIBRARIES TO MT_ORT ;                                   

GRANT SELECT ON SYS.DBA_OPERATORS TO MT_ORT ;                                   

GRANT SELECT ON SYS.DBA_INDEXTYPES TO MT_ORT ;                                  

GRANT SELECT ON SYS.DBA_INDEXTYPE_OPERATORS TO MT_ORT ;                         

GRANT SELECT ON SYS.DBA_PART_TABLES TO MT_ORT ;                                 

GRANT SELECT ON SYS.DBA_PART_INDEXES TO MT_ORT ;                                

GRANT SELECT ON SYS.DBA_TAB_PARTITIONS TO MT_ORT ;                              

GRANT SELECT ON SYS.DBA_IND_PARTITIONS TO MT_ORT ;                              

GRANT SELECT ON SYS.DBA_ERRORS TO MT_ORT ;                                      

GRANT SELECT ON SYS.DBA_SOURCE TO MT_ORT ;                                      

GRANT SELECT ON SYS.DBA_TRIGGERS TO MT_ORT ;                                    

GRANT SELECT ON SYS.DBA_SEGMENTS TO MT_ORT ;                                    

GRANT SELECT ON SYS.DBA_EXTENTS TO MT_ORT ;                                     

GRANT SELECT ON SYS.DBA_FREE_SPACE TO MT_ORT ;                                  

GRANT SELECT ON SYS.DBA_DATA_FILES TO MT_ORT ;                                  

GRANT SELECT ON SYS.DBA_TABLESPACES TO MT_ORT ;                                 

GRANT SELECT ON SYS.DBA_SNAPSHOTS TO MT_ORT ;                    

 

 

CREATE USER EN identified by  ;

 

ALTER USER EN TEMPORARY TABLESPACE TEMP01 ; ALTER USER EN DEFAULT TABLESPACE EN01 ;

 

ALTER USER EN QUOTA UNLIMITED ON EN01 ;

ALTER USER EN QUOTA UNLIMITED ON EN_IDX01 ;

 

GRANT MT_ORT TO EN ;

 

GRANT CREATE TYPE TO EN ;

GRANT CREATE LIBRARY TO EN ;

GRANT CREATE PROCEDURE TO EN ;

GRANT CREATE PUBLIC SYNONYM TO EN ;

GRANT CREATE SEQUENCE TO EN ;

GRANT CREATE SESSION TO EN ;

GRANT CREATE TABLE TO EN ;

GRANT CREATE TRIGGER TO EN ;

GRANT CREATE VIEW TO EN ;

GRANT DROP PUBLIC SYNONYM TO EN ;

 

Here is the roles script that would need to be run after the create user

script:

 

CREATE ROLE EN_USER ;

GRANT CREATE SESSION TO EN_USER ;

 

revoke en_user from system ;

 

 
