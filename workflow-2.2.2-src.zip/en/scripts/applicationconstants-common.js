// ApplicationConstants.jsp
function clearForm() {
  dForm = document.forms[0];
  dForm.elements["constant.applicationConstantName"].value="";
  dForm.elements["constant.applicationConstantValue"].value="";
}