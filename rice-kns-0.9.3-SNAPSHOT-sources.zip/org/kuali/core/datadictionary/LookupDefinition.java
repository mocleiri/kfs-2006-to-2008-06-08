/*
 * Copyright 2005-2007 The Kuali Foundation.
 *
 * Licensed under the Educational Community License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.opensource.org/licenses/ecl1.php
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.kuali.core.datadictionary;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.kuali.RiceConstants;
import org.kuali.core.datadictionary.exception.DuplicateEntryException;
import org.kuali.rice.KNSServiceLocator;

/**
 * Contains lookup-related information relating to the parent BusinessObject.
 *
 * Note: the setters do copious amounts of validation, to facilitate generating errors during the parsing process.
 *
 *
 */
public class LookupDefinition extends DataDictionaryDefinitionBase {
    // logger
    private static Log LOG = LogFactory.getLog(LookupDefinition.class);

    private String lookupableID;
    private String title;
    private String menubar;
    private String instructions;
    private SortDefinition defaultSort;

    private List<FieldDefinition> lookupFields;
    private Map<String,FieldDefinition> lookupFieldMap;
    private List<FieldDefinition> resultFields;
    private Map<String,FieldDefinition> resultFieldMap;

    private Integer resultSetLimit;

    private String extraButtonSource;
    private String extraButtonParams;

    public LookupDefinition() {
        LOG.debug("creating new LookupDefinition");

        lookupFields = new ArrayList<FieldDefinition>();
        resultFields = new ArrayList<FieldDefinition>();
        lookupFieldMap = new LinkedHashMap<String, FieldDefinition>();
        resultFieldMap = new LinkedHashMap<String, FieldDefinition>();
    }

    /**
     * @param lookupableID
     */
    public void setLookupableID(String lookupableID) {
        if (lookupableID == null) {
            throw new IllegalArgumentException("invalid (null) lookupableID");
        }

        this.lookupableID = lookupableID;
    }

    /**
     * @return custom lookupable id
     */
    public String getLookupableID() {
        return this.lookupableID;
    }

    /**
     * @return title
     */
    public String getTitle() {
        return title;
    }

    /**
     * Sets title to the given value.
     *
     * @param title
     * @throws IllegalArgumentException if the given title is blank
     */
    public void setTitle(String title) {
        if (StringUtils.isBlank(title)) {
            throw new IllegalArgumentException("invalid (blank) title");
        }
        this.title = title;
    }

    /**
     * @return true if this instance has a menubar
     */
    public boolean hasMenubar() {
        return (menubar != null);
    }

    /**
     * @return menubar
     */
    public String getMenubar() {
        return menubar;
    }

    /**
     * Sets menubar to the given value.
     *
     * @param menubar
     * @throws IllegalArgumentException if the given menubar is blank
     */
    public void setMenubar(String menubar) {
        if (StringUtils.isBlank(menubar)) {
            throw new IllegalArgumentException("invalid (blank) menubar");
        }
        // TODO: catch exception if service locator call fails
        this.menubar = menubar.replace("${kr.externalizable.images.url}", KNSServiceLocator.getKualiConfigurationService().getPropertyString(RiceConstants.EXTERNALIZABLE_IMAGES_URL_KEY)).replace("${externalizable.images.url}", KNSServiceLocator.getKualiConfigurationService().getPropertyString(RiceConstants.APPLICATION_EXTERNALIZABLE_IMAGES_URL_KEY));
    }


    /**
     * @return true if this instance has instructions
     */
    public boolean hasInstructions() {
        return (instructions != null);
    }

    /**
     * @return instructions
     */
    public String getInstructions() {
        return instructions;
    }

    /**
     * Sets instructions to the given value.
     *
     * @param title
     * @throws IllegalArgumentException if the given instructions are blank
     */
    public void setInstructions(String instructions) {
        if (StringUtils.isBlank(instructions)) {
            throw new IllegalArgumentException("invalid (blank) instructions");
        }
        this.instructions = instructions;
    }

    /**
     * @return true if this instance has a default sort defined
     */
    public boolean hasDefaultSort() {
        return (defaultSort != null);
    }

    /**
     * @return defaultSort
     */
    public SortDefinition getDefaultSort() {
        return defaultSort;
    }

    /**
     * Sets defaultSort to the given value.
     *
     * @param defaultSort
     * @throws IllegalArgumentException if the given defaultSort is blank
     */
    public void setDefaultSort(SortDefinition defaultSort) {
        if (defaultSort == null) {
            throw new IllegalArgumentException("invalid (null) defaultSort");
        }
        this.defaultSort = defaultSort;
    }

    /**
     * @return List of attributeNames of all lookupField FieldDefinitions associated with this LookupDefinition, in the order in
     *         which they were added
     */
    public List getLookupFieldNames() {
        List fieldNames = new ArrayList();
        fieldNames.addAll(this.lookupFieldMap.keySet());

        return fieldNames;
    }

    /**
     * @return Collection of all lookupField FieldDefinitions associated with this LookupDefinition, in the order in which they were
     *         added
     */
    public List<FieldDefinition> getLookupFields() {
        return lookupFields;
    }

    /**
     * @return FieldDefinition associated with the named lookup field, or null if there is none
     * @param fieldName
     */
    public FieldDefinition getLookupField(String attributeName) {
        return lookupFieldMap.get(attributeName);
    }

    /**
     * @return List of attributeNames of all resultField FieldDefinitions associated with this LookupDefinition, in the order in
     *         which they were added
     */
    public List<String> getResultFieldNames() {
        List<String> fieldNames = new ArrayList<String>();
        fieldNames.addAll(resultFieldMap.keySet());

        return fieldNames;
    }

    /**
     * @return Collection of all resultField FieldDefinitions associated with this LookupDefinition, in the order in which they were
     *         added
     */
    public List<FieldDefinition> getResultFields() {
        return resultFields;
    }


    /**
     * @return FieldDefinition associated with the named result field, or null if there is none
     * @param fieldName
     */
    public FieldDefinition getResultField(String attributeName) {
        return resultFieldMap.get(attributeName);
    }

    /**
     * @param resultSetLimit the resultSetLimit to set
     */
    public void setResultSetLimit(Integer resultSetLimit) {
        this.resultSetLimit = resultSetLimit;
    }

    /**
     * @return true if this instance has instructions
     */
    public boolean hasResultSetLimit() {
        return (resultSetLimit != null);
    }


    /**
     * @return the resultSetLimit
     */
    public Integer getResultSetLimit() {
        return resultSetLimit;
    }

    /**
     * Directly validate simple fields, call completeValidation on Definition fields.
     *
     * @see org.kuali.core.datadictionary.DataDictionaryDefinition#completeValidation(java.lang.Class, java.lang.Object)
     */
    public void completeValidation(Class rootBusinessObjectClass, Class otherBusinessObjectClass) {
        if (hasDefaultSort()) {
            defaultSort.completeValidation(rootBusinessObjectClass, null);
        }

        for ( FieldDefinition lookupField : lookupFields ) {
            lookupField.completeValidation(rootBusinessObjectClass, null);
        }

        for ( FieldDefinition resultField : resultFields ) {
            resultField.completeValidation(rootBusinessObjectClass, null);
        }
    }

    /**
     * @return true if this instance has extraButtonSource
     */
    public boolean hasExtraButtonSource() {
        return extraButtonSource != null;
    }

    /**
     * @return extraButtonSource
     */
    public String getExtraButtonSource() {
        return extraButtonSource;
    }

    /**
     * Sets extraButtonParams to the given value.
     *
     * @param extraButtonParams
     * @throws IllegalArgumentException if the given source is blank
     */
    public void setExtraButtonSource(String extraButtonSource) {
        if (StringUtils.isBlank(extraButtonSource)) {
            throw new IllegalArgumentException("invalid (blank) button source");
        }
        this.extraButtonSource = extraButtonSource;
    }

    /**
     * @return true if this instance has extraButtonParams
     */
    public boolean hasExtraButtonParams() {
        return extraButtonParams != null;
    }

    /**
     * @return extraButtonParams
     */
    public String getExtraButtonParams() {
        return extraButtonParams;
    }

    /**
     * Sets extraButtonParams to the given value.
     *
     * @param extraButtonParams
     */
    public void setExtraButtonParams(String extraButtonParams) {
        this.extraButtonParams = extraButtonParams;
    }

    public String toString() {
        return "LookupDefinition '" + getTitle() + "'";
    }

    public void setLookupFields(List<FieldDefinition> lookupFields) {
        lookupFieldMap.clear();
        for ( FieldDefinition lookupField : lookupFields ) {
            if (lookupField == null) {
                throw new IllegalArgumentException("invalid (null) lookupField");
            }
            String keyName = lookupField.getAttributeName();
            if (lookupFieldMap.containsKey(keyName)) {
                throw new DuplicateEntryException("duplicate lookupField entry for attribute '" + keyName + "'");
            }

            lookupFieldMap.put(keyName, lookupField);
        }
        this.lookupFields = lookupFields;
    }

    public void setResultFields(List<FieldDefinition> resultFields) {
        resultFieldMap.clear();
        for ( FieldDefinition resultField : resultFields ) {
            if (resultField == null) {
                throw new IllegalArgumentException("invalid (null) resultField");
            }
    
            String keyName = resultField.getAttributeName();
            if (resultFieldMap.containsKey(keyName)) {
                throw new DuplicateEntryException("duplicate resultField entry for attribute '" + keyName + "'");
            }
    
            resultFieldMap.put(keyName, resultField);
        }
        this.resultFields = resultFields;
    }
}