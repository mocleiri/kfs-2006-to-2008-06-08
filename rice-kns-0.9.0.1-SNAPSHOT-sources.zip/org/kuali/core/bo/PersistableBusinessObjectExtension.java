package org.kuali.core.bo;

public interface PersistableBusinessObjectExtension extends
		PersistableBusinessObject {

}
