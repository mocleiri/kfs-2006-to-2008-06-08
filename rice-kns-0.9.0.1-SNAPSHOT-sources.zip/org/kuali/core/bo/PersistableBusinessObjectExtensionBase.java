package org.kuali.core.bo;

import java.util.LinkedHashMap;

public class PersistableBusinessObjectExtensionBase extends
		PersistableBusinessObjectBase implements
		PersistableBusinessObjectExtension {

	@Override
	protected LinkedHashMap toStringMapper() {
		// TODO Auto-generated method stub
		return null;
	}

}
