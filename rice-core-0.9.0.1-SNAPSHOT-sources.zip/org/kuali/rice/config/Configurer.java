package org.kuali.rice.config;

import org.kuali.rice.lifecycle.Lifecycle;

public interface Configurer extends Lifecycle {
    // marker interface
}
