var g_ContentsURL = "kfsonlinehelp.htm-toc.htm";
var g_IndexURL = "kfsonlinehelp.htm-index.htm";
var g_SearchURL = "kfsonlinehelp.htm-search.htm";
var g_FavoritesURL = "kfsonlinehelp.htm-favorites.htm";
