// global members
var _d2hSecondaryWindowsByTopics = null;
function d2hInitSecondaryWindows()
{
    if (_d2hSecondaryWindowsByTopics == null)
    {
        _d2hSecondaryWindowsByTopics = new Array();
        _d2hSecondaryWindowsByTopics["worddocuments/cashdraweractivitytab1.htm"] = "d2hWnd_SecondaryPopup";

    }
}

function newDocContext(strTitle, strData)
{
    var elem = "<html><head>"
    if (strTitle != "")
        elem += "<title>" + strTitle + "</title>";
    elem += "</head><body>";
    elem += strData;
    elem += "</body></html>";
    document.clear();
    document.write(elem);
}

var _d2hAppletInitialized = 0;
function browserNotSupported()
{
    var strData = MSG_BROWSERNOTSUPPORTED;
    document.forms[1].innerHTML = strData;
}

function errorHandler(error)
{
    var strData = error == 0 ? MSG_SEARCHENGINENOTLOADED : MSG_SEARCHENGINENOTLOADED_PATHCONTAINSNONASCII;
    document.forms[1].innerHTML = strData;
    return true;
}

function d2hAppletInitialized()
{
    _d2hAppletInitialized = -1;
}

function accessibilityTest(win, app, func)
{
    if (_d2hAppletInitialized != -1 && _d2hAppletInitialized < 50)
    {
        _d2hAppletInitialized ++;
        setTimeout("processQuery()", 100);
    }
    else if (_d2hAppletInitialized == -1)
        return true;
    else
    {
        var root = d2hGetRoot(win.location.pathname);
        root = unescape(root);
        if (d2hIsAsciiOnly(root))
            func(0);
        else
            func(1);
    }
    return false;
}
function jhSearch(doc, app, strQuery)
{
    display(doc, app.execQuery(strQuery));
}

function display(doc, content)
{
    var elem = doc.forms[1];
    if (elem.parentNode)
        elem.parentNode.setAttribute("nowrap", true);
    waitCursor(doc, true);
    elem.innerHTML = content;
    waitCursor(doc, false);
}

function waitCursor(doc, isWait)
{
}
