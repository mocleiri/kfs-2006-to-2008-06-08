package edu.iu.uis.eden.messaging.threadpool;

import org.kuali.rice.lifecycle.Lifecycle;

import edu.emory.mathcs.backport.java.util.concurrent.ScheduledExecutorService;

public interface KSBScheduledPool extends ScheduledExecutorService, Lifecycle {

}
