package org.kuali.bus.ojb;

import org.kuali.rice.ojb.BaseOjbConfigurer;

public class OjbConfigurer extends BaseOjbConfigurer {

	private static final String DEFAULT_KSB_REPOSITORY_METADATA = "classpath:OJB-repository-ksb.xml";
	private static final String KSB_MESSAGE_JCD_ALIAS = "ksbMessageDataSource";
	private static final String KSB_REGISTRY_JCD_ALIAS = "ksbRegistryDataSource";

	@Override
	protected String[] getJcdAliases() {
		return new String[] { KSB_MESSAGE_JCD_ALIAS, KSB_REGISTRY_JCD_ALIAS };
	}

	@Override
	protected String getMetadataLocation() {
		return DEFAULT_KSB_REPOSITORY_METADATA;
	}
}