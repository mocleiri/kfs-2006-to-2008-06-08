package org.bouncycastle.ocsp;

public interface CertificateStatus
{
    public static final CertificateStatus GOOD = null;
}
