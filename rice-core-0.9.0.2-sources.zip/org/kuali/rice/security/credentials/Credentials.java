package org.kuali.rice.security.credentials;

/**
 * Marker interface for credentials.
 * 
 * @author Scott Battaglia
 * @version $Revision: 1.2 $ $Date: 2007/06/19 14:35:13 $
 * @since 0.9
 *
 */
public interface Credentials {
	// marker interface
}
