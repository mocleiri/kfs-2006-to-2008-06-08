package org.kuali.rice.config;

public interface ConfigHolder {

	public Config getConfig();

}
