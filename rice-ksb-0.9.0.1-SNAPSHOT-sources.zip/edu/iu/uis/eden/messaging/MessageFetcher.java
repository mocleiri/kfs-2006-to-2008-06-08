package edu.iu.uis.eden.messaging;

import org.apache.log4j.Logger;
import org.kuali.bus.services.KSBServiceLocator;
import org.kuali.rice.RiceConstants;
import org.springframework.transaction.TransactionStatus;
import org.springframework.transaction.support.TransactionCallback;

/**
 * Fetches messages from the db. Marks as 'R'. Gives messages to ThreadPool for execution
 * 
 * @author rkirkend
 * 
 */
public class MessageFetcher implements Runnable {

    private static final Logger LOG = Logger.getLogger(MessageFetcher.class);

    private Integer maxMessages;
    private Long routeQueueId;

    public MessageFetcher(Integer maxMessages) {
	this.maxMessages = maxMessages;
    }

    public MessageFetcher(Long routeQueueId) {
	this.routeQueueId = routeQueueId;
    }

    public void run() {
	try {
	    requeueDocument();
	    requeueMessages();
	} catch (Throwable t) {
	    LOG.error("Failed to fetch messages.", t);
	}
    }

    private void requeueMessages() {
	if (this.routeQueueId == null) {
	    try {
		for (final PersistedMessage message : getRouteQueueService().getNextDocuments(maxMessages)) {
		    markEnrouteAndSaveMessage(message);
		    executeMessage(message);
		}
	    } catch (Throwable t) {
		LOG.error("Failed to fetch or process some messages during requeueMessages", t);
	    }
	}
    }

    private void requeueDocument() {
	try {
	    if (this.routeQueueId != null) {
		PersistedMessage message = getRouteQueueService().findByRouteQueueId(this.routeQueueId);
		message.setQueueStatus(RiceConstants.ROUTE_QUEUE_ROUTING);
		getRouteQueueService().save(message);
		executeMessage(message);
	    }
	} catch (Throwable t) {
	    LOG.error("Failed to fetch or process some messages during requeueDocument", t);
	}
    }

    private void executeMessage(PersistedMessage message) {
	try {
	    KSBServiceLocator.getThreadPool().execute(new MessageServiceInvoker(message));
	} catch (Throwable t) {
	    LOG.error("Failed to place message " + message + " in thread pool for execution", t);
	}
    }

    private void markEnrouteAndSaveMessage(final PersistedMessage message) {
	try {
	    KSBServiceLocator.getTransactionTemplate().execute(new TransactionCallback() {
		public Object doInTransaction(TransactionStatus status) {
		    message.setQueueStatus(RiceConstants.ROUTE_QUEUE_ROUTING);
		    getRouteQueueService().save(message);
		    return null;
		}
	    });
	} catch (Throwable t) {
	    LOG.error("Caught error attempting to mark message " + message + " as R", t);
	}
    }

    private MessageQueueService getRouteQueueService() {
	return KSBServiceLocator.getRouteQueueService();
    }

}
