package edu.iu.uis.eden.messaging;

public class MessageProcessingException extends RuntimeException {

	/**
	 * 
	 */
	private static final long serialVersionUID = -1757928630462729547L;

	public MessageProcessingException(Throwable t) {
		super(t);
	}
	
}
