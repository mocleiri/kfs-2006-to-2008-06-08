/*
 * Copyright 2005-2007 The Kuali Foundation.
 * 
 * 
 * Licensed under the Educational Community License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 * http://www.opensource.org/licenses/ecl1.php
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package edu.iu.uis.eden.docsearch.dao;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import org.apache.ojb.broker.PersistenceBroker;
import org.apache.ojb.broker.accesslayer.LookupException;
import org.springmodules.orm.ojb.OjbFactoryUtils;
import org.springmodules.orm.ojb.support.PersistenceBrokerDaoSupport;

import edu.iu.uis.eden.docsearch.DocSearchCriteriaVO;
import edu.iu.uis.eden.docsearch.DocumentSearchGenerator;
import edu.iu.uis.eden.exception.EdenUserNotFoundException;

public class DocumentSearchDAOOjbImpl extends PersistenceBrokerDaoSupport implements DocumentSearchDAO {

    public static final org.apache.log4j.Logger LOG = org.apache.log4j.Logger.getLogger(DocumentSearchDAOOjbImpl.class);

    public List getList(DocumentSearchGenerator documentSearchGenerator,DocSearchCriteriaVO criteria) throws EdenUserNotFoundException {
        LOG.info("start getList");
        
        List docList = new ArrayList();
        PersistenceBroker broker = null;
        Connection conn = null;
        Statement statement = null;
        ResultSet rs = null;
        try {
            broker = getPersistenceBroker(false);
            conn = broker.serviceConnectionManager().getConnection();
            String sql = documentSearchGenerator.generateSearchSql(criteria);
            LOG.debug("Executing document search w/page size="+DocSearchCriteriaVO.SEARCH_RESULT_FETCH_SIZE+": " + sql);
            statement = conn.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE,ResultSet.CONCUR_READ_ONLY);
            // new paging for patch
            statement.setFetchSize(DocSearchCriteriaVO.SEARCH_RESULT_FETCH_SIZE);
//            statement.setMaxRows(DocSearchCriteriaVO.SEARCH_RESULT_CAP+1);
            // ...end paging
            rs = statement.executeQuery(sql);
            // TODO delyea - look at refactoring
            docList = documentSearchGenerator.processResultSet(rs, criteria);
        } catch (SQLException sqle) {
        	String errorMsg = "SQLException: " + sqle.getMessage();
            LOG.error("getList() " + errorMsg, sqle);
            throw new RuntimeException(errorMsg,sqle);
        } catch (LookupException le) {
        	String errorMsg = "LookupException: " + le.getMessage();
            LOG.error("getList() " + errorMsg, le);
            throw new RuntimeException(errorMsg,le);
        } finally {
        	if (rs != null) {
        		try {
        			rs.close();
        		} catch (SQLException e) {
        			LOG.warn("Could not close result set.");
        		}
        	}
        	if (statement != null) {
        		try {
        			statement.close();
        		} catch (SQLException e) {
        			LOG.warn("Could not close statement.");
        		}
        	}
        	if (broker != null) {
        		try {
        			OjbFactoryUtils.releasePersistenceBroker(broker, this.getPersistenceBrokerTemplate().getPbKey());
        		} catch (Exception e) {
        			LOG.error("Failed closing connection: " + e.getMessage(), e);
        		}
        	}
        }

        LOG.info("end getlist");
        return docList;
    }
//    
//    protected Platform getPlatform() {
//    	return (Platform)GlobalResourceLoader.getService(KEWServiceLocator.DB_PLATFORM);
//    }
}