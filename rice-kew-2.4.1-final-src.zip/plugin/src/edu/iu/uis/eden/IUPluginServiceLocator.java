/*
 * Copyright 2005-2007 The Kuali Foundation.
 * 
 * 
 * Licensed under the Educational Community License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 * http://www.opensource.org/licenses/ecl1.php
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package edu.iu.uis.eden;

import edu.iu.uis.eden.account.AccountService;
import edu.iu.uis.eden.fiscalsub.FiscalSubAccountService;
import edu.iu.uis.eden.fisdata.FISDataService;
import edu.iu.uis.eden.user.UserService;
import edu.iu.uis.eden.workgroup.WorkgroupService;

/**
 * This Service Locator should be used by application plugins at Indiana University.
 * 
 * @author ewestfal
 */
public class IUPluginServiceLocator {

    public static UserService getUserService() {
        return KEWServiceLocator.getUserService();
    }
    
    public static WorkgroupService getWorkgroupService() {
        return KEWServiceLocator.getWorkgroupService();
    }
        
    public static AccountService getAccountService() {
        return IUServiceLocator.getAccountService();
    }
    
    public static FiscalSubAccountService getFiscalSubAccountService() {
        return IUServiceLocator.getFiscalSubAccountService();
    }
   
    public static FISDataService getFISDataService() {
        return IUServiceLocator.getFISDataService();
    }
    
}
