/*
 * Copyright 2005-2007 The Kuali Foundation.
 * 
 * 
 * Licensed under the Educational Community License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 * http://www.opensource.org/licenses/ecl1.php
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package edu.iu.uis.eden.routing.chartorgnode;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.jdom.Element;

import edu.iu.uis.eden.IUServiceLocator;
import edu.iu.uis.eden.KEWServiceLocator;
import edu.iu.uis.eden.WorkflowServiceErrorException;
import edu.iu.uis.eden.doctype.DocumentType;
import edu.iu.uis.eden.engine.RouteContext;
import edu.iu.uis.eden.engine.RouteHelper;
import edu.iu.uis.eden.engine.node.Branch;
import edu.iu.uis.eden.engine.node.DynamicNode;
import edu.iu.uis.eden.engine.node.DynamicResult;
import edu.iu.uis.eden.engine.node.NoOpNode;
import edu.iu.uis.eden.engine.node.NodeState;
import edu.iu.uis.eden.engine.node.Process;
import edu.iu.uis.eden.engine.node.RequestsNode;
import edu.iu.uis.eden.engine.node.RouteNode;
import edu.iu.uis.eden.engine.node.RouteNodeInstance;
import edu.iu.uis.eden.engine.node.SimpleJoinNode;
import edu.iu.uis.eden.engine.node.SimpleSplitNode;
import edu.iu.uis.eden.engine.transition.SplitTransitionEngine;
import edu.iu.uis.eden.fisdata.Organization;
import edu.iu.uis.eden.routeheader.DocumentContent;
import edu.iu.uis.eden.routeheader.StandardDocumentContent;
import edu.iu.uis.eden.services.docelements.UniversityOrganizationElement;
import edu.iu.uis.eden.util.XmlHelper;

public class ChartOrgRoutingNode implements DynamicNode {

	protected final org.apache.log4j.Logger LOG = org.apache.log4j.Logger.getLogger(getClass());
	
    protected static final String SPLIT_PROCESS_NAME = "Organization Split";
    protected static final String JOIN_PROCESS_NAME = "Organization Join";
    protected static final String REQUEST_PROCESS_NAME = "Organization Request";
    protected static final String NO_CHART_ORG_NAME = "No ChartOrg";

    public static final String CHART_NODE_STATE_KEY = "chart";
    public static final String ORG_NODE_STATE_KEY = "org";

    //constants for the process state in tracking org we've traveled
    private static final String VISITED_ORGS = "visited_orgs";
    private static final String V_ORGS_DEL = ",";
    private static final String CHART_ORG_DEL = "-";
    
    private static final String INITIAL_SPLIT_NODE_MARKER = "InitialSplitNode";

    public DynamicResult transitioningInto(RouteContext context, RouteNodeInstance dynamicNodeInstance, RouteHelper helper) throws Exception {

        DocumentType documentType = setUpDocumentType(context.getDocument().getDocumentType(), dynamicNodeInstance);
        RouteNode splitNode = documentType.getNamedProcess(SPLIT_PROCESS_NAME).getInitialRouteNode();

        //set up initial SplitNodeInstance
        RouteNodeInstance splitNodeInstance = helper.getNodeFactory().createRouteNodeInstance(context.getDocument().getRouteHeaderId(), splitNode);
        splitNodeInstance.setBranch(dynamicNodeInstance.getBranch());
        markAsInitialSplitNode(splitNodeInstance);
        
        int i = 0;
        List orgs = getXMLOrgs(new StandardDocumentContent(context.getDocument().getDocContent()));
        if (orgs.isEmpty()) {
            // if we have no chart/orgs, then just return a no-op node with IU-UNIV attached, this will terminate the process
            RouteNode noChartOrgNode = documentType.getNamedProcess(NO_CHART_ORG_NAME).getInitialRouteNode();
            RouteNodeInstance noChartOrgInstance = helper.getNodeFactory().createRouteNodeInstance(context.getDocument().getRouteHeaderId(), noChartOrgNode);
            noChartOrgInstance.setBranch(dynamicNodeInstance.getBranch());
            noChartOrgInstance.addNodeState(new NodeState(CHART_NODE_STATE_KEY, "IU"));
            noChartOrgInstance.addNodeState(new NodeState(ORG_NODE_STATE_KEY, "UNIV"));
            return new DynamicResult(true, noChartOrgInstance);
        }
        for (Iterator iter = orgs.iterator(); iter.hasNext(); i++) {
            Organization org = (Organization) iter.next();
            RouteNode chartOrgNode = getChartOrgNode(org.getFinCoaCd(), org.getOrgCd(), documentType);
            createInitialRequestNodeInstance(org, splitNodeInstance, dynamicNodeInstance, chartOrgNode);
        }

        return new DynamicResult(false, splitNodeInstance);
    }

    public DynamicResult transitioningOutOf(RouteContext context, RouteHelper helper) throws Exception {

        RouteNodeInstance processInstance = context.getNodeInstance().getProcess();
        RouteNodeInstance chartOrgNode = context.getNodeInstance();
        Map chartOrgNodeMap = new HashMap();
        findChartOrgNodes(context, chartOrgNodeMap);//SpringServiceLocator.getRouteNodeService().findProcessNodeInstances(processInstance);
        String chartCd = chartOrgNode.getNodeState(CHART_NODE_STATE_KEY).getValue();
        String orgCd = chartOrgNode.getNodeState(ORG_NODE_STATE_KEY).getValue();
        if (chartCd.equals("IU") && orgCd.equals("UNIV")) {
            return new DynamicResult(true, null);
        }
        Organization org = IUServiceLocator.getFISDataService().findOrganization(chartCd, orgCd);
        //create a join node for the next node and attach any sibling orgs to the join
        //if no join node is necessary i.e. no siblings create a requests node
        InnerTransitionResult transition = canTransitionFrom(org, chartOrgNodeMap.values(), helper);
        DynamicResult result = null;
        if (transition.isCanTransition()) {
            DocumentType documentType = context.getDocument().getDocumentType();
            //          make a simple requests node
            RouteNodeInstance requestNode = createOrganizationalRequestNode(context, org, processInstance, helper);

            if (transition.getSiblings().isEmpty()) {
                result = new DynamicResult(false, requestNode);
            } else {

                //create a join to transition us to the next org
                RouteNode joinPrototype = documentType.getNamedProcess(JOIN_PROCESS_NAME).getInitialRouteNode();
                RouteNodeInstance joinNode = helper.getNodeFactory().createRouteNodeInstance(context.getDocument().getRouteHeaderId(), joinPrototype);
                String branchName = "Branch " + org.getFinCoaCd() + " " + org.getOrgCd();
                Branch joinBranch = helper.getNodeFactory().createBranch(branchName, null, joinNode);
                joinNode.setBranch(joinBranch);

                for (Iterator iterator = transition.getSiblings().iterator(); iterator.hasNext();) {
                    RouteNodeInstance sibling = (RouteNodeInstance) iterator.next();
                    helper.getJoinEngine().addExpectedJoiner(joinNode, sibling.getBranch());
                }

                //set the next org after the join
                joinNode.addNextNodeInstance(requestNode);

                result = new DynamicResult(false, joinNode);
            }

        } else {
            result = new DynamicResult(false, null);
        }
        result.getNextNodeInstances().addAll(getNewlyAddedOrgRouteInstances(context, helper));
        return result;
    }
    
    private void findChartOrgNodes(RouteContext context, Map chartOrgNodes) {
        List nodeInstances = KEWServiceLocator.getRouteNodeService().getFlattenedNodeInstances(context.getDocument(), true);
        for (Iterator iterator = nodeInstances.iterator(); iterator.hasNext();) {
            RouteNodeInstance nodeInstance = (RouteNodeInstance) iterator.next();
            if (nodeInstance.getNodeState(CHART_NODE_STATE_KEY) != null && nodeInstance.getNodeState(ORG_NODE_STATE_KEY) != null) {
                chartOrgNodes.put(nodeInstance.getRouteNodeInstanceId(), nodeInstance);
            }
        }
    }
    
    /**
     * Constructs a Map of RouteNodeInstances which represent the ChartOrgNodes attached the the currently running
     * dynamic node process.  The initial invocation of this method should pass an empty map which will be used as the
     * accumulator for the return value;
     * 
     * We can't go to the db for this because when in simulation these RouteNodeInstances will be in memory
     */
    /*private void findChartOrgNodes(RouteHelper helper, RouteNodeInstance chartOrgNode, RouteNodeInstance process, Map chartOrgNodes) {
        if (chartOrgNode.getProcess() != null &&
                process.getRouteNodeInstanceId().equals(chartOrgNode.getProcess().getRouteNodeInstanceId()) &&
                !chartOrgNodes.containsKey(chartOrgNode.getRouteNodeInstanceId())) {
            if (chartOrgNode.getNodeState(CHART_NODE_STATE_KEY) != null && chartOrgNode.getNodeState(ORG_NODE_STATE_KEY) != null) {
                chartOrgNodes.put(chartOrgNode.getRouteNodeInstanceId(), chartOrgNode);
            }
            // this will only be used in the case where the dynamic node returns a sub process and that sub process is given the organization state
            // that would normally be applied to the node, this will usually happen as a result of overriding the getChartOrgNode method below.
            // ERA example: ERADOC -> DynamicChartOrgNode -> ChartOrgRoutingNode -> SubProcess -> (RSP -> RSP Dispatch), so in this case
            // we are getting the ChartOrgRoutingNode as the passed in process, but the RSP or RSP Dispatch node is the chartOrgNode and the
            // chart+org state is on the SubProcess.
            else if (chartOrgNode.getProcess().getNodeState(CHART_NODE_STATE_KEY) != null && chartOrgNode.getProcess().getNodeState(ORG_NODE_STATE_KEY) != null) {
                chartOrgNodes.put(chartOrgNode.getProcess().getRouteNodeInstanceId(), chartOrgNode.getProcess());
            }
            // We are attempting to get a flattened view of the entire graph of nodes created by
            // this dynamic node and since our initial node of entry into this method is a leaf,
            // we'll look backward and forward.
            // The containsKey check above will prevent us from recursing infinitely.
            chartOrgNode = findNavigationalNodeInstance(chartOrgNode);
            findChartOrgNodes(helper, chartOrgNode.getNextNodeInstances(), process, chartOrgNodes);
            findChartOrgNodes(helper, chartOrgNode.getPreviousNodeInstances(), process, chartOrgNodes);
        }
    }
    
    private void findChartOrgNodes(RouteHelper helper, List nodeInstances, RouteNodeInstance process, Map chartOrgNodes) {
        if (nodeInstances != null) {
            for (Iterator iterator = nodeInstances.iterator(); iterator.hasNext();) {
                RouteNodeInstance nodeInstance = (RouteNodeInstance) iterator.next();
                findChartOrgNodes(helper, nodeInstance, process, chartOrgNodes);
            }
        }
    }*/
    
    /**
     * If the given node actually represents a sub process or a dynamic node, this method will return the initial node within
     * that process.  We need to be able to do this because a sub process node instance has no previous or next nodes so we need
     * to be able to have a way to hook into the navigational structure of the document route to be able to walk backwards and
     * forwards along the route path. 
     */
    //private RouteNodeInstance findNavigationalNodeInstance(DocumentRouteHeaderValue document, RouteNodeInstance processNodeInstance) {
    //    List flattenedNodeInstances = SpringServiceLocator.getRouteNodeService().getF
        
    //}

    private RouteNodeInstance createOrganizationalRequestNode(RouteContext context, Organization org, RouteNodeInstance processInstance, RouteHelper helper) {
        Organization futureOrg = new Organization();
        futureOrg.setFinCoaCd(org.getReportsToChart());
        futureOrg.setOrgCd(org.getReportsToOrg());
        RouteNode requestsPrototype = getChartOrgNode(futureOrg.getFinCoaCd(), futureOrg.getOrgCd(), context.getDocument().getDocumentType());
        RouteNodeInstance requestNode = helper.getNodeFactory().createRouteNodeInstance(context.getDocument().getRouteHeaderId(), requestsPrototype);
        requestNode.setBranch(processInstance.getBranch());
        requestNode.addNodeState(new NodeState(CHART_NODE_STATE_KEY, futureOrg.getFinCoaCd()));
        requestNode.addNodeState(new NodeState(ORG_NODE_STATE_KEY, futureOrg.getOrgCd()));
        addOrganizationToProcessState(processInstance, futureOrg);
        return requestNode;
    }

    /**
     * i can only transition from this if all the nodes left are completed immediate siblings
     * 
     * @param org
     * @param chartOrgNodes
     * @return List of Nodes that are siblings to the org passed in
     */
    private InnerTransitionResult canTransitionFrom(Organization currentOrg, Collection chartOrgNodes, RouteHelper helper) {

        InnerTransitionResult result = new InnerTransitionResult();
        result.setCanTransition(false);

        for (Iterator iter = chartOrgNodes.iterator(); iter.hasNext();) {
            RouteNodeInstance chartOrgNode = (RouteNodeInstance) iter.next();
            NodeState chartState = chartOrgNode.getNodeState(CHART_NODE_STATE_KEY);
            NodeState orgState = chartOrgNode.getNodeState(ORG_NODE_STATE_KEY);
            // continue if this node has no chart/org state
            if (chartState == null || orgState == null) {
                continue;
            }
            String chartCd = chartState.getValue();
            String orgCd = orgState.getValue();
            if (currentOrg.getFinCoaCd().equals(chartCd) && currentOrg.getOrgCd().equals(orgCd)) {
                continue;
            }

            Organization nodeOrg = IUServiceLocator.getFISDataService().findOrganization(chartCd, orgCd);
            Organization parent = IUServiceLocator.getFISDataService().findOrganization(currentOrg.getReportsToChart(), currentOrg.getReportsToOrg());
            if ((parent.getFinCoaCd().equals("IU") && parent.getOrgCd().equals("UNIV")) || hasAsParent(parent, nodeOrg)) {
                if (chartOrgNode.isActive()) {
                    return result;
                }
                //it's done and has our parent as a parent is it a direct sibling? if not let the other branch(s) catch up
                if (parent.getFinCoaCd().equals(currentOrg.getFinCoaCd()) && parent.getOrgCd().equals(currentOrg.getOrgCd())) {
                    result.getSiblings().add(chartOrgNode);
                }
            }
        }
        result.setCanTransition(true);
        return result;
    }

    private static class InnerTransitionResult {
        private boolean canTransition;
        private List siblings = new ArrayList();

        public boolean isCanTransition() {
            return canTransition;
        }

        public void setCanTransition(boolean canTransition) {
            this.canTransition = canTransition;
        }

        public List getSiblings() {
            return siblings;
        }

        public void setSiblings(List siblings) {
            this.siblings = siblings;
        }
    }

    private static void markAsInitialSplitNode(RouteNodeInstance splitNode) {
        splitNode.addNodeState(new NodeState(INITIAL_SPLIT_NODE_MARKER, INITIAL_SPLIT_NODE_MARKER));
    }

    /**
     * @param routeNodeInstance
     * @return
     */
    private static boolean isInitialSplitNode(RouteNodeInstance routeNodeInstance) {
        return routeNodeInstance.getNodeState(INITIAL_SPLIT_NODE_MARKER) != null;
    }

    /**
     * Adds the org to the process state 
     * @param processInstance
     * @param org
     */
    private static void addOrganizationToProcessState(RouteNodeInstance processInstance, Organization org) {
        String orgStateName = renderOrganizationForProcessState(org);
        NodeState visitedOrgsState = processInstance.getNodeState(VISITED_ORGS);
        if (visitedOrgsState == null) {
            processInstance.addNodeState(new NodeState(VISITED_ORGS, orgStateName + V_ORGS_DEL));
        } else if (! getVisitedOrgsList(processInstance).contains(orgStateName)) {
            visitedOrgsState.setValue(visitedOrgsState.getValue() + orgStateName + V_ORGS_DEL);
        }
    }
    
    /**
     * @param process
     * @return List of org strings on the process state
     */
    private static List getVisitedOrgsList(RouteNodeInstance process) {
        return Arrays.asList(process.getNodeState(VISITED_ORGS).getValue().split(V_ORGS_DEL));
    }
    
    /**
     * Determines if the org has been routed to or will be.
     * @param org
     * @param process
     * @return boolean if this is an org we would not hit in routing
     */
    private static boolean isNewOrganization(Organization org, RouteNodeInstance process) {
        
        String orgStateName = renderOrganizationForProcessState(org);
        List visitedOrgs = getVisitedOrgsList(process);
        boolean isInVisitedList = visitedOrgs.contains(orgStateName);
        if (isInVisitedList) {
            return false;
        }
        boolean willEventualRouteThere = false;
        //determine if we will eventually route to this chart anyway
        for (Iterator iter = visitedOrgs.iterator(); iter.hasNext() && willEventualRouteThere == false; ) {
            String[] orgStrings = ((String) iter.next()).split(CHART_ORG_DEL);
            Organization visitedOrg = IUServiceLocator.getFISDataService().findOrganization(orgStrings[0], orgStrings[1]);
            willEventualRouteThere = hasAsParent(org, visitedOrg) || willEventualRouteThere;
        }
        return ! willEventualRouteThere;
    }

    /**
     * @param org
     * @return String representing org for process state
     */
    private static String renderOrganizationForProcessState(Organization org) {
        return org.getFinCoaCd() + CHART_ORG_DEL + org.getOrgCd();
    }

    /**
     * Creates a Org Request RouteNodeInstance that is a child of the passed in split.  This is used to create the initial 
     * request RouteNodeInstances off the begining split.
     * @param org
     * @param splitNodeInstance
     * @param processInstance
     * @param requestsNode
     * @return Request RouteNodeInstance bound to the passed in split as a 'nextNodeInstance'
     */
    private static RouteNodeInstance createInitialRequestNodeInstance(Organization org, RouteNodeInstance splitNodeInstance, RouteNodeInstance processInstance, RouteNode requestsNode) {
        String branchName = "Branch " + org.getFinCoaCd() + " " + org.getOrgCd();
        RouteNodeInstance orgRequestInstance = SplitTransitionEngine.createSplitChild(branchName, requestsNode, splitNodeInstance);
        splitNodeInstance.addNextNodeInstance(orgRequestInstance);
        orgRequestInstance.addNodeState(new NodeState(CHART_NODE_STATE_KEY, org.getFinCoaCd()));
        orgRequestInstance.addNodeState(new NodeState(ORG_NODE_STATE_KEY, org.getOrgCd()));
        addOrganizationToProcessState(processInstance, org);
        return orgRequestInstance;
    }
    
    /**
     * Check the xml and determine there are any orgs declared that we will not travel through on our current trajectory.
     * @param context
     * @param helper
     * @return RouteNodeInstances for any orgs we would not have traveled through that are now in the xml.
     * @throws Exception
     */
    private List getNewlyAddedOrgRouteInstances(RouteContext context, RouteHelper helper) throws Exception {
        RouteNodeInstance processInstance = context.getNodeInstance().getProcess();
        RouteNodeInstance chartOrgNode = context.getNodeInstance();
        //check for new orgs in the xml
        List orgs = getXMLOrgs(new StandardDocumentContent(context.getDocument().getDocContent()));
        List newOrgsRoutingTo = new ArrayList();
        for (Iterator iter = orgs.iterator(); iter.hasNext();) {
            Organization org = (Organization) iter.next();
            if (isNewOrganization(org, processInstance)) {
                //the idea here is to always use the object referenced by the engine so simulation can occur
                List processNodes = chartOrgNode.getPreviousNodeInstances();
                for (Iterator iterator = processNodes.iterator(); iterator.hasNext();) {
                    RouteNodeInstance splitNodeInstance = (RouteNodeInstance) iterator.next();
                    if (isInitialSplitNode(splitNodeInstance)) {                        
                        RouteNode requestsNode = getChartOrgNode(org.getFinCoaCd(), org.getOrgCd(), context.getDocument().getDocumentType());
                        RouteNodeInstance newOrgRequestNode = createInitialRequestNodeInstance(org, splitNodeInstance, processInstance, requestsNode);
                        newOrgsRoutingTo.add(newOrgRequestNode);
                    }
                }
            }
        }
        return newOrgsRoutingTo;
    }    
    
    /**
     * @param parent
     * @param child
     * @return true - if child or one of it's eventual parents reports to parent false - if child or one of it's eventual parents does not report to parent
     */
    private static boolean hasAsParent(Organization parent, Organization child) {
        if (child.getFinCoaCd().equals("IU") && child.getOrgCd().equals("UNIV")) {
            return false;
        } else if (parent.getFinCoaCd().equals(child.getFinCoaCd()) && parent.getOrgCd().equals(child.getOrgCd())) {
            return true;
        } else {
            child = IUServiceLocator.getFISDataService().findOrganization(child.getReportsToChart(), child.getReportsToOrg());
            return hasAsParent(parent, child);
        }
    }

    /**
     * Make the 'floating' split, join and request RouteNodes that will be independent processes. These are the prototypes from which our RouteNodeInstance will belong
     * 
     * @param documentType
     * @param dynamicNodeInstance
     */
    private DocumentType setUpDocumentType(DocumentType documentType, RouteNodeInstance dynamicNodeInstance) {
        boolean altered = false;
        if (documentType.getNamedProcess(SPLIT_PROCESS_NAME) == null) {
            RouteNode splitNode = getSplitNode(dynamicNodeInstance);
            documentType.addProcess(getPrototypeProcess(splitNode, documentType));
            altered = true;
        }
        if (documentType.getNamedProcess(JOIN_PROCESS_NAME) == null) {
            RouteNode joinNode = getJoinNode(dynamicNodeInstance);
            documentType.addProcess(getPrototypeProcess(joinNode, documentType));
            altered = true;
        }
        if (documentType.getNamedProcess(REQUEST_PROCESS_NAME) == null) {
            RouteNode requestsNode = getRequestNode(dynamicNodeInstance);
            documentType.addProcess(getPrototypeProcess(requestsNode, documentType));
            altered = true;
        }
        if (documentType.getNamedProcess(NO_CHART_ORG_NAME) == null) {
            RouteNode noChartOrgNode = getNoChartOrgNode(dynamicNodeInstance);
            documentType.addProcess(getPrototypeProcess(noChartOrgNode, documentType));
            altered = true;
        }
        if (altered) {
        	//side step normal version etc. because it's a pain.
            KEWServiceLocator.getDocumentTypeService().save(documentType);
        }
        return KEWServiceLocator.getDocumentTypeService().findByName(documentType.getName());
    }

    /**
     * Places a Process on the documentType wrapping the node and setting the node as the process's initalRouteNode
     * 
     * @param node
     * @param documentType
     * @return Process wrapping the node passed in
     */
    protected Process getPrototypeProcess(RouteNode node, DocumentType documentType) {
        Process process = new Process();
        process.setDocumentType(documentType);
        process.setInitial(false);
        process.setInitialRouteNode(node);
        process.setName(node.getRouteNodeName());
        return process;
    }

    /**
     * @param process
     * @return Route Node of the JoinNode that will be prototype for the split RouteNodeInstances generated by this component
     */
    private static RouteNode getSplitNode(RouteNodeInstance process) {
        RouteNode dynamicNode = process.getRouteNode();
        RouteNode splitNode = new RouteNode();
        splitNode.setActivationType(dynamicNode.getActivationType());
        splitNode.setDocumentType(dynamicNode.getDocumentType());
        splitNode.setFinalApprovalInd(dynamicNode.getFinalApprovalInd());
        splitNode.setExceptionWorkgroupId(dynamicNode.getExceptionWorkgroupId());
        splitNode.setMandatoryRouteInd(dynamicNode.getMandatoryRouteInd());
        splitNode.setNodeType(SimpleSplitNode.class.getName());
        splitNode.setRouteMethodCode("FR");
        splitNode.setRouteMethodName(null);
        splitNode.setRouteNodeName(SPLIT_PROCESS_NAME);
        return splitNode;
        //SubRequests
    }

    /**
     * @param process
     * @return Route Node of the JoinNode that will be prototype for the join RouteNodeInstances generated by this component
     */
    private static RouteNode getJoinNode(RouteNodeInstance process) {
        RouteNode dynamicNode = process.getRouteNode();
        RouteNode joinNode = new RouteNode();
        joinNode.setActivationType(dynamicNode.getActivationType());
        joinNode.setDocumentType(dynamicNode.getDocumentType());
        joinNode.setFinalApprovalInd(dynamicNode.getFinalApprovalInd());
        joinNode.setExceptionWorkgroupId(dynamicNode.getExceptionWorkgroupId());
        joinNode.setMandatoryRouteInd(dynamicNode.getMandatoryRouteInd());
        joinNode.setNodeType(SimpleJoinNode.class.getName());
        joinNode.setRouteMethodCode("FR");
        joinNode.setRouteMethodName(null);
        joinNode.setRouteNodeName(JOIN_PROCESS_NAME);
        return joinNode;
    }

    /**
     * @param process
     * @return RouteNode of RequestsNode that will be prototype for RouteNodeInstances having requets that are generated by this component
     */
    private static RouteNode getRequestNode(RouteNodeInstance process) {
        RouteNode dynamicNode = process.getRouteNode();
        RouteNode requestsNode = new RouteNode();
        requestsNode.setActivationType(dynamicNode.getActivationType());
        requestsNode.setDocumentType(dynamicNode.getDocumentType());
        requestsNode.setFinalApprovalInd(dynamicNode.getFinalApprovalInd());
        requestsNode.setExceptionWorkgroupId(dynamicNode.getExceptionWorkgroupId());
        requestsNode.setMandatoryRouteInd(dynamicNode.getMandatoryRouteInd());
        requestsNode.setNodeType(RequestsNode.class.getName());
        requestsNode.setRouteMethodCode("FR");
        requestsNode.setRouteMethodName(process.getRouteNode().getRouteMethodName());
        requestsNode.setRouteNodeName(REQUEST_PROCESS_NAME);
        return requestsNode;
    }

    /**
     * @param process
     * @return RouteNode of a no-op node which will be used if the user sends no Chart+Org XML to this routing component.
     */
    private static RouteNode getNoChartOrgNode(RouteNodeInstance process) {
        RouteNode dynamicNode = process.getRouteNode();
        RouteNode noChartOrgNOde = new RouteNode();
        noChartOrgNOde.setActivationType(dynamicNode.getActivationType());
        noChartOrgNOde.setDocumentType(dynamicNode.getDocumentType());
        noChartOrgNOde.setFinalApprovalInd(dynamicNode.getFinalApprovalInd());
        noChartOrgNOde.setExceptionWorkgroupId(dynamicNode.getExceptionWorkgroupId());
        noChartOrgNOde.setMandatoryRouteInd(dynamicNode.getMandatoryRouteInd());
        noChartOrgNOde.setNodeType(NoOpNode.class.getName());
        noChartOrgNOde.setRouteMethodCode("FR");
        noChartOrgNOde.setRouteMethodName(null);
        noChartOrgNOde.setRouteNodeName(NO_CHART_ORG_NAME);
        return noChartOrgNOde;
    }

    
    /**
     * Find all root orgs in the xml and convert them into a list of Organization objects
     * 
     * @param docContent
     * @return List Organization objects
     */
    private static List getXMLOrgs(DocumentContent docContent) {
        List xmlOrgs = new ArrayList();
        UniversityOrganizationElement univOrgElement = new UniversityOrganizationElement();
        Element rootElement = null;
        try {
            rootElement = XmlHelper.buildJDocument(docContent.getDocument()).getRootElement();
        } catch (Exception e) {
            throw new WorkflowServiceErrorException("Invalid XML submitted", new ArrayList());
        }
        List chartOrgElements = XmlHelper.findElements(rootElement, univOrgElement.getElementName());
        for (Iterator iter = chartOrgElements.iterator(); iter.hasNext();) {
            Element chartOrgElement = (Element) iter.next();
            try {
                univOrgElement.loadFromXMLContent(chartOrgElement, false);
            } catch (Exception e) {
                throw new WorkflowServiceErrorException("Problems loading chart org element from string " + docContent, new ArrayList());
            }
            Organization org = new Organization();
            org.setFinCoaCd(univOrgElement.getChart());
            org.setOrgCd(univOrgElement.getOrgCode());
            xmlOrgs.add(org);
        }
        return xmlOrgs;
    }
    
    // methods which can be overridden to change the chart org routing node behavior
    
    protected RouteNode getChartOrgNode(String chart, String org, DocumentType documentType) {
        return documentType.getNamedProcess(REQUEST_PROCESS_NAME).getInitialRouteNode();
    }
    
}