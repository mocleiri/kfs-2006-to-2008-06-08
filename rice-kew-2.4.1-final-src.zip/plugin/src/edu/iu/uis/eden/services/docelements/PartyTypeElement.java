/*
 * Copyright 2005-2007 The Kuali Foundation.
 * 
 * 
 * Licensed under the Educational Community License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 * http://www.opensource.org/licenses/ecl1.php
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package edu.iu.uis.eden.services.docelements;

import org.jdom.Element;

import edu.iu.uis.eden.EdenConstants;
import edu.iu.uis.eden.WorkflowServiceErrorImpl;
import edu.iu.uis.eden.exception.InvalidXmlException;
import edu.iu.uis.eden.services.IDocElement;
import edu.iu.uis.eden.services.InconsistentDocElementStateException;
import edu.iu.uis.eden.services.ServiceErrorConstants;


/**
 * <p>Title: PartyTypeElement</p>
 * <p>Description: Business Respresentation of the PartyType both as an
 * XML Element and business Rules. <br><BR>
 *  See IDocElement documentation for
 * further explanation.</p>
 * <p>Copyright: Copyright (c) 2002</p>
 * <p>Company: Indiana University</p>
 * @author Ryan Kirkendall
 * @version 1.0
 */
public class PartyTypeElement implements IDocElement {
  private static final org.apache.log4j.Logger LOG = org.apache.log4j.Logger.getLogger(PartyTypeElement.class);
  private static final String ELEMENT_NAME = "party_type";
  private static final String ATTRIBUTE_NAME = "value";
  private boolean routeControl;
  private String partyType;

  public PartyTypeElement() {
    LOG.debug("constructing . . . ");
  }

  public Element getXMLContent() {
    LOG.debug("getXMLContent");

    //return empty String if partyType empty or null
    if (this.isEmpty()) {
      LOG.debug("partyType empty or null return empty String");

      return null;
    }

    //make an element and XMLOutputter
    Element me = new Element(ELEMENT_NAME);
    me.setAttribute(ATTRIBUTE_NAME, this.partyType);

    LOG.debug("returning XMLContent = " + me.toString());

    return me;
  }

  public void loadFromXMLContent(Element element, boolean allowBlank)
    throws InvalidXmlException, InconsistentDocElementStateException {
    LOG.debug("loadFromXMLContent allowBlank = " + allowBlank);

    if (DocElementValidator.returnWithNoWorkDone(this, element, allowBlank)) {
      return;
    }

    this.partyType = element.getAttributeValue(ATTRIBUTE_NAME);
  }

  public WorkflowServiceErrorImpl validate() {
    LOG.debug("validate");

    //if partyType is empty or null return DocElementError otherwise return null
    if (this.isEmpty()) {
      LOG.debug("partyType null or blank return new DocElementError");

      return new WorkflowServiceErrorImpl("partyType is Empty", ServiceErrorConstants.PARTY_TYPE_BLANK);
    }

    /* validate against EdenConstants */
    if ((!partyType.equals(EdenConstants.ACTION_REQUEST_USER_RECIPIENT_CD)) &&
          (!partyType.equals(EdenConstants.ACTION_REQUEST_WORKGROUP_RECIPIENT_CD))) {
      LOG.debug("party Type invalid partyType = " + partyType);

      return new WorkflowServiceErrorImpl("PartyType is invalid", ServiceErrorConstants.PARTY_TYPE_INVALID);
    }

    LOG.debug("partyType is valid");

    return null;
  }

  /**
   * Tell whether the objects value property/properties have values
   *
   * @return true when object is empty
   */
  public boolean isEmpty() {
    LOG.debug("isEmpty()");

    if ((this.partyType == null) || this.partyType.trim().equals("")) {
      LOG.debug("empty");

      return true;
    }

    LOG.debug("not empty");

    return false;
  }

  public String getElementName() {
    LOG.debug("getElementName");

    return ELEMENT_NAME;
  }

  public void setRouteControl(boolean routeController) {
    LOG.debug("setRouteControl setting false . . .");
    this.routeControl = false;
  }

  public boolean isRouteControl() {
    LOG.debug("isRouteControl");

    return this.routeControl;
  }

  /**
   *
   * @param partyType partType String value of Party Type
   */
  public void setPartyType(String partyType) {
    LOG.debug("setPartyType partyType = " + partyType);

    /* cap it if it's not null otherwise let the dude set it null */
    if (partyType != null) {
      partyType = partyType.toUpperCase();
      partyType = partyType.trim();
    }

    this.partyType = partyType;
  }

  /**
   *
   * @return value of Party Type
   */
  public String getPartyType() {
    LOG.debug("getPartyType partyType = " + this.partyType);

    return this.partyType;
  }

  /**
   * @return true if party type is user, false if not including null
   */
  public boolean isUser() {
    LOG.debug("isUser()");

    if ((this.getPartyType() != null) &&
          this.getPartyType().equals(EdenConstants.ACTION_REQUEST_USER_RECIPIENT_CD)) {
      LOG.debug("yes - return true");

      return true;
    }

    LOG.debug("no - returning false");

    return false;
  }

  /**
   * @return true if party type is workgroup, false if not including null
   */
  public boolean isWorkGroup() {
    LOG.debug("isWorkGroup()");

    if ((this.getPartyType() != null) &&
          this.getPartyType().equals(EdenConstants.ACTION_REQUEST_WORKGROUP_RECIPIENT_CD)) {
      LOG.debug("yes - returning true");

      return true;
    }

    LOG.debug("no - return false");

    return false;
  }
}





/*
 * Copyright 2003 The Trustees of Indiana University.  All rights reserved.
 *
 * This file is part of the EDEN software package.
 * For license information, see the LICENSE file in the top level directory
 * of the EDEN source distribution.
 */
