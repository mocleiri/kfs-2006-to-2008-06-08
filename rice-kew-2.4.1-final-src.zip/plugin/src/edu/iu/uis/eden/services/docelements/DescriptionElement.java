/*
 * Copyright 2005-2007 The Kuali Foundation.
 * 
 * 
 * Licensed under the Educational Community License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 * http://www.opensource.org/licenses/ecl1.php
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package edu.iu.uis.eden.services.docelements;

import org.jdom.Element;

import edu.iu.uis.eden.WorkflowServiceErrorImpl;
import edu.iu.uis.eden.exception.InvalidXmlException;
import edu.iu.uis.eden.services.IDocElement;
import edu.iu.uis.eden.services.InconsistentDocElementStateException;
import edu.iu.uis.eden.services.ServiceErrorConstants;


/**
 * <p>Title: DescriptionElement </p>
 * <p>Description: light weight string base Element.  description is the
 * xml element name value is stored in.  Validation checks for
 * empty only</p>
 * <p>Copyright: Copyright (c) 2002</p>
 * <p>Company: Indiana University</p>
 * @author Ryan Kirkendall
 * @version 1.0
 */
public class DescriptionElement implements IDocElement {
  private static final org.apache.log4j.Logger LOG = org.apache.log4j.Logger.getLogger(DescriptionElement.class);
  private static String ELEMENT_NAME = "description";
  private GenericStringElement stringElement;

  public DescriptionElement() {
    LOG.debug("constructing . . .");
    stringElement = new GenericStringElement(ELEMENT_NAME, ServiceErrorConstants.DESCRIPTION_BLANK,
        false);
  }

  public Element getXMLContent() {
    LOG.debug("getXMLContent()");

    return this.stringElement.getXMLContent();
  }

  public void loadFromXMLContent(Element element, boolean allowBlank)
    throws InvalidXmlException, InconsistentDocElementStateException {
    LOG.debug("loadFromXMLContent() allowBlank = " + allowBlank);
    this.stringElement.loadFromXMLContent(element, allowBlank);
  }

  public WorkflowServiceErrorImpl validate() {
    LOG.debug("validate - description always valid returning null");

    return null;
  }

  public String getElementName() {
    return ELEMENT_NAME;
  }

  public boolean isEmpty() {
    LOG.debug("isEmpty");

    return this.stringElement.isEmpty();
  }

  public void setRouteControl(boolean routeControl) {
  }

  public boolean isRouteControl() {
    return false;
  }

  /**
   * @param description value of DescriptionElement
   */
  public void setDescription(String description) {
    this.stringElement.setMyValue(description);
  }

  /**
   * @return value of DescriptionElement
   */
  public String getDescription() {
    /* because this is always valid we could have a valid null
       lets give back an empty String if we have a null value */
    if (this.stringElement.getMyValue() == null) {
      LOG.debug("description null but valid return empty String");

      return "";
    }

    return this.stringElement.getMyValue();
  }
}





/*
 * Copyright 2003 The Trustees of Indiana University.  All rights reserved.
 *
 * This file is part of the EDEN software package.
 * For license information, see the LICENSE file in the top level directory
 * of the EDEN source distribution.
 */
