/*
 * Copyright 2005-2007 The Kuali Foundation.
 * 
 * 
 * Licensed under the Educational Community License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 * http://www.opensource.org/licenses/ecl1.php
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package edu.iu.uis.eden.services.docelements;

import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

import org.jdom.Element;

import edu.iu.uis.eden.WorkflowServiceErrorImpl;
import edu.iu.uis.eden.exception.InvalidXmlException;
import edu.iu.uis.eden.services.IDocElement;
import edu.iu.uis.eden.services.InconsistentDocElementStateException;


/**
 * <p>Title: HeaderElement</p>
 * <p>Description: Manages key/value pairs and allows them to be
 * xml'ed.  For associating non critical information that requires no
 * documentation with a document</p>
 * <p>Copyright: Copyright (c) 2002</p>
 * <p>Company: Indiana University</p>
 * @author Ryan Kirkendall
 * @version 1.0
 */
public class HeaderElement implements IDocElement {
  private static final org.apache.log4j.Logger LOG = org.apache.log4j.Logger.getLogger(HeaderElement.class);
  private static final String ELEMENT_NAME = "header";
  private static final String ATTRIBUTE_NAME = "value";
  private boolean routeControl;
  private HashMap index;

  public HeaderElement() {
    LOG.debug("constructing . . .");
    index = new HashMap();
    routeControl = false;
  }

  public Element getXMLContent() {
    LOG.debug("getXMLContent");

    //return null if we're empty
    if (this.isEmpty()) {
      LOG.debug("empty returning null");

      return null;
    }

    Element element = new Element(ELEMENT_NAME);

    //make an element for each of our keys
    Set keys = index.keySet();
    Iterator iter = keys.iterator();

    //iterate over the keys
    while (iter.hasNext()) {
      String key = (String) iter.next();
      LOG.debug("making element for key = " + key);

      Element keyValueEl = new Element(key);
      keyValueEl.setAttribute(ATTRIBUTE_NAME, (String) index.get(key));
      element.addContent(keyValueEl);
    }

    return element;
  }

  public void loadFromXMLContent(Element element, boolean allowBlank)
    throws InvalidXmlException, InconsistentDocElementStateException {
    LOG.debug("loadFromXMLContent allowBlank = " + allowBlank);

    if (DocElementValidator.returnWithNoWorkDone(this, element, allowBlank)) {
      LOG.debug("returning with no work done");

      return;
    }

    //each child element is a key/value pair
    List keyVals = element.getChildren();
    Iterator iter = keyVals.iterator();

    //populate index HashMap according to the elements in the list
    while (iter.hasNext()) {
      Element keyVal = (Element) iter.next();
      index.put(keyVal.getName(), keyVal.getAttributeValue(ATTRIBUTE_NAME));
    }
  }

  public WorkflowServiceErrorImpl validate() {
    LOG.debug("validate");
    LOG.debug("valid returning null");

    return null;
  }

  public String getElementName() {
    return ELEMENT_NAME;
  }

  public void setRouteControl(boolean routeControl) {
  }

  public boolean isEmpty() {
    LOG.debug("isEmpty()");

    if (index.size() == 0) {
      LOG.debug("empty returning true");

      return true;
    }

    LOG.debug("not empty returning false");

    return false;
  }

  public boolean isRouteControl() {
    return this.routeControl;
  }

  /**
   * Will associate Key/value pairs of non routing business data with the
   * document.  Pesistable through EDEN by xml
   *
   * @param key to access value
   * @param value business data stored and associated with a key
   */
  public void setKeyValuePair(String key, String value) {
    index.put(key, value);
  }

  /**
   *
   * @param key value is index by key
   * @return value indexed to the key
   */
  public String getValueByKey(String key) {
    return (String) index.get(key);
  }

  /**
   * @return keys in header
   */
  public Collection getKeys() {
    return this.index.keySet();
  }

  /**
   * @param key - the key to be found
   * @return -true if the header contains the key false if not.
   */
  public boolean containsKey(String key) {
    return this.index.containsKey(key);
  }

  /**
   * @param key - the key in the header to be removed.
   */
  public void removeKey(String key) {
    this.index.remove(key);
  }
}





/*
 * Copyright 2003 The Trustees of Indiana University.  All rights reserved.
 *
 * This file is part of the EDEN software package.
 * For license information, see the LICENSE file in the top level directory
 * of the EDEN source distribution.
 */
