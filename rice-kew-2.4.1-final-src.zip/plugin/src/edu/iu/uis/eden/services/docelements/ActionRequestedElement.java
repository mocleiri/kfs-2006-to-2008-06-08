/*
 * Copyright 2005-2007 The Kuali Foundation.
 * 
 * 
 * Licensed under the Educational Community License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 * http://www.opensource.org/licenses/ecl1.php
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package edu.iu.uis.eden.services.docelements;

import org.jdom.Element;

import edu.iu.uis.eden.EdenConstants;
import edu.iu.uis.eden.WorkflowServiceErrorImpl;
import edu.iu.uis.eden.exception.InvalidXmlException;
import edu.iu.uis.eden.services.IDocElement;
import edu.iu.uis.eden.services.InconsistentDocElementStateException;
import edu.iu.uis.eden.services.ServiceErrorConstants;


/**
 * <p>Title: ActionRequestedElement </p>
 * <p>Description: Represents a ActionRequested element both in xml for documents and as a
 * ActionRequested entity itself concerning validation. <br><BR>
 * See IDocElement documentation for
 * further explanation.</p>
 * <p>Copyright: Copyright (c) 2002</p>
 * <p>Company: Indiana University</p>
 * @author Ryan Kirkendall
 * @version 1.0
 */
public class ActionRequestedElement implements IDocElement {
  private static final org.apache.log4j.Logger LOG = org.apache.log4j.Logger.getLogger(DateElement.class);
  private static final String ATTRIBUTE_NAME = "value";
  private static final String ELEMENT_NAME = "action_requested";
  private boolean routeControl;
  private String actionRequested;

  public ActionRequestedElement() {
    LOG.debug("constructing . . .");
    this.routeControl = false;
  }

  public Element getXMLContent() {
    LOG.debug("getXMLContent");

    if (this.isEmpty()) {
      LOG.debug("actionRequested null or empty returning empty String");

      return null;
    }

    /* make element and output it */
    Element me = new Element(ELEMENT_NAME);
    me.setAttribute(ATTRIBUTE_NAME, this.getActionRequested());

    LOG.debug("return XMLContent " + me.toString());

    return me;
  }

  public void loadFromXMLContent(Element element, boolean allowBlank)
    throws InvalidXmlException, InconsistentDocElementStateException {
    LOG.debug("loadFromXMLContent");

    if (DocElementValidator.returnWithNoWorkDone(this, element, allowBlank)) {
      LOG.debug("returning without setting");

      return;
    }

    /* it's good load from element */
    this.actionRequested = element.getAttributeValue(ATTRIBUTE_NAME);
    LOG.debug("loaded. actionRequested = " + this.actionRequested);
  }

  public WorkflowServiceErrorImpl validate() {
    LOG.debug("validate");

    if (this.isEmpty()) {
      LOG.debug("invalid - empty");

      return new WorkflowServiceErrorImpl("ActionRequested empty",
        ServiceErrorConstants.ACTION_REQUESTED_BLANK);
    }

    /* get eden constants and make sure the action request is valid */
    String actionRequested = this.getActionRequested();

    if ((!actionRequested.equals(EdenConstants.ACTION_REQUEST_ACKNOWLEDGE_REQ)) &&
          (!actionRequested.equals(EdenConstants.ACTION_REQUEST_APPROVE_REQ)) &&
          (!actionRequested.equals(EdenConstants.ACTION_REQUEST_CANCEL_REQ)) &&
          (!actionRequested.equals(EdenConstants.ACTION_REQUEST_COMPLETE_REQ)) &&
          (!actionRequested.equals(EdenConstants.ACTION_REQUEST_FYI_REQ))) {
      return new WorkflowServiceErrorImpl("ActionRequested of wrong type",
        ServiceErrorConstants.ACTION_REQUESTED_INVALID);
    }

    LOG.debug("valid returning null");

    return null;
  }

  /**
   * Tell whether the objects value property/properties have values
   *
   * @return true when object is empty
   */
  public boolean isEmpty() {
    LOG.debug("isEmptyp()");

    if ((this.actionRequested == null) || this.actionRequested.trim().equals("")) {
      LOG.debug("empty");

      return true;
    }

    LOG.debug("not empty");

    return false;
  }

  public String getElementName() {
    return ELEMENT_NAME;
  }

  public void setRouteControl(boolean routeControl) {
  }

  public boolean isRouteControl() {
    return this.routeControl;
  }

  /**
   * @param actionRequested value of the actionRequested
   */
  public void setActionRequested(String actionRequested) {
    this.actionRequested = actionRequested;
  }

  /**
   * @return value of the actionRequested
   */
  public String getActionRequested() {
    if (this.actionRequested == null) {
      return null;
    }

    return this.actionRequested.toUpperCase();
  }
}





/*
 * Copyright 2003 The Trustees of Indiana University.  All rights reserved.
 *
 * This file is part of the EDEN software package.
 * For license information, see the LICENSE file in the top level directory
 * of the EDEN source distribution.
 */
