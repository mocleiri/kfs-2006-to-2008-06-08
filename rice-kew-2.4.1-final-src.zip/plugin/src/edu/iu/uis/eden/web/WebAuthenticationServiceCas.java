/*
 * Copyright 2005-2007 The Kuali Foundation.
 * 
 * 
 * Licensed under the Educational Community License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 * http://www.opensource.org/licenses/ecl1.php
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package edu.iu.uis.eden.web;

import javax.servlet.http.HttpServletRequest;

import edu.iu.uis.cas.filter.CASFilter;
import edu.iu.uis.eden.web.session.UserSession;

public class WebAuthenticationServiceCas implements WebAuthenticationService {

	public WebAuthenticationServiceCas() {
	}

	public String getNetworkId(HttpServletRequest request) {
		return CASFilter.getRemoteUser(request);
	}
  
	/**
	 * This implementation will update the kerberos authentication (if it has not already been set) and
	 * the safeword authentication value on the UserSession if the user has logged into safeword on a subsequent request.
	 */
	public UserSession updateUserSession(UserSession userSession, HttpServletRequest request) {
		IUUserSessionUtils.setKerberosAuthenticated(userSession, true);
		IUUserSessionUtils.setSafewordAuthenticated(userSession, CASFilter.isUserSafewordAuthenticated(request));
		return userSession;
	}
  
}