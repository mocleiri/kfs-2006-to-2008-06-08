/*
 * Copyright 2005-2007 The Kuali Foundation.
 * 
 * 
 * Licensed under the Educational Community License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 * http://www.opensource.org/licenses/ecl1.php
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package edu.iu.uis.eden;

import javax.xml.namespace.QName;

import org.kuali.rice.lifecycle.BaseLifecycle;
import org.kuali.rice.resourceloader.ServiceLocator;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import edu.iu.uis.eden.account.AccountService;
import edu.iu.uis.eden.ads.AdsService;
import edu.iu.uis.eden.fiscalsub.FiscalSubAccountService;
import edu.iu.uis.eden.fisdata.FISDataService;
import edu.iu.uis.eden.mail.IUAuthenticatedEmailService;
import edu.iu.uis.eden.plugin.attributes.LookupableService;
import edu.iu.uis.eden.user.UserService;
import edu.iu.uis.eden.web.WebAuthenticationService;
import edu.iu.uis.eden.workgroup.WorkgroupService;

/**
 * @author ewestfal
 */
public class IUServiceLocator extends BaseLifecycle implements ServiceLocator {

	private static IUServiceLocator INSTANCE = new IUServiceLocator();

	private ApplicationContext appContext;

	private boolean initializationBegan = false;

	public static final String USER_SERVICE = "enUserService";

	public static final String WORKGROUP_SERVICE = "enWorkgroupService";

	public static final String WORKGROUP_MEMBER_SERVICE = "enWorkgroupMemberService";

	public static final String LOOKUPABLE_SERVICE = "enLookupableService";

	public static final String ADS_SERVICE = "enAdsService";

	public static final String FISCAL_SUB_ACCOUNT_SERVICE = "enFiscalSubAccountService";

	public static final String FIS_DATA_SERVICE = "FISDataService";

	public static final String ACCOUNT_SERVICE = "enAccountService";

	public static final String WEB_AUTHENTICATION_SERVICE = "enIUWebAuthenticationService";

	public static final String EMAIL_SERVICE = "enEmailService";

	public static IUServiceLocator getInstance() {
		return INSTANCE;
	}

	public void start() throws Exception {
		if (appContext == null && !initializationBegan) {
			initializationBegan = true;
			appContext = new ClassPathXmlApplicationContext("IUSpringBeans.xml");
		} else if (appContext == null && initializationBegan) {
			throw new RuntimeException("Spring not initialized properly.  Initialization has begun and the application context is null."
					+ "Probably spring loaded bean is trying to use SpringServiceLocator before the application context is initialized.");
		}
		super.start();
	}

	public void stop() throws Exception {
		if (appContext instanceof ConfigurableApplicationContext) {
			((ConfigurableApplicationContext) appContext).close();
		}
		super.stop();
	}

	public Object getService(QName serviceName) {
		if (appContext.containsBean(serviceName.toString())) {
			return appContext.getBean(serviceName.toString());
		}
		return null;
	}

	public Object getService(String serviceName) {
		return getService(new QName(serviceName));
	}

	public static UserService getUserService() {
		return (UserService) getInstance().getService(USER_SERVICE);
	}

	public static WorkgroupService getWorkgroupService() {
		return (WorkgroupService) getInstance().getService(WORKGROUP_SERVICE);
	}

	public static LookupableService getLookupableService() {
		return (LookupableService) getInstance().getService(LOOKUPABLE_SERVICE);
	}

	public static AdsService getAdsService() {
		return (AdsService) getInstance().getService(ADS_SERVICE);
	}

	public static AccountService getAccountService() {
		return (AccountService) getInstance().getService(ACCOUNT_SERVICE);
	}

	public static FiscalSubAccountService getFiscalSubAccountService() {
		return (FiscalSubAccountService) getInstance().getService(FISCAL_SUB_ACCOUNT_SERVICE);
	}

	public static FISDataService getFISDataService() {
		return (FISDataService) getInstance().getService(FIS_DATA_SERVICE);
	}

	public static WebAuthenticationService getWebAuthenticationService() {
		return (WebAuthenticationService) getInstance().getService(WEB_AUTHENTICATION_SERVICE);
	}

	public static IUAuthenticatedEmailService getEmailService() {
		return (IUAuthenticatedEmailService) getInstance().getService(EMAIL_SERVICE);
	}

	public String getContents(String indent, boolean servicePerLine) {
		String contents = indent + "SpringLoader services =";
		for (String beanName : appContext.getBeanDefinitionNames()) {
			if (servicePerLine) {
				contents += indent + "+++" + beanName + "\n";
			} else {
				contents += beanName + ", ";
			}
		}
		return contents;
	}
}