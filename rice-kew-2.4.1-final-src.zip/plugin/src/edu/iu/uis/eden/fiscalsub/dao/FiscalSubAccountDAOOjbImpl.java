/*
 * Copyright 2005-2007 The Kuali Foundation.
 * 
 * 
 * Licensed under the Educational Community License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 * http://www.opensource.org/licenses/ecl1.php
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package edu.iu.uis.eden.fiscalsub.dao;

import java.util.Collection;
import java.util.List;

import org.apache.ojb.broker.query.Criteria;
import org.apache.ojb.broker.query.QueryByCriteria;
import org.springmodules.orm.ojb.support.PersistenceBrokerDaoSupport;

import edu.iu.uis.eden.fiscalsub.FiscalSubAccount;
import edu.iu.uis.eden.util.Utilities;

/**
 * OJB implementation of the FiscalSubAccountDAO.
 *
 * @author Eric Westfall
 */
public class FiscalSubAccountDAOOjbImpl extends PersistenceBrokerDaoSupport implements FiscalSubAccountDAO {

    public FiscalSubAccount getSubAccount(String chart, String accountNumber, String subAccountNumber) {
        Criteria criteria = new Criteria();
        criteria.addEqualTo("finCoaCd", chart);
        criteria.addLike("accountNbr", accountNumber);
        criteria.addEqualTo("subAcctNbr", subAccountNumber);
        return (FiscalSubAccount) getPersistenceBrokerTemplate().getObjectByQuery(new QueryByCriteria(FiscalSubAccount.class, criteria));
    }

    public List searchForSubAccount(String chart, String accountNumber, String subAccountNumber, String subAccountName, String activeIndicator) {
        Criteria criteria = new Criteria();
        if (!Utilities.isEmpty(chart)) {
            criteria.addEqualTo("finCoaCd", chart);
        }
        if (!Utilities.isEmpty(accountNumber)) {
            accountNumber = accountNumber.replace('*', '%');
            criteria.addLike("accountNbr", "%"+accountNumber+"%");
        }
        if (!Utilities.isEmpty(activeIndicator)) {
            criteria.addEqualTo("activeInd", activeIndicator);
        }

        if (!Utilities.isEmpty(subAccountNumber)) {
            subAccountNumber = subAccountNumber.replace('*', '%');
            criteria.addLike("UPPER(subAcctNbr)", "%"+subAccountNumber.trim().toUpperCase()+"%");
        }
        if (!Utilities.isEmpty(subAccountName)) {
            subAccountName = subAccountName.replace('*', '%');
            criteria.addLike("UPPER(subAccountName)", "%"+subAccountName.trim().toUpperCase()+"%");
        }
        return (List) getPersistenceBrokerTemplate().getCollectionByQuery(new QueryByCriteria(FiscalSubAccount.class, criteria));
    }

    public Collection findAll() {
        return getPersistenceBrokerTemplate().getCollectionByQuery(new QueryByCriteria(FiscalSubAccount.class));
    }

}
