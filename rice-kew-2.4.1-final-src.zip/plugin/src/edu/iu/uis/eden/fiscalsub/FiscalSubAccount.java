/*
 * Copyright 2005-2007 The Kuali Foundation.
 * 
 * 
 * Licensed under the Educational Community License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 * http://www.opensource.org/licenses/ecl1.php
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package edu.iu.uis.eden.fiscalsub;

/**
 * @author Eric Westfall
 */
public class FiscalSubAccount implements java.io.Serializable {

	private String finCoaCd;
	private String accountNbr;
	private String subAcctNbr;
	private String subAccountName;
	private String activeInd;

	private String returnUrl;

	private static final String BACK_LOCATION_KEY_NAME = "backLocation";
	private static final String DOC_FORM_KEY_NAME = "docFormKey";

	public String getReturnUrl() {
		return returnUrl;
	}

	public void setReturnUrl(String returnUrl) {
		this.returnUrl = returnUrl;
	}

	public String getAccountNbr() {
		return accountNbr;
	}

	public void setAccountNbr(String accountNbr) {
		this.accountNbr = accountNbr;
	}

	public String getFinCoaCd() {
		return finCoaCd;
	}

	public void setFinCoaCd(String finCoaCd) {
		this.finCoaCd = finCoaCd;
	}

	public String getSubAcctNbr() {
		return subAcctNbr;
	}

	public void setSubAcctNbr(String subAcctNbr) {
		this.subAcctNbr = subAcctNbr;
	}

	public String getSubAccountName() {
		return subAccountName;
	}

	public void setSubAccountName(String subAccountName) {
		this.subAccountName = subAccountName;
	}

	public String getActiveInd() {
		return activeInd;
	}

	public void setActiveInd(String activeInd) {
		this.activeInd = activeInd;
	}

}
