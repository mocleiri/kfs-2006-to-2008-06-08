/*
 * Copyright 2005-2007 The Kuali Foundation.
 * 
 * 
 * Licensed under the Educational Community License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 * http://www.opensource.org/licenses/ecl1.php
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package edu.iu.uis.eden.workgroup;

import java.util.ArrayList;

import javax.naming.NamingException;

import edu.iu.uis.eden.IUServiceLocator;
import edu.iu.uis.eden.ads.AdsService;
import edu.iu.uis.eden.exception.EdenUserNotFoundException;
import edu.iu.uis.eden.exception.WorkflowRuntimeException;

/**
 * Workgroup service implementation for Indiana University.  Allows us to hook into our
 * ADS directory service for groups.
 *
 * @author Eric Westfall
 */
public class IUWorkgroupServiceImpl extends BaseWorkgroupService {

	private static final org.apache.log4j.Logger LOG = org.apache.log4j.Logger.getLogger(IUWorkgroupServiceImpl.class);

	public void save(Workgroup workgroup) {
		// since OJB is kind of dumb, we can't save an instance of ADSWorkgroup.  Instead we need to copy it back into
		// a BaseWorkgroup before we save it.
		Workgroup originalWorkgroup = workgroup;
		if (!(workgroup.getClass().equals(BaseWorkgroup.class))) {
			Workgroup copiedWorkgroup = copy(workgroup);
			// for ADS workgroups we don't want to save the members to the database, they are obtained lazily
			if (workgroup instanceof ADSWorkgroup) {
				LOG.info("Saving ADS Workgroup for the first time: " + workgroup.getDisplayName());
				copiedWorkgroup.setMembers(new ArrayList());
				// this addresses the issue whereby new ADS workgroups weren't getting their current indicators
				// set to true
				((BaseWorkgroup)copiedWorkgroup).setCurrentInd(Boolean.TRUE);
			}
			workgroup = copiedWorkgroup;
		}
		super.save(workgroup);
		// be sure to put our nice, shiny new id on the original workgroup
		originalWorkgroup.setWorkflowGroupId(workgroup.getWorkflowGroupId());
	}

	protected BaseWorkgroup initializeLoadedWorkgroup(BaseWorkgroup workgroup) throws EdenUserNotFoundException {
		workgroup = super.initializeLoadedWorkgroup(workgroup);
		if (workgroup.getWorkgroupType() != null && workgroup.getWorkgroupType().equals(ADSWorkgroup.ADS_TYPE) && !(workgroup instanceof ADSWorkgroup)) {
			workgroup = new ADSWorkgroup(workgroup);
		}
		return workgroup;
	}

	protected BaseWorkgroup getExternalWorkgroup(GroupId groupId, boolean loadWorkgroupExtensions) {
		ADSWorkgroup workgroup = null;
		if (loadWorkgroupExtensions && groupId instanceof GroupNameId) {
			GroupNameId groupName = (GroupNameId) groupId;
			try {
				workgroup = getAdsWorkgroup(groupName);
				if (workgroup != null) {
					save(workgroup);
					addToCache(workgroup);
					LOG.info("Loaded ADS workgroup with name '" + groupName.getNameId());
				}
			} catch (NamingException e) {
				throw new WorkflowRuntimeException("Problem locating ads workgroup, groupName=" + groupName.getNameId(), e);
			}
		}
		return workgroup;
	}

	/**
	 * Creates an ADS Workgroup for the given workgroup name.  If no ADS workgroup can be found
	 * with the given name, then null is returned.  The ADSWorkgroup returned from this method
	 * is an unsaved and unmaterialized workgroup.  In other words, it has no primary key and
	 * the members have not actually been loaded from the ADS server yet.  This is handled
	 * lazily by the ADSWorkgroup class.
	 */
	protected ADSWorkgroup getAdsWorkgroup(GroupNameId groupNameId) throws NamingException {
		ADSWorkgroup workgroup = null;
		if (getAdsService().getAdsHelper().isValidGroupName(groupNameId.getNameId())) {
			workgroup = new ADSWorkgroup();
			workgroup.setActiveInd(Boolean.TRUE);
			workgroup.setGroupNameId(groupNameId);
			workgroup.setCurrentInd(Boolean.TRUE);
			workgroup.setDescription("Workgroup for ADS Group " + groupNameId.getNameId());
			workgroup.setWorkgroupType(ADSWorkgroup.ADS_TYPE);
			workgroup.setVersionNumber(new Integer(0));
		}
		return workgroup;
	}

	private AdsService getAdsService() {
		return IUServiceLocator.getAdsService();
	}

}
