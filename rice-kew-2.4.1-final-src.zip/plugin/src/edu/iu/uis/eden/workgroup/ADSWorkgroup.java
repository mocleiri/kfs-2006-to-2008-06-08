/*
 * Copyright 2005-2007 The Kuali Foundation.
 * 
 * 
 * Licensed under the Educational Community License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 * http://www.opensource.org/licenses/ecl1.php
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package edu.iu.uis.eden.workgroup;

import java.util.Iterator;
import java.util.List;
import java.util.Vector;

import javax.naming.AuthenticationException;
import javax.naming.NamingException;

import edu.iu.uis.eden.IUServiceLocator;
import edu.iu.uis.eden.KEWServiceLocator;
import edu.iu.uis.eden.ads.AdsService;
import edu.iu.uis.eden.exception.EdenUserNotFoundException;
import edu.iu.uis.eden.exception.WorkflowRuntimeException;
import edu.iu.uis.eden.user.AuthenticationUserId;
import edu.iu.uis.eden.user.UserService;
import edu.iu.uis.eden.user.WorkflowUser;
import edu.iu.uis.eden.util.Utilities;
import edu.iu.uis.sit.util.directory.AdsHelper;

/**
 * An a Workgroup implementation which is backed by an ADS group.  This implementation wraps an existing
 * SimpleWorkgroup.
 *
 * @author Eric Westfall
 */
public class ADSWorkgroup extends BaseWorkgroup {

	private static final long serialVersionUID = -243171768448572648L;

	private static final org.apache.log4j.Logger LOG = org.apache.log4j.Logger.getLogger(ADSWorkgroup.class);

	public static final String ADS_TYPE = "A";

	private boolean adsMembersPopulated = false;

	public ADSWorkgroup() {
		setWorkgroupType(ADS_TYPE);
	}

	/**
	 * Creates an ADSWorkgroup out of the given SimpleWorkgroup.
	 */
	public ADSWorkgroup(BaseWorkgroup simpleWorkgroup) {
		if (!ADS_TYPE.equals(simpleWorkgroup.getWorkgroupType())) {
			throw new IllegalArgumentException("Workgroup is not an ADS workgroup.  Instead type was: " + simpleWorkgroup.getWorkgroupType());
		}
		setActiveInd(simpleWorkgroup.getActiveInd());
		setCurrentInd(simpleWorkgroup.getCurrentInd());
		setDescription(simpleWorkgroup.getDescription());
		setDocumentId(simpleWorkgroup.getDocumentId());
		setGroupNameId(simpleWorkgroup.getGroupNameId());
		setLockVerNbr(simpleWorkgroup.getLockVerNbr());
		setMembers(simpleWorkgroup.getMembers());
		setVersionNumber(simpleWorkgroup.getVersionNumber());
		setWorkflowGroupId(simpleWorkgroup.getWorkflowGroupId());
		setWorkgroupMembers(simpleWorkgroup.getWorkgroupMembers());
		setWorkgroupType(simpleWorkgroup.getWorkgroupType());
	}

	public List getUsers() {
		populateAdsMembers();
		return super.getUsers();
	}

    /**
     * Workgroups can be accessed by multiple threads if they are cached.
     */
    private synchronized void populateAdsMembers() {
    	if (!adsMembersPopulated) {
    		try {
    			if (!Utilities.isEmpty(getWorkgroupName())) {
    				AdsHelper adsHelper = getAdsService().getAdsHelper();
    				Vector users = adsHelper.getGroupUsers(getWorkgroupName(), AdsHelper.INFINITE_GROUP_DEPTH);
    				for (Iterator iterator = users.iterator(); iterator.hasNext();) {
    					String userName = (String) iterator.next();
    					userName = userName.toLowerCase();
    					try {
    						WorkflowUser workflowUser = getUserService().getWorkflowUser(new AuthenticationUserId(userName));
    						//SimpleWorkgroupMember member = new SimpleWorkgroupMember();
    						//member.setWorkflowId(workflowUser.getWorkflowUserId().getWorkflowId());
    						super.getUsers().add(workflowUser);
    					} catch (EdenUserNotFoundException e) {
    						LOG.warn("Could not locate ADS person: name=" + userName + ", in workgroup: name=" + getWorkgroupName() + ", id=" + getWorkgroupId());
    					}
    				}
    			}
    			adsMembersPopulated = true;
    		} catch (AuthenticationException e) {
    			throw new WorkflowRuntimeException("Error authenticating with ADS to resolve workgroup users, workgroupName="+getWorkgroupName(), e);
    		} catch (NamingException e) {
    			throw new WorkflowRuntimeException("Error resolving users for workgroup from ADS, workgroupName="+getWorkgroupName(), e);
    		}
    	}
    }

    private AdsService getAdsService() {
        return (AdsService)IUServiceLocator.getAdsService();
    }

    private UserService getUserService() {
        return (UserService)KEWServiceLocator.getService(KEWServiceLocator.USER_SERVICE);
    }

}
