/*
 * Copyright 2005-2007 The Kuali Foundation.
 * 
 * 
 * Licensed under the Educational Community License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 * http://www.opensource.org/licenses/ecl1.php
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package edu.iu.uis.eden.account.dao;

import java.util.ArrayList;
import java.util.List;

import org.apache.ojb.broker.query.Criteria;
import org.apache.ojb.broker.query.QueryByCriteria;
import org.springmodules.orm.ojb.support.PersistenceBrokerDaoSupport;

import edu.iu.uis.eden.account.Account;
import edu.iu.uis.eden.account.AccountDelegation;
import edu.iu.uis.eden.util.Utilities;

public class AccountDAOOjbImpl extends PersistenceBrokerDaoSupport implements AccountDAO {

    public Account findByChartAccount(String finCoaCd, String accountNbr) {
        Criteria crit = new Criteria();
        crit.addEqualTo("accountNbr", accountNbr);
        crit.addEqualTo("finCoaCd", finCoaCd);
        return (Account) this.getPersistenceBrokerTemplate().getObjectByQuery(new QueryByCriteria(Account.class, crit));
    }

    public List findDelegationsByChartAccount(String finCoaCd, String accountNbr) {
    	Criteria crit = new Criteria();
    	crit.addEqualTo("accountNbr", accountNbr);
        crit.addEqualTo("finCoaCd", finCoaCd);
        return (List) this.getPersistenceBrokerTemplate().getCollectionByQuery(new QueryByCriteria(AccountDelegation.class, crit));
    }

    public List search(String accountNbr, String accountName, String finCoaCd, String closedInd) {
        Criteria crit = new Criteria();
        if (!Utilities.isEmpty(accountNbr)) {
            accountNbr = accountNbr.replace('*', '%');
            crit.addLike("accountNbr", "%"+accountNbr.trim()+"%");
        }
        if (!Utilities.isEmpty(accountName)) {
            accountName = accountName.replace('*', '%');
            crit.addLike("UPPER(accountName)", "%"+accountName.trim().toUpperCase()+"%");
        }
        if (!Utilities.isEmpty(finCoaCd)) {
            finCoaCd = finCoaCd.replace('*', '%');
            crit.addLike("UPPER(finCoaCd)", "%"+finCoaCd.trim().toUpperCase()+"%");
        }
        if (!Utilities.isEmpty(closedInd)) {
            crit.addEqualTo("closedInd", closedInd);
        }

        return (List) this.getPersistenceBrokerTemplate().getCollectionByQuery(new QueryByCriteria(Account.class, crit));
    }
    public List getAllAccounts() {
        Criteria crit = new Criteria();
        crit.addEqualTo("closedInd", "N");
        return new ArrayList(this.getPersistenceBrokerTemplate().getCollectionByQuery(new QueryByCriteria(Account.class,crit)));
    }
}
