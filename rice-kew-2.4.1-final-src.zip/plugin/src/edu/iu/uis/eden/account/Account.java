/*
 * Copyright 2005-2007 The Kuali Foundation.
 * 
 * 
 * Licensed under the Educational Community License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 * http://www.opensource.org/licenses/ecl1.php
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package edu.iu.uis.eden.account;

import edu.iu.uis.eden.WorkflowPersistable;

public class Account implements WorkflowPersistable {

    private static final org.apache.log4j.Logger LOG = org.apache.log4j.Logger.getLogger(Account.class);
    private String finCoaCd;
    private String accountNbr;
    private String accountName;
    private String closedInd;
    private String fiscalOfficerUnvlId;
    //private List accountDelegations;
    
    // just for lookupables...
    private String returnUrl;

    public Account() {
    }

    public Object copy(boolean preserveKeys) {
        Account copy = new Account();
        copy.setFinCoaCd(getFinCoaCd());
        copy.setAccountName(getAccountName());
        copy.setAccountNbr(getAccountNbr());
        copy.setClosedInd(getClosedInd());
        copy.setFiscalOfficerUnvlId(getFiscalOfficerUnvlId());
        //copy.setAccountDelegations(getAccountDelegations());
        return copy;
    }

	/*public List getAccountDelegations() {
		return accountDelegations;
	}
	
	public void setAccountDelegations(List accountDelegations) {
		this.accountDelegations = accountDelegations;
	}*/

	public String getClosedInd() {
        return closedInd;
    }

    public void setClosedInd(String closedInd) {
        this.closedInd = closedInd;
    }

    public String getFinCoaCd() {
        return finCoaCd;
    }

    public void setFinCoaCd(String finCoaCd) {
        this.finCoaCd = finCoaCd;
    }

    public String getAccountName() {
        return accountName;
    }

    public void setAccountName(String accountName) {
        this.accountName = accountName;
    }

    public String getAccountNbr() {
        return accountNbr;
    }

    public void setAccountNbr(String accountNbr) {
        this.accountNbr = accountNbr;
    }

    public String getFiscalOfficerUnvlId() {
        return fiscalOfficerUnvlId;
    }

    public void setFiscalOfficerUnvlId(String fiscalOfficerUnvlId) {
        this.fiscalOfficerUnvlId = fiscalOfficerUnvlId;
    }

    public String getReturnUrl() {
        return returnUrl;
    }

    public void setReturnUrl(String returnUrl) {
        this.returnUrl = returnUrl;
    }

    
}