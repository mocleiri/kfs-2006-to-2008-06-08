/*
 * Copyright 2005-2007 The Kuali Foundation.
 * 
 * 
 * Licensed under the Educational Community License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 * http://www.opensource.org/licenses/ecl1.php
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package edu.iu.uis.eden.routetemplate.attribute;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import edu.iu.uis.eden.plugin.attributes.WorkflowAttribute;
import edu.iu.uis.eden.routeheader.DocumentContent;

/**
 * A simple composite wrapper around attributes.
 * 
 * @author ewestfal
 */
public abstract class CompositeAttribute implements WorkflowAttribute {

	private List attributes = new ArrayList();
	
	public CompositeAttribute() {}
	
	public CompositeAttribute(List attributes) {
		this.attributes = attributes;
	}
	
	public void addAttribute(WorkflowAttribute attribute) {
		attributes.add(attribute);
	}
	
	public boolean isMatch(DocumentContent docContent, List ruleExtensions) {
		for (Iterator iterator = attributes.iterator(); iterator.hasNext();) {
			WorkflowAttribute attribute = (WorkflowAttribute) iterator.next();
			if (!attribute.isMatch(docContent, ruleExtensions)) {
				return false;
			}
		}
		return true;
	}

	public List getRuleRows() {
		List rows = new ArrayList();
		for (Iterator iterator = attributes.iterator(); iterator.hasNext();) {
			WorkflowAttribute attribute = (WorkflowAttribute) iterator.next();
			rows.addAll(attribute.getRuleRows());
		}
		return rows;
	}

	public List getRoutingDataRows() {
		List rows = new ArrayList();
		for (Iterator iterator = attributes.iterator(); iterator.hasNext();) {
			WorkflowAttribute attribute = (WorkflowAttribute) iterator.next();
			rows.addAll(attribute.getRoutingDataRows());
		}
		return rows;
	}

	public String getDocContent() {
		StringBuffer buffer = new StringBuffer();
		for (Iterator iterator = attributes.iterator(); iterator.hasNext();) {
			WorkflowAttribute attribute = (WorkflowAttribute) iterator.next();
			buffer.append(attribute.getDocContent());
		}
		return buffer.toString();
	}

	public List getRuleExtensionValues() {
		List values = new ArrayList();
		for (Iterator iterator = attributes.iterator(); iterator.hasNext();) {
			WorkflowAttribute attribute = (WorkflowAttribute) iterator.next();
			values.addAll(attribute.getRuleExtensionValues());
		}
		return values;
	}

	public List validateRoutingData(Map paramMap) {
		List validations = new ArrayList();
		for (Iterator iterator = attributes.iterator(); iterator.hasNext();) {
			WorkflowAttribute attribute = (WorkflowAttribute) iterator.next();
			validations.addAll(attribute.validateRoutingData(paramMap));
		}
		return validations;
	}

	public List validateRuleData(Map paramMap) {
		List validations = new ArrayList();
		for (Iterator iterator = attributes.iterator(); iterator.hasNext();) {
			WorkflowAttribute attribute = (WorkflowAttribute) iterator.next();
			validations.addAll(attribute.validateRuleData(paramMap));
		}
		return validations;
	}

	public void setRequired(boolean required) {
		for (Iterator iterator = attributes.iterator(); iterator.hasNext();) {
			WorkflowAttribute attribute = (WorkflowAttribute) iterator.next();
			attribute.setRequired(required);
		}
	}

	public boolean isRequired() {
		for (Iterator iterator = attributes.iterator(); iterator.hasNext();) {
			WorkflowAttribute attribute = (WorkflowAttribute) iterator.next();
			if (attribute.isRequired()) {
				return true;
			}
		}
		return false;
	}

}
