/*
 * Copyright 2005-2007 The Kuali Foundation.
 * 
 * 
 * Licensed under the Educational Community License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 * http://www.opensource.org/licenses/ecl1.php
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package edu.iu.uis.eden.routetemplate.attribute;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.log4j.Logger;
import org.jdom.Document;
import org.jdom.Element;

import edu.iu.uis.eden.IUServiceLocator;
import edu.iu.uis.eden.WorkflowServiceErrorImpl;
import edu.iu.uis.eden.account.Account;
import edu.iu.uis.eden.account.AccountDelegation;
import edu.iu.uis.eden.engine.RouteContext;
import edu.iu.uis.eden.exception.EdenUserNotFoundException;
import edu.iu.uis.eden.lookupable.Field;
import edu.iu.uis.eden.lookupable.Row;
import edu.iu.uis.eden.plugin.attributes.RoleAttribute;
import edu.iu.uis.eden.plugin.attributes.WorkflowAttribute;
import edu.iu.uis.eden.routeheader.DocumentContent;
import edu.iu.uis.eden.routetemplate.ResolvedQualifiedRole;
import edu.iu.uis.eden.routetemplate.Role;
import edu.iu.uis.eden.user.UuId;
import edu.iu.uis.eden.util.Utilities;
import edu.iu.uis.eden.util.XmlHelper;

public class AccountAttribute implements WorkflowAttribute, RoleAttribute {

	private static Logger LOG = Logger.getLogger(AccountAttribute.class);

	private static Map docTypeTranslations;
	private static Set allFISDocTypes;

	static {
		docTypeTranslations = new HashMap();
		docTypeTranslations.put("EPICRequisition", "REQS");
		docTypeTranslations.put("EPICPurchaseOrder", "PO");
		docTypeTranslations.put("EPICPaymentRequest", "PREQ");
        docTypeTranslations.put("EPICCreditMemo", "PREQ");
		docTypeTranslations.put("TRAVELDOCS.TravelAuthorization", "TRAV");
		docTypeTranslations.put("TRAVELDOCS.TravelPrepaidExpenses", "TRPD");
		docTypeTranslations.put("TRAVELDOCS.TravelReimbursement", "TRRE");
		docTypeTranslations.put("TRAVELDOCS.TravelSupplementalReimbursement", "TRSP");

		allFISDocTypes = new HashSet();
		allFISDocTypes.add("PREQ");
		allFISDocTypes.add("REQS");
	}

	private static final String FIN_COA_CD_KEY = "fin_coa_cd";

	private static final String ACCOUNT_NBR_KEY = "account_nbr";

	private static final String DEFAULT_ACCOUNT_NBR_KEY = "accountNbr";

	private static final String FDOC_TOTAL_DOLLAR_AMOUNT_KEY = "fdoc_ttl_dlr_amt";

	private static final String FISCAL_OFFICER_ROLE_KEY = "FISCAL-OFFICER";

	private static final String FISCAL_OFFICER_ROLE_LABEL = "Fiscal Officer";

	private static final String FISCAL_OFFICER_PRIMARY_DELEGATE_ROLE_KEY = "FISCAL-OFFICER-PRIMARY-DELEGATE";

	private static final String FISCAL_OFFICER_PRIMARY_DELEGATE_ROLE_LABEL = "Fiscal Officer Primary Delegate";

	private static final String FISCAL_OFFICER_SECONDARY_DELEGATE_ROLE_KEY = "FISCAL-OFFICER-SECONDARY-DELEGATE";

	private static final String FISCAL_OFFICER_SECONDARY_DELEGATE_ROLE_LABEL = "Fiscal Officer Secondary Delegate";

	private static final String ACCOUNT_ATTRIBUTE = "ACCOUNT_ATTRIBUTE";

	private static final String LOOKUPABLE_CLASS = "AccountLookupableImplService";

	private static final String ROLE_STRING_DELIMITER = "~!~!~";

	private static final int ROLE_STRING_DELIMITER_LENGTH = 5;

	private String finCoaCd;

	private String accountNbr;

	private String totalDollarAmount;

	private boolean required;

	public AccountAttribute() {
	}

	public AccountAttribute(String finCoaCd, String accountNbr, String totalDollarAmount) {
		Account account = IUServiceLocator.getAccountService().findByChartAccount(finCoaCd, accountNbr);
		this.finCoaCd = finCoaCd;
		this.accountNbr = accountNbr;
		this.totalDollarAmount = totalDollarAmount;
	}

	public List getRoleNames() {
		List roles = new ArrayList();
		roles.add(new Role(this.getClass(), FISCAL_OFFICER_ROLE_KEY, FISCAL_OFFICER_ROLE_LABEL));
		roles.add(new Role(this.getClass(), FISCAL_OFFICER_PRIMARY_DELEGATE_ROLE_KEY, FISCAL_OFFICER_PRIMARY_DELEGATE_ROLE_LABEL));
		roles.add(new Role(this.getClass(), FISCAL_OFFICER_SECONDARY_DELEGATE_ROLE_KEY, FISCAL_OFFICER_SECONDARY_DELEGATE_ROLE_LABEL));
		return roles;
	}

	public boolean isRequired() {
		return required;
	}

	public void setRequired(boolean required) {
		this.required = required;
	}

	public List getRuleExtensionValues() {
		return new ArrayList();
	}

	public List validateRoutingData(Map paramMap) {
		List errors = new ArrayList();
		this.finCoaCd = (String) paramMap.get(FIN_COA_CD_KEY);
		this.accountNbr = (String) paramMap.get(ACCOUNT_NBR_KEY);
		this.totalDollarAmount = (String) paramMap.get(FDOC_TOTAL_DOLLAR_AMOUNT_KEY);
		
		if (!Utilities.isEmpty(this.finCoaCd) || !Utilities.isEmpty(this.accountNbr)) {
			Account account = IUServiceLocator.getAccountService().findByChartAccount(finCoaCd.toUpperCase(), accountNbr);
			if (account == null) {
				errors.add(new WorkflowServiceErrorImpl("Invalid account", "account.attribute.invalid"));
			}
		}
		return errors;
	}

	public List validateRuleData(Map paramMap) {
		return validateRoutingData(paramMap);
	}

	public String getDocContent() {
		if (Utilities.isEmpty(getFinCoaCd()) || Utilities.isEmpty(getAccountNbr())) {
			return "";
		}
		return "<" + ACCOUNT_ATTRIBUTE + ">" + "<" + FIN_COA_CD_KEY + ">" + getFinCoaCd() + "</" + FIN_COA_CD_KEY + ">" + "<" + ACCOUNT_NBR_KEY + ">" + getAccountNbr() + "</" + ACCOUNT_NBR_KEY + ">" + "<" + FDOC_TOTAL_DOLLAR_AMOUNT_KEY + ">" + getTotalDollarAmount() + "</" + FDOC_TOTAL_DOLLAR_AMOUNT_KEY + ">" + "</" + ACCOUNT_ATTRIBUTE + ">";
	}

	public boolean isMatch(DocumentContent docContent, List ruleExtensions) {
		return true;
	}

	public List getRoutingDataRows() {
		List rows = new ArrayList();

		List fields = new ArrayList();
		fields.add(new Field("Chart", "", Field.TEXT, false, FIN_COA_CD_KEY, "", null, LOOKUPABLE_CLASS, FIN_COA_CD_KEY));
		rows.add(new Row(fields, "Account", 3));

		fields = new ArrayList();
		fields.add(new Field("Account", "", Field.TEXT, false, ACCOUNT_NBR_KEY, "", null, LOOKUPABLE_CLASS, DEFAULT_ACCOUNT_NBR_KEY));
		fields.add(new Field("", "", Field.QUICKFINDER, false, "", "", null, LOOKUPABLE_CLASS));
		rows.add(new Row(fields, "Account", 3));

		fields = new ArrayList();
		fields.add(new Field("Total Dollar Amount", "", Field.TEXT, false, FDOC_TOTAL_DOLLAR_AMOUNT_KEY, "", null, null));
		rows.add(new Row(fields, "Account", 3));
		return rows;
	}

	public String getIdFieldName() {
		return "";
	}

	public String getLockFieldName() {
		return "";
	}

	public List getRuleRows() {
		return new ArrayList();
	}

	public String getAccountNbr() {
		return accountNbr;
	}

	public void setAccountNbr(String accountNbr) {
		this.accountNbr = accountNbr;
	}

	public String getFinCoaCd() {
		return finCoaCd;
	}

	public void setFinCoaCd(String finCoaCd) {
		this.finCoaCd = finCoaCd;
	}

	public String getTotalDollarAmount() {
		return totalDollarAmount;
	}

	public void setTotalDollarAmount(String totalDollarAmount) {
		this.totalDollarAmount = totalDollarAmount;
	}

	private String getQualifiedRoleString(String roleName, String chart, String account, String totalDollarAmount) {
		return roleName + ROLE_STRING_DELIMITER + chart + ROLE_STRING_DELIMITER + account + ROLE_STRING_DELIMITER + totalDollarAmount;
	}

	private String getUnqualifiedRoleFromString(String qualifiedRole) {
		return qualifiedRole.split(ROLE_STRING_DELIMITER)[0];
	}

	private String getUnqualifiedChartFromString(String qualifiedRole) {
		return qualifiedRole.split(ROLE_STRING_DELIMITER)[1];
	}

	private String getUnqualifiedAccountFromString(String qualifiedRole) {
		return qualifiedRole.split(ROLE_STRING_DELIMITER)[2];
	}

	private long getUnqualifiedTotalDollarAmountFromString(String qualifiedRole) {
		return new Long(qualifiedRole.split(ROLE_STRING_DELIMITER)[3]).longValue();
	}

	public List getQualifiedRoleNames(String roleName, DocumentContent docContent) throws EdenUserNotFoundException {
		Set qualifiedRoleNames = new HashSet();
		if (FISCAL_OFFICER_ROLE_KEY.equals(roleName) || FISCAL_OFFICER_PRIMARY_DELEGATE_ROLE_KEY.equals(roleName) || FISCAL_OFFICER_SECONDARY_DELEGATE_ROLE_KEY.equals(roleName)) {
			Document doc = null;
			// try {
			doc = XmlHelper.buildJDocument(docContent.getDocument());
			List accountElements = XmlHelper.findElements(doc.getRootElement(), ACCOUNT_ATTRIBUTE);
			for (Iterator iter = accountElements.iterator(); iter.hasNext();) {
				Element accountElement = (Element) iter.next();
				qualifiedRoleNames.add(getQualifiedRoleString(roleName, accountElement.getChild(FIN_COA_CD_KEY).getText(), accountElement.getChild(ACCOUNT_NBR_KEY).getText(), accountElement.getChild(FDOC_TOTAL_DOLLAR_AMOUNT_KEY).getText()));
			}
			/*
			 * } catch (InvalidXmlException ixe) { throw new
			 * WorkflowRuntimeException("Invalid XML content encountered"); }
			 */
		}

		return new ArrayList(qualifiedRoleNames);
	}

	private boolean isActiveDelegationRecord(Timestamp timestamp) {
		if (timestamp == null || timestamp.before(new Date())) {
			return true;
		} else {
			return false;
		}
	}

	private boolean isDelegationWithinRangeCheck(long fromAmount, long toAmount, long totalDollarAmount) {
		if (fromAmount == 0 && toAmount == 0) {
			return true;
		}
		if (fromAmount <= totalDollarAmount && toAmount >= totalDollarAmount) {
			return true;
		}
		return false;
	}

	public ResolvedQualifiedRole resolveQualifiedRole(RouteContext context, String roleName, String qualifiedRole) throws EdenUserNotFoundException {
		List members = new ArrayList();
		LOG.debug("Chart: " + getUnqualifiedChartFromString(qualifiedRole) + " Account: " + getUnqualifiedAccountFromString(qualifiedRole));
		Account account = IUServiceLocator.getAccountService().findByChartAccount(getUnqualifiedChartFromString(qualifiedRole).toUpperCase(), getUnqualifiedAccountFromString(qualifiedRole));
		String fisDocumentType = getFisDocumentTypeNameFromWorkflowDocumentTypeName(context.getRouteHeader().getDocumentType().getName());
		if (FISCAL_OFFICER_ROLE_KEY.equals(roleName)) {
			members.add(new UuId(account.getFiscalOfficerUnvlId()));
		} else if (FISCAL_OFFICER_PRIMARY_DELEGATE_ROLE_KEY.equals(roleName)) {
			members.addAll(findAccountDelegations(account, fisDocumentType, qualifiedRole, true));
			if (members.isEmpty() && isAllFISDocType(fisDocumentType)) {
				members.addAll(findAccountDelegations(account, "ALL", qualifiedRole, true));
			}

		} else if (FISCAL_OFFICER_SECONDARY_DELEGATE_ROLE_KEY.equals(roleName)) {
			members.addAll(findAccountDelegations(account, fisDocumentType, qualifiedRole, false));
			if (members.isEmpty() && isAllFISDocType(fisDocumentType)) {
				members.addAll(findAccountDelegations(account, "ALL", qualifiedRole, false));
			}
		}
		return new ResolvedQualifiedRole(roleName, members);
	}

	private List findAccountDelegations(Account account, String fisDocumentType, String qualifiedRole, boolean primary) {
		List delegations = new ArrayList();
		for (Iterator iter = IUServiceLocator.getAccountService().findDelegationsByChartAccount(account.getFinCoaCd(), account.getAccountNbr()).iterator(); iter.hasNext();) {
			AccountDelegation delegation = (AccountDelegation) iter.next();
			if (primary && fisDocumentType.equals(delegation.getFdocTypCd()) && "Y".equals(delegation.getAcctDlgtPrmrtCd()) && "Y".equals(delegation.getAcctDlgtActvCd()) && isActiveDelegationRecord(delegation.getAcctDlgtStartDt()) && isDelegationWithinRangeCheck(delegation.getFdocAprvFromAmt().longValue(), delegation.getFdocAprvToAmt().longValue(), getUnqualifiedTotalDollarAmountFromString(qualifiedRole))) {
				delegations.add(new UuId(delegation.getAcctDlgtUnvlId()));
			} else if (!primary && fisDocumentType.equals(delegation.getFdocTypCd()) && "N".equals(delegation.getAcctDlgtPrmrtCd()) && "Y".equals(delegation.getAcctDlgtActvCd()) && isActiveDelegationRecord(delegation.getAcctDlgtStartDt()) && isDelegationWithinRangeCheck(delegation.getFdocAprvFromAmt().longValue(), delegation.getFdocAprvToAmt().longValue(), getUnqualifiedTotalDollarAmountFromString(qualifiedRole))) {
				delegations.add(new UuId(delegation.getAcctDlgtUnvlId()));
			}
		}
		return delegations;
	}

	private String getFisDocumentTypeNameFromWorkflowDocumentTypeName(String documentTypeName) {
		String documentType = (String) docTypeTranslations.get(documentTypeName);
		if (documentType == null) {
			LOG.warn(documentType + " not found in AccountAttribute so returning empty document type");
			documentType = "";
		}
		return documentType;
		// return (String) docTypeTranslations.get(documentTypeName);
		// return Utilities.getApplicationConstant(documentTypeName);
		// TRAV Travel Authorization
		// TRPD Travel Additional Pre-Paid Expenses
		// TRRE Travel Reimbursement
		// TRSP Travel Supplemental Reimbursement
		// PREQ Purchase Requisition
		// PO Purchase Order
		// PYRE Payment Request
		// return "ALL";
	}

	private boolean isAllFISDocType(String fisDocTypeName) {
		return allFISDocTypes.contains(fisDocTypeName);
	}
}