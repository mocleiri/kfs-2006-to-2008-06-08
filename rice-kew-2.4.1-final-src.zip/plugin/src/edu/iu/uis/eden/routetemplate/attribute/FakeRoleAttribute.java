/*
 * Copyright 2005-2007 The Kuali Foundation.
 * 
 * 
 * Licensed under the Educational Community License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 * http://www.opensource.org/licenses/ecl1.php
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package edu.iu.uis.eden.routetemplate.attribute;

import java.util.ArrayList;
import java.util.List;

import edu.iu.uis.eden.KEWServiceLocator;
import edu.iu.uis.eden.engine.RouteContext;
import edu.iu.uis.eden.exception.EdenUserNotFoundException;
import edu.iu.uis.eden.routeheader.DocumentContent;
import edu.iu.uis.eden.routetemplate.AbstractRoleAttribute;
import edu.iu.uis.eden.routetemplate.ResolvedQualifiedRole;
import edu.iu.uis.eden.routetemplate.Role;
import edu.iu.uis.eden.user.AuthenticationUserId;
import edu.iu.uis.eden.user.UserService;

public class FakeRoleAttribute extends AbstractRoleAttribute {

    public static final String ROLE1_KEY = "ROLE1";
    public static final String ROLE2_KEY = "ROLE2";
    
    public List getRoleNames() {
        List roles = new ArrayList();
        roles.add(new Role(this.getClass(), ROLE1_KEY, ROLE1_KEY));
        roles.add(new Role(this.getClass(), ROLE2_KEY, ROLE2_KEY));
        return roles;
    }

    public List getQualifiedRoleNames(String roleName, DocumentContent docContent) {
        List roleNames = new ArrayList();
        if (roleName.equals(ROLE1_KEY)) {
            roleNames.add(ROLE1_KEY + " ewestfal");
//            roleNames.add(ROLE1_KEY + " rkirkend");
        } else if (roleName.equals(ROLE2_KEY)) {
            roleNames.add(ROLE2_KEY + " jhopf");
            roleNames.add(ROLE2_KEY + " xqi");
        }
        return roleNames;
    }

    public ResolvedQualifiedRole resolveQualifiedRole(RouteContext context, String roleName, String qualifiedRole) throws EdenUserNotFoundException {
        List members = new ArrayList();
        
        if (roleName.equals(ROLE1_KEY)) {
//            members.add(new GroupNameId("WorkflowAdmin"));
            members.add(new AuthenticationUserId("rkirkend"));
            members.add(new AuthenticationUserId("ewestfal"));
        } else if (roleName.equals(ROLE2_KEY)) {
            members.add(new AuthenticationUserId("jhopf"));
            members.add(new AuthenticationUserId("xqi"));
        }
        
        return new ResolvedQualifiedRole("Fakey Role", members);
    }
    
   /* public List getQualifiedRoleNames(String roleName, String docContent) throws EdenUserNotFoundException {
        List members = new ArrayList();
        if (roleName.equals(ROLE1_KEY)) {
            members.add(getUserService().getWorkflowUser(new AuthenticationUserId("ewestfal")));
            members.add(getUserService().getWorkflowUser(new AuthenticationUserId("rkirkend")));
        } else if (roleName.equals(ROLE2_KEY)) {
            members.add(getUserService().getWorkflowUser(new AuthenticationUserId("jhopf")));
            members.add(getUserService().getWorkflowUser(new AuthenticationUserId("xqi")));
        }
        return members;
    }*/

    private UserService getUserService() {
        return (UserService)KEWServiceLocator.getService(KEWServiceLocator.USER_SERVICE);
    }
    
}
