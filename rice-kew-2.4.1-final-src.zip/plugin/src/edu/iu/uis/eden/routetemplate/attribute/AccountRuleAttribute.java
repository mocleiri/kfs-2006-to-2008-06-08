/*
 * Copyright 2005-2007 The Kuali Foundation.
 * 
 * 
 * Licensed under the Educational Community License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 * http://www.opensource.org/licenses/ecl1.php
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package edu.iu.uis.eden.routetemplate.attribute;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.jdom.Document;
import org.jdom.Element;

import edu.iu.uis.eden.WorkflowServiceErrorImpl;
import edu.iu.uis.eden.lookupable.Field;
import edu.iu.uis.eden.lookupable.Row;
import edu.iu.uis.eden.plugin.attributes.WorkflowAttribute;
import edu.iu.uis.eden.routeheader.DocumentContent;
import edu.iu.uis.eden.routetemplate.RuleExtension;
import edu.iu.uis.eden.routetemplate.RuleExtensionValue;
import edu.iu.uis.eden.util.Utilities;
import edu.iu.uis.eden.util.XmlHelper;

public class AccountRuleAttribute implements WorkflowAttribute {
    
    private static final org.apache.log4j.Logger LOG = org.apache.log4j.Logger.getLogger(AccountRuleAttribute.class);
    
    private String accountNbr;
    private boolean required;
    
    private static final String ACCOUNT_NBR_KEY = "account_nbr";
    private static final String ACCOUNT_NBR_LOOKABLE_NAME = "accountNbr";
    private static final String ACCOUNT_ATTRIBUTE = "ACCOUNT_ATTRIBUTE";
    private static final String LOOKUPABLE_CLASS = "AccountLookupableImplService";

    public AccountRuleAttribute () {
    }
    
    public AccountRuleAttribute (String accountNbr) {
        this.accountNbr = accountNbr;
    }
    
    public boolean isMatch(DocumentContent docContent, List ruleExtensions) {

        for (Iterator iter = ruleExtensions.iterator(); iter.hasNext();) {
            RuleExtension ruleExtension = (RuleExtension) iter.next();
            for (Iterator iterator = ruleExtension.getExtensionValues().iterator(); iterator.hasNext();) {
                RuleExtensionValue ruleKeyValue = (RuleExtensionValue) iterator.next();
                if (ruleKeyValue.getKey().equals(ACCOUNT_NBR_KEY)) {
                    this.accountNbr = ruleKeyValue.getValue();
                }
            }
        }
        
        Document doc = null;
        //try {
            doc = XmlHelper.buildJDocument(docContent.getDocument());
            List accountElements = XmlHelper.findElements(doc.getRootElement(), ACCOUNT_ATTRIBUTE);
            for (Iterator iter = accountElements.iterator(); iter.hasNext();) {
                Element accountElement = (Element) iter.next();
                Element accountNbrElement = accountElement.getChild(ACCOUNT_NBR_KEY);
                String xmlAccountNbr = accountNbrElement.getText();
                if (xmlAccountNbr.equals(accountNbr)) {
                    return true;
                }
            }
        /*} catch (InvalidXmlException e) {
            LOG.warn("Caught exception parsing xml", e);
        }*/
        
        return false;
    }

    public List getRuleRows() {
        List rows = new ArrayList();
        List fields = new ArrayList();
        fields.add(new Field("Account", "", Field.TEXT, false, ACCOUNT_NBR_KEY, "", null, LOOKUPABLE_CLASS, ACCOUNT_NBR_LOOKABLE_NAME));
        fields.add(new Field("", "", Field.QUICKFINDER, false, "", "", null, LOOKUPABLE_CLASS));
        rows.add(new Row(fields));
        return rows;
    }

    public List getRoutingDataRows() {
        return getRuleRows();
    }

    public String getDocContent() {
        return "<" + ACCOUNT_ATTRIBUTE + "><" + ACCOUNT_NBR_KEY + ">" + getAccountNbr() + "</" + ACCOUNT_NBR_KEY + "></" + ACCOUNT_ATTRIBUTE + ">";
    }

    public List getRuleExtensionValues() {
        List ruleExtensionValues = new ArrayList();
        ruleExtensionValues.add(new RuleExtensionValue(ACCOUNT_NBR_KEY, accountNbr));
        return ruleExtensionValues;
    }

    public List validateRoutingData(Map paramMap) {
        return validateRuleData(paramMap);
    }

    public List validateRuleData(Map paramMap) {
        List errors = new ArrayList();
        this.accountNbr = (String) paramMap.get(ACCOUNT_NBR_KEY);
        if (isRequired() && Utilities.isEmpty(this.accountNbr)) {
            errors.add(new WorkflowServiceErrorImpl("The account can not be empty", "routetemplate.accountruleattribute.account.invalid"));
        }
        return errors;
    }

    public void setRequired(boolean required) {
        this.required = required;
    }

    public boolean isRequired() {
        return required;
    }
    public String getAccountNbr() {
        return accountNbr;
    }
    public void setAccountNbr(String accountNbr) {
        this.accountNbr = accountNbr;
    }
}