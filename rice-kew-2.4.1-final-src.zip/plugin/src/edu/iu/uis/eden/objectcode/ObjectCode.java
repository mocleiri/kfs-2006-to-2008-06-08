/*
 * Copyright 2005-2007 The Kuali Foundation.
 * 
 * 
 * Licensed under the Educational Community License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 * http://www.opensource.org/licenses/ecl1.php
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package edu.iu.uis.eden.objectcode;

import edu.iu.uis.eden.WorkflowPersistable;

public class ObjectCode implements WorkflowPersistable {

    private static final org.apache.log4j.Logger LOG = org.apache.log4j.Logger.getLogger(ObjectCode.class);

    private String objectCd;
    private String finCoaCd;
    private String objectCdName;
    private Integer fiscalYear;

    private String returnUrl;



    public Object copy(boolean preserveKeys) {
        ObjectCode copy = new ObjectCode();
        copy.setFinCoaCd(getFinCoaCd());
        copy.setObjectCd(getObjectCd());
        copy.setObjectCdName(getObjectCdName());
        return copy;
    }

    public String getFinCoaCd() {
        return finCoaCd;
    }

    public void setFinCoaCd(String finCoaCd) {
        this.finCoaCd = finCoaCd;
    }

    public String getObjectCd() {
        return objectCd;
    }

    public void setObjectCd(String objectCd) {
        this.objectCd = objectCd;
    }

    public String getObjectCdName() {
        return objectCdName;
    }

    public void setObjectCdName(String objectCdName) {
        this.objectCdName = objectCdName;
    }

    public String getReturnUrl() {
        return returnUrl;
    }

    public void setReturnUrl(String returnUrl) {
        this.returnUrl = returnUrl;
    }
    public Integer getFiscalYear() {
        return fiscalYear;
    }
    public void setFiscalYear(Integer fiscalYear) {
        this.fiscalYear = fiscalYear;
    }
}