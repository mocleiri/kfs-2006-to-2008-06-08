package edu.iu.uis.eden.services.docelements;

import java.util.Collection;

import org.jdom.Element;

import edu.iu.uis.eden.WorkflowServiceErrorImpl;
import edu.iu.uis.eden.services.IDocElement;
import edu.iu.uis.eden.services.ServiceErrorConstants;


public class TestCompoundReviewerElement extends IDocInterfaceTestTemplate {
  private CompoundReviewerElement compoundReviewer;
  private String partyType;

  public TestCompoundReviewerElement(String s) {
    super(s);
  }

  protected void setUp() {
    compoundReviewer = new CompoundReviewerElement();
    partyType = "U";
  }

  protected void tearDown() {
  }

  public IDocElement getIDocElement() {
    return this.compoundReviewer;
  }

  /**
   * no it isn't
   */
  public void testIsRouteControl() {
    assertEquals("CompoundReviewElement is not a route control", false,
      this.compoundReviewer.isRouteControl());

    //try to set and restest
    this.compoundReviewer.setRouteControl(true);
    assertEquals("CompoundReviewElement is allowing route control to be set", false,
      this.compoundReviewer.isRouteControl());
  }

  /**
   * check that the correct root element is there
   */
  public void testGetXMLContent() {
    this.compoundReviewer.addReviewer("rkirkend", this.partyType);

    Element me = this.compoundReviewer.getXMLContent();
    assertEquals("didn't make element with correct name", me.getName(),
      this.compoundReviewer.getElementName());
  }

  /**
   * is a collection of the correct number coming back
   */
  public void testGetReviewerCollection() {
    this.compoundReviewer.addReviewer("rkirkend", this.partyType);
    this.compoundReviewer.addReviewer("andlee", this.partyType);

    Collection reviewers = this.compoundReviewer.getReviewers();
    assertEquals("returning collection with incorrect count", 2, reviewers.size());
  }

  /**
   * empty when has no reviewer not empty when has reviewers
   */
  public void testIsEmpty() {
    assertTrue("empty obj. reporting not empty", this.compoundReviewer.isEmpty());
  }

  /**
   * set some reviewers make xml make a compoundReviewer from that xml
   * and see if the reviewers are there
   */
  public void testLoadFromXMLContent() {
    String reviewer1 = "rkirkend";
    String reviewer2 = "andlee";
    String partyType = "u";

    this.compoundReviewer.addReviewer(reviewer1, partyType);
    this.compoundReviewer.addReviewer(reviewer2, partyType);

    Element me = this.compoundReviewer.getXMLContent();

    CompoundReviewerElement aCompoundReviewer = new CompoundReviewerElement();

    try {
      aCompoundReviewer.loadFromXMLContent(me, false);
    } catch (Exception ex) {
      fail("threw exception loading from self generated xml");
    }

    ReviewerElement aReviewer1 = aCompoundReviewer.getReviewer(reviewer1, partyType);
    ReviewerElement aReviewer2 = aCompoundReviewer.getReviewer(reviewer2, partyType);

    assertEquals("didn't properly load children props with self generated " + "xml", reviewer1,
      aReviewer1.getNetworkId());
    assertEquals("didn't properly load children props with self generated " + "xml", reviewer2,
      aReviewer2.getNetworkId());
  }

  /**
   * empty is invalid empty error.  All others are individual reviewer
   * object errors and is a child_in_error error
   */
  public void testValidate() {
    try {
      WorkflowServiceErrorImpl err = this.compoundReviewer.validate();
      assertEquals("empty compoundReviewer returned incorrect err type",
        ServiceErrorConstants.COMPOUND_REVIEWER_BLANK, err.getKey());

      //give incorrect value and recheck
      this.compoundReviewer.addReviewer("", "");
      err = this.compoundReviewer.validate();
      assertEquals("compoundReviewer with child in error returned incorrect " + "err type",
        ServiceErrorConstants.CHILDREN_IN_ERROR, err.getKey());

      //validate an individual element that isn't there
      assertNull("compoundReviewer returned wrong error type when " +
        "validating a child that wasn't present",
        this.compoundReviewer.validateReviewer("helloI'm Not there", "U"));

      /* test for a valid partyType but invalid networkId */
      this.compoundReviewer = new CompoundReviewerElement();
      compoundReviewer.addReviewer("I don't exist", "U");
      err = this.compoundReviewer.validate();
      assertNotNull("CompoundReviewerElement with incorrect username returned " +
        "null (or correct) on validate", err);
      assertEquals("CompoundReviewerElement in error returned wrong error " + "type",
        ServiceErrorConstants.CHILDREN_IN_ERROR, err.getKey());
    } catch (Exception ex) {
      fail("threw exception validating");
    }
  }
}





/*
 * Copyright 2003 The Trustees of Indiana University.  All rights reserved.
 *
 * This file is part of the EDEN software package.
 * For license information, see the LICENSE file in the top level directory
 * of the EDEN source distribution.
 */
