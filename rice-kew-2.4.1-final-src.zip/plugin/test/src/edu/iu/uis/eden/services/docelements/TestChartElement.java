package edu.iu.uis.eden.services.docelements;

import junit.framework.TestCase;

import org.jdom.Element;

import edu.iu.uis.eden.WorkflowServiceErrorImpl;
import edu.iu.uis.eden.exception.InvalidXmlException;
import edu.iu.uis.eden.services.InconsistentDocElementStateException;


public class TestChartElement extends TestCase {
  private ChartElement chartElement;

  public TestChartElement(String s) {
    super(s);
  }

  protected void setUp() {
    chartElement = new ChartElement();
    chartElement.setChart("BL");
    chartElement.setRouteControl(true);
  }

  protected void tearDown() {
  }

  /**
   * given a proper value does ChartElement make correct XML
   */
  public void testGetXMLContent() {
    //for now just test not null we can do better later
    chartElement.setChart("chart");
    assertNotNull("Returned null when loaded", chartElement.getXMLContent());
  }

  /**
   * given a jdom element of the correct type it should load itself to the value
   * of the given jdom element
   *
   * if the jdom element is null and allowBlanks true it should return
   *
   * if the jdom element is null and allowBlanks is false its should throw
   * an InconsistentDocElementStateException
   *
   * if the element is of the incorrect type it should throw an
   * InvalidXmlException
   */
  public void testLoadFromXMLContent() {
    //make a new chartElement with clear values
    ChartElement chart = new ChartElement();

    //make a jdom docs with the content
    Element chartRootEl = new Element("financial_chart_of_accounts_eok");
    chartRootEl.setAttribute("route-control", "yes");

    Element chartEl = new Element("fin_coa_cd");
    chartEl.setAttribute("value", "BL");
    chartRootEl.addContent(chartEl);

    try {
      chart.loadFromXMLContent(chartRootEl, false);
      assertEquals("Didn't properly load from a valid element", "BL", chart.getChart());
    } catch (InvalidXmlException ex) {
      fail("loadFromXMLContent threw an InvalidXmlException when using a " + "good Element");
    } catch (InconsistentDocElementStateException ex) {
      fail("loadFromXMLContent threw an InconsistentDocElementStateException " +
        "when using a good Element");
    }

    //give a chart a bad element
    chart = new ChartElement();
    chartEl = new Element("imbad");
    chartEl.setAttribute("value", "BL");

    try {
      chart.loadFromXMLContent(chartEl, false);
      fail("Didn't throw InvalidXMLContentExcecption when using a bad " + "element");
    } catch (InvalidXmlException ex) {
    } catch (InconsistentDocElementStateException ex) {
      fail("Didn't throw InvalidXMLContentExcecption when using a bad " +
        "element, threw InconsistentDocElementStateException instead");
    }

    //same thing but allow blanks
    chart = new ChartElement();

    try {
      chart.loadFromXMLContent(chartEl, true);
      fail("Didn't throw InvalidXMLContentExcecption when using a bad " + "element");
    } catch (InvalidXmlException ex) {
    } catch (InconsistentDocElementStateException ex) {
      fail("Didn't throw InvalidXMLContentExcecption when using a bad " +
        "element, threw InconsistentDocElementStateException instead");
    }

    //pass null and allow blanks nothing should happen
    chart = new ChartElement();

    try {
      chart.loadFromXMLContent(null, true);
    } catch (InvalidXmlException ex) {
      fail("Threw InvalidXmlException when passed a " + "null value and allowBlanks set to true");
    } catch (InconsistentDocElementStateException ex) {
      fail("Threw InconsistentDocElementStateException when passed a " +
        "null value and allowBlanks set to true");
    }

    //pass null and dont allow blanks
    chart = new ChartElement();

    try {
      chart.loadFromXMLContent(null, false);
      fail("Didn't Throw InconsistentDocElementStateException when passed a " +
        "null value and allowBlanks set to false");
    } catch (InvalidXmlException ex) {
      fail("Didn't Throw InconsistentDocElementStateException when passed a " +
        "null value and allowBlanks set to false");
    } catch (InconsistentDocElementStateException ex) {
    }
  }

  /**
   * test that validate returns null when chart is set and that a
   * DocElementError is returned when nothing is set
   */
  public void testValidate() {
    try {
      //validate the default chart should be true
      assertNull("Valid ChartElement didn't return null from validate", chartElement.validate());

      //make a new BAD ChartElement
      ChartElement chart = new ChartElement();
      WorkflowServiceErrorImpl error = (WorkflowServiceErrorImpl) chart.validate();

      assertNotNull("Invalid CharElement returned null on validate", error);
    } catch (Exception ex) {
      fail("threw exception validating");
    }
  }

  /**
   * can this guy populate himself w/ xml he made.
   */
  public void testCanFeedOnOwnXML() {
    ChartElement chart = new ChartElement();
    chart.setChart("chart");

    Element chartEl = chart.getXMLContent();

    ChartElement aChartEl = new ChartElement();

    try {
      aChartEl.loadFromXMLContent(chartEl, false);
    } catch (InvalidXmlException ex) {
      fail("XML generated invalid could not be loaded " + "by itself");
    } catch (InconsistentDocElementStateException ex) {
      fail("XML generated invalid could not be loaded " + "by itself");
    }

    assertEquals("Could not find value from XML it generated", chart.getChart(), aChartEl.getChart());
  }

  /**
   * this should be a route control according to now business rules
   */
  public void testIsRouteControl() {
    assertEquals("This should be a routeControl", true, this.chartElement.isRouteControl());
  }
}





/*
 * Copyright 2003 The Trustees of Indiana University.  All rights reserved.
 *
 * This file is part of the EDEN software package.
 * For license information, see the LICENSE file in the top level directory
 * of the EDEN source distribution.
 */
