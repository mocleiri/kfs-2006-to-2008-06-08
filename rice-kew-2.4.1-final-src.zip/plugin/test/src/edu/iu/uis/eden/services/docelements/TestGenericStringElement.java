package edu.iu.uis.eden.services.docelements;

import org.jdom.Element;

import edu.iu.uis.eden.WorkflowServiceErrorImpl;
import edu.iu.uis.eden.services.IDocElement;
import edu.iu.uis.eden.services.ServiceErrorConstants;


public class TestGenericStringElement extends IDocInterfaceTestTemplate {
  private GenericStringElement stringElement;
  private String elementName = "name";
  private String errType = ServiceErrorConstants.POSITION_TYPE_BLANK;

  public TestGenericStringElement(String s) {
    super(s);
  }

  protected void setUp() {
    stringElement = new GenericStringElement(elementName, errType, false);
  }

  protected void tearDown() {
  }

  public IDocElement getIDocElement() {
    return this.stringElement;
  }

  /**
   * does validate return the constant we want
   */
  public void testValidate() {
    try {
      WorkflowServiceErrorImpl error = this.stringElement.validate();
      assertNotNull("returned null on validate() when empty", error);

      assertEquals("returned error of wrong type", this.errType, error.getKey());
    } catch (Exception ex) {
      fail("threw exception validating");
    }
  }

  /**
   * verify element is being correctly built
   */
  public void testGetXMLContent() {
    //check that empty is giving null
    assertNull("empty object didn't return null on getXMLContent)",
      this.stringElement.getXMLContent());

    //set the value and get some xml
    this.stringElement.setMyValue("aValue");

    Element element = stringElement.getXMLContent();
    assertNotNull("set object returned null on getXMLContent()", element);
    assertEquals("didn't correctly make element name", this.elementName, element.getName());
    assertEquals("didn't correct put prop in xml", "aValue", element.getAttributeValue("value"));
  }

  /**
   * true when nothing is set false when something is set
   */
  public void testIsEmpty() {
    assertTrue("newly instantiated object returned false on " + "isEmpty()",
      this.stringElement.isEmpty());

    //set his value and retest
    this.stringElement.setMyValue("aValue");
    assertEquals("set object returned true on isEmpty()", false, this.stringElement.isEmpty());
  }

  /**
   * does he act correctly given an element
   */
  public void testLoadFromXMLContent() {
    Element element = new Element(this.elementName);
    element.setAttribute("value", "aValue");

    try {
      this.stringElement.loadFromXMLContent(element, false);
      assertEquals("didn't properly load prop from xml", "aValue", this.stringElement.getMyValue());
    } catch (Exception ex) {
      fail("threw exception loading from valid xml");
    }
  }
}





/*
 * Copyright 2003 The Trustees of Indiana University.  All rights reserved.
 *
 * This file is part of the EDEN software package.
 * For license information, see the LICENSE file in the top level directory
 * of the EDEN source distribution.
 */
