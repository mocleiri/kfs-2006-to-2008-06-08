package edu.iu.uis.eden.lookupable;

import java.lang.reflect.Field;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import junit.framework.TestCase;
import edu.iu.uis.eden.SpringServiceLocator;
import edu.iu.uis.eden.objectcode.ObjectCode;
import edu.iu.uis.eden.plugin.attributes.WorkflowLookupable;


public class ObjectCodeTestPENDING extends TestCase {
    private WorkflowLookupable workflowLookupable;
    private Map conversionFields;

    protected void setUp() throws Exception {
        SpringServiceLocator.setToTestMode(null);
        workflowLookupable = new ObjectCodeLookupableImpl();

        conversionFields = new HashMap();
        conversionFields.put("objectCd", "test_objectCd");
    }

    public void testGetColumns() {
        for (Iterator iter = workflowLookupable.getColumns().iterator(); iter.hasNext();) {
            Column column = (Column) iter.next();
            try {
                Field field = ObjectCode.class.getDeclaredField(column.getPropertyName());
            } catch (NoSuchFieldException e) {
                assertTrue("Column property name on ObjectCode does not equal a property on the ObjectCode bean. Column: "+column.getPropertyName(), false);                
            }
        }
    }
    
    public void testGetNoReturnParams() {
        String parameters = workflowLookupable.getNoReturnParams(conversionFields);

        assertTrue("Return parameter objectCd is not correct.", parameters.indexOf("test_objectCd=") > 0);
    }
}
