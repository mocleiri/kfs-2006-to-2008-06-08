package edu.iu.uis.eden.hrmsreviewhierarchy;

import java.sql.Timestamp;
import java.util.Collection;
import java.util.Date;

import junit.framework.TestCase;
import edu.iu.uis.eden.SpringServiceLocator;
//import edu.iu.uis.eden.routemodules.hrmsreviewhierarchy.HRMSReviewHierarchy;
//import edu.iu.uis.eden.routemodules.hrmsreviewhierarchy.HRMSReviewHierarchyService;

public class TestHRMSReviewHierarchyServicePENDING extends TestCase {

/*    private String userName = "rkirkend";

    private HRMSReviewHierarchy hrmsReviewHier;
    private HRMSReviewHierarchy hrmsReviewHier2;
    private HRMSReviewHierarchy hrmsReviewHier3;

    protected void setUp() {
        SpringServiceLocator.setToTestMode(null);        
        hrmsReviewHier = new HRMSReviewHierarchy();
        hrmsReviewHier.setActionRequest("C");
        hrmsReviewHier.setActiveInd("Y");
        hrmsReviewHier.setDocTypeName("AddHRRv");
        hrmsReviewHier.setFinCoaCd("BL");
        hrmsReviewHier.setFromDate(new Timestamp(new Date().getTime() - 10000));
        hrmsReviewHier.setToDate(new Timestamp(new Date().getTime() + 10000));
        hrmsReviewHier.setOrgCd("BL");
        hrmsReviewHier.setUserType("U");
        hrmsReviewHier.setPriority(new Integer(1));
        hrmsReviewHier.setResponsibilityId(new Long(1));
        hrmsReviewHier.setRuleId(new Long(1));
        hrmsReviewHier.setReviewDesc("Test HRMS Review Hierarchy 1");
        hrmsReviewHier.setWorkflowId(this.userName);
        hrmsReviewHier.setSalaryPlan("CL");
        hrmsReviewHier.setPositionType("SB");
        hrmsReviewHier.setWorkgroupId(new Long(0));
        
        this.getHRMSReviewHierarchyService().save(hrmsReviewHier);

        hrmsReviewHier2 = new HRMSReviewHierarchy();
        hrmsReviewHier2.setActionRequest("A");
        hrmsReviewHier2.setActiveInd("Y");
        hrmsReviewHier2.setDocTypeName("AddHRRv");
        hrmsReviewHier2.setFinCoaCd("BL");
        hrmsReviewHier2.setFromDate(new Timestamp(new Date().getTime() - 10000));
        hrmsReviewHier2.setToDate(new Timestamp(new Date().getTime() + 10000));
        hrmsReviewHier2.setOrgCd("CHEM");
        hrmsReviewHier2.setUserType("W");
        hrmsReviewHier2.setPriority(new Integer(1));
        hrmsReviewHier2.setResponsibilityId(new Long(2));
        hrmsReviewHier2.setRuleId(new Long(2));
        hrmsReviewHier2.setReviewDesc("Test HRMS Review Hierarchy 2");
        hrmsReviewHier2.setWorkgroupId(new Long(1));
        hrmsReviewHier2.setSalaryPlan("PA");
        hrmsReviewHier2.setPositionType("SM");
        hrmsReviewHier2.setWorkflowId(null);
        
        this.getHRMSReviewHierarchyService().save(hrmsReviewHier2);

        hrmsReviewHier3 = new HRMSReviewHierarchy();
        hrmsReviewHier3.setActionRequest("A");
        hrmsReviewHier3.setActiveInd("N");
        hrmsReviewHier3.setDocTypeName("AddHRRv");
        hrmsReviewHier3.setFinCoaCd("BL");
        hrmsReviewHier3.setFromDate(new Timestamp(new Date().getTime() - 10000));
        hrmsReviewHier3.setToDate(new Timestamp(new Date().getTime() + 10000));
        hrmsReviewHier3.setOrgCd("ARSC");
        hrmsReviewHier3.setUserType("U");
        hrmsReviewHier3.setPriority(new Integer(1));
        hrmsReviewHier3.setResponsibilityId(new Long(3));
        hrmsReviewHier3.setRuleId(new Long(3));
        hrmsReviewHier3.setReviewDesc("Test HRMS Review Hierarchy 3");
        hrmsReviewHier3.setWorkflowId(this.userName);
        hrmsReviewHier3.setSalaryPlan("HR");
        hrmsReviewHier3.setPositionType("HR");
        hrmsReviewHier3.setWorkgroupId(new Long(0));
        
        this.getHRMSReviewHierarchyService().save(hrmsReviewHier3);
    }

    protected void tearDown() throws Exception {
        this.getHRMSReviewHierarchyService().delete(hrmsReviewHier);
        this.getHRMSReviewHierarchyService().delete(hrmsReviewHier2);
        this.getHRMSReviewHierarchyService().delete(hrmsReviewHier3);

        hrmsReviewHier = this.getHRMSReviewHierarchyService().findByRuleId(hrmsReviewHier.getRuleId());
        hrmsReviewHier2 = this.getHRMSReviewHierarchyService().findByRuleId(hrmsReviewHier2.getRuleId());
        hrmsReviewHier3 = this.getHRMSReviewHierarchyService().findByRuleId(hrmsReviewHier3.getRuleId());

        if (hrmsReviewHier != null || hrmsReviewHier2 != null || hrmsReviewHier3 != null) {
            throw new Exception("The hrms review hierarchy data has not been deleted from the database");
        }
    }

    public void testFindByResponsibilityId() throws Exception {
        Collection hrmsReviewHierarchies = this.getHRMSReviewHierarchyService().findByResponsibilityId(hrmsReviewHier.getResponsibilityId());
        assertFalse("Database rows were not retrieved for responsibility id", hrmsReviewHierarchies.isEmpty());
        assertFalse("Too many database rows returned for responsibility id", hrmsReviewHierarchies.size() > 1);
        assertEquals("Wrong database row retrieved for responsibility id", hrmsReviewHier.getReviewDesc(), ((HRMSReviewHierarchy) hrmsReviewHierarchies.iterator().next()).getReviewDesc());
    }

    public void testFindByRuleId() throws Exception {
        HRMSReviewHierarchy hrmsReviewHier4 = this.getHRMSReviewHierarchyService().findByRuleId(hrmsReviewHier2.getRuleId());
        assertNotNull("A hrms review hierarchy database row was not retrieved for rule id", hrmsReviewHier4);
        assertEquals("Wrong database row retrieved for rule id", hrmsReviewHier2.getReviewDesc(), hrmsReviewHier4.getReviewDesc());
    }

    public void testNarrowingFind() throws Exception {
        Collection hrmsReviewHierarchies = this.getHRMSReviewHierarchyService().narrowingFind(hrmsReviewHier3);
        assertFalse("Database rows were not retrieved for narrowing find", hrmsReviewHierarchies.isEmpty());
        assertFalse("Too many database rows returned for narrowing find", hrmsReviewHierarchies.size() > 1);
        assertEquals("Wrong database row retrieved for narrowing find", hrmsReviewHier3.getReviewDesc(), ((HRMSReviewHierarchy) hrmsReviewHierarchies.iterator().next()).getReviewDesc());
    }

    public void testFindRules() throws Exception {
        Collection rules = this.getHRMSReviewHierarchyService().findRules(hrmsReviewHier);
        assertFalse("Database rows were not retrieved when finding rules", rules.isEmpty());
        assertFalse("Too many database rows returned when finding rules", rules.size() > 1);
        assertEquals("Wrong database row retrieved when finding rules", hrmsReviewHier.getReviewDesc(), ((HRMSReviewHierarchy) rules.iterator().next()).getReviewDesc());
    }

    private HRMSReviewHierarchyService getHRMSReviewHierarchyService() {
        return (HRMSReviewHierarchyService) SpringServiceLocator.getService(SpringServiceLocator.HRMS_REVIEW_HIERARCHY_SRV);
    }
*/
}

/*
 * Copyright 2003 The Trustees of Indiana University. All rights reserved. This file is part of the EDEN software package. For license information, see the LICENSE file in the top level directory of the EDEN source distribution.
 */
