package edu.iu.uis.eden.services.docelements;

import junit.framework.TestCase;

import org.jdom.Element;
import org.jdom.output.XMLOutputter;

import edu.iu.uis.eden.WorkflowServiceErrorImpl;
import edu.iu.uis.eden.exception.InvalidXmlException;
import edu.iu.uis.eden.services.IDocElement;
import edu.iu.uis.eden.services.InconsistentDocElementStateException;
import edu.iu.uis.eden.services.ServiceErrorConstants;


public class TestUniversityOrganizationElement extends TestCase {
  UniversityOrganizationElement univElement;

  public TestUniversityOrganizationElement(String s) {
    super(s);
  }

  protected void setUp() {
    univElement = new UniversityOrganizationElement();
  }

  protected void tearDown() {
  }

  /**
   * this is a route control
   */
  public void testIsRouteControl() {
    assertTrue("UniversityOrganizationElement is a route control", univElement.isRouteControl());

    //attempt to set it to false
    univElement.setRouteControl(false);
    assertTrue("UniversityOrganizationElement is a route control", univElement.isRouteControl());
  }

  /**
   * test that this guy is returning an Element that contains good xml.
   */
  public void testGetXMLContent() {
    String goodXML = "<university_organization_eok route-control=\"yes\">" +
      "<financial_chart_of_accounts_eok route-control=\"yes\">" + "<fin_coa_cd value=\"BL\" />" +
      "</financial_chart_of_accounts_eok>" + "<org_cd value=\"ACQU\" />" +
      "</university_organization_eok>";

    univElement.setChart("BL");
    univElement.setOrgCode("ACQU");
    assertEquals("Didn't make element containing correct xml", goodXML,
      this.makeElementXMLString(univElement.getXMLContent()));
  }

  /**
   * if chart and org have been set we're valid if one hasn't we're not
   */
  public void testValidate() {
    try {
      //this should error
      WorkflowServiceErrorImpl error = univElement.validate();
      assertNotNull("invalid object returned null on validate", error);

      univElement.setChart("BL");
      error = univElement.validate();
      assertNotNull("invalid object returned null on validate", error);

      univElement.setOrgCode("ACQU");
      assertNull("valid object didn't return null on validation", univElement.validate());

      /* test a bad combo */
      univElement.setChart("imbad");

      WorkflowServiceErrorImpl err = univElement.validate();
      assertNotNull("invalid UniversityOrganizationElement didn't return " + "an error object", err);

      /* test that the correct constant is coming back */
      assertEquals("invalid UniversityOrganizationElement returned " +
        "DocElementError of the wrong type", ServiceErrorConstants.UNIVERSITY_ORGANIZATION_INVALID,
        err.getKey());
    } catch (Exception ex) {
      ex.printStackTrace();
      fail("threw exception validating");
    }
  }

  /**
   * pass good xml this dudes way and see if the props are loaded correctly
   * and the proper exceptions thrown
   */
  public void testLoadFromXMLContent() {
    //make an element representative of just a chart in there
    Element element = new Element(univElement.getElementName());
    ChartElement chartElement = new ChartElement();
    chartElement.setChart("BL");
    element.addContent(chartElement.getXMLContent());

    //missing org add but allowblanks
    try {
      univElement.loadFromXMLContent(element, true);
      assertEquals("didn't properly load props from a good element", "BL", univElement.getChart());
    } catch (Exception ex) {
      fail("threw exception loading from good element but missing org");
    }

    //try the same but missing chart
    univElement = new UniversityOrganizationElement();
    element = new Element(univElement.getElementName());

    OrgCodeElement orgCode = new OrgCodeElement();
    orgCode.setOrgCode("BL");
    element.addContent(orgCode.getXMLContent());

    try {
      univElement.loadFromXMLContent(element, true);
      assertEquals("didn't properly load props from a good element", "BL", univElement.getOrgCode());
    } catch (Exception ex) {
      fail("threw exception loading from good element but missing chart");
    }

    this.nonClassSpecificLoadFromXMLTests(univElement);
  }

  /**
   * can this guy populate himself w/ xml he made.
   */
  public void testCanFeedOnOwnXML() {
    String chart = "BL";
    String org = "BL";

    univElement.setChart("BL");
    univElement.setOrgCode("BL");

    Element element = univElement.getXMLContent();
    UniversityOrganizationElement aUnivElement = new UniversityOrganizationElement();

    try {
      aUnivElement.loadFromXMLContent(element, false);
    } catch (Exception ex) {
      fail("threw exception loading from self generated xml");
    }

    assertEquals("Didn't properly load chart from element", chart, aUnivElement.getChart());
    assertEquals("didn't properly load org from element", org, aUnivElement.getChart());
  }

  /**
   * utility method that is not object specific
   *
   * @param docElement the docElement being tested
   */
  public void nonClassSpecificLoadFromXMLTests(IDocElement docElement) {
    //give null allow blanks
    try {
      docElement.loadFromXMLContent(null, true);
    } catch (Exception ex) {
      fail("threw exception loading null element set to allow blanks");
    }

    //give null dont allow blanks
    try {
      docElement.loadFromXMLContent(null, false);
      fail("didn't throw InconsistentDocElementStateException " +
        "loaded with null element allowBlanks set to false");
    } catch (InconsistentDocElementStateException ex) {
    } catch (InvalidXmlException ex) {
      fail("didn't throw InconsistentDocElementStateException " +
        "loaded with null element allowBlanks set to false");
    }

    //give element of wrong type
    try {
      docElement.loadFromXMLContent(new Element("Imbad"), false);
      fail("Didn't throw InvalidXmlException when loaded with " + "element of the wrong type");
    } catch (InconsistentDocElementStateException ex) {
      fail("Didn't throw InvalidXmlException when loaded with " + "element of the wrong type");
    } catch (InvalidXmlException ex) {
    }
  }

  public String makeElementXMLString(Element element) {
    XMLOutputter outputter = new XMLOutputter();

    return outputter.outputString(element);
  }
}





/*
 * Copyright 2003 The Trustees of Indiana University.  All rights reserved.
 *
 * This file is part of the EDEN software package.
 * For license information, see the LICENSE file in the top level directory
 * of the EDEN source distribution.
 */
