package edu.iu.uis.eden.services.docelements;

import junit.framework.TestCase;

import org.jdom.Element;
import org.jdom.output.XMLOutputter;

import edu.iu.uis.eden.exception.InvalidXmlException;
import edu.iu.uis.eden.services.IDocElement;
import edu.iu.uis.eden.services.InconsistentDocElementStateException;


public class TestHeaderElement extends TestCase {
  private HeaderElement header;

  public TestHeaderElement(String s) {
    super(s);
  }

  protected void setUp() {
    header = new HeaderElement();
  }

  protected void tearDown() {
  }

  /**
   * this is not a routeControl
   */
  public void testIsRouteControl() {
    assertEquals("Header is returning true on isRouteControl", false, header.isRouteControl());

    //try and make it one
    header.setRouteControl(true);
    assertEquals("Header is returning true on isRouteControl", false, header.isRouteControl());
  }

  /**
   * get null if empty.
   *
   * If keys and values are set verify in the xml
   */
  public void testGetXMLContent() {
    assertNull("Empty header didn't return null on getXMLContent", header.getXMLContent());

    String key = "key";
    String value = "value";
    header.setKeyValuePair(key, value);

    Element element = header.getXMLContent();
    Element keyElement = element.getChild(key);
    assertNotNull("didn't make an element for an existing key/value pair", keyElement);
    assertEquals("didn't properly put key/values in xml", value, keyElement.getAttributeValue(value));

    //add another key/value pair test for it
    String key2 = "key2";
    String value2 = "value2";
    header.setKeyValuePair(key2, value2);

    element = header.getXMLContent();
    keyElement = element.getChild(key2);

    assertNotNull("didn't make an element for an existing key/value pair", keyElement);
    assertEquals("didn't properly put key/values in xml", value2,
      keyElement.getAttributeValue(value));
  }

  /**
   * standard interface tests and loading correct value/key pairs
   * from the element
   */
  public void testLoadFromXMLContent() {
    Element rootEl = new Element(header.getElementName());

    //make a key/value element
    Element keyValue1 = new Element("key1");
    keyValue1.setAttribute("value", "value1");

    //make another key/value element
    Element keyValue2 = new Element("key2");
    keyValue2.setAttribute("value", "value2");

    //add them to the header element
    rootEl.addContent(keyValue1);
    rootEl.addContent(keyValue2);

    try {
      header.loadFromXMLContent(rootEl, false);
    } catch (Exception ex) {
      fail("threw exception loading from valid element");
    }

    assertEquals("Didn't properly load HashMap from elements", "value1",
      header.getValueByKey("key1"));
    assertEquals("Didn't properly load HashMap from elements", "value2",
      header.getValueByKey("key2"));

    //test interface actions
    this.nonClassSpecificLoadFromXMLTests(header);
  }

  /**
   * currently always valid
   */
  public void testValidate() {
    try {
      assertNull("didn't return null on valid (blank) object", header.validate());

      //load and check for same result
      header.setKeyValuePair("key", "value");
      assertNull("didn't return null on valid object", header.validate());
    } catch (Exception ex) {
      fail("threw exception validating");
    }
  }

  /**
   * can this guy populate himself w/ xml he made.
   */
  public void testCanFeedOnOwnXML() {
    String key1 = "key1";
    String key2 = "key2";
    String value1 = "value1";
    String value2 = "value2";
    header.setKeyValuePair(key1, value1);
    header.setKeyValuePair(key2, value2);

    Element headerEl = header.getXMLContent();

    HeaderElement aHeader = new HeaderElement();

    try {
      aHeader.loadFromXMLContent(headerEl, false);
      assertEquals("Didn't properly set props from self generated element", value1,
        header.getValueByKey(key1));
      assertEquals("Didn't properly set props from self generated element", value2,
        header.getValueByKey(key2));
    } catch (Exception ex) {
      fail("threw exception loading from self generated element");
    }
  }

  /**
   * utility method that is not object specific
   *
   * @param docElement the docElement being tested
   */
  public void nonClassSpecificLoadFromXMLTests(IDocElement docElement) {
    //give null allow blanks
    try {
      docElement.loadFromXMLContent(null, true);
    } catch (Exception ex) {
      fail("threw exception loading null element set to allow blanks");
    }

    //give null dont allow blanks
    try {
      docElement.loadFromXMLContent(null, false);
      fail("didn't throw InconsistentDocElementStateException " +
        "loaded with null element allowBlanks set to false");
    } catch (InconsistentDocElementStateException ex) {
    } catch (InvalidXmlException ex) {
      fail("didn't throw InconsistentDocElementStateException " +
        "loaded with null element allowBlanks set to false");
    }

    //give element of wrong type
    try {
      docElement.loadFromXMLContent(new Element("Imbad"), false);
      fail("Didn't throw InvalidXmlException when loaded with " + "element of the wrong type");
    } catch (InconsistentDocElementStateException ex) {
      fail("Didn't throw InvalidXmlException when loaded with " + "element of the wrong type");
    } catch (InvalidXmlException ex) {
    }
  }

  public String makeElementXMLString(Element element) {
    XMLOutputter outputter = new XMLOutputter();

    return outputter.outputString(element);
  }
}





/*
 * Copyright 2003 The Trustees of Indiana University.  All rights reserved.
 *
 * This file is part of the EDEN software package.
 * For license information, see the LICENSE file in the top level directory
 * of the EDEN source distribution.
 */
