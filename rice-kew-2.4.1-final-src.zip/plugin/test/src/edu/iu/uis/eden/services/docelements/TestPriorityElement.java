package edu.iu.uis.eden.services.docelements;

import java.io.StringReader;

import junit.framework.TestCase;

import org.jdom.Document;
import org.jdom.Element;

import edu.iu.uis.eden.WorkflowServiceErrorImpl;
import edu.iu.uis.eden.exception.InvalidXmlException;
import edu.iu.uis.eden.services.IDocElement;
import edu.iu.uis.eden.services.InconsistentDocElementStateException;
import edu.iu.uis.eden.services.ServiceErrorConstants;
import edu.iu.uis.eden.util.XmlHelper;


public class TestPriorityElement extends TestCase {
  private PriorityElement priority;

  public TestPriorityElement(String s) {
    super(s);
  }

  protected void setUp() {
    priority = new PriorityElement();
  }

  protected void tearDown() {
  }

  /**
   * must be greater than 0
   */
  public void testValidate() {
    try {
      /* should get invalid priority type */
      WorkflowServiceErrorImpl error = this.priority.validate();
      assertEquals("did not return DocElementError with correct " + "type",
        ServiceErrorConstants.PRIORITY_INVALID, error.getKey());

      /* give it a valid value */
      this.priority.setPriority(1);
      assertNull("valid object didn't return null", priority.validate());
    } catch (Exception ex) {
      fail("threw exception validating");
    }
  }

  /**
   * given a jdom element of the correct type it should load itself to the value
   * of the given jdom element
   *
   * if the jdom element is null and allowBlanks true it should return
   *
   * if the jdom element is null and allowBlanks is false its should throw
   * an InconsistentDocElementStateException
   *
   * if the element is of the incorrect type it should throw an
   * InvalidXmlException
   */
  public void testLoadFromXMLContent() {
    Element priorityEl = new Element(priority.getElementName());
    priorityEl.setAttribute("value", new Long(1).toString());

    try {
      priority.loadFromXMLContent(priorityEl, false);
      assertEquals("didn't properly load props from good xml", 1, priority.getPriority());
    } catch (Exception ex) {
      fail("threw exception loading from good element");
    }
  }

  /**
   * is not a routeControl
   */
  public void testIsRouteControl() {
    //test default val
    assertEquals("returning true on isRouteControl", false, priority.isRouteControl());

    //set true and retest
    priority.setRouteControl(true);
    assertEquals("returning true on isRouteControl", false, priority.isRouteControl());
  }

  /**
   * does PriorityElement render correct XML
   */
  public void testGetXMLContent() {
    priority.setPriority(1);
    assertNotNull("Loaded priority returned null on getXMLContent", priority.getXMLContent());
  }

  /**
   * can this guy populate himself w/ xml he made.
   */
  public void testCanFeedOnOwnXML() {
    priority.setPriority(1);

    Element xmlContent = priority.getXMLContent();

    PriorityElement testPriority = new PriorityElement();

    try {
      testPriority.loadFromXMLContent(xmlContent, false);
      assertEquals("didn't correctly load props from self generated xml", 1,
        testPriority.getPriority());
    } catch (Exception ex) {
      fail("threw exception loading from self generated xml");
    }
  }

  /**
   * utility method that is not object specific
   *
   * @param docElement the docElement being tested
   */
  public void nonClassSpecificLoadFromXMLTests(IDocElement docElement) {
    //give null allow blanks
    try {
      docElement.loadFromXMLContent(null, true);
    } catch (Exception ex) {
      fail("threw exception loading null element set to allow blanks");
    }

    //give null dont allow blanks
    try {
      docElement.loadFromXMLContent(null, false);
      fail("didn't throw InconsistentDocElementStateException " +
        "loaded with null element allowBlanks set to false");
    } catch (InconsistentDocElementStateException ex) {
    } catch (InvalidXmlException ex) {
      fail("didn't throw InconsistentDocElementStateException " +
        "loaded with null element allowBlanks set to false");
    }

    //give element of wrong type
    try {
      docElement.loadFromXMLContent(new Element("Imbad"), false);
      fail("Didn't throw InvalidXmlException when loaded with " + "element of the wrong type");
    } catch (InconsistentDocElementStateException ex) {
      fail("Didn't throw InvalidXmlException when loaded with " + "element of the wrong type");
    } catch (InvalidXmlException ex) {
    }
  }

  public Element makeStringElement(String xmlContent) {
    Document doc = null;

    try {
      doc = new Document(XmlHelper.buildJDocument(new StringReader(xmlContent), false)
                                  .getRootElement());
    } catch (InvalidXmlException ex) {
      fail("Generated invalid xml");
    }

    return doc.getRootElement();
  }
}





/*
 * Copyright 2003 The Trustees of Indiana University.  All rights reserved.
 *
 * This file is part of the EDEN software package.
 * For license information, see the LICENSE file in the top level directory
 * of the EDEN source distribution.
 */
