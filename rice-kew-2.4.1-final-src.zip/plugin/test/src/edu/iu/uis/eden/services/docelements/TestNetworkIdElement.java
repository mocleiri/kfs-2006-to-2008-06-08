package edu.iu.uis.eden.services.docelements;

import junit.framework.TestCase;

import org.jdom.Element;

import edu.iu.uis.eden.exception.InvalidXmlException;
import edu.iu.uis.eden.services.InconsistentDocElementStateException;


public class TestNetworkIdElement extends TestCase {
  private NetworkIdElement networkId;

  public TestNetworkIdElement(String s) {
    super(s);
  }

  protected void setUp() {
    networkId = new NetworkIdElement();
    networkId.setNetworkId("rkirkend");
  }

  protected void tearDown() {
  }

  /**
   * if networkId is set null should be returned.
   *
   * if networkId is null or empty DocElementError should be returned.
   */
  public void testValidate() {
    try {
      //start with the default a known good guy
      assertNull("Correctly Loaded failed validation", networkId.validate());

      //make a new trouble maker
      networkId = new NetworkIdElement();

      networkId.validate();

      assertNotNull("Validate on incorrect NetworkIdElement returned null", networkId.validate());

      //set networkId blank and verify an error
      networkId.setNetworkId("");
      assertNotNull("Validate on incorrect NetworkIdElement returned null", networkId.validate());
    } catch (Exception ex) {
      fail("threw exception validating");
    }
  }

  /**
   * load the guy from valid element and check that props are set
   *
   * load the guy w/ null element but allowBlanks and make sure
   * exception isn't thrown
   *
   * load the guy w/ null don't allowBlanks and make sure
   * exception is thrown
   *
   * load with element of wrong type and check that invalidXMLException is thrown
   */
  public void testLoadFromXMLContent() {
    NetworkIdElement networkId = new NetworkIdElement();
    String daId = "rkirkend";

    Element networkEl = new Element(networkId.getElementName());
    networkEl.setAttribute("value", daId);

    try {
      networkId.loadFromXMLContent(networkEl, false);
      assertEquals("Did not properly load props from element", daId, networkId.getNetworkId());
    } catch (Exception ex) {
      fail("threw exception loading from valid element");
    }

    // give null element allow blanks
    try {
      networkId.loadFromXMLContent(null, true);
    } catch (Exception ex) {
      fail("threw exception loading from null element with allowBlanks " + "set true");
    }

    //give null element don't allow blanks
    try {
      networkId.loadFromXMLContent(null, false);
      fail("didn't throw InconsistentDocElementStateException loaded " +
        "with null element and allowBlanks set false");
    } catch (InconsistentDocElementStateException ex) {
    } catch (InvalidXmlException ex) {
      fail("didn't throw InconsistentDocElementStateException loaded " +
        "with null element and allowBlanks set false");
    }

    //give wrong type of element
    try {
      networkId.loadFromXMLContent(new Element("imbad"), true);
      fail("didn't throw InvalidXmlException loaded with wrong type " + "of element");
    } catch (InvalidXmlException ex) {
    } catch (InconsistentDocElementStateException ex) {
      fail("didn't throw InvalidXmlException loaded with wrong type " + "of element");
    }
  }

  /**
   * test that this sucker gives the correct XML.  This is dependent upon the
   * object made in setUp();
   */
  public void testGetXMLContent() {
    assertNotNull("Returned null when loaded", networkId.getXMLContent());
  }

  /**
   * should not be a routeControl according to the current rules
   */
  public void testIsRouteControl() {
    assertEquals("This should not be a routeControl according to the " + "current business rules",
      false, networkId.isRouteControl());
  }

  /**
   * can the object load from the same xml in generates and arrive at the same
   * property value
   */
  public void testFeedFromOwnXML() {
    Element xmlContent = networkId.getXMLContent();

    NetworkIdElement aNetworkIdEl = new NetworkIdElement();

    try {
      aNetworkIdEl.loadFromXMLContent(xmlContent, false);
    } catch (InvalidXmlException ex) {
      fail("XML generated invalid could not be loaded " + "by itself");
    } catch (Exception ex) {
      fail("XML generated invalid could not be loaded " + "by itself");
    }

    assertEquals("Could not find value from XML it generated", "rkirkend",
      aNetworkIdEl.getNetworkId());
  }
}





/*
 * Copyright 2003 The Trustees of Indiana University.  All rights reserved.
 *
 * This file is part of the EDEN software package.
 * For license information, see the LICENSE file in the top level directory
 * of the EDEN source distribution.
 */
