package org.apache.ojb.broker.core;

/* Copyright 2003-2004 The Apache Software Foundation
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

import java.util.HashMap;
import java.util.WeakHashMap;
import java.util.Iterator;

import org.apache.ojb.broker.PBFactoryException;
import org.apache.ojb.broker.PBKey;
import org.apache.ojb.broker.PersistenceBroker;
import org.apache.ojb.broker.PersistenceBrokerException;

/**
 * Helper class that tracks correspondence between PersistenceBroker instances
 * and threads. The main task that this class solves is: to get current
 * PersistenceBroker for the given thread. For internal use only.
 *
 * @author Oleg Nitz
 * @version $Id: PersistenceBrokerThreadMapping.java,v 1.6 2004/04/04 23:53:33 brianm Exp $
 */
public class PersistenceBrokerThreadMapping
{
    /**
     * The hashmap that maps PBKeys to current brokers for the thread
     **/
    private static ThreadLocal currentBrokerMap = new ThreadLocal();

    public static void setCurrentPersistenceBroker(PBKey key, PersistenceBroker broker)
         throws PBFactoryException
    {
        HashMap map = (HashMap) currentBrokerMap.get();
        WeakHashMap set = null;
        if (map == null)
        {
            map = new HashMap();
            currentBrokerMap.set(map);
        }
        else
        {
            set = (WeakHashMap) map.get(key);
        }

        if (set == null)
        {
            // We emulate weak HashSet using WeakHashMap
            set = new WeakHashMap();
            map.put(key, set);
        }
        set.put(broker, null);
    }

    public static void unsetCurrentPersistenceBroker(PBKey key, PersistenceBroker broker)
         throws PBFactoryException
    {
        HashMap map = (HashMap) currentBrokerMap.get();
        WeakHashMap set = null;
        if (map != null)
        {
            set = (WeakHashMap) map.get(key);
            if (set != null)
            {
                set.remove(broker);
            }
        }
    }

    /**
     * Return the current open {@link org.apache.ojb.broker.PersistenceBroker}
     * instance for the given {@link org.apache.ojb.broker.PBKey}, if any.
     * @param key
     * @return null if no open {@link org.apache.ojb.broker.PersistenceBroker} found.
     */
    public static PersistenceBroker currentPersistenceBroker(PBKey key)
         throws PBFactoryException, PersistenceBrokerException
    {
        HashMap map = (HashMap) currentBrokerMap.get();
        WeakHashMap set;
        PersistenceBroker broker = null;

        if (map == null)
        {
            return null;
        }

        set = (WeakHashMap) map.get(key);
        if (set == null)
        {
            return null;
        }

        // seek for an open broker, preferably in transaction
        for (Iterator it = set.keySet().iterator(); it.hasNext(); )
        {
            PersistenceBroker tmp = (PersistenceBroker) it.next();
            if (tmp == null || tmp.isClosed())
            {
                it.remove();
                continue;
            }
            broker = tmp;
            if (tmp.isInTransaction())
            {
                break; // the best choice found
            }
        }
        return broker;
    }
}
