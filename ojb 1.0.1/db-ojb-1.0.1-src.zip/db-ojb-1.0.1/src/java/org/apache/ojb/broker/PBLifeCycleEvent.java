package org.apache.ojb.broker;

/* Copyright 2003-2004 The Apache Software Foundation
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

import org.apache.commons.lang.builder.ToStringBuilder;
import org.apache.commons.lang.builder.ToStringStyle;

/**
 * The <code>PBLifeCycleEvent</code> encapsulates information about
 * the life-cycle of a persistent object.
 * <br/>
 * NOTE:
 * <br/>
 * Because of performance reasons OJB intern reuse instances of this class
 * by reset target object.
 *
 * @author <a href="mailto:armin@codeAuLait.de">Armin Waibel</a>
 * @version $Id: PBLifeCycleEvent.java,v 1.5 2004/04/04 23:53:30 brianm Exp $
 */
public final class PBLifeCycleEvent extends PersistenceBrokerEvent
{
    public static final int TYPE_BEFORE_INSERT = 1;
    public static final int TYPE_BEFORE_DELETE = 2;
    public static final int TYPE_BEFORE_UPDATE = 3;
    public static final int TYPE_AFTER_UPDATE = 4;
    public static final int TYPE_AFTER_DELETE = 5;
    public static final int TYPE_AFTER_LOOKUP = 6;
    public static final int TYPE_AFTER_INSERT = 7;

    private Type eventType;
    private Object target;

    public PBLifeCycleEvent(PersistenceBroker broker, Object target, Type eventType)
    {
        super(broker);
        this.target = target;
        this.eventType = eventType;
    }

    public PBLifeCycleEvent(PersistenceBroker broker, Type type)
    {
        super(broker);
        this.eventType = type;
    }

    /**
     * Try to find an {@link PersistenceBrokerAware} target object.
     */
    public PersistenceBrokerAware getPersitenceBrokerAware()
    {
        if (target != null && target instanceof PersistenceBrokerAware)
        {
            return (PersistenceBrokerAware) target;
        }
        else
            return null;
    }

    /**
     * Set the object the event belongs to.
     */
    public void setTarget(Object obj)
    {
        this.target = obj;
    }

    /**
     * Returns the object the event belongs to.
     */
    public Object getTarget()
    {
        return target;
    }

    public String toString()
    {
        ToStringBuilder buf = new ToStringBuilder(this, ToStringStyle.MULTI_LINE_STYLE);
        buf.append("target object", target).
                append("source object", getSource()).
                append("eventType", eventType.toString());
        return buf.toString();
    }

    public Type getEventType()
    {
        return eventType;
    }

    //**********************************************************************
    // Immutable inner class
    //**********************************************************************
    public static class Type
    {
        public static final Type BEFORE_INSERT = new Type(TYPE_BEFORE_INSERT);
        public static final Type BEFORE_UPDATE = new Type(TYPE_BEFORE_UPDATE);
        public static final Type AFTER_INSERT = new Type(TYPE_AFTER_INSERT);
        public static final Type AFTER_UPDATE = new Type(TYPE_AFTER_UPDATE);
        public static final Type BEFORE_DELETE = new Type(TYPE_BEFORE_DELETE);
        public static final Type AFTER_DELETE = new Type(TYPE_AFTER_DELETE);
        public static final Type AFTER_LOOKUP = new Type(TYPE_AFTER_LOOKUP);

        private int type;

        protected Type(int type)
        {
            this.type = type;
        }

        public final boolean equals(Object obj)
        {
            if (obj == this)
            {
                return true;
            }
            if (!(obj instanceof PBStateEvent))
            {
                return false;
            }

            return type == ((Type) obj).type;
        }

        public final int hashCode()
        {
            return type;
        }

        /**
         * Returns an unique identifier of the used eventType.
         */
        public final int typeId()
        {
            return type;
        }

        public String toString()
        {
            return this.getClass().getName() + " [type= " + typeAsName(type) + "]";
        }

        private static String typeAsName(int type)
        {
            if (type == TYPE_AFTER_DELETE)
                return "AFTER_DELETE";
            else if (type == TYPE_AFTER_LOOKUP)
                return "AFTER_LOOKUP";
            else if (type == TYPE_AFTER_INSERT)
                return "AFTER_INSERT";
            else if (type == TYPE_AFTER_UPDATE)
                return "AFTER_UPDATE";
            else if (type == TYPE_BEFORE_DELETE)
                return "BEFORE_DELETE";
            else if (type == TYPE_BEFORE_INSERT)
                return "BEFORE_INSERT";
            else if (type == TYPE_BEFORE_UPDATE)
                return "BEFORE_UPDATE";
            else
            {
                throw new OJBRuntimeException("Could not find type with typeId " + type);
            }
        }
    }
}
