package org.apache.ojb.broker.cache;

import java.io.Serializable;

/* Copyright 2002-2004 The Apache Software Foundation
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

/**
 * Encapsulates buffered objects.
 *
 * @author <a href="mailto:arminw@apache.org">Armin Waibel</a>
 * @version $Id: CacheEntry.java,v 1.1 2004/06/04 16:02:44 arminw Exp $
 */
public interface CacheEntry extends Serializable
{
    /**
     * Returns the class object of the cached object. This is independend from
     * the {@link org.apache.ojb.broker.Identity#getObjectsRealClass()} and
     * {@link org.apache.ojb.broker.Identity#getObjectsTopLevelClass()} setting in
     * {@link org.apache.ojb.broker.Identity}, because real class setting in class Identity
     * could be <em>null</em> or an interface or abstract class if no more information was
     * available when Identity was created.
     */
    Class getObjectInstanceClass();

    /**
     * Returns the lifetime of the cached object.
     */
    long getLifetime();

    /**
     * Returns the cached object or <em>null</em> if no longer available.
     */
    Object getObject();
}
