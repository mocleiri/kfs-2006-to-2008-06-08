package org.apache.ojb.broker.util;

/* Copyright 2002-2004 The Apache Software Foundation
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

import java.lang.reflect.Array;
import java.util.NoSuchElementException;

/**
 * This Iterator is used to iterate over Arrays.
 * Used in PersistenceBroker::storeCollections() and deleteCollections()
 * if arrays are used instead of Collections
 *
 * @author Thomas Mahler
 * @version $Id: ArrayIterator.java,v 1.6 2004/04/04 23:53:36 brianm Exp $
 */
public class ArrayIterator implements java.util.Iterator
{
    /**
     * the underlying array
     */
    private Object myArray;

    /**
     * current position of the Iterator
     */
    private int position;

    /**
     * total length of myArray
     */
    private int length;

    /**
     * create an Iterator for the Array array.
     * @throws UnsupportedOperationException if array is not an Array
     * @param array java.lang.Object
     */
    public ArrayIterator(Object array)
    {
        if (!array.getClass().isArray())
        {
            throw new UnsupportedOperationException("ArrayIterator must be "
                    + "initialized with an Array to iterate over");
        }
        myArray = array;
        position = 0;
        length = Array.getLength(myArray);
    }

    /**
     * Returns <tt>true</tt> if the iteration has more elements. (In other
     * words, returns <tt>true</tt> if <tt>next</tt> would return an element
     * rather than throwing an exception.)
     *
     * @return <tt>true</tt> if the iterator has more elements.
     */
    public boolean hasNext()
    {
        return (position < length);
    }

    /**
     * Returns the next element in the interation.
     *
     * @return the next element in the interation.
     * @exception java.util.NoSuchElementException iteration has no more
     *          elements.
     */
    public synchronized Object next() throws NoSuchElementException
    {
        try
        {
            Object result = Array.get(myArray, position);
            position++;
            return result;
        }
        catch (ArrayIndexOutOfBoundsException e)
        {
            throw new NoSuchElementException(e.getMessage());
        }
    }

    /**
     *
     * Removes from the underlying collection the last element returned by the
     * iterator (optional operation).  This method can be called only once per
     * call to <tt>next</tt>.  The behavior of an iterator is unspecified if
     * the underlying collection is modified while the iteration is in
     * progress in any way other than by calling this method.
     *
     * @exception UnsupportedOperationException if the <tt>remove</tt>
     * operation is not supported by this Iterator.
     *
     * @exception IllegalStateException if the <tt>next</tt> method has not
     * yet been called, or the <tt>remove</tt> method has already
     * been called after the last call to the <tt>next</tt>
     * method.
     */
    public void remove()
    {
        throw new UnsupportedOperationException("I'm sorry Dave...");
    }
}
