package org.apache.ojb.broker.metadata;

/* Copyright 2002-2004 The Apache Software Foundation
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang.SystemUtils;
import org.apache.commons.lang.builder.ToStringBuilder;
import org.apache.commons.lang.builder.ToStringStyle;
import org.apache.ojb.broker.OJBRuntimeException;
import org.apache.ojb.broker.PersistenceBrokerException;
import org.apache.ojb.broker.util.ClassHelper;
import org.apache.ojb.broker.util.logging.LoggerFactory;

/**
 * The repository containing all object mapping and manipulation information of
 * all used persistent objects.
 * <br>
 * Note: Be careful when use references of this class or caching instances of this class,
 * because instances could become invalid (see {@link MetadataManager}).
 *
 * @author <a href="mailto:thma@apache.org">Thomas Mahler<a>
 * @author <a href="mailto:leandro@ibnetwork.com.br">Leandro Rodrigo Saad Cruz<a>
 * @version $Id: DescriptorRepository.java,v 1.50.2.2 2004/08/04 00:31:51 arminw Exp $
 */
public final class DescriptorRepository extends DescriptorBase
        implements Serializable, XmlCapable, IsolationLevels
{
	static final long serialVersionUID = -1556339982311359524L;
    /**
     * The version identifier of the Repository.
     * Used to validate repository.xml against the dtd.
     */
    private static final String VERSION = "1.0";
    /**
     * the default isolation level used for this repository
     */
    private int defaultIsolationLevel = IsolationLevels.IL_DEFAULT;
    /**
     * This table holds all known Mapping descriptions.
     * Key values are the respective Class objects
     */
    private HashMap descriptorTable;
    /**
     * We need a lot the extent, to which a class belongs
     * (@see DescriptorRepository#getExtentClass). To speed up the costy
     * evaluation, we use this tiny hash map.
     */
    private Map extentTable;

    private transient Map m_multiMappedTableMap;
    private transient Map m_topLevelClassTable;
    private transient Map m_firstConcreteClassMap;
    private transient Map m_allConcreteSubClass;

    /**
     * Constructor declaration
     */
    public DescriptorRepository() throws PersistenceBrokerException
    {
        descriptorTable = new HashMap();
        extentTable = new HashMap();
    }

    public static String getVersion()
    {
        return VERSION;
    }

    /**
     * Add a pair of extent/classdescriptor to the extentTable to gain speed
     * while retrieval of extents.
     * @param classname the name of the extent itself
     * @param cld the class descriptor, where it belongs to
     */
    void addExtent(String classname, ClassDescriptor cld)
    {
        synchronized (extentTable)
        {
            extentTable.put(classname, cld);
        }
    }

    /**
     * Remove a pair of extent/classdescriptor from the extentTable.
     * @param classname the name of the extent itself
     */
    void removeExtent(String classname)
    {
        synchronized (extentTable)
        {
            // returns the super class for given extent class name
            ClassDescriptor cld = (ClassDescriptor) extentTable.remove(classname);
            if(cld != null && m_topLevelClassTable != null)
            {
                Class extClass = null;
                try
                {
                    extClass = ClassHelper.getClass(classname);
                }
                catch (ClassNotFoundException e)
                {
                    // Should not happen
                    throw new MetadataException("Can't instantiate class object for needed extent remove", e);
                }
                // remove extent from super class descriptor
                cld.removeExtentClass(classname);
                m_topLevelClassTable.remove(extClass);
                // clear map with first concrete classes, because the removed
                // extent could be such a first found concrete class
                m_firstConcreteClassMap = null;
            }
        }
    }

    /**
     * Returns the top level (extent) class to which the given class belongs.
     * This may be a (abstract) base-class, an interface or the given class
     * itself if given class is not defined as an extent in other class
     * descriptors.
     *
     * @throws ClassNotPersistenceCapableException if clazz is not persistence capable,
     * i.e. if clazz is not defined in the DescriptorRepository.
     */
    public Class getTopLevelClass(Class clazz) throws ClassNotPersistenceCapableException
    {
        if(m_topLevelClassTable == null)
        {
            m_topLevelClassTable = new HashMap();
        }
        // try to find an extent that contains clazz
        Class retval = (Class) m_topLevelClassTable.get(clazz);
        if (retval == null)
        {
            synchronized (extentTable)
            {
                ClassDescriptor cld = (ClassDescriptor) extentTable.get(clazz.getName());
                if (cld != null)
                {
                    // fix by Mark Rowell
                    // Changed to call getExtentClass recursively
                    retval = getTopLevelClass(cld.getClassOfObject());
                    // if such an extent could not be found just return clazz itself.
                    if (retval == null)
                    {
                        retval = clazz;
                    }
                }
                else
                {
                    // check if class is persistence capable
                    getDescriptorFor(clazz);
                    retval = clazz;
                }
                m_topLevelClassTable.put(clazz, retval);
            }
        }
        return retval;
    }

    /**
     * @return all field descriptors for a class that belongs to a set of classes mapped
     * to the same table, otherwise the select queries produced won't contain the necessary
     * information to materialize extents mapped to the same class.
     */
    public FieldDescriptor[] getFieldDescriptorsForMultiMappedTable(ClassDescriptor targetCld)
    {
        if(m_multiMappedTableMap == null)
        {
            m_multiMappedTableMap = new HashMap();
        }
        FieldDescriptor[] retval = (FieldDescriptor[]) m_multiMappedTableMap.get(targetCld.getClassNameOfObject());
        if (retval == null)
        {
            synchronized (m_multiMappedTableMap)
            {
                retval = getAllMappedColumns(getClassesMappedToSameTable(targetCld));
                m_multiMappedTableMap.put(targetCld.getClassNameOfObject(), retval);
            }
        }
        return retval;
    }

    private FieldDescriptor[] getAllMappedColumns(List classDescriptors)
    {
        Iterator it = classDescriptors.iterator();
        HashMap map = new HashMap();
        ClassDescriptor temp = null;
        FieldDescriptor[] fields;
        while (it.hasNext())
        {
            temp = (ClassDescriptor) it.next();
            fields = temp.getFieldDescriptions();
            if (fields != null)
            {
                for (int i = 0; i < fields.length; i++)
                {
                    /*
                    MBAIRD
                    hashmap will only allow one entry per unique key,
                    so no need to check contains(fields[i].getColumnName()).
                    arminw:
                    use contains to avoid overriding of target class fields by the same
                    field-descriptor of other classes mapped to the same DB table, because
                    the other class can use e.g. different FieldConversion.
                    In #getClassesMappedToSameTable(...) we make sure that target
                    class has first position in list.
                     */
                    if(!map.containsKey(fields[i].getColumnName()))
                    {
                        map.put(fields[i].getColumnName(), fields[i]);
                    }
                }
            }
        }
        Iterator retvalIterator = map.values().iterator();
        FieldDescriptor[] retval = new FieldDescriptor[map.size()];
        int i = 0;
        while (retvalIterator.hasNext())
        {
            retval[i] = (FieldDescriptor) retvalIterator.next();
            i++;
        }
        return retval;
    }

    private List getClassesMappedToSameTable(ClassDescriptor targetCld)
    {
        /*
        try to find an extent that contains clazz
        clone map to avoid synchronization problems, because another thread
        can do a put(..) operation on descriptor table
        */
        Iterator iter = ((HashMap)descriptorTable.clone()).values().iterator();
        List retval = new ArrayList();
        // make sure that target class is at first position
        retval.add(targetCld);
        while (iter.hasNext())
        {
            ClassDescriptor cld = (ClassDescriptor) iter.next();
            if (cld.getFullTableName() != null)
            {
                if (cld.getFullTableName().equals(targetCld.getFullTableName())
                        && !targetCld.getClassOfObject().equals(cld.getClassOfObject()))
                {
                    retval.add(cld);
                }
            }
        }
        return retval;
    }

    public Map getDescriptorTable()
    {
        return descriptorTable;
    }

    /**
     * Return the first found concrete class {@link ClassDescriptor}.
     * This means a class which is not an interface or an abstract class.
     * If given class descriptor is a concrete class, given class descriptor
     * was returned. If no concrete class can be found <code>null</code> will be
     * returned.
     */
    public ClassDescriptor findFirstConcreteClass(ClassDescriptor cld)
    {
        if(m_firstConcreteClassMap == null)
        {
            m_firstConcreteClassMap = new HashMap();
        }
        ClassDescriptor result = (ClassDescriptor) m_firstConcreteClassMap.get(cld.getClassNameOfObject());
        if (result == null)
        {
            if(cld.isInterface() || cld.isAbstract())
            {
                if(cld.isExtent())
                {
                    List extents = cld.getExtentClasses();
                    for (int i = 0; i < extents.size(); i++)
                    {
                        Class ext = (Class) extents.get(i);
                        result = findFirstConcreteClass(getDescriptorFor(ext));
                        if(result != null) break;
                    }
                }
                else
                {
                    LoggerFactory.getDefaultLogger().error("["+this.getClass().getName()+"] Found interface/abstract class" +
                            " in metadata declarations without concrete class: "+cld.getClassNameOfObject());
                }
                m_firstConcreteClassMap.put(cld.getClassNameOfObject(), result);
            }
            else
            {
                result = cld;
            }
        }
        return result;
    }

    /**
     *
     * Utility method to discover all concrete subclasses of a given super class. <br>
     * This method was introduced in order to get Extent Aware Iterators.
     *
     * @return a Collection of ClassDescriptor objects
     */
    public Collection getAllConcreteSubclassDescriptors(ClassDescriptor aCld)
    {
        if(m_allConcreteSubClass == null)
        {
            m_allConcreteSubClass = new HashMap();
        }
        Collection concreteSubclassClds = (Collection) m_allConcreteSubClass.get(aCld.getClassOfObject());

        if (concreteSubclassClds == null)
        {
            // BRJ: As long as we do not have an ordered Set
            // duplicates have to be prevented manually.
            // a HashSet should not be used because the order is unpredictable
            concreteSubclassClds = new ArrayList();
            Iterator iter = aCld.getExtentClasses().iterator();

            while (iter.hasNext())
            {
                Class extentClass = (Class) iter.next();
                ClassDescriptor extCld = getDescriptorFor(extentClass);
                if (aCld.equals(extCld))
                {
                    // prevent infinite recursion caused by cyclic references
                    continue;
                }
                if (!extCld.isInterface() && !extCld.isAbstract())
                {
                    if (!concreteSubclassClds.contains(extCld))
                    {
                        concreteSubclassClds.add(extCld);
                    }
                }

                // recurse
                Iterator subIter = getAllConcreteSubclassDescriptors(extCld).iterator();
                while (subIter.hasNext())
                {
                    ClassDescriptor subCld = (ClassDescriptor)subIter.next();
                    if (!concreteSubclassClds.contains(subCld))
                    {
                        concreteSubclassClds.add(subCld);
                    }
                }
            }
            m_allConcreteSubClass.put(aCld.getClassOfObject(), concreteSubclassClds);
        }

        return concreteSubclassClds;
    }


    /**
     * Checks if repository contains given class.
     */
    public boolean hasDescriptorFor(Class c)
    {
        return descriptorTable.containsKey(c.getName());
    }

    /**
     * lookup a ClassDescriptor in the internal Hashtable
     * @param strClassName a fully qualified class name as it is returned by Class.getName().
     */
    public ClassDescriptor getDescriptorFor(String strClassName) throws ClassNotPersistenceCapableException
    {
        ClassDescriptor result = discoverDescriptor(strClassName);
        if (result == null)
        {
            throw new ClassNotPersistenceCapableException(strClassName + " not found in OJB Repository");
        }
        else
        {
            return result;
        }
    }

    /**
     * lookup a ClassDescriptor in the internal Hashtable
     */
    public ClassDescriptor getDescriptorFor(Class c) throws ClassNotPersistenceCapableException
    {
        return this.getDescriptorFor(c.getName());
    }

    /**
     * Convenience for {@link #put(Class c, ClassDescriptor cld)}
     */
    public void setClassDescriptor(ClassDescriptor cld)
    {
        this.put(cld.getClassNameOfObject(), cld);
    }

    /**
     * Add a ClassDescriptor to the internal Hashtable<br>
     * Set the Repository for ClassDescriptor
     */
    public void put(Class c, ClassDescriptor cld)
    {
        this.put(c.getName(), cld);
    }

    /**
     * Add a ClassDescriptor to the internal Hashtable<br>
     * Set the Repository for ClassDescriptor
     */
    public void put(String classname, ClassDescriptor cld)
    {
        cld.setRepository(this); // BRJ
        synchronized (descriptorTable)
        {
            descriptorTable.put(classname, cld);
            List extentClasses = cld.getExtentClasses();
            for (int i = 0; i < extentClasses.size(); ++i)
            {
                addExtent(((Class) extentClasses.get(i)).getName(), cld);
            }
            changeDescriptorEvent();
        }
    }

    public void remove(String className)
    {
        synchronized (descriptorTable)
        {
            ClassDescriptor cld = (ClassDescriptor) descriptorTable.remove(className);
            if(cld != null)
            {
                // class itself could no longer be a extent
                Iterator it = descriptorTable.values().iterator();
                while (it.hasNext())
                {
                    ((ClassDescriptor) it.next()).removeExtentClass(className);
                }
                removeExtent(className);
                List extentClasses = cld.getExtentClasses();
                for (int i = 0; i < extentClasses.size(); ++i)
                {
                    removeExtent(((Class) extentClasses.get(i)).getName());
                }
                changeDescriptorEvent();
            }
        }
    }

    public void remove(Class clazz)
    {
        remove(clazz.getName());
    }

    private void changeDescriptorEvent()
    {
        m_multiMappedTableMap = null;
        m_topLevelClassTable = null;
        m_firstConcreteClassMap = null;
        m_allConcreteSubClass = null;
    }

    /**
     * Returns an iterator over all managed {@link ClassDescriptor}.
     */
    public Iterator iterator()
    {
        /*
        clone map to avoid synchronization problems
        */
        return ((HashMap)descriptorTable.clone()).values().iterator();
    }

    /**
     * Returns the defaultIsolationLevel.
     * @return int
     */
    public int getDefaultIsolationLevel()
    {
        return defaultIsolationLevel;
    }

    /**
     * Sets the defaultIsolationLevel.
     * @param defaultIsolationLevel The defaultIsolationLevel to set
     */
    public void setDefaultIsolationLevel(int defaultIsolationLevel)
    {
        this.defaultIsolationLevel = defaultIsolationLevel;
    }

    /**
     * returns a string representation
     */
    public String toString()
    {
        Map temp = (Map)descriptorTable.clone();
        Iterator itKey = temp.keySet().iterator();
        ToStringBuilder buf = new ToStringBuilder(this, ToStringStyle.MULTI_LINE_STYLE);
        String className = "class name: ";
        String tableName = "> table name: ";
        while (itKey.hasNext())
        {
            Object cl = itKey.next();
            ClassDescriptor descriptor = (ClassDescriptor) temp.get(cl);
            buf.append(className + cl.toString() + " =", tableName + descriptor.getFullTableName());
        }
        return buf.toString();
    }

    /*
     * @see XmlCapable#toXML()
     */
    public String toXML()
    {
        String eol = SystemUtils.LINE_SEPARATOR;
        StringBuffer buf = new StringBuffer();

        // write all ClassDescriptors
        Iterator i = this.iterator();
        while (i.hasNext())
        {
            buf.append(((XmlCapable) i.next()).toXML() + eol);
        }
        return buf.toString();
    }

    /**
     * returns IsolationLevel literal as matching
     * to the corresponding id
     * @return the IsolationLevel literal
     */
    protected String getIsolationLevelAsString()
    {
        if (defaultIsolationLevel == IL_READ_UNCOMMITTED)
        {
            return LITERAL_IL_READ_UNCOMMITTED;
        }
        else if (defaultIsolationLevel == IL_READ_COMMITTED)
        {
            return LITERAL_IL_READ_COMMITTED;
        }
        else if (defaultIsolationLevel == IL_REPEATABLE_READ)
        {
            return LITERAL_IL_REPEATABLE_READ;
        }
        else if (defaultIsolationLevel == IL_SERIALIZABLE)
        {
            return LITERAL_IL_SERIALIZABLE;
        }
        else if (defaultIsolationLevel == IL_OPTIMISTIC)
        {
            return LITERAL_IL_OPTIMISTIC;
        }
        return LITERAL_IL_READ_UNCOMMITTED;
    }

    /**
     * Starts by looking to see if the <code>className</code> is
     * already mapped specifically to the descritpor repository.
     * If the <code>className</code> is not specifically mapped we
     * look at the <code>className</code>'s parent class for a mapping.
     * We do this until the parent class is of the type
     * <code>java.lang.Object</code>.  If no mapping was found,
     * <code>null</code> is returned.  Mappings successfuly discovered
     * through inheritence are added to the internal table of
     * class descriptors to improve performance on subsequent requests
     * for those classes.
     *
     * <br/>
     * author <a href="mailto:weaver@apache.org">Scott T. Weaver</a>
     * @param className name of class whose descriptor we need to find.
     * @return ClassDescriptor for <code>className</code> or <code>null</code>
     * if no ClassDescriptor could be located.
     */
    protected ClassDescriptor discoverDescriptor(String className)
    {
        ClassDescriptor result = (ClassDescriptor) descriptorTable.get(className);
        if (result == null)
        {
            Class clazz;
            try
            {
                clazz = ClassHelper.getClass(className, true);
            }
            catch (ClassNotFoundException e)
            {
                throw new OJBRuntimeException("Class, " + className + ", could not be found.", e);
            }
            result = discoverDescriptor(clazz);
         }
        return result;
    }

    /**
     * Internal method for recursivly searching for a class descriptor that avoids
     * class loading when we already have a class object.
     *
     * @param clazz The class whose descriptor we need to find
     * @return ClassDescriptor for <code>clazz</code> or <code>null</code>
     *         if no ClassDescriptor could be located.
     */
    private ClassDescriptor discoverDescriptor(Class clazz)
    {
        ClassDescriptor result = (ClassDescriptor) descriptorTable.get(clazz.getName());

        if (result == null)
        {
            Class superClass = clazz.getSuperclass();
            // only recurse if the superClass is not java.lang.Object
            if (superClass != null)
            {
                result = discoverDescriptor(superClass);
            }
            if (result == null)
            {
                // we're also checking the interfaces as there could be normal
                // mappings for them in the repository (using factory-class,
                // factory-method, and the property field accessor)
                Class[] interfaces = clazz.getInterfaces();

                if ((interfaces != null) && (interfaces.length > 0))
                {
                    for (int idx = 0; (idx < interfaces.length) && (result == null); idx++)
                    {
                        result = discoverDescriptor(interfaces[idx]);
                    }
                }
            }

            if (result != null)
            {
                descriptorTable.put(clazz.getName(), result);
            }
        }
        return result;
    }

    protected void finalize() throws Throwable
    {
        LoggerFactory.getDefaultLogger().info("# finalize DescriptorRepository instance #");
    }
}
