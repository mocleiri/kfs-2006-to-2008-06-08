package org.apache.ojb.broker;

/* Copyright 2003-2004 The Apache Software Foundation
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */


import java.util.Collection;

import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.ojb.broker.core.proxy.ProxyHelper;
import org.apache.ojb.broker.metadata.ClassDescriptor;
import org.apache.ojb.broker.metadata.CollectionDescriptor;

/**
 *
 * @author <a href="leandro@ibnetwork.com.br">Leandro Rodrigo Saad Cruz</a>
 * @version $Id: MtoNImplementor.java,v 1.7 2004/04/09 13:22:30 tomdz Exp $
 */
public class MtoNImplementor
{
    private Object _left;
    private Object _right;
	private CollectionDescriptor _collectionDesc;
	private PersistenceBroker _pb;

    /**
     *
     */
    public MtoNImplementor(PersistenceBroker pb , CollectionDescriptor cod, Object left, Object right)
    {
        if(left == null || right == null)
        {
            throw new IllegalArgumentException("both objects must exist");
        }

        _pb = pb;
        _collectionDesc = cod;
        _left = left;
        _right = right;

    }

	public MtoNImplementor(PersistenceBroker pb , String collectionName, Object left, Object right)
	{
		if(left == null || right == null)
		{
			throw new IllegalArgumentException("both objects must exist");
		}
        _pb = pb;
        _left = left;
        _right = right;
        _collectionDesc = pb.getClassDescriptor(
                ProxyHelper.getRealObject(_left).getClass()).getCollectionDescriptorByName(collectionName);

	}


    public Object getLeftObject()
    {
        return _left;
    }

    public Object getRightObject()
    {
        return _right;
    }

    public CollectionDescriptor getCollectionDescriptor()
    {
    	return _collectionDesc;
    }

	/**
	 *
	 * @param mnKeys
	 * @return
	 */
    public String getInsertStmt(Collection mnKeys)
    {
		_left = ProxyHelper.getRealObject(_left);
		String[] leftPkColumns = _collectionDesc.getFksToThisClass();
		String[] rightPkColumns = _collectionDesc.getFksToItemClass();
		String table = _collectionDesc.getIndirectionTable();
		Key key = new Key(getRightPkValues());

		if (mnKeys.contains(key))
		{
			return null;
		}

		return _pb.serviceSqlGenerator().getInsertMNStatement(table, leftPkColumns, rightPkColumns);
    }


	/**
	 *
	 * @return an Object Array with the primary key values of the left object
	 */
	public Object[] getLeftPkValues()
	{
		ClassDescriptor leftCld = _pb.getDescriptorRepository().getDescriptorFor(_left.getClass());
		return _pb.serviceBrokerHelper().getKeyValues(leftCld, _left);
	}

	/**
	 *
	 * @return an Object Array with the primary key values of the right object
	 */
	public Object[] getRightPkValues()
	{
		ClassDescriptor rightCld = _pb.getDescriptorRepository().getDescriptorFor(_right.getClass());
		return _pb.serviceBrokerHelper().getKeyValues(rightCld, _right);
	}

    /**
     * Inner class to model the key
     */
    private static final class Key
    {

        final Object[] m_key;

        Key(final Object[] aKey)
        {
            m_key = new Object[aKey.length];

            for (int i = 0; i < aKey.length; i++)
            {
                // BRJ:
                // convert all Numbers to Long to simplify equals
                // could lead to problems when Floats are used as key
                if (aKey[i] instanceof Number)
                {
                    m_key[i] = new Long(((Number)aKey[i]).longValue());
                }
                else
                {
                    m_key[i] = aKey[i];
                }
            }
        }

        public boolean equals(Object other)
        {
            if (other == this)
            {
                return true;
            }
            if (!(other instanceof Key))
            {
                return false;
            }

            Key otherKey = (Key) other;
            EqualsBuilder eb = new EqualsBuilder();

            eb.append(m_key, otherKey.m_key);
            return eb.isEquals();
        }

        public int hashCode()
        {
            HashCodeBuilder hb = new HashCodeBuilder();
            hb.append(m_key);

            return hb.toHashCode();
        }
    }
}

