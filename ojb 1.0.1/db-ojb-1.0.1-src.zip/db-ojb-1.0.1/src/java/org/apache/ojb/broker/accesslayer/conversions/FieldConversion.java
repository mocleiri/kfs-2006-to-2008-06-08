package org.apache.ojb.broker.accesslayer.conversions;

/* Copyright 2002-2004 The Apache Software Foundation
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

import java.io.Serializable;


/**
 *
 * FieldConversion declares a protocol for type and value 
 * conversions between persistent classes attributes and the columns
 * of the RDBMS. 
 * The default implementation does not modify its input.
 * OJB users can use predefined implementation and can also 
 * build their own conversions that perform arbitrary mappings.
 * the mapping has to defined in the xml repository in the FieldDescriptor.
 *
 * @author Thomas Mahler
 * @version $Id: FieldConversion.java,v 1.6 2004/04/04 23:53:32 brianm Exp $
 *
 */
public interface FieldConversion extends Serializable
{
	static final long serialVersionUID = 2692919097691347845L;    /** convert a Java object to its SQL pendant, used for insert & update*/
    public abstract Object javaToSql(Object source) throws ConversionException;

    /** convert a SQL value to a Java Object, used for SELECT*/
    public abstract Object sqlToJava(Object source) throws ConversionException;

}
