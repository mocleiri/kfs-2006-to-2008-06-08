package org.apache.ojb.broker.cache;

import org.apache.commons.lang.builder.ToStringBuilder;
import org.apache.commons.lang.builder.ToStringStyle;
import org.apache.ojb.broker.Identity;

import java.util.ArrayList;

/* Copyright 2003-2004 The Apache Software Foundation
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */


/**
 * This {@link ObjectCache Meta-ObjectCache} implementation enabled
 * the {@link CacheFilter} feature support.
 * <br/>
 * With the {@link #addCacheFilter} method {@link CacheFilter}
 * could be add.
 * <br/><br/>
 * <b>Note:</b> Using this meta cache will affect the
 * cache performance, thus do not add too many {@link CacheFilter}.
 *
 * @author <a href="mailto:armin@codeAuLait.de">Armin Waibel</a>
 * @version $Id: CacheFilterRegistry.java,v 1.3.2.1 2004/08/09 07:51:26 arminw Exp $
 */
public class CacheFilterRegistry extends AbstractMetaCache
{
    private ArrayList filterList = new ArrayList();
    private ObjectCache realCache;

    public CacheFilterRegistry(ObjectCache realCache)
    {
        this.realCache = realCache;
    }

    /**
     * Add a {@link CacheFilter}.
     */
    protected void addCacheFilter(CacheFilter filter)
    {
        filterList.add(filter);
    }

    public ObjectCache getCache(Identity oid, Object obj, int callingMethod)
    {
        return checkFilterList(callingMethod, oid, obj) ? realCache : null;
    }

    public void clear()
    {
        realCache.clear();
    }

    private boolean checkFilterList(int callingMethod, Identity oid, Object obj)
    {
        boolean result = true;
        if (callingMethod == METHOD_CACHE)
        {
            for (int i = filterList.size() - 1; i >= 0; i--)
            {
                result = result && ((CacheFilter) filterList.get(i)).beforeCache(oid, obj);
                if(result == false) return false;
            }
        }
        else if (callingMethod == METHOD_LOOKUP)
        {
            for (int i = filterList.size() - 1; i >= 0; i--)
            {
                result = result && ((CacheFilter) filterList.get(i)).beforeLookup(oid);
                if(result == false) return false;
            }
        }
        else if (callingMethod == METHOD_REMOVE)
        {
            for (int i = filterList.size() - 1; i >= 0; i--)
            {
                result = result && ((CacheFilter) filterList.get(i)).beforeRemove(oid);
                if(result == false) return false;
            }
        }
        else
            throw new RuntimeCacheException("Unkown filter method id: " + callingMethod);

        return result;
    }

    public String toString()
    {
        ToStringBuilder buf = new ToStringBuilder(this, ToStringStyle.MULTI_LINE_STYLE);
        buf.append(" - used filters", filterList).
                append(" - underlying ObjectCache", realCache);
        return buf.toString();
    }
}
