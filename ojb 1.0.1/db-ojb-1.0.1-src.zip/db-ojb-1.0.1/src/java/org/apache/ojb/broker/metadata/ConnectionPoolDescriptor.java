package org.apache.ojb.broker.metadata;


/* Copyright 2002-2004 The Apache Software Foundation
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

import java.io.Serializable;

import org.apache.commons.lang.SystemUtils;
import org.apache.ojb.broker.util.pooling.PoolConfiguration;


/**
 * Encapsulates connection pooling configuration properties managed by
 * {@link org.apache.ojb.broker.metadata.JdbcConnectionDescriptor}.
 * <br/>
 * Every new instantiated <code>ConnectionPoolDescriptor</code> was
 * associated with default connection pool attributes.
 *
 * @author <a href="mailto:armin@codeAuLait.de">Armin Waibel</a>
 * @version $Id: ConnectionPoolDescriptor.java,v 1.14 2004/04/04 23:53:34 brianm Exp $
 */
public class ConnectionPoolDescriptor extends PoolConfiguration implements Serializable, XmlCapable
{
	private static final long serialVersionUID = -3071461685659671879L;
    private Class connectionFactory;

    public ConnectionPoolDescriptor()
    {
        super();
        init();
    }

    /**
     * Set some initial values.
     */
    public void init()
    {
        this.setTestOnBorrow(true);
        this.setTestOnReturn(false);
        this.setTestWhileIdle(false);
        this.setLogAbandoned(false);
        this.setRemoveAbandoned(false);
    }

    public Class getConnectionFactory()
    {
        return this.connectionFactory;
    }

    public void setConnectionFactory(Class connectionFactory)
    {
        if (connectionFactory == null) throw new MetadataException("Given ConnectionFactory was null");
        this.connectionFactory = connectionFactory;
    }

    public String toXML()
    {
        RepositoryTags tags = RepositoryTags.getInstance();
        String eol = SystemUtils.LINE_SEPARATOR;
        StringBuffer buf = new StringBuffer();
        //opening tag + attributes
        buf.append("      " + tags.getOpeningTagNonClosingById(CONNECTION_POOL) + eol);
        buf.append("         " + tags.getAttribute(RepositoryElements.CON_MAX_ACTIVE, "" + getMaxActive()) + eol);
        buf.append("         " + tags.getAttribute(RepositoryElements.CON_MAX_IDLE, "" + getMaxIdle()) + eol);
        buf.append("         " + tags.getAttribute(RepositoryElements.CON_MAX_WAIT, "" + getMaxWait()) + eol);
        buf.append("         " + tags.getAttribute(RepositoryElements.CON_MIN_EVICTABLE_IDLE_TIME_MILLIS, "" +
                getMinEvictableIdleTimeMillis()) + eol);
        buf.append("         " + tags.getAttribute(RepositoryElements.CON_NUM_TESTS_PER_EVICTION_RUN, "" +
                getNumTestsPerEvictionRun()) + eol);
        buf.append("         " + tags.getAttribute(RepositoryElements.CON_TEST_ON_BORROW, "" + isTestOnBorrow()) + eol);
        buf.append("         " + tags.getAttribute(RepositoryElements.CON_TEST_ON_RETURN, "" + isTestOnReturn()) + eol);
        buf.append("         " + tags.getAttribute(RepositoryElements.CON_TEST_WHILE_IDLE, "" + isTestWhileIdle()) + eol);
        buf.append("         " + tags.getAttribute(RepositoryElements.CON_TIME_BETWEEN_EVICTION_RUNS_MILLIS, "" +
                getTimeBetweenEvictionRunsMillis()) + eol);
        buf.append("         " + tags.getAttribute(RepositoryElements.CON_WHEN_EXHAUSTED_ACTION, "" +
                getWhenExhaustedAction()) + eol);
        buf.append("         " + tags.getAttribute(RepositoryElements.VALIDATION_QUERY, "" + getValidationQuery()) + eol);

        buf.append("         " + tags.getAttribute(RepositoryElements.CON_LOG_ABANDONED, "" + isLogAbandoned()) + eol);
        buf.append("         " + tags.getAttribute(RepositoryElements.CON_REMOVE_ABANDONED, "" +
                isRemoveAbandoned()) + eol);
        buf.append("         " + tags.getAttribute(RepositoryElements.CON_REMOVE_ABANDONED_TIMEOUT, "" +
                getRemoveAbandonedTimeout()) + eol);
        buf.append("      />" + eol);
        return buf.toString();
    }
}

