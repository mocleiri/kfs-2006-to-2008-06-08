package org.apache.ojb.broker.accesslayer;

/* Copyright 2002-2004 The Apache Software Foundation
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

import org.apache.commons.dbcp.AbandonedConfig;
import org.apache.commons.dbcp.DriverManagerConnectionFactory;
import org.apache.commons.dbcp.PoolableConnectionFactory;
import org.apache.commons.dbcp.PoolingDataSource;
import org.apache.commons.pool.KeyedObjectPoolFactory;
import org.apache.commons.pool.ObjectPool;
import org.apache.commons.pool.impl.GenericKeyedObjectPoolFactory;
import org.apache.commons.pool.impl.GenericObjectPool;
import org.apache.ojb.broker.metadata.JdbcConnectionDescriptor;
import org.apache.ojb.broker.util.ClassHelper;
import org.apache.ojb.broker.util.logging.Logger;
import org.apache.ojb.broker.util.logging.LoggerFactory;

import javax.sql.DataSource;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;

/**
 * ConnectionFactory implementation using jakarta-DBCP
 * to pool driver based connections.
 *
 * (based on a proposal of Dirk Verbeek - Thanks).
 *
 * @author <a href="mailto:armin@codeAuLait.de">Armin Waibel</a>
 * @version $Id: ConnectionFactoryDBCPImpl.java,v 1.10 2004/05/23 16:36:53 brianm Exp $
 */
public class ConnectionFactoryDBCPImpl extends ConnectionFactoryAbstractImpl
{
    private Logger log = LoggerFactory.getLogger(ConnectionFactoryDBCPImpl.class);

    private Map poolMap = new HashMap();

    public Connection getConnectionFromPool(JdbcConnectionDescriptor jcd) throws LookupException
    {
        DataSource ds = (DataSource) poolMap.get(jcd.getPBKey());
        if (ds == null) // found no pool for PBKey
        {
            try
            {
                // setup new pool
                ds = setupPool(jcd);
                poolMap.put(jcd.getPBKey(), ds);
            }
            catch (Exception e)
            {
                log.error("Could not setup DataSource for " + jcd, e);
                throw new LookupException(e);
            }
        }
        try
        {
            Connection con = ds.getConnection();
            return con;
        }
        catch (SQLException e)
        {
            throw new LookupException("Can't get connection from DBCP-DataSource", e);
        }
    }

    public void returnConnectionToPool(JdbcConnectionDescriptor jcd, Connection con)
            throws LookupException
    {
        try
        {
            // we using datasources, thus close return connection to pool
            con.close();
        }
        catch (SQLException e)
        {
            log.warn("Connection close failed", e);
        }
    }

    /**
     * Override this method to setup your own pool
     */
    protected DataSource setupPool(JdbcConnectionDescriptor jcd)
    {
        log.info("Create new DBCP connection pool:" + jcd);

        try
        {
            ClassHelper.newInstance(jcd.getDriver());
        }
        catch (InstantiationException e)
        {
            log.fatal("Unable to instantiate the driver class: " + jcd.getDriver() + " in ConnectionFactoryDBCImpl!" , e);
        }
        catch (IllegalAccessException e)
        {
            log.fatal("IllegalAccessException while instantiating the driver class: " + jcd.getDriver() + " in ConnectionFactoryDBCImpl!" , e);
        }
        catch (ClassNotFoundException e)
        {
            log.fatal("Could not find the driver class : " + jcd.getDriver() + " in ConnectionFactoryDBCImpl!" , e);
        }


        // get the configuration for the connection pool
        GenericObjectPool.Config conf = jcd.getConnectionPoolDescriptor().getObjectPoolConfig();

        // First, we'll need a ObjectPool that serves as the
        // actual pool of connections.
        //
        // We'll use a GenericObjectPool instance, although
        // any ObjectPool implementation will suffice.
        //
        // TODO: make objectPool configurable at runtime?
        ObjectPool connectionPool = createObjectPool(conf);

        // Next, we'll create a ConnectionFactory that the
        // pool will use to create Connections.
        // We'll use the DriverManagerConnectionFactory,
        //
        org.apache.commons.dbcp.ConnectionFactory connectionFactory = createConnectionFactory(jcd);

        KeyedObjectPoolFactory statementPoolFactory = createStatementPoolFactory(null);
        // set the validation query
        String validationQuery = jcd.getConnectionPoolDescriptor().getValidationQuery();
        boolean defaultReadOnly = false;
        // set autocommit mode
        boolean defaultAutoCommit = (jcd.getUseAutoCommit() == JdbcConnectionDescriptor.AUTO_COMMIT_SET_FALSE) ?
                false : true;

        // Abandoned configuration
        AbandonedConfig ac = jcd.getConnectionPoolDescriptor().getAbandonedConfig();

        //
        // Now we'll create the PoolableConnectionFactory, which wraps
        // the "real" Connections created by the ConnectionFactory with
        // the classes that implement the pooling functionality.
        //
        PoolableConnectionFactory poolableConnectionFactory = new PoolableConnectionFactory(
                connectionFactory,
                connectionPool,
                statementPoolFactory,
                validationQuery,
                defaultReadOnly,
                defaultAutoCommit,
                ac);

        //
        // Finally, we create the PoolingDriver itself,
        // passing in the object pool we created.
        //
        PoolingDataSource dataSource = createPoolingDataSource(poolableConnectionFactory.getPool());
        return dataSource;
    }

    protected ObjectPool createObjectPool(GenericObjectPool.Config config)
    {
        return new GenericObjectPool(null, config);
    }

    protected org.apache.commons.dbcp.ConnectionFactory createConnectionFactory(JdbcConnectionDescriptor jcd)
    {
        return new DriverManagerConnectionFactory(getDbURL(jcd), jcd.getUserName(), jcd.getPassWord());
    }

    protected KeyedObjectPoolFactory createStatementPoolFactory(Object obj)
    {
        return new GenericKeyedObjectPoolFactory(null);
    }

    protected PoolingDataSource createPoolingDataSource(ObjectPool pool)
    {
        return new PoolingDataSource(pool);
    }
}
