package org.apache.ojb.broker.metadata.fieldaccess;

/* Copyright 2003-2004 The Apache Software Foundation
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

import java.lang.reflect.Field;

import org.apache.commons.lang.SystemUtils;
import org.apache.ojb.broker.core.proxy.ProxyHelper;
import org.apache.ojb.broker.metadata.MetadataException;
import org.apache.ojb.broker.util.logging.Logger;
import org.apache.ojb.broker.util.logging.LoggerFactory;

/**
 * Abstract {@link PersistentField} base implementation.
 *
 * @author <a href="mailto:armin@codeAuLait.de">Armin Waibel</a>
 * @version $Id: AbstractPersistentField.java,v 1.22 2004/06/26 23:51:37 arminw Exp $
 */
public abstract class AbstractPersistentField implements PersistentField
{
    public static final String PATH_TOKEN = "::";
    public static final Class PERSISTENT_FIELD_IMPL_FOR_NESTED = PersistentFieldDirectAccessImpl.class;

    private static final int UNKNOWN_FIELD = 0;
    private static final int NORMAL_FIELD = 1;
    private static final int NESTED_FIELD = 2;

    protected transient Field field;
    protected String fieldName;
    protected Class rootObjectType;
    /**
     * 0 - not initialized
     * 1 - normal field
     * 2 - nested field
     */
    private int isNestedField = UNKNOWN_FIELD;

    /**
     * For internal use only!!
     * TODO: Default constructor only needed to support
     * PersistentFieldFactory#usesAccessorsAndMutators()
     * method - find a better solution. Make 'public' to
     * allow helper class to instantiate class.
     */
    public AbstractPersistentField()
    {
    }

    public AbstractPersistentField(Class clazz, String fieldname)
    {
        this.rootObjectType = clazz;
        this.fieldName = fieldname;
    }

    /**
     * Set value for target object.
     */
    public abstract void doSet(Object targetObject, Object value);

    /**
     * Get value for field extracted from given target object.
     */
    public abstract Object doGet(Object targetObject);

    /**
     * A value of true indicates that this field should
     * suppress Java language access checking when it is used.
     */
    public abstract boolean makeAccessible();

    /**
     * do not override this method, have a look at {@link #doSet}
     */
    public void set(Object targetObject, Object value) throws MetadataException
    {
        if(targetObject == null) return;
        if (isNestedField())
        {
            if (value != null || !getField().getType().isPrimitive())
            {
                setNestedObject(targetObject, fieldName, value);
            }
        }
        else
        {
            doSet(targetObject, value);
        }
    }

    /**
     * do not override this method, have a look at {@link #doGet}
     */
    public Object get(Object targetObject) throws MetadataException
    {
        if(targetObject == null) return null;
        if (isNestedField())
        {
            return getNestedObject(targetObject, fieldName);
        }
        else
        {
            return doGet(targetObject);
        }
    }

    protected Logger getLog()
    {
        return LoggerFactory.getLogger("PersistentField");
    }

    /**
     * Returns the underlying field object.
     * If parameter <tt>setAccessible</tt> is true the
     * field access checking was suppressed.
     */
    protected Field getField()
    {
        if (field == null)
        {
            field = computeField(rootObjectType, fieldName, isNestedField(), makeAccessible());
        }
        return field;
    }

    /**
     * Tries to compute a {@link java.lang.reflect.Field} object
     * based on given <code>Class</code> and field name - The field
     * name may a nested name string (e.g. stock::stockdetail::name)
     *
     * @throws MetadataException if there is an error computing the field
     * ( No Field was found into the class hierarchy)
     */
    protected static Field computeField(Class c, String fieldname, boolean isNested, boolean makeAccessible)
    {
        try
        {
            Field f;
            if (isNested)
            {
                f = getNestedRecursiveField(c, fieldname);
            }
            else
            {
                f = getFieldRecursive(c, fieldname);
            }

            if (makeAccessible)
            {
                f.setAccessible(true);
            }
            return f;
        }
        catch (NoSuchFieldException e)
        {
            throw new MetadataException("Can't find member '" + fieldname + "' in " + c.getName(), e);
        }
    }

    /**
     * try to find a field in class c, recurse through class hierarchy if necessary
     * @throws NoSuchFieldException if no Field was found into the class hierarchy
     */
    private static Field getFieldRecursive(Class c, String name) throws NoSuchFieldException
    {
        try
        {
            Field f = c.getDeclaredField(name);
            return f;
        }
        catch (NoSuchFieldException e)
        {
            // if field  could not be found in the inheritance hierarchy, signal error
            if ((c == Object.class) || (c.getSuperclass() == null) || c.isInterface())
            {
                throw e;
            }
            // if field could not be found in class c try in superclass
            else
            {
                return getFieldRecursive(c.getSuperclass(), name);
            }
        }
    }

    /**
     * Return field of the given field name path expression
     */
    private static Field getNestedRecursiveField(Class c, String aFieldName) throws NoSuchFieldException
    {
        Field result = null;
        int index = aFieldName.indexOf(PATH_TOKEN);
        if (index >= 0)
        {
            String pathName = aFieldName.substring(0, index);
            Field path = getFieldRecursive(c, pathName); // assert(path != null);
            result = getNestedRecursiveField(path.getType(), aFieldName.substring(index + PATH_TOKEN.length()));
        }
        else
        {
            result = getFieldRecursive(c, aFieldName);
        }
        return result;
    }

    protected boolean isNestedField()
    {
        if (isNestedField == UNKNOWN_FIELD) // not initialized
        {
            if (fieldName == null)
            {
                throw new MetadataException(
                        "Unexpected behaviour: fieldName is null, can not calculate field rootObjectType");
            }
            if (fieldName.indexOf(PATH_TOKEN) >= 0)
            {
                isNestedField = NESTED_FIELD;
            }
            else
            {
                isNestedField = NORMAL_FIELD;
            }
        }
        return isNestedField == NESTED_FIELD;
    }

    /**
     * Get nested attribute with given field name.
     * @param obj object from which the represented field's value is to be extracted
     * @param aFieldName nested attribute name
     * @return Object the value of the represented field in object obj
     */
    protected Object getNestedObject(Object obj, String aFieldName)
    {
        Object result = null;
        int index = aFieldName.indexOf(PATH_TOKEN);
        // make sure not to use a proxy object
        Object realObj = ProxyHelper.getRealObject(obj);
        Class realClass = ProxyHelper.getRealClass(obj);
        if (index >= 0)
        {
            String name = aFieldName.substring(0, index);
            PersistentField pField = createInternPersistentField(realClass, name);
            Object attrib = pField.get(realObj);

            if (attrib != null)
            {
                String nestedName = aFieldName.substring(index + PATH_TOKEN.length());
                result = getNestedObject(attrib, nestedName);
            }
        }
        else
        {
            PersistentField pField = createInternPersistentField(realClass, aFieldName);
            result = pField.get(realObj);
        }
        return result;
    }

    /**
     * Set nested attribute with given value.
     * @param obj the object whose field should be modified
     * @param fieldName nested attribute name
     * @param value the new value for the field of obj being modified
     */
    protected void setNestedObject(Object obj, String fieldName, Object value)
    {
        int index = fieldName.indexOf(PATH_TOKEN);
        Class realClass = ProxyHelper.getRealClass(obj);
        Object realObj = ProxyHelper.getRealObject(obj);
        if (index >= 0)
        {
            String name = fieldName.substring(0, index);
            PersistentField pField = createInternPersistentField(realClass, name);
            Object attrib = pField.get(realObj);

            if (attrib != null || value != null)
            {
                if (attrib == null)
                {
                    try
                    {
                        attrib = createNestedFieldValue(pField);
                    }
                    catch (InstantiationException e)
                    {
                        throw new MetadataException("Error instantiate field: "
                                + name + " in object:" + realClass.getName(), e);
                    }
                    catch (IllegalAccessException e)
                    {
                        throw new MetadataException("Error getting field:"
                                + name + " in object:" + realClass.getName(), e);
                    }

                    /*
                    TODO: here we need cast to AbstractPersistentField to execute the doSet-method.
                    Find better solution without cast?
                    */
                    if (pField instanceof AbstractPersistentField)
                    {
                        ((AbstractPersistentField) pField).doSet(realObj, attrib);
                    }
                    else
                    {
                        pField.set(realObj, attrib);
                    }
                }
                String nestedName = fieldName.substring(index + PATH_TOKEN.length());
                setNestedObject(attrib, nestedName, value);
            }
        }
        else
        {
            PersistentField pField = createInternPersistentField(realClass, fieldName);
            pField.set(realObj, value);
        }

    }

    protected Object createNestedFieldValue(PersistentField nestedField) throws InstantiationException, IllegalAccessException
    {
        return nestedField.getType().newInstance();
    }

    private PersistentField createInternPersistentField(Class fieldType, String aFieldName)
    {
        try
        {
            return PersistentFieldFactory.createPersistentField(fieldType, aFieldName);
        }
        catch (Exception e)
        {
            throw new MetadataException("Cannot create PersistentField for field '" + aFieldName + "' of class " +
                    fieldType.getName(), e);
        }
    }

    public String toString()
    {
        StringBuffer buf = new StringBuffer();
        buf.append("fieldName=");
        buf.append(fieldName);
        buf.append(", field [");
        buf.append(field);
        buf.append("]");
        return buf.toString();
    }

    public String getName()
    {
        return fieldName;
    }

    public Class getType()
    {
        return getField().getType();
    }

    public Class getDeclaringClass()
    {
        return getField().getDeclaringClass();
    }

    /**
     * Build a String representation of given arguments.
     */
	public String buildMessageString(Object obj, Object value, Field aField)
	{
		String eol = SystemUtils.LINE_SEPARATOR;
		StringBuffer buf = new StringBuffer();
		buf
			.append(eol + "[try to set 'object value' in 'target object'")
            .append(eol + "target obj class: " + (obj != null ? obj.getClass().getName() : null))
			.append(eol + "target field name: " + (aField != null ? aField.getName() : null))
			.append(eol + "target field type: " + (aField != null ? aField.getType() : null))
			.append(eol + "object value class: " + (value != null ? value.getClass().getName() : null))
			.append(eol + "object value: " + (value != null ? value : null))
			.append(eol + "]");
		return buf.toString();
	}
}
