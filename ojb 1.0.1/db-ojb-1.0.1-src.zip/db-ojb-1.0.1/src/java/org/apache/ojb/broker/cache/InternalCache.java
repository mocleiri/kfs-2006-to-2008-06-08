package org.apache.ojb.broker.cache;

/* Copyright 2004-2004 The Apache Software Foundation
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

import java.util.HashMap;
import java.util.Iterator;

import org.apache.ojb.broker.Identity;
import org.apache.ojb.broker.util.logging.Logger;
import org.apache.ojb.broker.util.logging.LoggerFactory;

/**
 * A wrapper class for {@link ObjectCache} implementation. This class is used as a
 * workaround for a concurrency materialization problem with shared cache implementations.
 * To avoid passing of partial materialized objects to cache this class act as a
 * temporary storage for unmaterialized (read) objects.
 * <br/>
 * TODO: Will be replaced on cache refactoring
 *
 * @author <a href="mailto:arminw@apache.org">Armin Waibel</a>
 * @version $Id: InternalCache.java,v 1.5 2004/06/25 16:09:50 arminw Exp $
 */
public class InternalCache implements ObjectCache
{
    private static Logger log = LoggerFactory.getLogger(InternalCache.class);

    private ObjectCache realCache;
    private HashMap localCache;
    private boolean enabledReadCache;

    public InternalCache(ObjectCache realCache)
    {
        this.realCache = realCache;
        this.localCache = new HashMap();
        enabledReadCache = false;
    }

    public void enableMaterializationCache()
    {
        enabledReadCache = true;
    }

    public void disableMaterializationCache()
    {
        enabledReadCache = false;
        pushToRealCache();
    }

    private void pushToRealCache()
    {
        Iterator it = localCache.keySet().iterator();
        Identity oid;
        while (it.hasNext())
        {
            oid = (Identity) it.next();
            realCache.cache(oid, localCache.get(oid));
        }
        localCache.clear();
    }

    public void cache(Identity oid, Object obj)
    {
        if(enabledReadCache)
        {
            localCache.put(oid, obj);
        }
        else
        {
            realCache.cache(oid, obj);
        }
    }

    public Object lookup(Identity oid)
    {
        Object result = null;
        if(enabledReadCache)
        {
            result = localCache.get(oid);
        }
        if(result == null)
        {
            result = realCache.lookup(oid);
        }
        return result;
    }

    public void remove(Identity oid)
    {
        if(enabledReadCache && !localCache.isEmpty())
        {
            localCache.remove(oid);
        }
        realCache.remove(oid);
    }

    public void localClear()
    {
        if(localCache.size() > 0)
        {
            log.warn("Found " + localCache.size() + " abandoned objects in local cache, check code to force" +
                    " push to real ObjectCache");
        }
        localCache.clear();
    }

    public void clear()
    {
        localCache.clear();
        realCache.clear();
    }
}
