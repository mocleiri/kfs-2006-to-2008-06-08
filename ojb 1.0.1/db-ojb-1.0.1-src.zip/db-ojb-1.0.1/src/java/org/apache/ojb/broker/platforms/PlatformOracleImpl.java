package org.apache.ojb.broker.platforms;

/* Copyright 2002-2004 The Apache Software Foundation
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

import org.apache.ojb.broker.util.logging.Logger;
import org.apache.ojb.broker.util.logging.LoggerFactory;

import java.io.ByteArrayInputStream;
import java.io.InputStreamReader;
import java.io.Reader;
import java.io.StringReader;
import java.lang.reflect.Field;
import java.security.AccessController;
import java.security.PrivilegedAction;
import java.sql.Connection;
import java.sql.DatabaseMetaData;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Types;

/**
 * This class is a concrete implementation of <code>Platform</code>. Provides an implementation
 * that works around some issues with Oracle in general and Oracle's Thin driver in particular..
 * 
 * @author <a href="mailto:thma@apache.org">Thomas Mahler <a>
 * @version $Id: PlatformOracleImpl.java,v 1.20 2004/05/22 09:55:33 brj Exp $
 */

public class PlatformOracleImpl extends PlatformDefaultImpl
{
    protected static final String THIN_URL_PREFIX = "jdbc:oracle:thin";
    // Oracle:thin handles direct BLOB insert <= 4000 and update <= 2000
    protected static final int THIN_BLOB_MAX_SIZE = 2000;
    // Oracle:thin handles direct CLOB insert and update <= 4000
    protected static final int THIN_CLOB_MAX_SIZE = 4000;
    private Logger logger = LoggerFactory.getLogger(PlatformOracleImpl.class);

    /**
     * In Oracle we set escape processing explizit 'true' after a statement was created.
     */
    public void afterStatementCreate(Statement stmt) throws PlatformException
    {
        try
        {
            stmt.setEscapeProcessing(true);
        }
        catch (SQLException e)
        {
            throw new PlatformException("Could not set escape processing", e);
        }
    }

    /**
     * For objects beyond 4k, weird things happen in Oracle if you try to use "setBytes", so for
     * all cases it's better to use setBinaryStream. Oracle also requires a change in the resultset
     * type of the prepared statement. MBAIRD NOTE: BLOBS may not work with Oracle database/thin
     * driver versions prior to 8.1.6.
     * 
     * @see Platform#setObjectForStatement
     */
    public void setObjectForStatement(PreparedStatement ps, int index, Object value, int sqlType)
            throws SQLException
    {
        if (((sqlType == Types.VARBINARY) || (sqlType == Types.LONGVARBINARY) || (sqlType == Types.BLOB))
                && (value instanceof byte[]))
        {
            byte buf[] = (byte[]) value;
            int length = buf.length;
            if (isUsingOracleThinDriver(ps.getConnection()) && length > THIN_BLOB_MAX_SIZE)
            {
                throw new SQLException(
                        "Oracle thin driver cannot update BLOB values with length>2000. (Consider using Oracle9i as OJB platform.)");
            }
            ByteArrayInputStream inputStream = new ByteArrayInputStream(buf);
            changePreparedStatementResultSetType(ps);
            ps.setBinaryStream(index, inputStream, length);
        }
        else if (value instanceof Double)
        {
            // workaround for the bug in Oracle thin driver
            ps.setDouble(index, ((Double) value).doubleValue());
        }
        else if (sqlType == Types.BIGINT && value instanceof Integer)
        {
            // workaround: Oracle thin driver problem when expecting long
            ps.setLong(index, ((Integer) value).intValue());
        }
        else if (sqlType == Types.INTEGER && value instanceof Long)
        {
            ps.setLong(index, ((Long) value).longValue());
        }
        else if (sqlType == Types.DATE && value instanceof String)
        {
            // special handling of like for dates (birthDate like '2000-01%')
            ps.setString(index, (String) value);
        }
        else if (sqlType == Types.CLOB && (value instanceof String || value instanceof byte[]))
        {
            Reader reader = null;
            int length = 0;
            if (value instanceof String)
            {
                String stringValue = (String) value;
                length = stringValue.length();
                reader = new StringReader(stringValue);
            }
            else
            {
                byte buf[] = (byte[]) value;
                ByteArrayInputStream inputStream = new ByteArrayInputStream(buf);
                reader = new InputStreamReader(inputStream);
                length = buf.length;
            }
            if (isUsingOracleThinDriver(ps.getConnection()) && length > THIN_CLOB_MAX_SIZE)
            {
                throw new SQLException(
                        "Oracle thin driver cannot insert CLOB values with length>4000. (Consider using Oracle9i as OJB platform.)");
            }
            ps.setCharacterStream(index, reader, length);
        }
        else
        {
            super.setObjectForStatement(ps, index, value, sqlType);
        }
    }

    /**
     * Attempts to modify a private member in the Oracle thin driver's resultset to allow proper
     * setting of large binary streams.
     */
    protected void changePreparedStatementResultSetType(PreparedStatement ps)
    {
        try
        {
            final Field f = ps.getClass().getSuperclass().getDeclaredField("m_userRsetType");
            AccessController.doPrivileged(new PrivilegedAction()
            {
                public Object run()
                {
                    f.setAccessible(true);
                    return null;
                }
            });
            f.setInt(ps, 1);
            f.setAccessible(false);
        }
        catch (Exception e)
        {
            logger.info("Not using classes12.zip.");
        }
    }

    /**
     * Get join syntax type for this RDBMS - one on of the constants from JoinSyntaxType interface
     */
    public byte getJoinSyntaxType()
    {
        return ORACLE_JOIN_SYNTAX;
    }

    public String createSequenceQuery(String sequenceName)
    {
        return "create sequence " + sequenceName;
    }

    public String nextSequenceQuery(String sequenceName)
    {
        return "select " + sequenceName + ".nextval from dual";
    }

    public String dropSequenceQuery(String sequenceName)
    {
        return "drop sequence " + sequenceName;
    }

    /**
     * Checks if the supplied connection is using the Oracle thin driver.
     * 
     * @param conn database connection for which to check JDBC-driver
     * @return <code>true</code> if the connection is using Oracle thin driver, <code>false</code>
     *         otherwise.
     */
    protected static boolean isUsingOracleThinDriver(Connection conn)
    {
        if (conn == null)
        {
            return false;
        }
        final DatabaseMetaData dbMetaData;
        final String dbUrl;
        try
        {
            dbMetaData = conn.getMetaData();
            dbUrl = dbMetaData.getURL();
            if (dbUrl != null && dbUrl.startsWith(THIN_URL_PREFIX))
            {
                return true;
            }
        }
        catch (Exception e)
        {
            // ignore it
        }
        return false;
    }

}
