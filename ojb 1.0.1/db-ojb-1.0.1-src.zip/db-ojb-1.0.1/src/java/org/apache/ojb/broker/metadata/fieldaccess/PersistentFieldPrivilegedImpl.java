package org.apache.ojb.broker.metadata.fieldaccess;

/* Copyright 2003-2004 The Apache Software Foundation
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

import org.apache.ojb.broker.metadata.MetadataException;

import java.io.Serializable;
import java.lang.reflect.Field;
import java.security.AccessController;
import java.security.PrivilegedAction;

/**
 * A {@link PersistentField} implementation using
 * reflection to access but does cooperate with
 * AccessController and do not suppress the java
 * language access check.
 *
 * @see PersistentFieldDirectAccessImpl
 *
 * @author <a href="mailto:thma@apache.org">Thomas Mahler<a>
 * @author <a href="mailto:armin@codeAuLait.de">Armin Waibel</a>
 * @version $Id: PersistentFieldPrivilegedImpl.java,v 1.11 2004/04/04 23:53:35 brianm Exp $
 */
public class PersistentFieldPrivilegedImpl extends PersistentFieldDirectAccessImpl
{
    private static final long serialVersionUID = -6110158693763128846L;
    
    private SetAccessibleAction setAccessibleAction = new SetAccessibleAction();
    private UnsetAccessibleAction unsetAccessibleAction = new UnsetAccessibleAction();
    private static final int ACCESSIBLE_STATE_UNKOWN = 0;
    private static final int ACCESSIBLE_STATE_FALSE = 1;
    private static final int ACCESSIBLE_STATE_SET_TRUE = 2;

    public PersistentFieldPrivilegedImpl()
    {
    }

    public PersistentFieldPrivilegedImpl(Class type, String fieldname)
    {
        super(type, fieldname);
    }

    /**
     *
     */
    public synchronized void doSet(Object obj, Object value) throws MetadataException
    {
        int accessibleState = ACCESSIBLE_STATE_UNKOWN;
        Field fld = getField();
        if (!fld.isAccessible()) accessibleState = ACCESSIBLE_STATE_FALSE;
        if (accessibleState == ACCESSIBLE_STATE_FALSE)
        {
            accessibleState = ACCESSIBLE_STATE_SET_TRUE;
            AccessController.doPrivileged(setAccessibleAction);
        }
        try
        {
            super.doSet(obj, value);
        }
        finally
        {
            if (accessibleState == ACCESSIBLE_STATE_SET_TRUE)
            {
                AccessController.doPrivileged(unsetAccessibleAction);
            }
        }
    }

    /**
     *
     */
    public synchronized Object doGet(Object obj) throws MetadataException
    {
        int accessibleState = ACCESSIBLE_STATE_UNKOWN;
        Field fld = getField();
        Object result = null;
        if (!fld.isAccessible()) accessibleState = ACCESSIBLE_STATE_FALSE;
        if (accessibleState == ACCESSIBLE_STATE_FALSE)
        {
            accessibleState = ACCESSIBLE_STATE_SET_TRUE;
            AccessController.doPrivileged(setAccessibleAction);
        }
        try
        {
            result = super.doGet(obj);
        }
        finally
        {
            if (accessibleState == ACCESSIBLE_STATE_SET_TRUE)
            {
                AccessController.doPrivileged(unsetAccessibleAction);
            }
        }
        return result;
    }

    /**
     * This implementation returns always 'false'.
     * @see AbstractPersistentField#makeAccessible()
     */
    public boolean makeAccessible()
    {
        return false;
    }

    /**
     * Always returns 'false'.
     * @see PersistentField#usesAccessorsAndMutators
     */
    public boolean usesAccessorsAndMutators()
    {
        return false;
    }

    //************************************************************
    // inner class
    //************************************************************
    private class SetAccessibleAction implements PrivilegedAction, Serializable
    {
		static final long serialVersionUID = 8152025069698028050L;        
        
        public Object run()
        {
            getField().setAccessible(true);
            return null;
        }
    }

    private class UnsetAccessibleAction implements PrivilegedAction, Serializable
    {
		static final long serialVersionUID = -2284913657454430305L;        
        
        public Object run()
        {
            getField().setAccessible(false);
            return null;
        }
    }
}
