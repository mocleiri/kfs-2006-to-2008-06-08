package org.apache.ojb.broker.accesslayer;

/* Copyright 2002-2004 The Apache Software Foundation
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

import org.apache.ojb.broker.metadata.JdbcConnectionDescriptor;
import org.apache.ojb.broker.platforms.Platform;

import java.sql.Connection;

/**
 * The connection manager handle the life cycle of a connection.
 * Each {@link org.apache.ojb.broker.PersistenceBroker} instance
 * use it's own connection manager.
 */
public interface ConnectionManagerIF
{
    /**
     * Return the associated {@link org.apache.ojb.broker.metadata.JdbcConnectionDescriptor}
     */
    public JdbcConnectionDescriptor getConnectionDescriptor();

    /**
     * Returns the supported {@link org.apache.ojb.broker.platforms.Platform}
     * determined by the {@link org.apache.ojb.broker.metadata.JdbcConnectionDescriptor}.
     * @see #getConnectionDescriptor
     */
    public Platform getSupportedPlatform();

    /**
     * checks if Connection conn is still open.
     * returns true, if connection is open, else false.
     */
    boolean isAlive(Connection conn);

    /**
     * Return a connection.
     */
    public Connection getConnection() throws LookupException;

    /**
     * Hold connection is in local transaction.
     */
    public boolean isInLocalTransaction();

    /**
     * Begin local transaction on the hold connection
     * and set autocommit to false.
     */
    public void localBegin();

    /**
     * Commit the local transaction on the hold connection.
     */
    public void localCommit();

    /**
     * Rollback a changes on the hold connection.
     */
    public void localRollback();

    /**
     * Release the hold connection.
     */
    public void releaseConnection();

    /**
     * Sets the batch mode on (<code>true</code>) or
     * off (<code>false</code>).
     */
    public void setBatchMode(boolean mode);

    /**
     * @return the batch mode.
     */
    public boolean isBatchMode();

    /**
     * Execute batch (if the batch mode where used).
     */
    public void executeBatch();

    /**
     * Execute batch if the number of statements in it
     * exceeded the limit (if the batch mode where used).
     */
    public void executeBatchIfNecessary();

    /**
     * Clear batch (if the batch mode where used).
     */
    public void clearBatch();
}
