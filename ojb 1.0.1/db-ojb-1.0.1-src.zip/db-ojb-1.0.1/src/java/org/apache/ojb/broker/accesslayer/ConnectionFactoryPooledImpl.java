package org.apache.ojb.broker.accesslayer;

/* Copyright 2002-2004 The Apache Software Foundation
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

import org.apache.commons.pool.BasePoolableObjectFactory;
import org.apache.commons.pool.ObjectPool;
import org.apache.commons.pool.PoolableObjectFactory;
import org.apache.commons.pool.impl.GenericObjectPool;
import org.apache.ojb.broker.metadata.JdbcConnectionDescriptor;
import org.apache.ojb.broker.util.logging.Logger;
import org.apache.ojb.broker.util.logging.LoggerFactory;
import org.apache.ojb.broker.OJBRuntimeException;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

/**
 * Connection factory which pools the requested
 * connections for different JdbcConnectionDescriptors
 * using jakarta-commons-pool api.
 *
 * @author <a href="mailto:armin@codeAuLait.de">Armin Waibel</a>.
 * @version $Id: ConnectionFactoryPooledImpl.java,v 1.15 2004/06/11 18:49:09 brj Exp $
 */
public class ConnectionFactoryPooledImpl extends ConnectionFactoryAbstractImpl
{
    private Logger log = LoggerFactory.getLogger(ConnectionFactoryPooledImpl.class);
    private Map connectionPools = new HashMap();

    public ConnectionFactoryPooledImpl()
    {

    }

    public void returnConnectionToPool(JdbcConnectionDescriptor jcd, Connection con)
            throws LookupException
    {
        try
        {
            ((ObjectPool) this.connectionPools.get(jcd.getPBKey())).returnObject(con);
        }
        catch (Exception e)
        {
            throw new LookupException(e);
        }
    }

    public Connection getConnectionFromPool(JdbcConnectionDescriptor jcd) throws LookupException
    {
        ObjectPool op = (ObjectPool) connectionPools.get(jcd.getPBKey());
        if (op == null)
        {
            log.info("Create new connection pool:" + jcd);
            op = createConnectionPool(jcd);
            synchronized (connectionPools)
            {
                connectionPools.put(jcd.getPBKey(), op);
            }
        }
        try
        {
            return (Connection) op.borrowObject();
        }
        catch (Exception e)
        {
            throw new LookupException("Could not borrow connection from pool - " +
                    JdbcConnectionDescriptor.class.getName() + ":  " + jcd, e);
        }
    }

    /**
     * Create the pool for pooling the connections of the given connection descriptor.
     * Override this method to implement your on {@link org.apache.commons.pool.ObjectPool}.
     */
    public ObjectPool createConnectionPool(JdbcConnectionDescriptor jcd)
    {
        if (log.isDebugEnabled()) log.debug("createPool was called");
        PoolableObjectFactory pof = new ConPoolFactory(this, jcd);
        GenericObjectPool.Config conf = jcd.getConnectionPoolDescriptor().getObjectPoolConfig();
        ObjectPool op = new GenericObjectPool(pof, conf);
        return op;
    }

    /**
     * Closes all managed pools.
     */
    public void releaseAllResources()
    {
        super.releaseAllResources();
        synchronized (connectionPools)
        {
            Collection pools = connectionPools.values();
            connectionPools = new HashMap(connectionPools.size());
            ObjectPool op = null;
            for (Iterator iterator = pools.iterator(); iterator.hasNext();)
            {
                try
                {
                    op = ((ObjectPool) iterator.next());
                    op.close();
                }
                catch (Exception e)
                {
                    log.error("Exception occured while closing pool " + op, e);
                }
            }
        }
    }

    //**************************************************************************************
    // Inner classes
    //************************************************************************************

    /**
     * Inner class - {@link org.apache.commons.pool.PoolableObjectFactory}
     * used as factory for connection pooling
     */
    class ConPoolFactory extends BasePoolableObjectFactory
    {
        int failedValidationQuery;
        JdbcConnectionDescriptor jcd;
        ConnectionFactoryPooledImpl cf;

        public ConPoolFactory(ConnectionFactoryPooledImpl cf, JdbcConnectionDescriptor jcd)
        {
            this.cf = cf;
            this.jcd = jcd;
        }

        public boolean validateObject(Object obj)
        {
            Connection con = (Connection) obj;
            String query = jcd.getConnectionPoolDescriptor().getValidationQuery();
            if (query == null || query.trim().equals(""))
            {
                try
                {
                    return !con.isClosed();
                }
                catch (SQLException e)
                {
                    log.warn("Connection validation failed: " + e.getMessage());
                    if (log.isDebugEnabled()) log.debug(e);
                    return false;
                }
            }
            else
            {
                return validateConnection(con, query);
            }
        }

        private boolean validateConnection(Connection conn, String query)
        {
            Statement stmt = null;
            ResultSet rset = null;
            boolean isValid = false;
            if(failedValidationQuery > 100)
            {
                throw new OJBRuntimeException("Validation of connection "+conn+" using validation query "+
                        query + " failed more than 100 times.");
            }
            try
            {
                stmt = conn.createStatement();
                rset = stmt.executeQuery(query);
                if (rset.next())
                {
                    failedValidationQuery = 0;
                    isValid = true;
                }
                else
                {
                    ++failedValidationQuery;
                    log.warn("Validation query '" + query +
                            "' result set does not match, discard connection");
                    isValid = false;
                }
            }
            catch (SQLException e)
            {
                ++failedValidationQuery;
                log.warn("Validation query for connection failed, discard connection. Query was " +
                        query + ", Message was " + e.getMessage());
                if (log.isDebugEnabled()) log.debug(e);
            }
            finally
            {
                try
                {
                    if(rset != null) rset.close();
                }
                catch (SQLException t)
                {
                    if (log.isDebugEnabled()) log.debug("ResultSet already closed.", t);
                }
                try
                {
                    if(stmt != null) stmt.close();
                }
                catch (SQLException t)
                {
                    if (log.isDebugEnabled()) log.debug("Statement already closed.", t);
                }
            }
            return isValid;
        }

        public Object makeObject() throws Exception
        {
            if (log.isDebugEnabled()) log.debug("makeObject called");
            return cf.newConnectionFromDriverManager(jcd);
        }

        public void destroyObject(Object obj)
                throws Exception
        {
            log.info("Destroy object was called, try to close connection: " + obj);
            try
            {
                ((Connection) obj).close();
            }
            catch (SQLException ignore)
            {
                //ignore it
            }
        }
    }
}
