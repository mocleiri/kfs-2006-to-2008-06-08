package org.apache.ojb.broker.cache;

import org.apache.ojb.broker.Identity;
import org.apache.ojb.broker.PersistenceBroker;

/* Copyright 2003-2004 The Apache Software Foundation
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

/**
 * A {@link CacheFilter} implementation for filtering objects
 * before cached, using custom attribute <code>cacheable</code>
 * in <code>class-descriptor</code> in repository file.
 *
 * <br/>
 * <b>Example:</b>
 * <br/>
 * Add this custom attribute to your <code>class-descriptor</code> to avoid
 * caching of the class.
 * <pre>
 * &lt;attribute
 *    attribute-name="cacheable"
 *    attribute-value="false"/&gt;
 * </pre>
 *
 * @author <a href="mailto:armin@codeAuLait.de">Armin Waibel</a>
 * @version $Id: CacheFilterClassImpl.java,v 1.6.2.1 2004/08/09 07:51:26 arminw Exp $
 */
public class CacheFilterClassImpl implements CacheFilter
{
    public static final String CACHEABLE = "cacheable";
    private PersistenceBroker broker;
    private ObjectCache cache;

    public CacheFilterClassImpl(PersistenceBroker broker, ObjectCache cache)
    {
        this.broker = broker;
        this.cache = cache;
    }

    public boolean beforeCache(Identity oid, Object obj)
    {
        String cacheable = broker.getClassDescriptor(oid.getObjectsRealClass()).getAttribute(CACHEABLE);
        if (cacheable == null || Boolean.valueOf(cacheable).booleanValue())
        {
            return true;
        }
        else
        {
            return false;
        }
    }

    public boolean beforeLookup(Identity oid)
    {
        return true;
    }

    public boolean beforeRemove(Identity oid)
    {
        return true;
    }

    public ObjectCache getObjectCache()
    {
        return cache;
    }
}
