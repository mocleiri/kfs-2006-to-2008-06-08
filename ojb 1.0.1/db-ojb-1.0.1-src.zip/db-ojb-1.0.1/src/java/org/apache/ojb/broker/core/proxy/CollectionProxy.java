package org.apache.ojb.broker.core.proxy;

/**
 * Interface which Collection proxies need to implement to be
 * treated like collection proxies in ODMG.
 * <p> 
 * Presently the collection proxy impl class can be plugged in and
 * not implement this interface, but those implementations will
 * *not* be treated as proxies by OJB
 */
public interface CollectionProxy
{
    /**
     * Adds a listener to this collection.
     *
     * @param listener The listener to add
     */
    void addListener(CollectionProxyListener listener);

    /**
     * Removes the given listener from this collecton.
     *
     * @param listener The listener to remove
     */
    void removeListener(CollectionProxyListener listener);

    /**
     * Determines whether the collection data already has been loaded from the database.
     *
     * @return <code>true</code> if the data is already loaded
     */
    public boolean isLoaded();
}
