package org.apache.ojb.broker.util.logging;

/* Copyright 2002-2004 The Apache Software Foundation
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

import java.util.HashMap;
import java.util.Map;

import org.apache.ojb.broker.util.ClassHelper;

/**
 * The factory class <code>LoggerFactory</code> can be used
 * to create <code>Logger</code> instances.
 * The <code>Logger</code>-implementation class served
 * by the factory is configured by settings in the
 * OJB.properties file.
 *
 * @author Thomas Mahler
 * @author <a href="leandro@ibnetwork.com.br">Leandro Rodrigo Saad Cruz</a>
 *
 * @version $Id: LoggerFactoryImpl.java,v 1.18 2004/06/23 07:13:51 tomdz Exp $
 *
 * @see <a href="http://jakarta.apache.org/log4j/docs/index.html">jakarta-log4j</a>
 */
public class LoggerFactoryImpl
{
    public static final LoggerFactoryImpl INSTANCE = new LoggerFactoryImpl();

    private Logger defaultLogger = null;

    private Logger bootLogger = null;

    /** Used for caching logger instances */
    private Map cache = new HashMap();
    /** The configuration */
    private LoggingConfiguration conf;
    
    // yes. it's a singleton !
    private LoggerFactoryImpl()
    {

    }
    
    public static LoggerFactoryImpl getInstance()
    {
        return INSTANCE;
    }

    private LoggingConfiguration getConfiguration()
    {
        if (conf == null)
        {
            // this will load the configuration
            conf = new LoggingConfiguration();
        }
        return conf;
    }

    /**
     * returns a minimal logger that needs no configuration
     * and can thus be safely used during OJB boot phase
     * (i.e. when OJB.properties have not been loaded).
     * @return Logger the OJB BootLogger
     */
    public Logger getBootLogger()
    {
        if (bootLogger == null)
        {
            bootLogger = new PoorMansLoggerImpl("BOOT");
            // allow user to set boot log level via system property
            String level = System.getProperty("OJB.bootLogLevel", LoggingConfiguration.OJB_DEFAULT_LOG_LEVEL);
            ((PoorMansLoggerImpl) bootLogger).setLevel(level);
        }
        return bootLogger;
    }


    /**
     * returns the default logger. This Logger can
     * be used when it is not appropriate to use a
     * dedicated fresh Logger instance.
     * @return default Logger
     */
    public Logger getDefaultLogger()
    {
        if (defaultLogger == null)
        {
            defaultLogger = getLogger("DEFAULT");
        }
        return defaultLogger;
    }


    /**
     * returns a Logger. The Logger is named
     * after the full qualified name of input parameter clazz
     * @param clazz the Class which name is to be used as name
     * @return Logger the returned Logger
     */
    public Logger getLogger(Class clazz)
    {
        return getLogger(clazz.getName());
    }


    /**
     * returns a Logger.
     * @param loggerName the name of the Logger
     * @return Logger the returned Logger
     */
    public Logger getLogger(String loggerName)
    {
        //lookup in the cache first
        if (cache.containsKey(loggerName))
        {
            //getBootLogger().debug("Returning cached version of Logger[" + loggerName + "]");
            return (Logger) cache.get(loggerName);
        }
        //getBootLogger().debug("Logger[" + loggerName + "] not cached");

        Logger logger      = null;
        Class  loggerClass = null;

        try
        {
            // get the configuration (not from the configurator because this is independent)
            LoggingConfiguration conf = getConfiguration();

            loggerClass = conf.getLoggerClass();
            getBootLogger().debug("Using logger class " + loggerClass + " for " + loggerName);
            logger = (Logger) ClassHelper.newInstance(loggerClass, String.class, loggerName);

            // configure the logger
            try
            {
                getBootLogger().debug("Initializing logger instance " + loggerName);
                logger.configure(conf);
            }
            catch (Exception ex)
            {
                logger = getBootLogger();
                logger.error("[" + this.getClass().getName() + "] Could not initialize logger for class " + loggerClass.getName(), ex);
            }

            //cache it so we can get it faster the next time
            cache.put(loggerName, logger);
        }
        catch (Throwable t)
        {
            logger = getBootLogger();
            logger.error("[" + this.getClass().getName() + "] Could not set logger for class " + loggerClass.getName(), t);
        }
        return logger;
    }

}
