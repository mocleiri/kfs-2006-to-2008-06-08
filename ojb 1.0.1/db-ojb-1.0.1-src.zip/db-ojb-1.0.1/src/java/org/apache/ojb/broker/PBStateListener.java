package org.apache.ojb.broker;

/* Copyright 2003-2004 The Apache Software Foundation
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
public interface PBStateListener extends PBListener
{
    /**
     * Called after the {@link org.apache.ojb.broker.PersistenceBroker}
     * instance was obtained from pool.
     */
    public void afterOpen(PBStateEvent event);

    /**
     * Called before a <tt>PersistenceBroker transaction</tt> was started.
     */
    public void beforeBegin(PBStateEvent event);

    /**
     * Called after a <tt>PersistenceBroker transaction</tt> was started.
     */
    public void afterBegin(PBStateEvent event);

    /**
     * Called before a <tt>PersistenceBroker commit</tt> was called.
     */
    public void beforeCommit(PBStateEvent event);

    /**
     * Called after a <tt>PersistenceBroker commit</tt> was called.
     */
    public void afterCommit(PBStateEvent event);

    /**
     * Called before a <tt>PersistenceBroker rollback</tt> was called.
     */
    public void beforeRollback(PBStateEvent event);

    /**
     * Called after a <tt>PersistenceBroker rollback</tt> was called.
     */
    public void afterRollback(PBStateEvent event);

    /**
     * Called before the {@link org.apache.ojb.broker.PersistenceBroker}
     * instance was returned to pool.
     */
    public void beforeClose(PBStateEvent event);
}
