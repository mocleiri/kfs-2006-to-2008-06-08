package org.apache.ojb.broker.accesslayer;

/* Copyright 2002-2004 The Apache Software Foundation
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

import org.apache.ojb.broker.metadata.JdbcConnectionDescriptor;
import org.apache.ojb.broker.platforms.PlatformException;
import org.apache.ojb.broker.platforms.PlatformFactory;
import org.apache.ojb.broker.util.ClassHelper;
import org.apache.ojb.broker.util.logging.Logger;
import org.apache.ojb.broker.util.logging.LoggerFactory;

import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;

/**
 * Abstract base class to simplify implementation of {@link ConnectionFactory}'s.
 *
 * @author <a href="mailto:armin@codeAuLait.de">Armin Waibel</a>
 * @version $Id: ConnectionFactoryAbstractImpl.java,v 1.10 2004/04/04 23:53:30 brianm Exp $
 */
public abstract class ConnectionFactoryAbstractImpl implements ConnectionFactory
{
    private Logger log = LoggerFactory.getLogger(ConnectionFactoryAbstractImpl.class);

    /**
     * holds the datasource looked up from JNDI in a map, keyed
     * by the JNDI name.
     */
    private Map dataSourceCache = new HashMap();

    /**
     * Implement this method. This method was called to obtain
     * a jdbc-connection from the pool.
     * <br/>
     * Note: This method was
     * not called, if jdbc-connection-descriptor use datasources - OJB
     * only pool connections from DriverManager.
     */
    public abstract Connection getConnectionFromPool(JdbcConnectionDescriptor jcd)
            throws LookupException;

    /**
     * Implement this method. Was called to return a
     * connection to pool.
     * <br/>
     * Note: This method was
     * not called, if the jdbc-connection-descriptor uses datasources - OJB
     * only pool connections from DriverManager.
     */
    public abstract void returnConnectionToPool(JdbcConnectionDescriptor jcd, Connection con)
            throws LookupException;

    public void releaseConnection(JdbcConnectionDescriptor jcd, Connection con)
    {
        if (con == null) return;
        if (jcd.isDataSource())
        {
            try
            {
                con.close();
            }
            catch (SQLException e)
            {
                log.error("Closing connection failed", e);
            }
        }
        else
        {
            try
            {
                returnConnectionToPool(jcd, con);
            }
            catch (LookupException e)
            {
                log.error("Unexpected exception when return connection " + con +
                        " to pool using " + jcd, e);
            }
        }
    }

    public Connection lookupConnection(JdbcConnectionDescriptor jcd) throws LookupException
    {
        Connection conn;
        /*
        use JNDI datasourcelookup or ordinary jdbc DriverManager
        to obtain connection ?
        */
        if (jcd.isDataSource())
        {
            if (log.isDebugEnabled())
                log.debug("do datasource lookup, name: " + jcd.getDatasourceName() +
                        ", user: " + jcd.getUserName());
            conn = newConnectionFromDataSource(jcd);
        }
        else
        {
            conn = getConnectionFromPool(jcd);
            // check connection
            try
            {
                if (conn == null || conn.isClosed())
                {
                    log.error("Connection for JdbcConnectionDiscriptor (" +
                            (jcd.getDatasourceName() != null ? "datasource: " + jcd.getDatasourceName() :
                            "db-url: " + getDbURL(jcd) + ", user: " + jcd.getUserName()) +
                            ") was not valid, either *closed* or *null*");
                    throw new LookupException("Could not lookup valid connection from pool/DB, connection was "+conn);
                }
            }
            catch (SQLException e)
            {
                log.error("Error during sanity check of new DB Connection, either it was closed", e);
                throw new LookupException("Connection check failed", e);
            }
        }
        return conn;
    }

    /**
     * Initialize the connection with the specified properties in OJB
     * configuration files and platform depended properties.
     * Invoke this method after a NEW connection was created.
     *
     * @see org.apache.ojb.broker.platforms.PlatformFactory
     * @see org.apache.ojb.broker.platforms.Platform
     */
    protected void initializeJdbcConnection(Connection con, JdbcConnectionDescriptor jcd)
            throws LookupException
    {
        // initialize connection
        // perform platform specific initializations:
        try
        {
            PlatformFactory.getPlatformFor(jcd).initializeJdbcConnection(jcd, con);
        }
        catch (PlatformException e)
        {
            throw new LookupException("Platform dependent initialization of connection failed", e);
        }
    }

    /**
     * Override this method to do cleanup in your implenetation.
     * Do a <tt>super.releaseAllResources()</tt> in your method implementation
     * to free resources used by this class.
     */
    public synchronized void releaseAllResources()
    {
        this.dataSourceCache.clear();
    }

    /**
     *
     * @param jcd
     * @return an instance of Connection from the named Datasource
     * @throws LookupException if we can't get a connection from the datasource either due to a
     *          naming exception, a failed sanity check, or a SQLException.
     */
    protected Connection newConnectionFromDataSource(JdbcConnectionDescriptor jcd)
            throws LookupException
    {
        Connection retval = null;
        // use JNDI lookup
        DataSource ds = (DataSource) dataSourceCache.get(jcd.getDatasourceName());
        try
        {
            if (ds == null)
            {
                /**
                 * this synchronization block won't be a big deal as we only look up
                 * new datasources not found in the map.
                 */
                synchronized (dataSourceCache)
                {
                    InitialContext ic = new InitialContext();
                    ds = (DataSource) ic.lookup(jcd.getDatasourceName());
                    /**
                     * cache the datasource lookup.
                     */
                    dataSourceCache.put(jcd.getDatasourceName(), ds);
                }
            }
            if (jcd.getUserName() == null)
            {
                retval = ds.getConnection();
            }
            else
            {
                retval = ds.getConnection(jcd.getUserName(), jcd.getPassWord());
            }
        }
        catch (SQLException sqlEx)
        {
            log.error("SQLException thrown while trying to get Connection from Datasource (" +
                    jcd.getDatasourceName() + ")", sqlEx);
            throw new LookupException("SQLException thrown while trying to get Connection from Datasource (" +
                    jcd.getDatasourceName() + ")", sqlEx);
        }
        catch (NamingException namingEx)
        {
            log.error("Naming Exception while looking up DataSource (" + jcd.getDatasourceName() + ")", namingEx);
            throw new LookupException("Naming Exception while looking up DataSource (" + jcd.getDatasourceName() +
                    ")", namingEx);
        }
        // initialize connection
        initializeJdbcConnection(retval, jcd);
        if(log.isDebugEnabled()) log.debug("Create new connection using DataSource: "+retval);
        return retval;
    }

    /**
     * Returns a new created connection
     *
     * @param jcd the connection descriptor
     * @return an instance of Connection from the drivermanager
     */
    protected Connection newConnectionFromDriverManager(JdbcConnectionDescriptor jcd)
            throws LookupException
    {
        Connection retval = null;
        // use JDBC DriverManager
        String driver = jcd.getDriver();
        String url = getDbURL(jcd);
        try
        {
            // loads the driver - NB call to newInstance() added to force initialisation
            ClassHelper.getClass(driver, true);
            if (jcd.getUserName() == null)
            {
                retval = DriverManager.getConnection(url);
            }
            else
            {
                retval = DriverManager.getConnection(url, jcd.getUserName(), jcd.getPassWord());
            }
        }
        catch (SQLException sqlEx)
        {
            log.error("Error getting Connection from DriverManager with url (" + url + ") and driver (" + driver + ")", sqlEx);
            throw new LookupException("Error getting Connection from DriverManager with url (" + url + ") and driver (" + driver + ")", sqlEx);
        }
        catch (ClassNotFoundException cnfEx)
        {
            log.error(cnfEx);
            throw new LookupException("A class was not found", cnfEx);
        }
        catch (Exception e)
        {
            log.error("Instantiation of jdbc driver failed", e);
            throw new LookupException("Instantiation of jdbc driver failed", e);
        }
        // initialize connection
        initializeJdbcConnection(retval, jcd);
        if(log.isDebugEnabled()) log.debug("Create new connection using DriverManager: "+retval);
        return retval;
    }

    protected String getDbURL(JdbcConnectionDescriptor jcd)
    {
        return jcd.isDataSource() ? jcd.getDatasourceName() :
                jcd.getProtocol() + ":" + jcd.getSubProtocol() + ":" + jcd.getDbAlias();
    }
}
