package org.apache.ojb.broker.metadata.fieldaccess;

/* Copyright 2003-2004 The Apache Software Foundation
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

import java.util.Vector;

import org.apache.ojb.broker.metadata.ClassDescriptor;
import org.apache.ojb.broker.metadata.MetadataException;
import org.apache.ojb.broker.util.ClassHelper;

/**
 * @author Houar TINE
 * @version $Id: AnonymousPersistentFieldForInheritance.java,v 1.11.2.1 2004/07/27 00:33:11 arminw Exp $
 */
public class AnonymousPersistentFieldForInheritance extends AnonymousPersistentField
{
    private static final long serialVersionUID = -8367827598025566663L;

    ClassDescriptor cld = null;

    public AnonymousPersistentFieldForInheritance(ClassDescriptor cld, String fieldname)
    {
        super(fieldname);
        this.cld = cld;
    }

    private void copyObjectToObject(Object fromObject, Object toObject)
    {
        Vector persistentFields = cld.getSuperPersistentFieldDescriptors();
        for (int i = persistentFields.size() - 1; i >= 0; i--)
        {
            PersistentField pf = (PersistentField) persistentFields.get(i);
            pf.set(toObject, pf.get(fromObject));
        }
    }

    /**
     * Field values of 'value' (base object) are copied to 'obj' (derived object)
     * then obj is saved in a map
     *
     * @param obj - the base object instance
     * @param value - the derived object instance
     * @throws MetadataException
     */
    public synchronized void set(Object obj, Object value) throws MetadataException
    {
        copyObjectToObject(value, obj);
        putToFieldCache(obj, value);
    }

    /**
     * Field values of 'obj' (derived object) are copied to 'value' (base object)
     * then value is returned as a referenced object.
     *
     * @param obj - the base object instance
     * @throws MetadataException
     */
    public synchronized Object get(Object obj) throws MetadataException
    {
        Object value = getFromFieldCache(obj);
        if (null == value)
        {
            try
            {
                ClassDescriptor baseCld = cld.getRepository().getDescriptorFor(cld.getBaseClass());
                value = ClassHelper.buildNewObjectInstance(baseCld);
            }
            catch (Exception e)
            {
                throw new MetadataException("Can't create new base class object for '" + cld.getBaseClass()+"'", e);
            }
            putToFieldCache(obj, value);
        }

        copyObjectToObject(obj, value);
        return value;
    }
}
