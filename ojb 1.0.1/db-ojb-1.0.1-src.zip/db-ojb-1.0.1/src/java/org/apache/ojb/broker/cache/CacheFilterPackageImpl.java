package org.apache.ojb.broker.cache;

import org.apache.ojb.broker.Identity;
import org.apache.ojb.broker.PersistenceBroker;

import java.util.StringTokenizer;

/* Copyright 2003-2004 The Apache Software Foundation
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */


/**
 * A {@link CacheFilter} implementation for filtering objects
 * before cached when the given objects package name match a
 * given package, defined as custom attribute within the
 * <code>descriptor-repository</code> element or
 * <code>jdbc-connection-descriptor</code> in the repository file.
 * <br/>
 * <b>Example:</b>
 * <br/>
 * Add this custom attribute to a <code>jdbc-connection-descriptor</code>
 * to avoid caching of package trees for the described connection.
 *
 * <pre>
 * &lt;attribute
 *    attribute-name="exclude-packages"
 *    attribute-value="org.my.test,org.my.admin"/&gt;
 * </pre>
 *
 * To enable a global exclude of caching, add the custom attribute
 * entry under the <code>descriptor-repository</code> element.
 *
 * @author <a href="mailto:armin@codeAuLait.de">Armin Waibel</a>
 * @version $Id: CacheFilterPackageImpl.java,v 1.8.2.1 2004/08/09 07:51:26 arminw Exp $
 */
public class CacheFilterPackageImpl implements CacheFilter
{
    public static final String EXCLUDE_PACKAGES = "exclude-packages";
    private static final String COMMA = ",";

    private PersistenceBroker broker;
    private ObjectCache cache;
    private StringTokenizer tok;
    private String filterPackages;

    public CacheFilterPackageImpl(PersistenceBroker broker, ObjectCache cache)
    {
        this.broker = broker;
        this.cache = cache;
    }

    public boolean beforeCache(Identity oid, Object obj)
    {
        filterPackages = null;
        filterPackages = broker.serviceConnectionManager().
                getConnectionDescriptor().getAttribute(EXCLUDE_PACKAGES);
        filterPackages = broker.getDescriptorRepository().getAttribute(EXCLUDE_PACKAGES) +
                (filterPackages != null ? COMMA + filterPackages : "");
        return matchFilterPackages(filterPackages, oid.getObjectsRealClass());
    }

    public boolean beforeLookup(Identity oid)
    {
        return true;
    }

    public boolean beforeRemove(Identity oid)
    {
        return true;
    }

    public ObjectCache getObjectCache()
    {
        return cache;
    }

    private boolean matchFilterPackages(String aFilterPackages, Class clazz)
    {
        boolean result = true;
        if (aFilterPackages != null && aFilterPackages.length() != 0)
        {
            String token;
            tok = new StringTokenizer(aFilterPackages, COMMA);
            while (tok.hasMoreTokens())
            {
                token = tok.nextToken().trim();
                if (!token.equals("") && clazz.getName().startsWith(token))
                {
                    result = false;
                    break;
                }
            }
        }
        return result;
    }
}
