package org.apache.ojb.broker.cache;

/* Copyright 2002-2004 The Apache Software Foundation
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

import org.apache.ojb.broker.PersistenceBroker;
import org.apache.ojb.broker.core.PersistenceBrokerConfiguration;
import org.apache.ojb.broker.util.ClassHelper;
import org.apache.ojb.broker.util.configuration.impl.OjbConfigurator;
import org.apache.ojb.broker.util.factory.ConfigurableFactory;

import java.util.Properties;

/**
 * Factory for {@link ObjectCache} implementation classes.
 * Each given {@link org.apache.ojb.broker.PersistenceBroker}
 * was associated with its own <code>ObjectCache</code> instance
 * and vice versa.
 *
 * @author <a href="mailto:thma@apache.org">Thomas Mahler<a>
 * @version $Id: ObjectCacheFactory.java,v 1.17 2004/04/04 23:53:33 brianm Exp $
 */

public class ObjectCacheFactory extends ConfigurableFactory
{
    private static ObjectCacheFactory singleton = new ObjectCacheFactory();

    /**
     * Get the ObjectCacheFactory instance.
     */
    public static ObjectCacheFactory getInstance()
    {
        return singleton;
    }

    public ObjectCacheFactory()
    {
    }

    /**
     * Creates a new {@link ObjectCache} instance. Each <tt>ObjectCache</tt>
     * implementation was wrapped by a {@link CacheDistributor} instance and if
     * cache filtering is enabled by a {@link CacheFilterRegistry} instance too.
     *
     * @param broker The PB instance to associate with the cache instance
     */
    public ObjectCache createObjectCache(PersistenceBroker broker)
    {
        ObjectCache objectCache;
        ObjectCache defaultCache = null;
        try
        {
            getLogger().info("Start creating new ObjectCache instance");
            /*
            1.
            if default cache was not found,
            create an new instance of the default cache specified in the
            configuration.
            2.
            Then instantiate AllocatorObjectCache to handle
            per connection/ per class caching instances.
            3.
            Check if cache filtering is enabled. If true, create filter classes
            and add to filter registry instance - wraps AllocatorCache.
            4.
            To support intern operations we wrap ObjectCache with an
            InternalObjectCache implementation
            */

            defaultCache = (ObjectCache) this.createNewInstance(
                    new Class[]{PersistenceBroker.class, Properties.class}, new Object[]{broker, null});

            objectCache = defaultCache;
            getLogger().info("Default ObjectCache class was " + objectCache.getClass().getName());
            objectCache = new CacheDistributor(broker, objectCache);
            getLogger().info("Instantiate new " + objectCache.getClass().getName() + " class object");
            /*
            if cache filtering was enabled, we wrap the cache
            with a class manages the filter classes
            */
            if (useCacheFilter())
            {
                getLogger().info("Enable CacheFilters");
                CacheFilterRegistry filterCache = new CacheFilterRegistry(objectCache);
                String[] filters = getFiltersFromConfiguration();
                for (int i = 0; i < filters.length; i++)
                {
                    getLogger().info("Create CacheFilter: "
                            + (filters[i] != null ? filters[i].getClass().getName() : null));
                    filterCache.addCacheFilter(
                            (CacheFilter) ClassHelper.newInstance(
                                    filters[i],
                                    new Class[]{PersistenceBroker.class, ObjectCache.class},
                                    new Object[]{broker, objectCache}));
                }
                objectCache = filterCache;
            }
            getLogger().debug("Object cache created, using cache:" + objectCache);

        }
        catch (Exception e)
        {
            getLogger().error("Error while ObjectCache initiation, please check your configuration" +
                    " files and the used implementation class - use default cache " + defaultCache + "instead", e);
            objectCache = defaultCache;
        }
        getLogger().info("New ObjectCache instance was created");
        return objectCache;
    }

    /**
     * @see org.apache.ojb.broker.util.factory.ConfigurableFactory#getConfigurationKey()
     */
    protected String getConfigurationKey()
    {
        return "ObjectCacheClass";
    }

    private boolean useCacheFilter()
    {
        return (getFiltersFromConfiguration() != null);
    }

    private String[] getFiltersFromConfiguration()
    {
        return ((PersistenceBrokerConfiguration) OjbConfigurator.
                getInstance().getConfigurationFor(null)).getCacheFilters();
    }

    protected ObjectCache createNewCacheInstance(Class target, PersistenceBroker broker,
                                                    Properties prop) throws Exception
    {
        ObjectCache newCache = null;
        try
        {
            newCache = (ObjectCache) ClassHelper.newInstance(
                            target,
                            new Class[]{PersistenceBroker.class, Properties.class},
                            new Object[]{broker, prop});
        }
        catch (Exception e)
        {
            getLogger().error("Can not create ObjectCache instance using class " + target, e);
            throw e;
        }
        return newCache;
    }
}
