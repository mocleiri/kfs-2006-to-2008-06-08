package org.apache.ojb.broker.metadata.fieldaccess;

/* Copyright 2003-2004 The Apache Software Foundation
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

import org.apache.ojb.broker.core.proxy.ProxyHelper;
import org.apache.ojb.broker.metadata.MetadataException;

import java.lang.reflect.Field;

/**
 * A {@link PersistentField} implementation
 * is a high-speed version of the access strategies.
 * It does not cooperate with an AccessController,
 * but accesses the fields directly. This implementation persistent
 * attributes don't need getters and setters
 * and don't have to be declared public or protected
 *
 * @author <a href="mailto:thma@apache.org">Thomas Mahler<a>
 * @author <a href="mailto:armin@codeAuLait.de">Armin Waibel</a>
 * @version $Id: PersistentFieldDirectAccessImpl.java,v 1.13 2004/04/09 13:22:29 tomdz Exp $
 */
public class PersistentFieldDirectAccessImpl extends AbstractPersistentField
{
    private static final long serialVersionUID = -5458024240998909205L;

    public PersistentFieldDirectAccessImpl()
    {
    }

    public PersistentFieldDirectAccessImpl(Class type, String fieldname)
    {
        super(type, fieldname);
    }

    /**
     * Sets the field represented by this PersistentField object on the specified object argument to the specified new value.
     * The new value is automatically unwrapped if the underlying field has a primitive type.
     * This implementation invokes set() on its underlying Field object if the argument <b>is not null</b>.
     * OBS IllegalArgumentExceptions are wrapped as PersistenceBrokerExceptions.
     *
     * @throws MetadataException if there is an error setting this field value on obj
     * @see java.lang.reflect.Field
     */
    public void doSet(Object obj, Object value) throws MetadataException
    {
        Field fld = getField();
        Class type = fld.getType();
        try
        {
            /**
             * MBAIRD
             * we need to be able to set values to null. We can only set something to null if
             * the type is not a primitive (assignable from Object).
             */
            // thanks to Tomasz Wysocki for this trick
            if ((value != null) || !type.isPrimitive())
            {
                fld.set(ProxyHelper.getRealObject(obj), value);
            }
        }
        catch (NullPointerException ignored)
        {
            getLog().info("Value for field " + (fld != null ? fld.getName() : null) +
                    " of type " + type.getName() + " is null. Can't write into null.", ignored);
        }
        catch (IllegalAccessException e)
        {
            getLog().error("while set field: " + buildMessageString(obj, value, fld));
            throw new MetadataException("IllegalAccess error setting field:" +
                    (fld != null ? fld.getName() : null) + " in object:" + obj.getClass().getName(), e);
        }
        catch (Exception e)
        {
            getLog().error("while set field: " + buildMessageString(obj, value, fld), e);
            throw new MetadataException("Error setting field:" + (fld != null ? fld.getName() : null) +
                    " in object:" + obj.getClass().getName(), e);
        }
    }

    /**
     * Returns the value of the field represented by this PersistentField, on the specified object.
     * This implementation invokes get() on its underlying Field object.
     *
     * @param obj - the object instance which we are trying to get the field value from
     * @throws MetadataException if there is an error getting this field value from obj
     * @see java.lang.reflect.Field
     */
    public Object doGet(Object obj) throws MetadataException
    {
        if(obj == null) return null;
        Field fld = getField();
        try
        {
            Object result = fld.get(ProxyHelper.getRealObject(obj));
            return result;
        }
        catch (IllegalAccessException e)
        {
            throw new MetadataException(
                    "IllegalAccess error getting field:" +
                    (fld != null ? fld.getName() : null) + " in object:"
                    + obj != null ? obj.getClass().getName() : null, e);
        }
        catch (Throwable e)
        {
            throw new MetadataException("Error getting field:" +
                    (fld != null ? fld.getName() : null) + " in object:" +
                    (obj != null ? obj.getClass().getName() : null) , e);
        }
    }

    /**
     * This implementation returns always 'false'.
     * @see AbstractPersistentField#makeAccessible()
     */
    public boolean makeAccessible()
    {
        return true;
    }

    /**
     * Always returns 'false'.
     * @see PersistentField#usesAccessorsAndMutators
     */
    public boolean usesAccessorsAndMutators()
    {
        return false;
    }
}
