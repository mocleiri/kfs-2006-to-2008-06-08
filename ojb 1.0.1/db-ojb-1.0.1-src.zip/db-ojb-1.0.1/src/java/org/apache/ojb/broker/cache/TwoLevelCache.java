package org.apache.ojb.broker.cache;


import org.apache.ojb.broker.Identity;
import org.apache.ojb.broker.PBStateEvent;
import org.apache.ojb.broker.PBStateListener;
import org.apache.ojb.broker.PersistenceBroker;
import org.apache.ojb.broker.PBKey;
import org.apache.ojb.broker.OJBRuntimeException;
import org.apache.ojb.broker.util.logging.Logger;
import org.apache.ojb.broker.util.logging.LoggerFactory;
import org.apache.ojb.broker.core.PersistenceBrokerImpl;
import org.apache.ojb.broker.core.proxy.VirtualProxy;
import org.apache.ojb.broker.metadata.ObjectReferenceDescriptor;
import org.apache.ojb.broker.metadata.ClassDescriptor;
import org.apache.ojb.broker.metadata.DescriptorRepository;
import org.apache.ojb.broker.metadata.CollectionDescriptor;
import org.apache.ojb.broker.metadata.fieldaccess.PersistentField;
import org.apache.ojb.broker.cache.ObjectCache;
import org.apache.ojb.broker.cache.ObjectCacheDefaultImpl;
import org.apache.commons.lang.builder.ToStringBuilder;
import org.apache.commons.lang.builder.ToStringStyle;

import java.lang.ref.SoftReference;
import java.lang.reflect.Method;
import java.lang.reflect.InvocationTargetException;
import java.util.HashMap;
import java.util.Map;
import java.util.Iterator;
import java.util.Properties;


/* Copyright 2003-2004 The Apache Software Foundation
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
public class TwoLevelCache implements ObjectCache, PBStateListener
{
  /**
   * the hashtable holding all cached objects
   */
  protected Map objectTable = null;
  private static ObjectCache secondLevelCache = new ObjectCacheDefaultImpl(null, null);
  private int secondLevelFoundCount;

  protected final Logger logger = LoggerFactory.getLogger(this.getClass());
  private DescriptorRepository descriptorRepository;
  private PBKey pbKey;
  private PersistenceBroker myBroker;
  private int hitCount = 0;
  private int failCount = 0;
  private int gcCount = 0;

  /**
   * OJB calls this constructor by reflection.
   * @param props ignored
   */
  public TwoLevelCache(PersistenceBroker broker, Properties props)
  {
    objectTable = new HashMap();
    descriptorRepository = broker.getDescriptorRepository();
    myBroker = broker;
    pbKey = broker.getPBKey();
    // add this cache as permanent listener
    broker.addListener(this, true);
    // todo: maybe make this configurable.
  }

  private PBKey getPbKey()
  {
    return pbKey;
  }

  /**
   * @return the content of the repository.xml or the like.
   */
  protected final DescriptorRepository getDescriptorRepository()
  {
    return descriptorRepository;
  }

  /**
   * Clear ObjectCache. I.e. remove all entries for classes and objects.
   * Do not clear the second-level cache
   */
  public void clear()
  {
    objectTable.clear();
  }

  /**
   * clear the second level cache, which is shared by all instances
   * in the same VM.
   */
  public static void clearSecondLevel()
  {
    secondLevelCache.clear();
  }

  /**
   * If this method is being called while retrieving the object from
   * database, then the references and collections of obj are filled.
   *
   * Problem: if this method is called during insert inside a transaction
   * that is later rolledback, then there are objects entered into the second-level
   * cache that should not be there.
   */
  public void cache(Identity oid, Object obj)
  {
    if (logger.isDebugEnabled()) logger.debug("Caching object with identity " + oid);
    if ((obj != null))
    {
      SoftReference ref = new SoftReference(obj);
      objectTable.put(oid, ref);
    }
  }

  /**
   * Insert a( clone of a)n Object into the 2nd level cache.
   * @param oid the object's indetity
   * @param obj the object itsself
   */
  private void insertInto2ndLevel(Identity oid, Object obj)
  {
    // if we insert a clone rather than the object itsself into the second level cache,
    // this has the following consequence:
    // the collections and references are all null, not even proxies.
    // if we insert the object itsself, we have the following problem:
    // subsequent modfications to the object affect the cached version, too,
    // which might be unintended.
    try
    {
      Object clone = clone(obj);
      if (logger.isDebugEnabled())
        logger.debug("inserting clone into 2. level cache " + oid);
      unsetReferences(clone, obj);
      secondLevelCache.cache(oid, clone);
      if (logger.isDebugEnabled())
        logger.debug("cache insert: "  + myBroker + ": " + oid);
    }
    catch (CloneNotSupportedException exc)
    {
      logger.error("second level caching failed: " + exc);
    }
  }

  /**
   * Retrieve an object from the second level cache.
   * @param oid
   * @return a clone of the clone present in the cache, or null.
   */
  private Object lookupFrom2ndLevel(Identity oid)
  {
    Object cacheObj = secondLevelCache.lookup(oid);
    if (cacheObj != null)
    {
      // the object has been found in the cache.  All references and collections
      // should be null.  We have to the reference and collection fields
      try
      {
        Object obj = clone(cacheObj);
        initReferences(obj);
        initLookedUpCollections(obj, cacheObj);
        // We have to clone the object to preserve txn isolation.
        // Problem: the references and collections are identical in obj2 and its clone.
        // this spoils transaction isolation when these references are traversed.
        // todo: replace references and collections by suitable proxies or by clones.
        if (logger.isDebugEnabled()) logger.debug("+++ retrieved object from second level cache.");
        objectTable.put(oid, new SoftReference(obj)); // insert into this broker's cache.
        secondLevelFoundCount++;
        return obj;
      }
      catch (CloneNotSupportedException exc)
      {
        logger.error("Cannot clone object from 2nd level cache: " + cacheObj);
      }
    }
    else
    {
        failCount++;
    }
    return null;
  }

  /**
   * code similar to PersistenceBrokerImpl
   */
  private Object getReferenceProxy(ClassDescriptor cld, ObjectReferenceDescriptor rds, Object obj)
  {
    Object[] pkVals = rds.getForeignKeyValues(obj, cld);
    boolean allPkNull = true;

    for (int j = 0; j < pkVals.length; j++)
    {
      if (pkVals[j] != null)
      {
        allPkNull = false;
        break;
      }
    }
    if (allPkNull)
      return null;
    Class referencedProxy = rds.getItemProxyClass();
    if (referencedProxy == null)
    {
      referencedProxy = descriptorRepository.getDescriptorFor(rds.getItemClass()).getDynamicProxyClass();
    }
    return getProxy(rds.getItemClass(), referencedProxy, pkVals);
  }

  protected final Object getProxy(Class referencedClass, Class referencedProxy, Object[] pkVals)
  {
    Class topLevelReferencedClass = descriptorRepository.getTopLevelClass(referencedClass);
    Object ret = VirtualProxy.createProxy(getPbKey(), referencedProxy,
            new Identity(null, topLevelReferencedClass, pkVals));
    return ret;
  }

  private Method getCloneMethod(Object in)
  {
    for (Class clazz = in.getClass(); ; )
    {
      try
      {
        return clazz.getDeclaredMethod("clone", null);
      }
      catch (NoSuchMethodException exc)
      {
        clazz = clazz.getSuperclass();
        if (clazz == null)
          throw new NoCloneMethod(in.getClass());
      }
    }
  }

  /**
   * this method is invoked when an object in inserted or retrieved from
   * the second level.
   *
   * Maybe overridden to do model-specific cloning or the like.
   *
   * @param in some object
   * @return clone of that object.
   * @throws CloneNotSupportedException
   */
  protected Object clone(Object in) throws CloneNotSupportedException
  {
    Method cloneMethod = getCloneMethod(in);
    try
    {
      return cloneMethod.invoke(in, null);
    }
    catch (IllegalAccessException exc)
    {
      throw new OJBRuntimeException(exc);
    }
    catch (InvocationTargetException exc)
    {
      throw new OJBRuntimeException(exc);
    }
  }

  /**
   * Initialize the non-embedded reference of obj (with suitable proxies.)
   * Make sure that all collection fields are proxies, otherwise queries are issued!!
   *
   * In the context where this method is called, obj had been clone after the basic type fields
   * have been read from the database and before the references and collections have been read.
   *
   * code similar to PersistenceBrokerImpl
   * This code could be moved into Object and could be replaced by code generation.
   */
  private void initReferences(Object obj)
  {
    if (logger.isDebugEnabled())
      logger.debug("initializing references");
    ClassDescriptor cld = descriptorRepository.getDescriptorFor(obj.getClass());
    for (Iterator i = cld.getObjectReferenceDescriptors().iterator(); i.hasNext(); )
    {
      ObjectReferenceDescriptor rds = (ObjectReferenceDescriptor) i.next();
      Object refObj = getReferenceProxy(cld, rds, obj);
      PersistentField refField = rds.getPersistentField();
      if (logger.isDebugEnabled())
        logger.debug("setting reference: " + refField.getName() + ", " + (refObj == null ? ("<null>") : refObj.getClass().getName()));
      refField.set(obj, refObj);
    }
  }

  /**
   * Initializes the the non-embedded collection fields after the object has been retrieved from the cache.
   * @param obj the freshly retrieved object
   * @param cacheObj its copy in the cache
   */
  protected void initLookedUpCollections(Object obj, Object cacheObj)
  {
    if (logger.isDebugEnabled())
      logger.debug("initializing collections");
    ClassDescriptor cld = descriptorRepository.getDescriptorFor(obj.getClass());
    // the next statements instantiates proxies only if the collection field is configured
    // accordingly.
    ((PersistenceBrokerImpl)myBroker).getReferenceBroker().retrieveCollections(obj, cld, false);
  }

  /**
   * Set all non-embedded references and collections to null.
   * @param cacheObj
   */
  private void unsetReferences(Object cacheObj, Object origObj)
  {
    if (logger.isDebugEnabled())
      logger.debug("unsetting references");
    ClassDescriptor cld = descriptorRepository.getDescriptorFor(cacheObj.getClass());
    for (Iterator i = cld.getObjectReferenceDescriptors().iterator(); i.hasNext(); )
    {
      ObjectReferenceDescriptor rds = (ObjectReferenceDescriptor) i.next();
      PersistentField refField = rds.getPersistentField();
      if (logger.isDebugEnabled())
        logger.debug("unsetting reference: " + refField.getName());
      refField.set(cacheObj, null);
    }

    for (Iterator i = cld.getCollectionDescriptors().iterator(); i.hasNext(); )
    {
      CollectionDescriptor colDesc = (CollectionDescriptor) i.next();
      if (logger.isDebugEnabled())
        logger.debug("unsetting collection: " + colDesc.getAttributeName());
      initCacheCollectionField(colDesc, cacheObj, origObj);
    }
  }

  /**
   * Sets the value of one collection field when an object is inserted into
   * the cache.
   *
   * @param colDesc
   * @param cacheObj the copy of the object in the cache
   * @param origObject the copy of the object in the scope of some PersistenceBroker
   */
  protected void initCacheCollectionField(CollectionDescriptor colDesc, Object cacheObj, Object origObject)
  {
    PersistentField refField = colDesc.getPersistentField();
    refField.set(cacheObj, null);
  }

  /**
   * Does an extra lookup in the secondLevelCache if the first lookup fails.
   * @see org.apache.ojb.broker.cache.ObjectCachePerBrokerImpl#lookup
   */
  public Object lookup(Identity oid)
  {
    if (logger.isDebugEnabled())
    {
      logger.debug("****** lookup " + myBroker + ": " + oid);
    }
    hitCount++;

    Object obj = null;
    SoftReference ref = (SoftReference) objectTable.get(oid);
    if (ref != null)
    {
      obj = ref.get();
      if (obj == null)
      {
        gcCount++;
        objectTable.remove(oid);    // Soft-referenced Object reclaimed by GC
      }
      else
      {
        if (logger.isDebugEnabled()) logger.debug("cache hit: "  + myBroker + ": " + oid);
      }
    }
    if (obj == null)
    {
      obj = lookupFrom2ndLevel(oid);
    }
    return obj;
  }

  public String toString()
  {
    ToStringBuilder buf = new ToStringBuilder(this, ToStringStyle.MULTI_LINE_STYLE);
    buf.append("CACHE STATISTICS");
    buf.append("Count of cached objects", objectTable.keySet().size());
    buf.append("lookups", hitCount);
    buf.append("failures", failCount);
    buf.append("reclaimed", gcCount);
    buf.append("2. level success", secondLevelFoundCount);
    buf.append(secondLevelCache.toString());
    return buf.toString();
  }

  /**
   * Removes an Object from the cache.
   */
  public void remove(Identity oid)
  {
    if (oid != null)
    {
      objectTable.remove(oid);
      secondLevelCache.remove(oid);
    }
  }

  /**
   * We clear the cache
   */
  public void beforeClose(PBStateEvent event)
  {
    clear();
  }

  public void afterOpen(PBStateEvent event)
  {
      //do nothing
  }

  public void beforeBegin(PBStateEvent event)
  {
      //do nothing
  }

  public void afterBegin(PBStateEvent event)
  {
      //do nothing
  }

  public void beforeCommit(PBStateEvent event)
  {
      //do nothing
  }

  public void afterCommit(PBStateEvent event)
  {
    for (Iterator iter = this.objectTable.keySet().iterator(); iter.hasNext(); )
    {
      Identity oid = (Identity) iter.next();
      SoftReference ref = (SoftReference) objectTable.get(oid);
      Object obj = ref.get();
      if (obj != null)
      {
        insertInto2ndLevel(oid, obj);
      }
    }
    // clear();  // todo: decide whether to clear. oma.
  }

  public void beforeRollback(PBStateEvent event)
  {
    clear();
  }

  public void afterRollback(PBStateEvent event)
  {
    // clear to be in sync with DB
    // todo: avoid to throw away the second level cache.
    clear();
  }

  static class NoCloneMethod extends OJBRuntimeException
  {
    NoCloneMethod(Class clazz)
    {
      super(clazz.toString() + " has no clone method.");
    }
  }
}
