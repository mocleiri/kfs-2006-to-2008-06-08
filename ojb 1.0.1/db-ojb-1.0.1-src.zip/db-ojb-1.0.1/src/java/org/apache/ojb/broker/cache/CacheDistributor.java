package org.apache.ojb.broker.cache;

/* Copyright 2003-2004 The Apache Software Foundation
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

import org.apache.commons.lang.builder.ToStringBuilder;
import org.apache.commons.lang.builder.ToStringStyle;
import org.apache.ojb.broker.Identity;
import org.apache.ojb.broker.PersistenceBroker;
import org.apache.ojb.broker.metadata.ObjectCacheDescriptor;
import org.apache.ojb.broker.util.configuration.impl.OjbConfigurator;
import org.apache.ojb.broker.util.logging.Logger;
import org.apache.ojb.broker.util.logging.LoggerFactory;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

/**
 * A intern used {@link AbstractMetaCache} implementation acting
 * as distributor of <code>ObjectCache</code> implementations declared
 * in configuration metadata.
 * <p>
 * Reads the name of the used ObjectCache implementation
 * <br/>
 * a) from class-descriptor, or if not found
 * <br/>
 * b) from jdbc-connection-descriptor, or if not found
 * <br/>
 * use a given standard ObjectCache implementation (given by
 * constructor argument).
 * </p>
 * <p>
 *
 * </p>
 *
 * @author  Matthew Baird  (mattbaird@yahoo.com)
 * @author <a href="mailto:armin@codeAuLait.de">Armin Waibel</a>
 * @version $Id: CacheDistributor.java,v 1.7 2004/04/04 23:53:33 brianm Exp $
 */
public class CacheDistributor extends AbstractMetaCache
{
    private static Logger logger = LoggerFactory.getLogger(CacheDistributor.class);
    private static final String DESCRIPTOR_BASED_CACHES = "descriptorBasedCaches";

    /**
     * map, represents used cache implementations
     */
    private Map caches = new HashMap();

    private ObjectCache defaultCache;
    private PersistenceBroker broker;
    /**
     * If <code>true</code> the class name of the object is used
     * to find a per class {@link ObjectCache} implementation.
     * If set <code>false</code> the {@link ObjectCacheDescriptor}
     * instance is used as key to find a per class ObjectCache.
     */
    private boolean descriptorBasedCaches;

    /**
     * public Default Constructor
     */
    public CacheDistributor(PersistenceBroker broker, ObjectCache defaultCache)
    {
        this.broker = broker;
        this.defaultCache = defaultCache;
        this.descriptorBasedCaches = OjbConfigurator.getInstance().getConfigurationFor(null)
                            .getBoolean(DESCRIPTOR_BASED_CACHES, false);
        logger.info("Use property 'descriptorBasedCaches' is set '"+descriptorBasedCaches+"'");
    }

    private ObjectCache prepareAndAddCache(PersistenceBroker aBroker,
                                                        ObjectCacheDescriptor ocd, Object key)
    {
        ObjectCache cache;
        // before the synchronize method lock this,
        // another thread maybe added same key
        if(caches.containsKey(key))
        {
            logger.info("Contains key '"+key+"', do not create new ObjectCache implementation");
            cache = (ObjectCache) caches.get(key);
        }
        else
        {
            logger.info("Create new ObjectCacheImplementation for '"+key+"'");
            cache = createObjectCache(aBroker, ocd);
            caches.put(key, cache);
        }
        return cache;
    }

    private ObjectCache createObjectCache(PersistenceBroker aBroker, ObjectCacheDescriptor ocd)
    {
        ObjectCache cache = null;
        try
        {
            cache = ObjectCacheFactory.getInstance()
                    .createNewCacheInstance(ocd.getObjectCache(), aBroker, ocd.getConfigurationProperties());
        }
        catch (Exception e)
        {
            logger.error("Can not create ObjectCache instance using " + ocd.getObjectCache() +
                    ", use default cache instead", e);
        }
        return cache;
    }


    public void clear()
    {
        /**
         * first be nice to the GC and clear each internal cache.
         */
        defaultCache.clear();

        synchronized (caches)
        {
            Iterator it = caches.values().iterator();
            ObjectCache oc = null;
            while (it.hasNext())
            {
                oc = (ObjectCache) it.next();
                oc.clear();
            }
            /**
             * then call clear on the caches hashmap.
             */
            caches.clear();
        }
    }

    public ObjectCache getCache(Identity oid, Object obj, int callingMethod)
    {
        /*
        the priorities to find an ObjectCache for a specific object are:
        1. try to find a cache defined per class
        2. try to find a cache defined per jdbc-connection-descriptor
        3. use the default cache implementation
        */
        boolean connectionLevel = false;
        ObjectCache retval = null;
        /*
        first search in class-descriptor, then in jdbc-connection-descriptor
        for ObjectCacheDescriptor.
        */
        ObjectCacheDescriptor ocd = searchInClassDescriptor(oid);
        if(ocd == null)
        {
            ocd = searchInJdbcConnectionDescriptor();
            connectionLevel = true;
        }
        /*
        If no ObjectCacheDescriptor was found means there is no specific ObjectCache
        defined, thus we use the default ObjectCache
        */
        if (ocd == null)
        {
            retval = defaultCache;
        }
        else
        {
            // use a class-descriptor level cache
            if (!connectionLevel)
            {
                if (!descriptorBasedCaches)
                {
                    synchronized (caches)
                    {
                        retval = lookupCache(oid.getObjectsRealClass());

                        if (retval == null && oid.getObjectsRealClass() != null
                                            && callingMethod == AbstractMetaCache.METHOD_CACHE)
                        {
                            retval = prepareAndAddCache(broker, ocd, oid.getObjectsRealClass());
                        }
                    }
                }
                else
                {
                    synchronized (caches)
                    {
                        retval = lookupCache(ocd);

                        if (retval == null && callingMethod == AbstractMetaCache.METHOD_CACHE)
                        {
                            retval = prepareAndAddCache(broker, ocd, ocd);
                        }
                    }
                }
            }
            // use a jdbc-connection-descriptor level cache
            else
            {
                String jcdAlias = broker.serviceConnectionManager().getConnectionDescriptor().getJcdAlias();
                synchronized (caches)
                {
                    retval = lookupCache(jcdAlias);

                    if (retval == null && callingMethod == AbstractMetaCache.METHOD_CACHE)
                    {
                        retval = prepareAndAddCache(broker, ocd, jcdAlias);
                    }
                }
            }
        }
        return retval;
    }

    private ObjectCache lookupCache(Object key)
    {
        return (ObjectCache) caches.get(key);
    }

    /**
     * Try to lookup {@link ObjectCacheDescriptor} in
     * {@link org.apache.ojb.broker.metadata.ClassDescriptor}.
     *
     * @param oid
     * @return Returns the found {@link ObjectCacheDescriptor} or <code>null</code>
     * if none was found.
     */
    protected ObjectCacheDescriptor searchInClassDescriptor(Identity oid)
    {
        return oid.getObjectsRealClass() != null
                ? broker.getClassDescriptor(oid.getObjectsRealClass()).getObjectCacheDescriptor()
                : null;
    }

    /**
     * Lookup {@link ObjectCacheDescriptor} in
     * {@link org.apache.ojb.broker.metadata.JdbcConnectionDescriptor}.
     *
     * @return Returns the found {@link ObjectCacheDescriptor} or <code>null</code>
     * if none was found.
     */
    protected ObjectCacheDescriptor searchInJdbcConnectionDescriptor()
    {
        return broker.serviceConnectionManager().getConnectionDescriptor().getObjectCacheDescriptor();
    }

    public String toString()
    {
        ToStringBuilder buf = new ToStringBuilder(this, ToStringStyle.DEFAULT_STYLE);
        return buf.append("Associated PB", broker)
                .append("Used default cache", defaultCache)
                .append("Mapped caches", caches).toString();
    }
}
