package org.apache.ojb.broker.metadata;

/* Copyright 2002-2004 The Apache Software Foundation
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

/**
 * This Interface defines Isolation level constants.
 * It contains numeric constants and literal constants
 * representing all known isolation levels.
 * @author Thomas Mahler
 */
public interface IsolationLevels
{
    /** 
     * numeric constant representing the uncommited read isolation level.
     */
    public final static int IL_READ_UNCOMMITTED = 0;
    
    /** 
     * numeric constant representing the commited read isolation level.
     */
    public final static int IL_READ_COMMITTED   = 1;
    
    /** 
     * numeric constant representing the repeatable read isolation level.
     */
    public final static int IL_REPEATABLE_READ  = 2;
    
    /** 
     * numeric constant representing the serializable transactions isolation level.
     */
    public final static int IL_SERIALIZABLE     = 3;
    
    /** 
     * numeric constant representing the optimistic locking isolation level.
     */
    public final static int IL_OPTIMISTIC       = 4;
    
    
    /** 
     * numeric constant representing the default (i.e. uncommited read) isolation level.
     */
    public final static int IL_DEFAULT = IL_READ_UNCOMMITTED;
    
    
    /** 
     * literal constant representing the uncommited read isolation level.
     */
    public final static String LITERAL_IL_READ_UNCOMMITTED = "read-uncommitted";
    
    /** 
     * literal constant representing the commited read isolation level.
     */
    public final static String LITERAL_IL_READ_COMMITTED   = "read-committed";
    
    /** 
     * literal constant representing the repeatable read isolation level.
     */
    public final static String LITERAL_IL_REPEATABLE_READ  = "repeatable-read";
    
    /** 
     * literal constant representing the serializable transactions isolation level.
     */
    public final static String LITERAL_IL_SERIALIZABLE     = "serializable";
    
    /** 
     * literal constant representing the optimistic locking isolation level.
     */
    public final static String LITERAL_IL_OPTIMISTIC       = "optimistic";
    
    
    
}
