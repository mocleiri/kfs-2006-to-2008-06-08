package org.apache.ojb.broker.accesslayer.sql;

/* Copyright 2002-2004 The Apache Software Foundation
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

import java.util.ArrayList;
import java.util.List;

import org.apache.ojb.broker.metadata.ClassDescriptor;
import org.apache.ojb.broker.metadata.FieldDescriptor;
import org.apache.ojb.broker.util.logging.Logger;

/**
 * Model a SELECT Statement by Primary Key
 * 
 * @author <a href="mailto:jbraeuchi@hotmail.com">Jakob Braeuchi</a>
 * @version $Id: SqlSelectByPkStatement.java,v 1.8 2004/04/04 23:53:32 brianm Exp $
 */

public class SqlSelectByPkStatement extends SqlPkStatement
{

	/**
	 * Constructor for SqlSelectByPkStatement.
	 * @param cld
	 * @param logger
	 */
	public SqlSelectByPkStatement(ClassDescriptor cld, Logger logger)
	{
		super(cld, logger);
	}

    /**
     * Appends to the statement a comma separated list of column names.
     *
     * MBAIRD: if the object being queried on has multiple classes mapped to the table,
     * then we will get all the fields that are a unique set across all those classes so if we need to
     * we can materialize an extent
     *
     * DO NOT use this if order of columns is important. The row readers build reflectively and look up
     * column names to find values, so this is safe. In the case of update, you CANNOT use this as the
     * order of columns is important.
     *
     * @return list of column names for the set of all unique columns for multiple classes mapped to the
     * same table.
     */
	protected List appendListOfColumnsForSelect(ClassDescriptor cld, StringBuffer buf)
    {
        FieldDescriptor[] fieldDescriptors = cld.getRepository().getFieldDescriptorsForMultiMappedTable(cld);
        ArrayList columnList = new ArrayList();

        if (fieldDescriptors != null)
        {
            int i = 0;
            int fieldDescriptorLength = fieldDescriptors.length;
            FieldDescriptor field = null;
            
            for (int j = 0; j < fieldDescriptorLength; j++)
            {
                field = fieldDescriptors[j];
                if (i > 0)
                {
                    buf.append(",");
                }
                buf.append(field.getColumnName());
                columnList.add(field.getAttributeName());
                i++;
            }
        }
        return columnList;
    }

	/**
     * Answer the SELECT by primary key Sql for the Statement
     */
    public String getStatement()
    {
        StringBuffer stmt = new StringBuffer(1024);
        ClassDescriptor cld = getClassDescriptor();
 		
        stmt.append("SELECT ");
 		appendListOfColumnsForSelect(cld, stmt);
        stmt.append(" FROM ");
        appendTable(cld, stmt);
        appendWhereClause(cld, false, stmt);
        
        return stmt.toString();
    }

}
