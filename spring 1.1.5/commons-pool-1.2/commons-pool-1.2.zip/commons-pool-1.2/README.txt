See http://jakarta.apache.org/commons/pool/ for additional and 
up-to-date information on Commons Pool.
