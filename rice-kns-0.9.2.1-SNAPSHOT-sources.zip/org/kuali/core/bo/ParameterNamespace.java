package org.kuali.core.bo;

public class ParameterNamespace extends KualiCodeBase {
	
	public String getParameterNamespaceCode() {
		return code;
	}
	
	public void setParameterNamespaceCode(String parameterNamespaceCode) {
		code = parameterNamespaceCode;
	}
	
	public String getParameterNamespaceName() {
		return name;
	}
	
	public void setParameterNamespaceName(String parameterNamespaceName) {
		name = parameterNamespaceName;
	}

}
